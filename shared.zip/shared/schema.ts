import { pgTable, text, serial, integer, boolean, decimal, timestamp, varchar, json, unique } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const agents = pgTable("agents", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  name: text("name"),
  location: text("location"),
  bio: text("bio").default(""),
  profileImage: text("profile_image").default("https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face"),
  company: text("company"),
  nextHoliday: text("next_holiday").default(""),
  rating: decimal("rating", { precision: 2, scale: 1 }).notNull().default("0.0"),
  reviewCount: integer("review_count").notNull().default(0),
  profileViews: integer("profile_views").notNull().default(0),
  yearsExperience: integer("years_experience").default(0),
  specializations: text("specializations").array().default([]),
  destinations: text("destinations").array().default([]),
  languages: text("languages").array().default([]),
  photos: text("photos").array().default([]),
  videoUrl: text("video_url"),
  isTopRated: boolean("is_top_rated").notNull().default(false),
  isVerified: boolean("is_verified").notNull().default(false),
  isEmailVerified: boolean("is_email_verified").notNull().default(false),
  emailVerificationToken: text("email_verification_token"),
  profileCompleted: boolean("profile_completed").notNull().default(false),
  approvalStatus: text("approval_status").notNull().default("pending"), // "pending", "approved", "rejected"
  approvedAt: timestamp("approved_at"),
  approvedBy: text("approved_by"),
  hasFinancialProtection: boolean("has_financial_protection").default(true),
  protectionBodies: text("protection_bodies").array().default([]), // ATOL, ABTA, ABTOT, TTA
  licenseNumbers: json("license_numbers").default({}), // {ATOL: "12345", ABTA: "67890"}
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const destinations = pgTable("destinations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  image: text("image").notNull(),
  agentCount: integer("agent_count").notNull().default(0),
  continent: text("continent").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const holidayTypes = pgTable("holiday_types", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  slug: text("slug").notNull().unique(),
  icon: text("icon").notNull(),
  image: text("image").notNull(),
  description: text("description").notNull(),
  tagline: text("tagline").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const offers = pgTable("offers", {
  id: serial("id").primaryKey(),
  agentId: integer("agent_id").references(() => agents.id).notNull(),
  title: text("title").notNull(),
  description: text("description").notNull(),
  briefDescription: text("brief_description").notNull(),
  heroImage: text("hero_image"),
  images: text("images").array().default([]),
  fromPrice: text("from_price").notNull(),
  destinations: text("destinations").array().notNull().default([]),
  holidayTypes: text("holiday_types").array().notNull().default([]),
  offerMessage1: text("offer_message_1"),
  offerMessage2: text("offer_message_2"), 
  offerMessage3: text("offer_message_3"),
  bookFromDate: timestamp("book_from_date"),
  bookToDate: timestamp("book_to_date"),
  travelFromDate: timestamp("travel_from_date"),
  travelToDate: timestamp("travel_to_date"),
  status: text("status").notNull().default("draft"), // draft, published
  validUntil: timestamp("valid_until"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const enquiries = pgTable("enquiries", {
  id: serial("id").primaryKey(),
  agentId: integer("agent_id").references(() => agents.id).notNull(),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull(),
  phoneNumber: text("phone_number").notNull(),
  numberOfAdults: integer("number_of_adults").notNull(),
  numberOfChildren: integer("number_of_children").notNull().default(0),
  childrenAges: json("children_ages").$type<number[]>().default([]),
  budgetPerPerson: text("budget_per_person").notNull(),
  destinations: json("destinations").$type<string[]>().default([]),
  holidayTypes: json("holiday_types").$type<string[]>().default([]),
  preferredCallbackTime: text("preferred_callback_time"),
  preferredCallbackDate: text("preferred_callback_date"),
  travelMonths: json("travel_months").$type<string[]>().default([]),
  travelYear: text("travel_year").notNull(),
  enquiryDetails: text("enquiry_details").notNull(),
  status: text("status").notNull().default("pending"),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  agentId: integer("agent_id").references(() => agents.id).notNull(),
  enquiryId: integer("enquiry_id").references(() => enquiries.id),
  customerName: text("customer_name").notNull(),
  customerEmail: text("customer_email").notNull(),
  customerImage: text("customer_image"),
  rating: integer("rating").notNull(),
  reviewText: text("review_text").notNull(),
  isVerified: boolean("is_verified").notNull().default(false),
  reviewEmailSent: boolean("review_email_sent").notNull().default(false),
  reviewEmailSentAt: timestamp("review_email_sent_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Table to track when to send review emails
export const reviewReminders = pgTable("review_reminders", {
  id: serial("id").primaryKey(),
  enquiryId: integer("enquiry_id").references(() => enquiries.id).notNull(),
  agentId: integer("agent_id").references(() => agents.id).notNull(),
  customerEmail: text("customer_email").notNull(),
  customerName: text("customer_name").notNull(),
  scheduledDate: timestamp("scheduled_date").notNull(), // 7 days after enquiry
  emailSent: boolean("email_sent").notNull().default(false),
  emailSentAt: timestamp("email_sent_at"),
  reviewSubmitted: boolean("review_submitted").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const blogPosts = pgTable("blog_posts", {
  id: serial("id").primaryKey(),
  agentId: integer("agent_id").references(() => agents.id).notNull(),
  title: text("title").notNull(),
  slug: text("slug").notNull().unique(),
  excerpt: text("excerpt").notNull(),
  content: text("content").notNull(),
  heroImage: text("hero_image"),
  images: json("images").$type<string[]>().default([]),
  holidayTypes: json("holiday_types").$type<string[]>().default([]),
  destinations: json("destinations").$type<string[]>().default([]),
  status: text("status").notNull().default("draft"),
  publishedAt: timestamp("published_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

export const newsletters = pgTable("newsletters", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  firstName: text("first_name"),
  lastName: text("last_name"),
  phoneNumber: text("phone_number"),
  budgetRange: text("budget_range"),
  destinations: json("destinations").$type<string[]>().default([]),
  holidayTypes: json("holiday_types").$type<string[]>().default([]),
  travelTiming: text("travel_timing"), // e.g., "Next 6 months", "6-12 months", "Next year"
  familyStatus: text("family_status"), // e.g., "Couple", "Family with children", "Solo traveller"
  isSubscribed: boolean("is_subscribed").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Blog Post Reactions
export const blogReactions = pgTable("blog_reactions", {
  id: serial("id").primaryKey(),
  blogPostId: integer("blog_post_id").notNull().references(() => blogPosts.id, { onDelete: "cascade" }),
  userId: text("user_id"), // Can use IP or session ID for anonymous users
  emoji: text("emoji").notNull(), // Store emoji character
  createdAt: timestamp("created_at").defaultNow().notNull(),
}, (table) => ({
  // Ensure one reaction per user per blog post per emoji type
  uniqueReaction: unique("unique_user_blog_emoji").on(table.blogPostId, table.userId, table.emoji),
}));

// Profile Visits Tracking
export const profileVisits = pgTable("profile_visits", {
  id: serial("id").primaryKey(),
  agentId: integer("agent_id").notNull().references(() => agents.id, { onDelete: "cascade" }),
  visitorId: text("visitor_id").notNull(), // IP hash or session ID for unique visitor tracking
  userAgent: text("user_agent"), // Browser info for additional uniqueness
  visitedAt: timestamp("visited_at").defaultNow().notNull(),
}, (table) => ({
  // Ensure one visit per unique visitor per agent per day
  uniqueVisit: unique("unique_visitor_agent_date").on(table.agentId, table.visitorId),
}));

// Email Templates Management
export const emailTemplates = pgTable("email_templates", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  type: text("type").notNull(), // 'enquiry_confirmation', 'review_request', 'welcome', 'agent_notification'
  subject: text("subject").notNull(),
  htmlContent: text("html_content").notNull(),
  textContent: text("text_content").notNull(),
  variables: text("variables").array().notNull().default([]),
  description: text("description").notNull(),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Health Check Logs for System Monitoring
export const healthCheckLogs = pgTable("health_check_logs", {
  id: serial("id").primaryKey(),
  checkTime: timestamp("check_time").defaultNow().notNull(),
  databaseStatus: text("database_status").notNull(), // 'connected', 'error', 'warning'
  databaseMessage: text("database_message").notNull(),
  mailchimpStatus: text("mailchimp_status").notNull(), // 'active', 'error', 'warning'  
  mailchimpMessage: text("mailchimp_message").notNull(),
  emailTemplatesStatus: text("email_templates_status").notNull(), // 'operational', 'error', 'warning'
  emailTemplatesMessage: text("email_templates_message").notNull(),
  autoFixApplied: boolean("auto_fix_applied").notNull().default(false),
  autoFixDescription: text("auto_fix_description"),
  overallStatus: text("overall_status").notNull(), // 'healthy', 'warning', 'error'
});

// Persistent Automation Task Scheduling for Tag Cleanup and Review Requests
export const automationSchedules = pgTable("automation_schedules", {
  id: serial("id").primaryKey(),
  email: text("email").notNull(),
  tagName: text("tag_name").notNull(), // 'enquiry-submitted' or 'review-request-due'
  actionType: text("action_type").notNull(), // 'remove' or 'add'
  scheduledFor: timestamp("scheduled_for").notNull(),
  completed: boolean("completed").notNull().default(false),
  enquiryId: integer("enquiry_id"),
  customerData: json("customer_data"), // Store customer data for review requests
  createdAt: timestamp("created_at").defaultNow().notNull(),
});



// Insert schemas
export const insertAgentSchema = createInsertSchema(agents).omit({
  id: true,
  createdAt: true,
  rating: true,
  reviewCount: true,
  isTopRated: true,
  isVerified: true,
});

// Initial signup schema - just email and password
export const agentSignupSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

// Profile completion schema - full profile details
export const agentProfileCompletionSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  location: z.string().min(1, "Location is required"),
  company: z.string().min(1, "Business name is required"),
  nextHoliday: z.string().optional(),
  specializations: z.array(z.string()).max(5, "Maximum 5 holiday types allowed"),
  destinations: z.array(z.string()).max(5, "Maximum 5 destinations allowed"),
  languages: z.array(z.string()).min(1, "At least one language is required"),
  bio: z.string().min(50, "Bio must be at least 50 characters").max(2000, "Bio must not exceed 2000 characters"),
  yearsExperience: z.number().min(0, "Years of experience must be positive"),
  hasFinancialProtection: z.boolean().refine(val => val === true, "Financial protection is required"),
  protectionBodies: z.array(z.enum(["ATOL", "ABTA", "ABTOT", "TTA"])).min(1, "At least one protection body is required"),
  licenseNumbers: z.record(z.string(), z.string().min(1, "License number is required")),
});

// Legacy registration schema for backward compatibility
export const agentRegistrationSchema = agentProfileCompletionSchema.extend({
  email: z.string().email("Invalid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

export const agentLoginSchema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(1, "Password is required"),
});

export const insertDestinationSchema = createInsertSchema(destinations).omit({
  id: true,
  createdAt: true,
  agentCount: true,
  slug: true,
});

export const insertHolidayTypeSchema = createInsertSchema(holidayTypes).omit({
  id: true,
  createdAt: true,
  slug: true,
});

export const insertOfferSchema = createInsertSchema(offers, {
  title: z.string().min(1, "Title is required").max(255, "Title too long"),
  description: z.string().min(1, "Description is required"),
  briefDescription: z.string().min(1, "Brief description is required").max(200, "Brief description too long"),
  fromPrice: z.string().min(1, "Price is required"),
  destinations: z.array(z.string()).min(1, "At least one destination is required"),
  holidayTypes: z.array(z.string()).min(1, "At least one holiday type is required"),
  offerMessage1: z.string().optional(),
  offerMessage2: z.string().optional(),
  offerMessage3: z.string().optional(),
  bookFromDate: z.union([z.string(), z.date()]).optional().nullable(),
  bookToDate: z.union([z.string(), z.date()]).optional().nullable(),
  travelFromDate: z.union([z.string(), z.date()]).optional().nullable(),
  travelToDate: z.union([z.string(), z.date()]).optional().nullable(),
  status: z.enum(["draft", "published"]),
}).omit({
  id: true,
  agentId: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEnquirySchema = createInsertSchema(enquiries).omit({
  id: true,
  createdAt: true,
  status: true,
  isRead: true
});

export const insertReviewSchema = createInsertSchema(reviews).omit({
  id: true,
  createdAt: true,
});

export const insertBlogPostSchema = createInsertSchema(blogPosts).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
  publishedAt: true,
});

export const insertBlogReactionSchema = createInsertSchema(blogReactions).omit({
  id: true,
  createdAt: true,
});

export const insertProfileVisitSchema = createInsertSchema(profileVisits).omit({
  id: true,
  visitedAt: true,
});

export const insertNewsletterSchema = createInsertSchema(newsletters).omit({
  id: true,
  createdAt: true,
  isSubscribed: true,
});

export const insertEmailTemplateSchema = createInsertSchema(emailTemplates).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertHealthCheckLogSchema = createInsertSchema(healthCheckLogs).omit({
  id: true,
  checkTime: true,
});

// Types
export type Agent = typeof agents.$inferSelect;
export type InsertAgent = z.infer<typeof insertAgentSchema>;
export type AgentSignup = z.infer<typeof agentSignupSchema>;
export type AgentProfileCompletion = z.infer<typeof agentProfileCompletionSchema>;
export type AgentRegistration = z.infer<typeof agentRegistrationSchema>;
export type AgentLogin = z.infer<typeof agentLoginSchema>;

export type Destination = typeof destinations.$inferSelect;
export type InsertDestination = z.infer<typeof insertDestinationSchema>;

export type HolidayType = typeof holidayTypes.$inferSelect;
export type InsertHolidayType = z.infer<typeof insertHolidayTypeSchema>;

export type Offer = typeof offers.$inferSelect;
export type InsertOffer = z.infer<typeof insertOfferSchema>;

export type Enquiry = typeof enquiries.$inferSelect;
export type InsertEnquiry = z.infer<typeof insertEnquirySchema>;

export type Review = typeof reviews.$inferSelect;
export type InsertReview = z.infer<typeof insertReviewSchema>;

export type ReviewReminder = typeof reviewReminders.$inferSelect;
export type InsertReviewReminder = typeof reviewReminders.$inferInsert;

export type EmailTemplate = typeof emailTemplates.$inferSelect;
export type InsertEmailTemplate = z.infer<typeof insertEmailTemplateSchema>;

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

export type BlogPost = typeof blogPosts.$inferSelect;
export type InsertBlogPost = z.infer<typeof insertBlogPostSchema>;
export type BlogReaction = typeof blogReactions.$inferSelect;
export type InsertBlogReaction = z.infer<typeof insertBlogReactionSchema>;

export type ProfileVisit = typeof profileVisits.$inferSelect;
export type InsertProfileVisit = z.infer<typeof insertProfileVisitSchema>;

export type Newsletter = typeof newsletters.$inferSelect;
export type InsertNewsletter = z.infer<typeof insertNewsletterSchema>;

export type HealthCheckLog = typeof healthCheckLogs.$inferSelect;
export type InsertHealthCheckLog = z.infer<typeof insertHealthCheckLogSchema>;





export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

// Languages list for agent registration
export const LANGUAGES = [
  "English",
  "Spanish", 
  "French",
  "German",
  "Italian",
  "Portuguese",
  "Dutch",
  "Russian",
  "Chinese (Mandarin)",
  "Japanese",
  "Korean",
  "Arabic",
  "Hindi",
  "Thai",
  "Vietnamese",
  "Turkish",
  "Greek",
  "Polish",
  "Swedish",
  "Norwegian",
  "Danish",
  "Finnish",
  "Czech",
  "Hungarian",
  "Romanian",
  "Bulgarian",
  "Croatian",
  "Serbian",
  "Ukrainian",
  "Hebrew"
] as const;
