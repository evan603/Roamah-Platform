import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Link } from 'wouter';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Search, Calendar, User, MapPin, Plane, ChevronLeft, ChevronRight } from 'lucide-react';
import { format } from 'date-fns';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';

const formatDate = (dateString: string) => {
  return format(new Date(dateString), 'MMM d, yyyy');
};

interface BlogPost {
  id: number;
  title: string;
  excerpt: string;
  slug: string;
  heroImage: string | null;
  publishedAt: string | null;
  createdAt: string;
  holidayTypes: string[] | null;
  destinations: string[] | null;
  agent: {
    id: number;
    name: string;
    profileImage: string | null;
  };
}

interface Agent {
  id: number;
  name: string;
}

interface Destination {
  id: number;
  name: string;
}

interface HolidayType {
  id: number;
  name: string;
}

export default function BlogsPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedAgent, setSelectedAgent] = useState<string>('all');
  const [selectedDestination, setSelectedDestination] = useState<string>('all');
  const [selectedHolidayType, setSelectedHolidayType] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('newest');
  const [currentPage, setCurrentPage] = useState(1);
  const blogsPerPage = 9;

  // Fetch all blog posts
  const { data: blogPosts, isLoading: blogLoading } = useQuery<BlogPost[]>({
    queryKey: ['/api/blog'],
  });

  // Fetch agents for filter dropdown
  const { data: agents } = useQuery<Agent[]>({
    queryKey: ['/api/agents'],
    select: (data: any[]) => data?.map(agent => ({
      id: agent.id,
      name: agent.name
    })) || []
  });

  // Fetch destinations for filter dropdown
  const { data: destinations } = useQuery<Destination[]>({
    queryKey: ['/api/destinations'],
  });

  // Fetch holiday types for filter dropdown
  const { data: holidayTypes } = useQuery<HolidayType[]>({
    queryKey: ['/api/holiday-types'],
  });

  // Get unique filter options from existing blogs only
  const availableAgents = blogPosts?.reduce((acc, post) => {
    if (!acc.find(agent => agent.id === post.agent.id)) {
      acc.push({ id: post.agent.id, name: post.agent.name || 'Travel Agent' });
    }
    return acc;
  }, [] as Agent[]) || [];

  const availableDestinations = blogPosts?.reduce((acc, post) => {
    if (post.destinations) {
      post.destinations.forEach(dest => {
        if (!acc.includes(dest)) {
          acc.push(dest);
        }
      });
    }
    return acc;
  }, [] as string[]) || [];

  const availableHolidayTypes = blogPosts?.reduce((acc, post) => {
    if (post.holidayTypes) {
      post.holidayTypes.forEach(type => {
        if (!acc.includes(type)) {
          acc.push(type);
        }
      });
    }
    return acc;
  }, [] as string[]) || [];

  // Filter and sort blog posts
  const filteredAndSortedPosts = blogPosts?.filter(post => {
    // Search filter
    if (searchTerm && !post.title.toLowerCase().includes(searchTerm.toLowerCase()) && 
        !post.excerpt.toLowerCase().includes(searchTerm.toLowerCase())) {
      return false;
    }

    // Agent filter
    if (selectedAgent !== 'all' && post.agent.id !== parseInt(selectedAgent)) {
      return false;
    }

    // Destination filter
    if (selectedDestination !== 'all' && 
        (!post.destinations || !post.destinations.includes(selectedDestination))) {
      return false;
    }

    // Holiday type filter
    if (selectedHolidayType !== 'all' && 
        (!post.holidayTypes || !post.holidayTypes.includes(selectedHolidayType))) {
      return false;
    }

    return true;
  })?.sort((a, b) => {
    const aDate = new Date(a.publishedAt || a.createdAt);
    const bDate = new Date(b.publishedAt || b.createdAt);
    
    switch (sortBy) {
      case 'newest':
        return bDate.getTime() - aDate.getTime();
      case 'oldest':
        return aDate.getTime() - bDate.getTime();
      case 'title':
        return a.title.localeCompare(b.title);
      default:
        return bDate.getTime() - aDate.getTime();
    }
  });

  // Pagination calculations
  const totalPosts = filteredAndSortedPosts?.length || 0;
  const totalPages = Math.ceil(totalPosts / blogsPerPage);
  const startIndex = (currentPage - 1) * blogsPerPage;
  const endIndex = startIndex + blogsPerPage;
  const currentPosts = filteredAndSortedPosts?.slice(startIndex, endIndex) || [];

  const clearFilters = () => {
    setSearchTerm('');
    setSelectedAgent('all');
    setSelectedDestination('all');
    setSelectedHolidayType('all');
    setSortBy('newest');
    setCurrentPage(1);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      {/* Hero Section */}
      <section className="bg-roamah-peach py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-6 text-roamah-dark">Travel Blog</h1>
          <p className="text-xl max-w-4xl mx-auto mb-4 text-roamah-gray">
            Discover inspiring travel stories and expert insights handwritten by our professional travel agents. 
            Every article is crafted by experienced specialists who share their authentic knowledge and personal experiences.
          </p>
          <div className="flex items-center justify-center space-x-6 text-sm text-roamah-gray">
            <div className="flex items-center">
              <div className="w-2 h-2 bg-roamah-orange rounded-full mr-2"></div>
              Expert Insights
            </div>
            <div className="flex items-center">
              <div className="w-2 h-2 bg-roamah-orange rounded-full mr-2"></div>
              Authentic Stories
            </div>
            <div className="flex items-center">
              <div className="w-2 h-2 bg-roamah-orange rounded-full mr-2"></div>
              Professional Advice
            </div>
          </div>
        </div>
      </section>

      {/* Stats and Filters Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="text-sm text-roamah-gray">
              Showing {startIndex + 1}-{Math.min(endIndex, totalPosts)} of {totalPosts} articles
              {totalPosts !== (blogPosts?.length || 0) && ` (filtered from ${blogPosts?.length || 0} total)`}
            </div>
            <div className="text-sm text-roamah-gray">
              Page {currentPage} of {totalPages || 1}
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Filters */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
              {/* Search */}
              <div className="lg:col-span-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search articles..."
                    value={searchTerm}
                    onChange={(e) => { setSearchTerm(e.target.value); setCurrentPage(1); }}
                    className="pl-10"
                  />
                </div>
              </div>

              {/* Agent Filter */}
              <Select value={selectedAgent} onValueChange={(value) => { setSelectedAgent(value); setCurrentPage(1); }}>
                <SelectTrigger>
                  <User className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="All agents" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All agents</SelectItem>
                  {availableAgents.sort((a, b) => a.name.localeCompare(b.name)).map(agent => (
                    <SelectItem key={agent.id} value={agent.id.toString()}>
                      {agent.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Destination Filter */}
              <Select value={selectedDestination} onValueChange={(value) => { setSelectedDestination(value); setCurrentPage(1); }}>
                <SelectTrigger>
                  <MapPin className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="All destinations" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All destinations</SelectItem>
                  {availableDestinations.sort().map(destination => (
                    <SelectItem key={destination} value={destination}>
                      {destination}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Holiday Type Filter */}
              <Select value={selectedHolidayType} onValueChange={(value) => { setSelectedHolidayType(value); setCurrentPage(1); }}>
                <SelectTrigger>
                  <Plane className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="All holiday types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All holiday types</SelectItem>
                  {availableHolidayTypes.sort().map(type => (
                    <SelectItem key={type} value={type}>
                      {type}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* Sort Filter */}
              <Select value={sortBy} onValueChange={setSortBy}>
                <SelectTrigger>
                  <Calendar className="w-4 h-4 mr-2" />
                  <SelectValue placeholder="Sort by" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="newest">Newest first</SelectItem>
                  <SelectItem value="oldest">Oldest first</SelectItem>
                  <SelectItem value="title">Title A-Z</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Clear Filters */}
            <div className="mt-4">
              <Button variant="outline" size="sm" onClick={clearFilters}>
                Clear all filters
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Blog Posts Grid */}
        {blogLoading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <Card key={i} className="animate-pulse">
                <div className="bg-gray-200 h-48 w-full"></div>
                <CardContent className="p-6">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-1/2 mb-4"></div>
                  <div className="h-3 bg-gray-200 rounded w-full mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-2/3"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : totalPosts === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <div className="text-gray-400 mb-4">
                <Search className="w-12 h-12 mx-auto" />
              </div>
              <h3 className="text-lg font-semibold text-roamah-dark mb-2">No articles found</h3>
              <p className="text-roamah-gray mb-4">
                Try adjusting your filters or search terms to find what you're looking for.
              </p>
              <Button onClick={clearFilters} variant="outline">
                Clear filters
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {currentPosts.map((post) => (
              <Card key={post.id} className="group hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col h-full">
                <Link href={`/blog/${post.slug}`}>
                  <div className="cursor-pointer flex-1 flex flex-col">
                    <div className="relative overflow-hidden">
                      <img
                        src={post.heroImage ?? 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=600&h=400&fit=crop'}
                        alt={post.title}
                        className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                    <CardContent className="p-6 flex-1 flex flex-col">
                      {/* Tags */}
                      <div className="flex flex-wrap gap-2 mb-3 min-h-[32px]">
                        {post.holidayTypes?.slice(0, 2).map((type) => (
                          <Badge key={type} variant="secondary" className="bg-green-100 text-green-800 text-xs h-5 font-normal">
                            {type}
                          </Badge>
                        ))}
                        {post.destinations?.slice(0, 1).map((dest) => (
                          <Badge key={dest} variant="secondary" className="bg-blue-100 text-blue-800 text-xs h-5 font-normal">
                            {dest}
                          </Badge>
                        ))}
                        {(!post.holidayTypes || post.holidayTypes.length === 0) && 
                         (!post.destinations || post.destinations.length === 0) && (
                          <Badge variant="secondary" className="bg-green-100 text-green-800 text-xs h-5 font-normal">
                            Travel Tips
                          </Badge>
                        )}
                      </div>

                      <h3 className="text-xl font-semibold text-roamah-dark mb-3 group-hover:text-roamah-orange transition-colors line-clamp-2 min-h-[56px]">
                        {post.title}
                      </h3>
                      <p className="text-roamah-gray mb-4 line-clamp-3 flex-1">{post.excerpt}</p>
                    </CardContent>
                  </div>
                </Link>
                
                {/* Author Info - Fixed at bottom */}
                <div className="px-6 pb-6 border-t bg-gray-50/50 mt-auto">
                  <Link href={`/agent/${post.agent.id}`}>
                    <div className="flex items-center pt-4 cursor-pointer hover:opacity-80 transition-opacity">
                      <img
                        src={post.agent.profileImage ?? 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face'}
                        alt={post.agent.name ?? 'Agent'}
                        className="w-10 h-10 rounded-full mr-3 aspect-square object-cover"
                      />
                      <div>
                        <p className="text-sm font-semibold text-roamah-dark hover:text-roamah-orange transition-colors">
                          {post.agent.name ?? 'Travel Agent'}
                        </p>
                        <p className="text-xs text-roamah-gray">
                          {post.publishedAt ? formatDate(post.publishedAt) : formatDate(post.createdAt)}
                        </p>
                      </div>
                    </div>
                  </Link>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Pagination Controls */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center space-x-2 mt-12">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.max(1, currentPage - 1))}
              disabled={currentPage === 1}
            >
              <ChevronLeft className="w-4 h-4 mr-1" />
              Previous
            </Button>
            
            <div className="flex space-x-1">
              {Array.from({ length: totalPages }, (_, i) => i + 1).map((page) => (
                <Button
                  key={page}
                  variant={currentPage === page ? "default" : "outline"}
                  size="sm"
                  onClick={() => setCurrentPage(page)}
                  className={currentPage === page ? "bg-roamah-orange hover:bg-roamah-orange/90" : ""}
                >
                  {page}
                </Button>
              ))}
            </div>
            
            <Button
              variant="outline"
              size="sm"
              onClick={() => setCurrentPage(Math.min(totalPages, currentPage + 1))}
              disabled={currentPage === totalPages}
            >
              Next
              <ChevronRight className="w-4 h-4 ml-1" />
            </Button>
          </div>
        )}
      </div>

      <Footer />
    </div>
  );
}