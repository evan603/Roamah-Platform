import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { Share2, FileText, Camera, BarChart3, Users, Mail, Download } from "lucide-react";

export default function MarketingTools() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="pt-20 pb-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Marketing Tools for Travel Experts</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Grow your travel business with our comprehensive suite of marketing resources and tools designed specifically for travel professionals.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
            {/* Social Media Assets */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex items-center mb-4">
                <Share2 className="h-8 w-8 text-roamah-orange mr-3" />
                <h3 className="text-xl font-semibold text-gray-900">Social Media Assets</h3>
              </div>
              <p className="text-gray-600 mb-4">
                Download branded templates, destination images, and social media graphics to enhance your online presence.
              </p>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Instagram story templates</li>
                <li>• Facebook post designs</li>
                <li>• LinkedIn banner graphics</li>
                <li>• Holiday-themed visuals</li>
              </ul>
            </div>

            {/* Content Templates */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex items-center mb-4">
                <FileText className="h-8 w-8 text-blue-600 mr-3" />
                <h3 className="text-xl font-semibold text-gray-900">Content Templates</h3>
              </div>
              <p className="text-gray-600 mb-4">
                Ready-to-use blog post templates, email newsletters, and marketing copy to engage your audience.
              </p>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Blog post templates</li>
                <li>• Email newsletter layouts</li>
                <li>• Client testimonial formats</li>
                <li>• Promotional copy examples</li>
              </ul>
            </div>

            {/* Photography Resources */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex items-center mb-4">
                <Camera className="h-8 w-8 text-green-600 mr-3" />
                <h3 className="text-xl font-semibold text-gray-900">Photography Resources</h3>
              </div>
              <p className="text-gray-600 mb-4">
                Access our library of high-quality destination photos and learn best practices for travel photography.
              </p>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Destination photo library</li>
                <li>• Photography guidelines</li>
                <li>• Image sizing recommendations</li>
                <li>• Brand-compliant visuals</li>
              </ul>
            </div>

            {/* Analytics Dashboard */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex items-center mb-4">
                <BarChart3 className="h-8 w-8 text-purple-600 mr-3" />
                <h3 className="text-xl font-semibold text-gray-900">Performance Analytics</h3>
              </div>
              <p className="text-gray-600 mb-4">
                Track your profile performance, enquiry rates, and customer engagement through your dashboard.
              </p>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Profile view statistics</li>
                <li>• Enquiry conversion rates</li>
                <li>• Customer engagement metrics</li>
                <li>• Monthly performance reports</li>
              </ul>
            </div>

            {/* Customer Insights */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex items-center mb-4">
                <Users className="h-8 w-8 text-indigo-600 mr-3" />
                <h3 className="text-xl font-semibold text-gray-900">Customer Insights</h3>
              </div>
              <p className="text-gray-600 mb-4">
                Understand your target audience better with demographic data and booking pattern analysis.
              </p>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Customer demographics</li>
                <li>• Popular destinations</li>
                <li>• Seasonal booking trends</li>
                <li>• Budget preferences</li>
              </ul>
            </div>

            {/* Email Marketing */}
            <div className="bg-white rounded-lg shadow-lg p-6">
              <div className="flex items-center mb-4">
                <Mail className="h-8 w-8 text-pink-600 mr-3" />
                <h3 className="text-xl font-semibold text-gray-900">Email Marketing</h3>
              </div>
              <p className="text-gray-600 mb-4">
                Leverage our integrated email system to nurture leads and maintain customer relationships.
              </p>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Automated follow-up sequences</li>
                <li>• Holiday promotion templates</li>
                <li>• Customer review requests</li>
                <li>• Newsletter integration</li>
              </ul>
            </div>
          </div>

          {/* Resource Downloads Section */}
          <div className="bg-white rounded-lg shadow-lg p-8">
            <div className="text-center mb-8">
              <Download className="h-12 w-12 text-roamah-orange mx-auto mb-4" />
              <h2 className="text-2xl font-bold text-gray-900 mb-2">Download Marketing Resources</h2>
              <p className="text-gray-600">
                Access our complete library of marketing materials to enhance your travel business
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="border rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-2">Brand Guidelines Pack</h3>
                <p className="text-gray-600 text-sm mb-4">
                  Complete brand guidelines including logos, colours, fonts, and usage examples.
                </p>
                <button className="w-full bg-roamah-orange text-white py-2 px-4 rounded-lg hover:bg-roamah-orange/90">
                  Download Brand Pack
                </button>
              </div>

              <div className="border rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-2">Social Media Templates</h3>
                <p className="text-gray-600 text-sm mb-4">
                  Ready-to-use templates for Instagram, Facebook, and LinkedIn posts.
                </p>
                <button className="w-full bg-blue-600 text-white py-2 px-4 rounded-lg hover:bg-blue-700">
                  Download Templates
                </button>
              </div>

              <div className="border rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-2">Content Calendar</h3>
                <p className="text-gray-600 text-sm mb-4">
                  Monthly content planning template with seasonal travel themes.
                </p>
                <button className="w-full bg-green-600 text-white py-2 px-4 rounded-lg hover:bg-green-700">
                  Download Calendar
                </button>
              </div>

              <div className="border rounded-lg p-6">
                <h3 className="font-semibold text-gray-900 mb-2">Marketing Checklist</h3>
                <p className="text-gray-600 text-sm mb-4">
                  Step-by-step checklist to optimise your travel expert profile.
                </p>
                <button className="w-full bg-purple-600 text-white py-2 px-4 rounded-lg hover:bg-purple-700">
                  Download Checklist
                </button>
              </div>
            </div>
          </div>

          {/* Support Section */}
          <div className="mt-12 text-center">
            <div className="bg-gray-100 rounded-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-4">Need Marketing Support?</h2>
              <p className="text-gray-600 mb-6">
                Our marketing team is here to help you succeed. Get in touch for personalised advice and support.
              </p>
              <a 
                href="/contact" 
                className="inline-block bg-roamah-orange text-white px-8 py-3 rounded-lg font-semibold hover:bg-roamah-orange/90 transition-colors"
              >
                Contact Marketing Team
              </a>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}