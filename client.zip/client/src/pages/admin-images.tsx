import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Upload, Eye, Edit, Image as ImageIcon, FileText, LogOut, Plus, Globe, MapPin, Camera } from "lucide-react";

interface Destination {
  id: number;
  name: string;
  slug: string;
  image: string;
  description: string;
  continent: string;
  agentCount: number;
}

interface HolidayType {
  id: number;
  name: string;
  slug: string;
  image: string;
  icon: string;
  description: string;
  tagline: string;
}

export default function AdminImages() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const [selectedDestination, setSelectedDestination] = useState<Destination | null>(null);
  const [selectedHolidayType, setSelectedHolidayType] = useState<HolidayType | null>(null);
  const [showDestinationUpload, setShowDestinationUpload] = useState(false);
  const [showHolidayTypeUpload, setShowHolidayTypeUpload] = useState(false);
  const [showCreateDestination, setShowCreateDestination] = useState(false);
  const [showCreateHolidayType, setShowCreateHolidayType] = useState(false);
  const [showEditDestination, setShowEditDestination] = useState(false);
  const [editingDestination, setEditingDestination] = useState<Destination | null>(null);
  const [showEditHolidayType, setShowEditHolidayType] = useState(false);
  const [editingHolidayType, setEditingHolidayType] = useState<HolidayType | null>(null);
  
  // Form states for creating new items
  const [newDestination, setNewDestination] = useState({
    name: '',
    description: '',
    continent: '',
    image: ''
  });
  
  const [newHolidayType, setNewHolidayType] = useState({
    name: '',
    description: '',
    tagline: '',
    icon: '',
    image: ''
  });
  
  // Upload states
  const [isUploadingDestImage, setIsUploadingDestImage] = useState(false);
  const [isUploadingHolidayImage, setIsUploadingHolidayImage] = useState(false);

  // Check admin authentication
  useEffect(() => {
    const adminToken = localStorage.getItem('adminToken');
    if (!adminToken) {
      setLocation('/admin/login');
      return;
    }
  }, [setLocation]);

  // Fetch destinations
  const { data: destinations, isLoading: destinationsLoading } = useQuery<Destination[]>({
    queryKey: ["/api/destinations"],
  });

  // Fetch holiday types
  const { data: holidayTypes, isLoading: holidayTypesLoading } = useQuery<HolidayType[]>({
    queryKey: ["/api/holiday-types"],
  });

  // Sort destinations and holiday types alphabetically
  const sortedDestinations = destinations?.sort((a, b) => a.name.localeCompare(b.name)) || [];
  const sortedHolidayTypes = holidayTypes?.sort((a, b) => a.name.localeCompare(b.name)) || [];

  // Update destination image mutation
  const updateDestinationImage = useMutation({
    mutationFn: async ({ id, imageUrl }: { id: number; imageUrl: string }) => {
      return apiRequest(`/api/admin/destinations/${id}/image`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem('adminToken')}`,
        },
        body: JSON.stringify({ image: imageUrl }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/destinations"] });
      toast({
        title: "Success",
        description: "Destination image updated successfully",
      });
      setSelectedDestination(null);
      setShowDestinationUpload(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update destination image",
        variant: "destructive",
      });
    },
  });

  // Update holiday type image mutation
  const updateHolidayTypeImage = useMutation({
    mutationFn: async ({ id, imageUrl }: { id: number; imageUrl: string }) => {
      return apiRequest(`/api/admin/holiday-types/${id}/image`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem('adminToken')}`,
        },
        body: JSON.stringify({ image: imageUrl }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/holiday-types"] });
      toast({
        title: "Success",
        description: "Holiday type image updated successfully",
      });
      setSelectedHolidayType(null);
      setShowHolidayTypeUpload(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update holiday type image",
        variant: "destructive",
      });
    },
  });

  // Create destination mutation
  const createDestination = useMutation({
    mutationFn: async (destinationData: typeof newDestination) => {
      return apiRequest("/api/admin/destinations", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem('adminToken')}`,
        },
        body: JSON.stringify(destinationData),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/destinations"] });
      toast({
        title: "Success",
        description: "Destination created successfully",
      });
      setShowCreateDestination(false);
      setNewDestination({ name: '', description: '', continent: '', image: '' });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create destination",
        variant: "destructive",
      });
    },
  });

  // Create holiday type mutation
  const createHolidayType = useMutation({
    mutationFn: async (holidayTypeData: typeof newHolidayType) => {
      return apiRequest("/api/admin/holiday-types", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem('adminToken')}`,
        },
        body: JSON.stringify(holidayTypeData),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/holiday-types"] });
      toast({
        title: "Success",
        description: "Holiday type created successfully",
      });
      setShowCreateHolidayType(false);
      setNewHolidayType({ name: '', description: '', tagline: '', icon: '', image: '' });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create holiday type",
        variant: "destructive",
      });
    },
  });

  // Edit destination mutation
  const editDestination = useMutation({
    mutationFn: async (data: { id: number; name: string; description: string; continent: string }) => {
      return apiRequest(`/api/admin/destinations/${data.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem('adminToken')}`,
        },
        body: JSON.stringify({
          name: data.name,
          description: data.description,
          continent: data.continent,
        }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/destinations"] });
      toast({
        title: "Success",
        description: "Destination updated successfully",
      });
      setShowEditDestination(false);
      setEditingDestination(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update destination",
        variant: "destructive",
      });
    },
  });

  // Edit holiday type mutation
  const editHolidayType = useMutation({
    mutationFn: async (data: { id: number; name: string; description: string; tagline: string; icon: string }) => {
      return apiRequest(`/api/admin/holiday-types/${data.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem('adminToken')}`,
        },
        body: JSON.stringify({
          name: data.name,
          description: data.description,
          tagline: data.tagline,
          icon: data.icon,
        }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/holiday-types"] });
      toast({
        title: "Success",
        description: "Holiday type updated successfully",
      });
      setShowEditHolidayType(false);
      setEditingHolidayType(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update holiday type",
        variant: "destructive",
      });
    },
  });

  const handleNewDestinationImageUpload = async (file: File) => {
    setIsUploadingDestImage(true);
    const formData = new FormData();
    formData.append('image', file);
    
    try {
      const response = await fetch('/api/upload/destination-image', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error('Upload failed');
      }
      
      const data = await response.json();
      setNewDestination(prev => ({ ...prev, image: data.imageUrl }));
      
      toast({
        title: "Success",
        description: "Image uploaded successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to upload image",
        variant: "destructive",
      });
    } finally {
      setIsUploadingDestImage(false);
    }
  };

  const handleNewHolidayTypeImageUpload = async (file: File) => {
    setIsUploadingHolidayImage(true);
    const formData = new FormData();
    formData.append('image', file);
    
    try {
      const response = await fetch('/api/upload/holiday-type-image', {
        method: 'POST',
        body: formData,
      });
      
      if (!response.ok) {
        throw new Error('Upload failed');
      }
      
      const data = await response.json();
      setNewHolidayType(prev => ({ ...prev, image: data.imageUrl }));
      
      toast({
        title: "Success",
        description: "Image uploaded successfully",
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to upload image",
        variant: "destructive",
      });
    } finally {
      setIsUploadingHolidayImage(false);
    }
  };

  const handleDestinationImageUpload = async (file: File) => {
    if (!selectedDestination) return;

    const formData = new FormData();
    formData.append('image', file);

    try {
      const response = await fetch('/api/admin/upload/destination-image', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`,
        },
        body: formData,
      });

      if (!response.ok) throw new Error('Upload failed');
      
      const { imageUrl } = await response.json();
      updateDestinationImage.mutate({ id: selectedDestination.id, imageUrl });
    } catch (error: any) {
      toast({
        title: "Upload Error",
        description: error.message || "Failed to upload image",
        variant: "destructive",
      });
    }
  };

  const handleHolidayTypeImageUpload = async (file: File) => {
    if (!selectedHolidayType) return;

    const formData = new FormData();
    formData.append('image', file);

    try {
      const response = await fetch('/api/admin/upload/holiday-type-image', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`,
        },
        body: formData,
      });

      if (!response.ok) throw new Error('Upload failed');
      
      const { imageUrl } = await response.json();
      updateHolidayTypeImage.mutate({ id: selectedHolidayType.id, imageUrl });
    } catch (error: any) {
      toast({
        title: "Upload Error",
        description: error.message || "Failed to upload image",
        variant: "destructive",
      });
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-roamah-cream to-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header with navigation */}
        <div className="mb-8">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-bold text-roamah-dark mb-2">
                Admin: Image Management
              </h1>
              <p className="text-roamah-gray">
                Manage images for destinations and holiday types used throughout the platform
              </p>
            </div>
            <div className="flex gap-3">
              <Button 
                variant="outline"
                onClick={() => setLocation('/admin/enquiries')}
                className="flex items-center space-x-2"
              >
                <FileText className="h-4 w-4" />
                <span>Enquiries</span>
              </Button>
              <Button 
                variant="outline"
                onClick={() => window.open('/', '_blank')}
                className="flex items-center space-x-2 text-roamah-orange border-roamah-orange hover:bg-roamah-orange hover:text-white"
              >
                <Eye className="h-4 w-4" />
                <span>View Site Live</span>
              </Button>
              <Button 
                variant="outline"
                onClick={() => {
                  localStorage.removeItem('adminToken');
                  setLocation('/admin/login');
                }}
                className="text-red-600 border-red-200 hover:bg-red-50"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>

        <Tabs defaultValue="destinations" className="space-y-6">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="destinations">Destinations</TabsTrigger>
            <TabsTrigger value="holiday-types">Holiday Types</TabsTrigger>
          </TabsList>

          <TabsContent value="destinations" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Destination Images</h2>
              <div className="flex items-center gap-3">
                <Button
                  onClick={() => setShowCreateDestination(true)}
                  className="bg-roamah-orange hover:bg-roamah-orange/90"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Destination
                </Button>
                <Badge variant="secondary">
                  {destinations?.length || 0} destinations
                </Badge>
              </div>
            </div>

            {destinationsLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <div className="h-48 bg-gray-200 rounded-t-lg"></div>
                    <CardContent className="p-4">
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sortedDestinations.map((destination) => (
                  <Card key={destination.id} className="overflow-hidden">
                    <div className="relative h-48">
                      <img
                        src={destination.image}
                        alt={destination.name}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center">
                        <div className="opacity-0 hover:opacity-100 transition-opacity duration-200 flex space-x-2">
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => window.open(destination.image, '_blank')}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => {
                              setSelectedDestination(destination);
                              setShowDestinationUpload(true);
                            }}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <CardTitle className="text-lg mb-2">{destination.name}</CardTitle>
                      <CardDescription className="text-sm text-gray-600 mb-3">
                        {destination.continent} • {destination.agentCount} experts
                      </CardDescription>
                      <div className="flex justify-between items-center">
                        <Badge variant="outline">{destination.slug}</Badge>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setEditingDestination(destination);
                              setShowEditDestination(true);
                            }}
                          >
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setSelectedDestination(destination);
                              setShowDestinationUpload(true);
                            }}
                          >
                            <Upload className="h-4 w-4 mr-2" />
                            Image
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="holiday-types" className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-semibold">Holiday Type Images</h2>
              <div className="flex items-center gap-3">
                <Button
                  onClick={() => setShowCreateHolidayType(true)}
                  className="bg-roamah-orange hover:bg-roamah-orange/90"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Add Holiday Type
                </Button>
                <Badge variant="secondary">
                  {holidayTypes?.length || 0} holiday types
                </Badge>
              </div>
            </div>

            {holidayTypesLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="animate-pulse">
                    <div className="h-48 bg-gray-200 rounded-t-lg"></div>
                    <CardContent className="p-4">
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-3 bg-gray-200 rounded w-3/4"></div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {sortedHolidayTypes.map((holidayType) => (
                  <Card key={holidayType.id} className="overflow-hidden">
                    <div className="relative h-48">
                      <img
                        src={holidayType.image}
                        alt={holidayType.name}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-black bg-opacity-0 hover:bg-opacity-30 transition-all duration-200 flex items-center justify-center">
                        <div className="opacity-0 hover:opacity-100 transition-opacity duration-200 flex space-x-2">
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => window.open(holidayType.image, '_blank')}
                          >
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            size="sm"
                            onClick={() => {
                              setSelectedHolidayType(holidayType);
                              setShowHolidayTypeUpload(true);
                            }}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <CardTitle className="text-lg mb-2">{holidayType.name}</CardTitle>
                      <CardDescription className="text-sm text-gray-600 mb-3">
                        {holidayType.tagline}
                      </CardDescription>
                      <div className="flex justify-between items-center">
                        <Badge variant="outline">{holidayType.slug}</Badge>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setEditingHolidayType(holidayType);
                              setShowEditHolidayType(true);
                            }}
                          >
                            <Edit className="h-4 w-4 mr-2" />
                            Edit
                          </Button>
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setSelectedHolidayType(holidayType);
                              setShowHolidayTypeUpload(true);
                            }}
                          >
                            <Upload className="h-4 w-4 mr-2" />
                            Image
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>

        {/* Destination Image Upload Modal */}
        {showDestinationUpload && selectedDestination && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg p-6 max-w-md w-full">
              <h3 className="text-lg font-semibold mb-4">
                Update Image for {selectedDestination.name}
              </h3>
              <p className="text-gray-600 mb-4">
                Upload a new image for this destination. The image will be used in destination cards and hero sections.
              </p>
              
              <div className="space-y-4">
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      handleDestinationImageUpload(file);
                    }
                  }}
                  className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-roamah-orange file:text-white hover:file:bg-roamah-orange/90"
                />
              </div>

              <div className="flex justify-end space-x-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowDestinationUpload(false);
                    setSelectedDestination(null);
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Holiday Type Image Upload Modal */}
        {showHolidayTypeUpload && selectedHolidayType && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg p-6 max-w-md w-full">
              <h3 className="text-lg font-semibold mb-4">
                Update Image for {selectedHolidayType.name}
              </h3>
              <p className="text-gray-600 mb-4">
                Upload a new image for this holiday type. The image will be used in holiday type cards and promotional sections.
              </p>
              
              <div className="space-y-4">
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) {
                      handleHolidayTypeImageUpload(file);
                    }
                  }}
                  className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-roamah-orange file:text-white hover:file:bg-roamah-orange/90"
                />
              </div>

              <div className="flex justify-end space-x-3">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowHolidayTypeUpload(false);
                    setSelectedHolidayType(null);
                  }}
                >
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Create Destination Modal */}
        {showCreateDestination && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="flex items-center gap-3 mb-6">
                <Globe className="h-6 w-6 text-roamah-orange" />
                <h3 className="text-xl font-semibold">Create New Destination</h3>
              </div>
              
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="dest-name">Destination Name *</Label>
                    <Input
                      id="dest-name"
                      placeholder="e.g. Bali, Indonesia"
                      value={newDestination.name}
                      onChange={(e) => setNewDestination(prev => ({ ...prev, name: e.target.value }))}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="dest-continent">Continent *</Label>
                    <Select
                      value={newDestination.continent}
                      onValueChange={(value) => setNewDestination(prev => ({ ...prev, continent: value }))}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select continent" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Africa">Africa</SelectItem>
                        <SelectItem value="Asia">Asia</SelectItem>
                        <SelectItem value="Europe">Europe</SelectItem>
                        <SelectItem value="North America">North America</SelectItem>
                        <SelectItem value="South America">South America</SelectItem>
                        <SelectItem value="Oceania">Oceania</SelectItem>
                        <SelectItem value="Antarctica">Antarctica</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="dest-description">Description *</Label>
                  <Textarea
                    id="dest-description"
                    placeholder="Write a compelling description of this destination..."
                    rows={4}
                    value={newDestination.description}
                    onChange={(e) => setNewDestination(prev => ({ ...prev, description: e.target.value }))}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="dest-image">Image *</Label>
                  <div className="flex gap-3">
                    <Input
                      id="dest-image"
                      placeholder="https://example.com/image.jpg or upload file"
                      value={newDestination.image}
                      onChange={(e) => setNewDestination(prev => ({ ...prev, image: e.target.value }))}
                      className="flex-1"
                    />
                    <div className="relative">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            handleNewDestinationImageUpload(file);
                            // Clear the input so the same file can be selected again
                            e.target.value = '';
                          }
                        }}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                        disabled={isUploadingDestImage}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        disabled={isUploadingDestImage}
                        className="h-full px-3"
                      >
                        {isUploadingDestImage ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-900"></div>
                        ) : (
                          <Camera className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                  <p className="text-sm text-gray-500">
                    Upload an image file or enter a URL. Recommended: High-quality landscape image (1200x800px minimum)
                  </p>
                </div>
                
                {newDestination.image && (
                  <div className="space-y-2">
                    <Label>Image Preview</Label>
                    <div className="border rounded-lg overflow-hidden">
                      <img 
                        src={newDestination.image} 
                        alt="Preview" 
                        className="w-full h-48 object-cover"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.style.display = 'none';
                        }}
                      />
                    </div>
                  </div>
                )}
              </div>
              
              <div className="flex justify-end space-x-3 mt-8 pt-6 border-t">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowCreateDestination(false);
                    setNewDestination({ name: '', description: '', continent: '', image: '' });
                  }}
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => createDestination.mutate(newDestination)}
                  disabled={!newDestination.name || !newDestination.description || !newDestination.continent || !newDestination.image || createDestination.isPending}
                  className="bg-roamah-orange hover:bg-roamah-orange/90"
                >
                  {createDestination.isPending ? "Creating..." : "Create Destination"}
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Create Holiday Type Modal */}
        {showCreateHolidayType && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg p-6 max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="flex items-center gap-3 mb-6">
                <MapPin className="h-6 w-6 text-roamah-orange" />
                <h3 className="text-xl font-semibold">Create New Holiday Type</h3>
              </div>
              
              <div className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="holiday-name">Holiday Type Name *</Label>
                    <Input
                      id="holiday-name"
                      placeholder="e.g. Wellness Retreats"
                      value={newHolidayType.name}
                      onChange={(e) => setNewHolidayType(prev => ({ ...prev, name: e.target.value }))}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="holiday-icon">Icon (Optional)</Label>
                    <Input
                      id="holiday-icon"
                      placeholder="e.g. 🧘‍♀️ or spa"
                      value={newHolidayType.icon}
                      onChange={(e) => setNewHolidayType(prev => ({ ...prev, icon: e.target.value }))}
                    />
                    <p className="text-sm text-gray-500">
                      Use emoji or icon name (Lucide React icons) - optional field
                    </p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="holiday-tagline">Tagline *</Label>
                  <Input
                    id="holiday-tagline"
                    placeholder="e.g. Rejuvenate mind, body and soul"
                    value={newHolidayType.tagline}
                    onChange={(e) => setNewHolidayType(prev => ({ ...prev, tagline: e.target.value }))}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="holiday-description">Description *</Label>
                  <Textarea
                    id="holiday-description"
                    placeholder="Write a detailed description of this holiday type..."
                    rows={4}
                    value={newHolidayType.description}
                    onChange={(e) => setNewHolidayType(prev => ({ ...prev, description: e.target.value }))}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="holiday-image">Image *</Label>
                  <div className="flex gap-3">
                    <Input
                      id="holiday-image"
                      placeholder="https://example.com/image.jpg or upload file"
                      value={newHolidayType.image}
                      onChange={(e) => setNewHolidayType(prev => ({ ...prev, image: e.target.value }))}
                      className="flex-1"
                    />
                    <div className="relative">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            handleNewHolidayTypeImageUpload(file);
                            // Clear the input so the same file can be selected again
                            e.target.value = '';
                          }
                        }}
                        className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                        disabled={isUploadingHolidayImage}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        disabled={isUploadingHolidayImage}
                        className="h-full px-3"
                      >
                        {isUploadingHolidayImage ? (
                          <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-gray-900"></div>
                        ) : (
                          <Camera className="h-4 w-4" />
                        )}
                      </Button>
                    </div>
                  </div>
                  <p className="text-sm text-gray-500">
                    Upload an image file or enter a URL. Recommended: High-quality image representing this holiday type (1200x800px minimum)
                  </p>
                </div>
                
                {newHolidayType.image && (
                  <div className="space-y-2">
                    <Label>Image Preview</Label>
                    <div className="border rounded-lg overflow-hidden">
                      <img 
                        src={newHolidayType.image} 
                        alt="Preview" 
                        className="w-full h-48 object-cover"
                        onError={(e) => {
                          const target = e.target as HTMLImageElement;
                          target.style.display = 'none';
                        }}
                      />
                    </div>
                  </div>
                )}
              </div>
              
              <div className="flex justify-end space-x-3 mt-8 pt-6 border-t">
                <Button
                  variant="outline"
                  onClick={() => {
                    setShowCreateHolidayType(false);
                    setNewHolidayType({ name: '', description: '', tagline: '', icon: '', image: '' });
                  }}
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => createHolidayType.mutate(newHolidayType)}
                  disabled={!newHolidayType.name || !newHolidayType.description || !newHolidayType.tagline || !newHolidayType.image || createHolidayType.isPending}
                  className="bg-roamah-orange hover:bg-roamah-orange/90"
                >
                  {createHolidayType.isPending ? "Creating..." : "Create Holiday Type"}
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Edit Destination Dialog */}
        {showEditDestination && editingDestination && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-semibold">Edit Destination</h2>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setShowEditDestination(false);
                      setEditingDestination(null);
                    }}
                  >
                    ×
                  </Button>
                </div>
                
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-dest-name">Destination Name *</Label>
                    <Input
                      id="edit-dest-name"
                      placeholder="e.g., Jordan"
                      value={editingDestination.name}
                      onChange={(e) => setEditingDestination(prev => prev ? { ...prev, name: e.target.value } : null)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="edit-dest-continent">Continent *</Label>
                    <Select 
                      value={editingDestination.continent} 
                      onValueChange={(value) => setEditingDestination(prev => prev ? { ...prev, continent: value } : null)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select continent" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Africa">Africa</SelectItem>
                        <SelectItem value="Asia">Asia</SelectItem>
                        <SelectItem value="Europe">Europe</SelectItem>
                        <SelectItem value="North America">North America</SelectItem>
                        <SelectItem value="South America">South America</SelectItem>
                        <SelectItem value="Oceania">Oceania</SelectItem>
                        <SelectItem value="Antarctica">Antarctica</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="edit-dest-description">Description *</Label>
                    <Textarea
                      id="edit-dest-description"
                      rows={8}
                      placeholder="Detailed description of the destination, what makes it special, key attractions, experiences available..."
                      value={editingDestination.description}
                      onChange={(e) => setEditingDestination(prev => prev ? { ...prev, description: e.target.value } : null)}
                    />
                    <p className="text-sm text-gray-500">
                      Write a compelling description that highlights what makes this destination unique. This will appear on destination pages and help travelers understand what to expect.
                    </p>
                  </div>
                </div>
                
                <div className="flex justify-end space-x-3 mt-8 pt-6 border-t">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowEditDestination(false);
                      setEditingDestination(null);
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={() => {
                      if (editingDestination) {
                        editDestination.mutate({
                          id: editingDestination.id,
                          name: editingDestination.name,
                          description: editingDestination.description,
                          continent: editingDestination.continent,
                        });
                      }
                    }}
                    disabled={!editingDestination?.name || !editingDestination?.description || !editingDestination?.continent || editDestination.isPending}
                    className="bg-roamah-orange hover:bg-roamah-orange/90"
                  >
                    {editDestination.isPending ? "Updating..." : "Update Destination"}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Edit Holiday Type Dialog */}
        {showEditHolidayType && editingHolidayType && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-semibold">Edit Holiday Type</h2>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setShowEditHolidayType(false);
                      setEditingHolidayType(null);
                    }}
                  >
                    ×
                  </Button>
                </div>
                
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="edit-holiday-name">Holiday Type Name *</Label>
                    <Input
                      id="edit-holiday-name"
                      placeholder="e.g., Golf Holidays"
                      value={editingHolidayType.name}
                      onChange={(e) => setEditingHolidayType(prev => prev ? { ...prev, name: e.target.value } : null)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="edit-holiday-tagline">Tagline *</Label>
                    <Input
                      id="edit-holiday-tagline"
                      placeholder="Short, catchy tagline describing this holiday type"
                      value={editingHolidayType.tagline}
                      onChange={(e) => setEditingHolidayType(prev => prev ? { ...prev, tagline: e.target.value } : null)}
                    />
                    <p className="text-sm text-gray-500">
                      A brief, compelling tagline that captures the essence of this holiday type (e.g., "Tee off in paradise")
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="edit-holiday-icon">Icon</Label>
                    <Input
                      id="edit-holiday-icon"
                      placeholder="e.g., golf, spa, mountain (optional)"
                      value={editingHolidayType.icon}
                      onChange={(e) => setEditingHolidayType(prev => prev ? { ...prev, icon: e.target.value } : null)}
                    />
                    <p className="text-sm text-gray-500">
                      Icon name for visual representation (optional). Use simple keywords like "golf", "spa", "mountain"
                    </p>
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="edit-holiday-description">Description *</Label>
                    <Textarea
                      id="edit-holiday-description"
                      rows={6}
                      placeholder="Detailed description of this holiday type, what makes it special, typical activities..."
                      value={editingHolidayType.description}
                      onChange={(e) => setEditingHolidayType(prev => prev ? { ...prev, description: e.target.value } : null)}
                    />
                    <p className="text-sm text-gray-500">
                      Describe what makes this holiday type unique, typical activities, and who it appeals to
                    </p>
                  </div>
                </div>
                
                <div className="flex justify-end space-x-3 mt-8 pt-6 border-t">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowEditHolidayType(false);
                      setEditingHolidayType(null);
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={() => {
                      if (editingHolidayType) {
                        editHolidayType.mutate({
                          id: editingHolidayType.id,
                          name: editingHolidayType.name,
                          description: editingHolidayType.description,
                          tagline: editingHolidayType.tagline,
                          icon: editingHolidayType.icon,
                        });
                      }
                    }}
                    disabled={!editingHolidayType?.name || !editingHolidayType?.description || !editingHolidayType?.tagline || editHolidayType.isPending}
                    className="bg-roamah-orange hover:bg-roamah-orange/90"
                  >
                    {editHolidayType.isPending ? "Updating..." : "Update Holiday Type"}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}