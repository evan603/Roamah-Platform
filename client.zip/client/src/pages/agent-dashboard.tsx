import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Progress } from "@/components/ui/progress";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import ReactCrop, { type Crop, centerCrop, makeAspectCrop, convertToPixelCrop } from 'react-image-crop';
import 'react-image-crop/dist/ReactCrop.css';
import { 
  User, 
  MapPin, 
  Camera, 
  Video, 
  FileText, 
  Tag, 
  MessageSquare,
  Settings,
  LogOut,
  Plus,
  Edit,
  Trash2,
  Upload,
  PenTool,
  Eye,
  RotateCw,
  Save,
  X,
  Star,
  CheckCircle,
  Clock
} from "lucide-react";
import { BlogEditor } from "@/components/BlogEditor";
import { OfferEditor } from "@/components/OfferEditor";
import { OfferPreviewModal } from "@/components/OfferPreviewModal";
import type { BlogPost, Offer } from "@shared/schema";

interface AgentProfile {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  name: string;
  location: string;
  bio: string;
  profileImage: string;
  company: string;
  nextHoliday: string;
  specializations: string[];
  destinations: string[];
  languages: string[];
  photos: string[];
  videoUrl?: string;
  yearsExperience: number;
  rating: string;
  reviewCount: number;
  profileViews?: number;
}

export default function AgentDashboard() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { isAuthenticated, logout, isLoading: authLoading } = useAuth();

  // Clear any error toasts when user successfully accesses dashboard
  useEffect(() => {
    if (isAuthenticated) {
      // Clear any lingering error notifications
      const errorElements = document.querySelectorAll('[data-toast][data-state="open"]');
      errorElements.forEach(element => {
        const closeButton = element.querySelector('button[data-action="close"]');
        if (closeButton) {
          (closeButton as HTMLButtonElement).click();
        }
      });
    }
  }, [isAuthenticated]);

  // Redirect to login if not authenticated
  useEffect(() => {
    if (!authLoading && !isAuthenticated) {
      toast({
        title: "Authentication Required",
        description: "Please log in to access your dashboard.",
        variant: "destructive",
      });
      setLocation("/agent-login");
    }
  }, [isAuthenticated, authLoading, setLocation, toast]);
  const [isEditing, setIsEditing] = useState(false);
  const [uploadingMedia, setUploadingMedia] = useState(false);
  const [uploadingProfileImage, setUploadingProfileImage] = useState(false);
  const [imageUpdateKey, setImageUpdateKey] = useState(Date.now());
  const [videoUploadProgress, setVideoUploadProgress] = useState(0);
  const [blogEditorOpen, setBlogEditorOpen] = useState(false);
  const [editingBlog, setEditingBlog] = useState<BlogPost | null>(null);
  const [offerEditorOpen, setOfferEditorOpen] = useState(false);
  const [editingOffer, setEditingOffer] = useState<Offer | null>(null);
  const [previewOffer, setPreviewOffer] = useState<Offer | null>(null);
  const [showOfferPreview, setShowOfferPreview] = useState(false);
  
  // Image cropping states
  const [cropModalOpen, setCropModalOpen] = useState(false);
  const [originalImage, setOriginalImage] = useState<string>("");
  const [crop, setCrop] = useState<Crop>();
  const [rotation, setRotation] = useState(0);
  const [scale, setScale] = useState(1);
  const [imgRef, setImgRef] = useState<HTMLImageElement | null>(null);
  const [editForm, setEditForm] = useState({
    firstName: "",
    lastName: "",
    location: "",
    company: "",
    bio: "",
    nextHoliday: "",
    yearsExperience: 0,
    specializations: [] as string[],
    destinations: [] as string[],
    languages: [] as string[]
  });

  // Check if user is authenticated
  useEffect(() => {
    const token = localStorage.getItem('agentToken');
    if (!token) {
      setLocation('/agent-login');
    }
  }, [setLocation]);

  // Profile image upload function - opens crop modal
  const handleProfileImageUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !file.type.startsWith('image/')) {
      toast({
        title: "Invalid file",
        description: "Please select an image file",
        variant: "destructive",
      });
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      setOriginalImage(reader.result as string);
      setCropModalOpen(true);
      setRotation(0);
      setScale(1);
    };
    reader.readAsDataURL(file);
  };

  // Initialize crop when image loads
  const onImageLoad = useCallback((e: React.SyntheticEvent<HTMLImageElement>) => {
    const { naturalWidth: width, naturalHeight: height } = e.currentTarget;
    const crop = centerCrop(
      makeAspectCrop({ unit: '%', width: 90 }, 1, width, height),
      width,
      height
    );
    setCrop(crop);
    setImgRef(e.currentTarget);
  }, []);

  // Create canvas and upload cropped image using proven working method
  const getCroppedImg = useCallback((image: HTMLImageElement, crop: Crop): Promise<Blob> => {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('No 2d context');

    const pixelCrop = convertToPixelCrop(crop, image.naturalWidth, image.naturalHeight);
    
    const scaleX = image.naturalWidth / image.width;
    const scaleY = image.naturalHeight / image.height;
    const pixelRatio = window.devicePixelRatio;

    canvas.width = Math.floor(pixelCrop.width * scaleX * pixelRatio);
    canvas.height = Math.floor(pixelCrop.height * scaleY * pixelRatio);

    ctx.scale(pixelRatio, pixelRatio);
    ctx.imageSmoothingQuality = 'high';

    const cropX = pixelCrop.x * scaleX;
    const cropY = pixelCrop.y * scaleY;

    const rotateRads = rotation * (Math.PI / 180);
    const centerX = image.naturalWidth / 2;
    const centerY = image.naturalHeight / 2;

    ctx.save();

    ctx.translate(-cropX, -cropY);
    ctx.translate(centerX, centerY);
    ctx.rotate(rotateRads);
    ctx.scale(scale, scale);
    ctx.translate(-centerX, -centerY);
    ctx.drawImage(
      image,
      0,
      0,
      image.naturalWidth,
      image.naturalHeight,
      0,
      0,
      image.naturalWidth,
      image.naturalHeight,
    );

    ctx.restore();

    return new Promise<Blob>((resolve, reject) => {
      canvas.toBlob((blob) => {
        if (blob && blob.size > 100) {
          console.log('Cropped image blob created successfully:', {
            size: blob.size,
            type: blob.type,
            dimensions: `${canvas.width}x${canvas.height}`
          });
          resolve(blob);
        } else {
          console.error('Failed to create valid blob or blob too small');
          reject(new Error('Canvas blob creation failed'));
        }
      }, 'image/jpeg', 0.9);
    });
  }, [rotation, scale]);

  // Save cropped profile image
  const saveCroppedProfileImage = async () => {
    if (!imgRef || !crop) {
      toast({
        title: "No image to crop",
        description: "Please select an image first",
        variant: "destructive",
      });
      return;
    }

    setUploadingProfileImage(true);
    try {
      const croppedImageBlob = await getCroppedImg(imgRef, crop);
      
      if (!croppedImageBlob) {
        throw new Error('Failed to create image blob');
      }

      console.log('Cropped image blob size:', croppedImageBlob.size);
      
      const token = localStorage.getItem('agentToken');
      const formData = new FormData();
      formData.append('profileImage', croppedImageBlob, 'profile.jpg');

      const response = await fetch('/api/agents/upload/profile-image', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || 'Failed to upload profile image');
      }

      toast({
        title: "Profile image updated",
        description: "Your profile image has been updated successfully",
      });
      
      // Force refresh profile data and clear query cache
      queryClient.removeQueries({ queryKey: ['/api/agents/profile'] });
      await queryClient.refetchQueries({ queryKey: ['/api/agents/profile'] });
      
      // Update image key to force React re-render
      setImageUpdateKey(Date.now());
      
      setCropModalOpen(false);
      
    } catch (error) {
      console.error('Profile image upload error:', error);
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Failed to upload profile image. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploadingProfileImage(false);
    }
  };

  // File upload function for photos
  const handlePhotoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files || files.length === 0) return;

    setUploadingMedia(true);
    try {
      const token = localStorage.getItem('agentToken');
      const formData = new FormData();
      
      Array.from(files).forEach((file) => {
        if (file.type.startsWith('image/')) {
          formData.append('photos', file);
        }
      });

      const response = await fetch('/api/agents/upload/photos', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Failed to upload photos');
      }

      const result = await response.json();
      
      toast({
        title: "Photos uploaded successfully",
        description: `${result.photos.length} photo(s) added to your profile`,
      });
      
      // Refresh profile data
      queryClient.invalidateQueries({ queryKey: ['/api/agents/profile'] });
      
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Failed to upload photos. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploadingMedia(false);
    }
  };

  // File upload function for videos with progress tracking
  const handleVideoUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file || !file.type.startsWith('video/')) {
      toast({
        title: "Invalid file",
        description: "Please select a video file",
        variant: "destructive",
      });
      return;
    }

    setUploadingMedia(true);
    setVideoUploadProgress(0);
    
    try {
      const token = localStorage.getItem('agentToken');
      const formData = new FormData();
      formData.append('video', file);

      // Create XMLHttpRequest for progress tracking
      const xhr = new XMLHttpRequest();
      
      // Set up progress listener
      xhr.upload.addEventListener('progress', (event) => {
        if (event.lengthComputable) {
          const progress = Math.round((event.loaded / event.total) * 100);
          setVideoUploadProgress(progress);
        }
      });

      // Create promise wrapper for XMLHttpRequest
      const uploadPromise = new Promise<any>((resolve, reject) => {
        xhr.onload = () => {
          if (xhr.status >= 200 && xhr.status < 300) {
            try {
              const result = JSON.parse(xhr.responseText);
              resolve(result);
            } catch (e) {
              reject(new Error('Invalid response format'));
            }
          } else {
            reject(new Error(`Upload failed with status ${xhr.status}`));
          }
        };
        
        xhr.onerror = () => reject(new Error('Network error occurred'));
        xhr.ontimeout = () => reject(new Error('Upload timed out'));
        
        xhr.open('POST', '/api/agents/upload/video');
        xhr.setRequestHeader('Authorization', `Bearer ${token}`);
        xhr.send(formData);
      });

      const result = await uploadPromise;
      
      setVideoUploadProgress(100);
      
      toast({
        title: "Video uploaded successfully",
        description: "Your introduction video has been updated",
      });
      
      // Refresh profile data
      queryClient.invalidateQueries({ queryKey: ['/api/agents/profile'] });
      
    } catch (error) {
      console.error('Video upload error:', error);
      toast({
        title: "Upload failed",
        description: error instanceof Error ? error.message : "Failed to upload video. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploadingMedia(false);
      setTimeout(() => setVideoUploadProgress(0), 1000); // Reset progress after 1 second
    }
  };

  // Fetch agent profile
  const { data: profile, isLoading: profileLoading, error: profileError } = useQuery<AgentProfile>({
    queryKey: ['/api/agents/profile'],
    queryFn: async () => {
      const token = localStorage.getItem('agentToken');
      if (!token) throw new Error('No auth token');
      
      const response = await fetch('/api/agents/profile', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch profile');
      }
      
      return response.json();
    },
  });

  // Fetch blog posts
  const { data: blogPosts } = useQuery<BlogPost[]>({
    queryKey: ["/api/agents/blog"],
    queryFn: () => apiRequest("/api/agents/blog", {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('agentToken')}`,
      },
    }),
  });

  // Fetch offers
  const { data: offers = [] } = useQuery<Offer[]>({
    queryKey: ['/api/agents/offers'],
    queryFn: () => apiRequest('/api/agents/186/offers', {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('agentToken')}`,
      },
    }),
    enabled: !!profile?.id,
  });

  // Fetch reviews
  const { data: reviews = [] } = useQuery<any[]>({
    queryKey: ['/api/agents', profile?.id, 'reviews'],
    enabled: !!profile?.id,
  });

  // Fetch enquiries
  const { data: enquiries = [] } = useQuery<any[]>({
    queryKey: [`/api/agents/${profile?.id}/enquiries`],
    queryFn: () => apiRequest(`/api/agents/${profile?.id}/enquiries`, {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('agentToken')}`,
      },
    }),
    enabled: !!profile?.id,
  });

  // Fetch unread enquiries count
  const { data: unreadData } = useQuery<{ count: number }>({
    queryKey: ['/api/agents/enquiries/unread-count'],
    queryFn: () => apiRequest('/api/agents/enquiries/unread-count', {
      headers: {
        'Authorization': `Bearer ${localStorage.getItem('agentToken')}`,
      },
    }),
  });
  
  const unreadCount = unreadData?.count || 0;

  // Initialize edit form when profile loads
  useEffect(() => {
    if (profile && !isEditing) {
      setEditForm({
        firstName: profile.firstName || "",
        lastName: profile.lastName || "",
        location: profile.location || "",
        company: profile.company || "",
        bio: profile.bio || "",
        nextHoliday: profile.nextHoliday || "",
        yearsExperience: profile.yearsExperience || 0,
        specializations: profile.specializations || [],
        destinations: profile.destinations || [],
        languages: profile.languages || []
      });
    }
  }, [profile, isEditing]);

  // Save profile changes
  const saveProfileChanges = async () => {
    try {
      const token = localStorage.getItem('agentToken');
      const response = await fetch('/api/agents/profile', {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(editForm),
      });

      if (!response.ok) {
        throw new Error('Failed to update profile');
      }

      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully",
      });

      setIsEditing(false);
      queryClient.invalidateQueries({ queryKey: ['/api/agents/profile'] });
    } catch (error) {
      toast({
        title: "Update failed",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Delete blog post mutation
  const deleteBlogMutation = useMutation({
    mutationFn: async (blogId: number) => {
      return apiRequest(`/api/agents/blog/${blogId}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('agentToken')}`,
        },
      });
    },
    onSuccess: () => {
      toast({
        title: "Blog post deleted",
        description: "Your blog post has been deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/agents/blog'] });
    },
    onError: (error: any) => {
      toast({
        title: "Delete failed",
        description: error.message || "Failed to delete blog post. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleDeleteBlog = (blogId: number, title: string) => {
    if (confirm(`Are you sure you want to delete "${title}"? This action cannot be undone.`)) {
      deleteBlogMutation.mutate(blogId);
    }
  };

  // Mark enquiry as read mutation
  const markEnquiryAsReadMutation = useMutation({
    mutationFn: async (enquiryId: number) => {
      return apiRequest(`/api/enquiries/${enquiryId}/read`, {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('agentToken')}`,
        },
      });
    },
    onSuccess: () => {
      // Refresh enquiries and unread count 
      queryClient.invalidateQueries({ queryKey: [`/api/agents/${profile?.id}/enquiries`] });
      queryClient.invalidateQueries({ queryKey: ['/api/agents/enquiries/unread-count'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to mark enquiry as read",
        variant: "destructive",
      });
    },
  });

  const handleMarkAsRead = (enquiryId: number) => {
    markEnquiryAsReadMutation.mutate(enquiryId);
  };

  // Mark all enquiries as read mutation
  const markAllEnquiriesAsReadMutation = useMutation({
    mutationFn: async () => {
      return apiRequest('/api/agents/enquiries/mark-all-read', {
        method: 'PATCH',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('agentToken')}`,
        },
      });
    },
    onSuccess: () => {
      // Refresh enquiries and unread count 
      queryClient.invalidateQueries({ queryKey: [`/api/agents/${profile?.id}/enquiries`] });
      queryClient.invalidateQueries({ queryKey: ['/api/agents/enquiries/unread-count'] });
      toast({
        title: "Success",
        description: "All enquiries marked as read",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to mark all enquiries as read",
        variant: "destructive",
      });
    },
  });

  const handleMarkAllAsRead = () => {
    markAllEnquiriesAsReadMutation.mutate();
  };

  // Photo deletion mutation
  const deletePhotoMutation = useMutation({
    mutationFn: async (photoUrl: string) => {
      return apiRequest('/api/agents/upload/photos', {
        method: 'DELETE',
        body: JSON.stringify({ photoUrl })
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Photo deleted successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/agents/profile'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete photo",
        variant: "destructive",
      });
    },
  });

  const handleDeletePhoto = (photoUrl: string) => {
    deletePhotoMutation.mutate(photoUrl);
  };

  const handleLogout = () => {
    logout();
    setLocation('/');
  };

  if (profileLoading || authLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-orange-600 mx-auto"></div>
          <p className="mt-2 text-gray-600">Loading dashboard...</p>
        </div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-600">Agent not found</p>
          {profileError && (
            <p className="text-sm text-red-600 mt-2">Error: {profileError.message}</p>
          )}
          <Button onClick={() => setLocation('/agent-login')} className="mt-4">
            Back to Login
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-6">
              <button 
                onClick={() => setLocation('/')}
                className="text-2xl font-bold text-roamah-orange hover:text-roamah-orange/80 transition-colors"
              >
                Roamah
              </button>
              <div className="h-6 w-px bg-gray-300"></div>
              <h1 className="text-xl font-semibold text-gray-900">Agent Dashboard</h1>
            </div>
            <div className="flex items-center space-x-3">
              <Button variant="outline" size="sm" className="text-gray-700 border-gray-300 hover:bg-gray-50">
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </Button>
              <Button variant="outline" size="sm" onClick={handleLogout} className="text-red-600 border-red-200 hover:bg-red-50">
                <LogOut className="w-4 h-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Welcome Section */}
        <div className="mb-8">
          <Card className="bg-gradient-to-br from-white via-roamah-orange/5 to-roamah-orange/10 border border-roamah-orange/20 shadow-xl">
            <CardHeader className="pb-6 px-6">
              <div className="space-y-4">
                {/* Top Row: Profile Image with Welcome Text and Button to the Right */}
                <div className="flex flex-col sm:flex-row sm:items-center space-y-4 sm:space-y-0 sm:space-x-6">
                  <div className="relative group flex-shrink-0">
                    <div className="bg-gradient-to-br from-roamah-orange/10 to-roamah-orange/20 p-1 rounded-2xl">
                      <img
                        key={`${profile.profileImage}-${imageUpdateKey}`} 
                        src={profile.profileImage ? `${profile.profileImage}?v=${imageUpdateKey}` : '/placeholder-avatar.jpg'}
                        alt={profile.name}
                        className="w-28 h-28 sm:w-32 sm:h-32 lg:w-36 lg:h-36 rounded-xl object-cover ring-2 ring-white shadow-2xl transition-transform duration-300 group-hover:scale-105"
                        onError={(e) => {
                          console.error('Failed to load profile image:', profile.profileImage);
                          console.error('Image error event:', e);
                          console.error('Current src attempted:', e.currentTarget.src);
                          e.currentTarget.src = '/placeholder-avatar.jpg';
                        }}
                        onLoad={(e) => {
                          console.log('Profile image loaded successfully:', profile.profileImage);
                          console.log('Loaded image dimensions:', e.currentTarget.naturalWidth, 'x', e.currentTarget.naturalHeight);
                        }}
                      />
                    </div>
                    <label htmlFor="profile-image-upload" className="absolute -bottom-2 -right-2 bg-roamah-orange text-white rounded-xl p-2 sm:p-3 cursor-pointer hover:bg-roamah-orange/90 transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-110">
                      <Camera className="w-3 h-3 sm:w-4 sm:h-4" />
                    </label>
                    <input
                      id="profile-image-upload"
                      type="file"
                      accept="image/*"
                      onChange={handleProfileImageUpload}
                      className="hidden"
                    />
                  </div>
                  
                  <div className="flex-1 min-w-0 space-y-3">
                    <div>
                      <CardTitle className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-2 bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text break-words">
                        Welcome back, {profile.firstName}!
                      </CardTitle>
                      <CardDescription className="text-lg sm:text-xl text-gray-600 font-medium break-words">
                        {profile.name} • {profile.location}
                      </CardDescription>
                    </div>
                    
                    {/* Edit Profile Button */}
                    {isEditing ? (
                      <div className="flex space-x-3">
                        <Button onClick={saveProfileChanges} className="bg-green-600 hover:bg-green-700 shadow-lg">
                          Save Changes
                        </Button>
                        <Button variant="outline" onClick={() => setIsEditing(false)}>
                          Cancel
                        </Button>
                      </div>
                    ) : (
                      <div className="flex space-x-3">
                        <Button 
                          onClick={() => setLocation('/edit-profile-live')}
                          className="bg-roamah-orange hover:bg-roamah-orange/90 shadow-lg hover:shadow-xl transition-all duration-300"
                        >
                          <Edit className="w-4 h-4 mr-2" />
                          Edit Profile
                        </Button>
                        <Button 
                          onClick={() => window.open(`/agent/${profile.id}`, '_blank')}
                          variant="outline"
                          className="border-roamah-orange text-roamah-orange hover:bg-roamah-orange hover:text-white shadow-lg hover:shadow-xl transition-all duration-300"
                        >
                          <Eye className="w-4 h-4 mr-2" />
                          View Live Profile
                        </Button>
                      </div>
                    )}
                  </div>
                </div>
                
                {/* Bottom Row: Stats Grid */}
                <div className="grid grid-cols-2 lg:grid-cols-4 gap-2.5">
                  <div className="bg-white/70 backdrop-blur-sm rounded-lg p-2.5 border border-gray-200/50 shadow-sm">
                    <div className="flex items-center space-x-2">
                      <div className="p-1 bg-blue-100 rounded-md flex-shrink-0">
                        <MapPin className="w-3 h-3 text-blue-600" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-medium text-gray-500">Business</p>
                        <p className="text-sm font-semibold text-gray-900 truncate">{profile.company}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white/70 backdrop-blur-sm rounded-lg p-2.5 border border-gray-200/50 shadow-sm">
                    <div className="flex items-center space-x-2">
                      <div className="p-1 bg-green-100 rounded-md flex-shrink-0">
                        <Eye className="w-3 h-3 text-green-600" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-medium text-gray-500">Profile Views</p>
                        <p className="text-sm font-semibold text-gray-900">{profile.profileViews || 0}</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white/70 backdrop-blur-sm rounded-lg p-2.5 border border-gray-200/50 shadow-sm">
                    <div className="flex items-center space-x-2">
                      <div className="p-1 bg-purple-100 rounded-md flex-shrink-0">
                        <User className="w-3 h-3 text-purple-600" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-medium text-gray-500">Experience</p>
                        <p className="text-sm font-semibold text-gray-900">{profile.yearsExperience} years</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-white/70 backdrop-blur-sm rounded-lg p-2.5 border border-gray-200/50 shadow-sm">
                    <div className="flex items-center space-x-2">
                      <div className="p-1 bg-yellow-100 rounded-md flex-shrink-0">
                        <span className="text-yellow-600 text-xs">⭐</span>
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="text-xs font-medium text-gray-500">Rating</p>
                        <p className="text-sm font-semibold text-gray-900">{profile.rating}/5.0</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardHeader>
          </Card>
        </div>

        {/* Dashboard Tabs */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-6 h-12 bg-white shadow-sm rounded-lg border">
            <TabsTrigger value="overview" className="flex items-center space-x-2 data-[state=active]:bg-roamah-orange data-[state=active]:text-white">
              <User className="w-4 h-4" />
              <span className="font-medium">Overview</span>
            </TabsTrigger>
            <TabsTrigger value="blog" className="flex items-center space-x-2 data-[state=active]:bg-roamah-orange data-[state=active]:text-white">
              <FileText className="w-4 h-4" />
              <span className="font-medium">Blog</span>
            </TabsTrigger>
            <TabsTrigger value="offers" className="flex items-center space-x-2 data-[state=active]:bg-roamah-orange data-[state=active]:text-white">
              <Tag className="w-4 h-4" />
              <span className="font-medium">My Offers</span>
            </TabsTrigger>
            <TabsTrigger value="enquiries" className="flex items-center space-x-2 data-[state=active]:bg-roamah-orange data-[state=active]:text-white relative">
              <MessageSquare className="w-4 h-4" />
              <span className="font-medium">Enquiries</span>
              {unreadCount > 0 && (
                <Badge className="bg-red-500 text-white text-xs px-1.5 py-0.5 rounded-full min-w-[18px] h-4 flex items-center justify-center absolute -top-1 -right-1">
                  {unreadCount}
                </Badge>
              )}
            </TabsTrigger>
            <TabsTrigger value="reviews" className="flex items-center space-x-2 data-[state=active]:bg-roamah-orange data-[state=active]:text-white">
              <Star className="w-4 h-4" />
              <span className="font-medium">Reviews</span>
            </TabsTrigger>
            <TabsTrigger value="profile" className="flex items-center space-x-2 data-[state=active]:bg-roamah-orange data-[state=active]:text-white">
              <Settings className="w-4 h-4" />
              <span className="font-medium">Profile</span>
            </TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Reviews</CardTitle>
                  <MessageSquare className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{profile.reviewCount}</div>
                  <p className="text-xs text-muted-foreground">Rating: {profile.rating}/5.0</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Active Offers</CardTitle>
                  <Tag className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{offers?.length || 0}</div>
                  <p className="text-xs text-muted-foreground">Live on platform</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Blog Posts</CardTitle>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{blogPosts?.length || 0}</div>
                  <p className="text-xs text-muted-foreground">Published articles</p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Enquiries</CardTitle>
                  <MessageSquare className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{enquiries?.length || 0}</div>
                  <p className="text-xs text-muted-foreground">
                    {unreadCount > 0 ? `${unreadCount} new enquiries` : 'All read'}
                  </p>
                </CardContent>
              </Card>
            </div>

            {/* Media Upload Section */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Photos */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center">
                      <Camera className="w-5 h-5 mr-2" />
                      Travel Photos
                    </CardTitle>
                    <label htmlFor="photo-upload">
                      <Button size="sm" disabled={uploadingMedia} asChild>
                        <span className="cursor-pointer">
                          {uploadingMedia ? (
                            <>
                              <Upload className="w-4 h-4 mr-2 animate-spin" />
                              Uploading...
                            </>
                          ) : (
                            <>
                              <Camera className="w-4 h-4 mr-2" />
                              Upload Photos
                            </>
                          )}
                        </span>
                      </Button>
                    </label>
                    <input
                      id="photo-upload"
                      type="file"
                      accept="image/*"
                      multiple
                      onChange={handlePhotoUpload}
                      className="hidden"
                    />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="bg-blue-50 border border-blue-200 rounded-lg p-3 mb-4">
                    <p className="text-sm text-blue-800 font-medium">📸 Upload Requirements:</p>
                    <ul className="text-xs text-blue-700 mt-1 space-y-1">
                      <li>• <strong>Format:</strong> JPEG, PNG, WebP (max 5MB per file)</li>
                      <li>• <strong>Size:</strong> Minimum 800x600px recommended</li>
                      <li>• <strong>Content:</strong> Your travel experiences, destinations, professional shots</li>
                      <li>• <strong>Multiple:</strong> Select multiple photos at once</li>
                    </ul>
                  </div>
                  
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {profile.photos && profile.photos.length > 0 ? (
                      profile.photos.map((photo, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={photo}
                            alt={`Travel photo ${index + 1}`}
                            className="w-full h-32 object-cover rounded-lg"
                          />
                          <div className="absolute inset-0 bg-black bg-opacity-0 group-hover:bg-opacity-50 transition-all duration-200 rounded-lg flex items-center justify-center">
                            <Button
                              size="sm"
                              variant="destructive"
                              className="opacity-0 group-hover:opacity-100 transition-all duration-200"
                              disabled={deletePhotoMutation.isPending}
                              onClick={() => handleDeletePhoto(photo)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ))
                    ) : (
                      <div className="col-span-3 text-center py-8 text-gray-500">
                        <Camera className="w-12 h-12 mx-auto mb-2 opacity-50" />
                        <p>No photos uploaded yet</p>
                        <p className="text-sm">Click "Upload Photos" to add your travel experiences</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>

              {/* Videos */}
              <Card>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="flex items-center">
                      <Video className="w-5 h-5 mr-2" />
                      Introduction Video
                    </CardTitle>
                    <label htmlFor="video-upload">
                      <Button size="sm" disabled={uploadingMedia} asChild>
                        <span className="cursor-pointer">
                          {uploadingMedia ? (
                            <>
                              <Upload className="w-4 h-4 mr-2 animate-spin" />
                              Uploading...
                            </>
                          ) : (
                            <>
                              <Video className="w-4 h-4 mr-2" />
                              Upload Video
                            </>
                          )}
                        </span>
                      </Button>
                    </label>
                    <input
                      id="video-upload"
                      type="file"
                      accept="video/*"
                      onChange={handleVideoUpload}
                      className="hidden"
                    />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                    <p className="text-sm text-green-800 font-medium">🎥 Video Requirements:</p>
                    <ul className="text-xs text-green-700 mt-1 space-y-1">
                      <li>• <strong>Format:</strong> MP4, WebM, MOV (max 200MB)</li>
                      <li>• <strong>Duration:</strong> 30 seconds to 3 minutes recommended</li>
                      <li>• <strong>Content:</strong> Personal introduction, travel experience, expertise</li>
                      <li>• <strong>Quality:</strong> Clear audio and HD video preferred</li>
                    </ul>
                  </div>
                  
                  {/* Upload Progress Bar */}
                  {uploadingMedia && videoUploadProgress > 0 && (
                    <div className="mb-4 p-4 bg-blue-50 border border-blue-200 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="text-sm font-medium text-blue-800">
                          Uploading video...
                        </span>
                        <span className="text-sm font-bold text-blue-800">
                          {videoUploadProgress}%
                        </span>
                      </div>
                      <Progress value={videoUploadProgress} className="h-2" />
                      <p className="text-xs text-blue-600 mt-1">
                        Please don't close this page while uploading
                      </p>
                    </div>
                  )}
                  
                  {profile.videoUrl ? (
                    <div className="space-y-4">
                      <div className="relative">
                        <video
                          src={profile.videoUrl}
                          controls
                          className="w-full h-64 object-cover rounded-lg"
                          poster="/placeholder-video-thumbnail.jpg"
                        >
                          Your browser does not support the video tag.
                        </video>
                        <div className="absolute top-2 right-2">
                          <Button
                            size="sm"
                            variant="destructive"
                            onClick={() => {
                              // TODO: Add delete video functionality
                              toast({
                                title: "Delete Video",
                                description: "Video deletion feature coming soon",
                              });
                            }}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <Video className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>No introduction video uploaded</p>
                      <p className="text-sm">Upload a video to introduce yourself to potential clients</p>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Blog Tab */}
          <TabsContent value="blog" className="space-y-8">
            {/* Blog Management Section */}
            <Card className="shadow-lg border-0">
              <CardHeader className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-t-lg border-b">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center text-xl">
                    <PenTool className="w-6 h-6 mr-3 text-roamah-orange" />
                    Blog Posts
                  </CardTitle>
                  <Button 
                    onClick={() => setBlogEditorOpen(true)}
                    className="bg-roamah-orange hover:bg-roamah-orange/90 shadow-md"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create New Post
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                {blogPosts && blogPosts.length > 0 ? (
                  <div className="space-y-6">
                    {blogPosts.map((post) => (
                      <div key={post.id} className="bg-white border border-gray-200 rounded-xl overflow-hidden hover:shadow-lg transition-all duration-200 hover:border-roamah-orange/30">
                        <div className="flex">
                          {/* Hero Image Preview */}
                          {post.heroImage && (
                            <div className="w-48 h-32 flex-shrink-0">
                              <img
                                src={post.heroImage}
                                alt={post.title}
                                className="w-full h-full object-cover"
                              />
                            </div>
                          )}
                          
                          {/* Content */}
                          <div className="flex-1 p-6">
                            <div className="flex items-start justify-between">
                              <div className="flex-1">
                                <div className="space-y-2 mb-4">
                                  <div className="flex items-center gap-2">
                                    <Badge 
                                      variant={post.status === 'published' ? 'default' : 'secondary'}
                                      className={post.status === 'published' 
                                        ? 'bg-green-600 hover:bg-green-700 text-white px-3 py-1 text-sm font-medium' 
                                        : 'bg-gray-500 hover:bg-gray-600 text-white px-3 py-1 text-sm font-medium'
                                      }
                                    >
                                      {post.status}
                                    </Badge>
                                  </div>
                                  
                                  {post.holidayTypes && post.holidayTypes.length > 0 && (
                                    <div className="flex flex-wrap gap-2">
                                      {post.holidayTypes.map((type) => (
                                        <Badge 
                                          key={type} 
                                          variant="secondary" 
                                          className="bg-green-50 text-green-700 border border-green-200 px-3 py-1.5 text-sm font-medium hover:bg-green-100 transition-colors"
                                        >
                                          🌟 {type}
                                        </Badge>
                                      ))}
                                    </div>
                                  )}
                                  
                                  {post.destinations && post.destinations.length > 0 && (
                                    <div className="flex flex-wrap gap-2">
                                      {post.destinations.map((dest) => (
                                        <Badge 
                                          key={dest} 
                                          variant="secondary" 
                                          className="bg-blue-50 text-blue-700 border border-blue-200 px-3 py-1.5 text-sm font-medium hover:bg-blue-100 transition-colors"
                                        >
                                          📍 {dest}
                                        </Badge>
                                      ))}
                                    </div>
                                  )}
                                </div>
                                <h3 className="font-bold text-xl text-gray-900 mb-2 line-clamp-2">{post.title}</h3>
                                <p className="text-gray-600 mb-3 line-clamp-2">{post.excerpt}</p>
                                <div className="flex items-center text-sm text-gray-500 space-x-4">
                                  <span>Created: {new Date(post.createdAt).toLocaleDateString()}</span>
                                  {post.publishedAt && (
                                    <span>Published: {new Date(post.publishedAt).toLocaleDateString()}</span>
                                  )}
                                </div>
                              </div>
                              <div className="flex items-center space-x-2 ml-6">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  onClick={() => {
                                    setEditingBlog(post);
                                    setBlogEditorOpen(true);
                                  }}
                                  className="border-gray-300 hover:border-roamah-orange hover:text-roamah-orange"
                                >
                                  <Edit className="w-4 h-4" />
                                  <span className="ml-1 hidden sm:inline">Edit</span>
                                </Button>
                                <Button
                                  size="sm"
                                  variant="ghost"
                                  className="text-red-600 hover:text-red-700 hover:bg-red-50"
                                  onClick={() => handleDeleteBlog(post.id, post.title)}
                                  disabled={deleteBlogMutation.isPending}
                                >
                                  <Trash2 className="w-4 h-4" />
                                  <span className="ml-1 hidden sm:inline">Delete</span>
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 text-gray-500">
                    <FileText className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No blog posts yet</h3>
                    <p className="text-gray-600 mb-6">Create your first blog post to share your travel expertise and attract more clients</p>
                    <Button 
                      onClick={() => setBlogEditorOpen(true)}
                      className="bg-roamah-orange hover:bg-roamah-orange/90"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Create Your First Post
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* My Offers Tab */}
          <TabsContent value="offers" className="space-y-8">
            <Card className="shadow-lg border-0">
              <CardHeader className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-t-lg border-b">
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center text-xl">
                    <Tag className="w-6 h-6 mr-3 text-roamah-orange" />
                    My Holiday Offers
                  </CardTitle>
                  <Button 
                    onClick={() => {
                      setEditingOffer(null);
                      setOfferEditorOpen(true);
                    }}
                    className="bg-roamah-orange hover:bg-roamah-orange/90 shadow-md"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    Create New Offer
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="p-6">
                {offers && offers.length > 0 ? (
                  <div className="space-y-6">
                    {offers.map((offer) => (
                      <div key={offer.id} className="bg-white border border-gray-200 rounded-xl p-6 hover:shadow-lg transition-all duration-200 hover:border-roamah-orange/30">
                        <div className="flex items-start justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-3">
                              <Badge className={`px-3 py-1 text-sm font-medium ${
                                offer.status === 'published' 
                                  ? 'bg-roamah-orange hover:bg-roamah-orange/90 text-white' 
                                  : 'bg-gray-100 text-gray-600'
                              }`}>
                                {offer.status === 'published' ? 'Published' : 'Draft'}
                              </Badge>
                              <Badge variant="secondary" className="bg-blue-50 text-blue-700 border border-blue-200 px-3 py-1.5 text-sm font-medium">
                                {offer.fromPrice}
                              </Badge>
                              {offer.offerMessages && offer.offerMessages.length > 0 && (
                                <Badge className="bg-green-100 text-green-700 border border-green-200 px-2 py-1 text-xs">
                                  {offer.offerMessages[0]}
                                </Badge>
                              )}
                            </div>
                            <h3 className="font-bold text-xl text-gray-900 mb-2">{offer.title}</h3>
                            <p className="text-gray-600 mb-3 line-clamp-2">{offer.briefDescription}</p>
                            <div className="flex flex-wrap gap-1 mb-2">
                              {offer.destinations?.slice(0, 2).map((dest) => (
                                <Badge key={dest} variant="outline" className="text-xs">
                                  {dest}
                                </Badge>
                              ))}
                              {offer.destinations?.length > 2 && (
                                <Badge variant="outline" className="text-xs">
                                  +{offer.destinations.length - 2} more
                                </Badge>
                              )}
                            </div>
                          </div>
                          <div className="flex items-center space-x-2 ml-6">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setPreviewOffer(offer);
                                setShowOfferPreview(true);
                              }}
                              className="border-blue-300 text-blue-600 hover:border-blue-500 hover:text-blue-700"
                            >
                              <Eye className="w-4 h-4" />
                              <span className="ml-1 hidden sm:inline">Preview</span>
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setEditingOffer(offer);
                                setOfferEditorOpen(true);
                              }}
                              className="border-gray-300 hover:border-roamah-orange hover:text-roamah-orange"
                            >
                              <Edit className="w-4 h-4" />
                              <span className="ml-1 hidden sm:inline">Edit</span>
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-red-600 hover:text-red-700 hover:bg-red-50"
                              onClick={() => {
                                toast({
                                  title: "Coming Soon",
                                  description: "Offer deletion feature will be available soon",
                                });
                              }}
                            >
                              <Trash2 className="w-4 h-4" />
                              <span className="ml-1 hidden sm:inline">Delete</span>
                            </Button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-12 text-gray-500">
                    <Tag className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No holiday offers yet</h3>
                    <p className="text-gray-600 mb-6">Create your first holiday offer to attract clients with special packages and deals</p>
                    <Button 
                      onClick={() => {
                        setEditingOffer(null);
                        setOfferEditorOpen(true);
                      }}
                      className="bg-roamah-orange hover:bg-roamah-orange/90"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Create Your First Offer
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Reviews Tab */}
          <TabsContent value="reviews" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Customer Reviews</h2>
                <p className="text-gray-600 mt-1">
                  {reviews.length === 0 ? 'No reviews yet' : 
                   `${reviews.length} reviews • ${profile?.rating}/5.0 average rating`}
                </p>
              </div>
              <div className="flex items-center space-x-2">
                <Star className="w-5 h-5 text-yellow-400 fill-current" />
                <span className="text-2xl font-bold">{profile?.rating}</span>
                <span className="text-gray-500">({profile?.reviewCount} reviews)</span>
              </div>
            </div>

            {reviews.length === 0 ? (
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-12 text-gray-500">
                    <Star className="w-16 h-16 mx-auto mb-4 opacity-30" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No reviews yet</h3>
                    <p className="text-gray-600 max-w-sm mx-auto">
                      When customers leave reviews about their travel experiences with you, they'll appear here. 
                      Provide excellent service to start collecting positive reviews!
                    </p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {reviews.map((review: any) => (
                  <Card key={review.id} className="hover:shadow-md transition-all duration-200">
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        {/* Header with customer info and rating */}
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center space-x-3">
                              <h3 className="font-semibold text-lg text-gray-900">
                                {review.customerName}
                              </h3>
                              {review.isVerified && (
                                <Badge className="bg-green-50 text-green-700 border border-green-200 text-xs">
                                  ✓ Verified
                                </Badge>
                              )}
                            </div>
                            <p className="text-sm text-gray-500">
                              {new Date(review.createdAt).toLocaleDateString('en-US', {
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric'
                              })}
                            </p>
                          </div>
                          <div className="flex items-center space-x-1">
                            {Array.from({ length: 5 }, (_, i) => (
                              <Star
                                key={i}
                                className={`w-5 h-5 ${
                                  i < review.rating
                                    ? "text-yellow-400 fill-current"
                                    : "text-gray-300"
                                }`}
                              />
                            ))}
                          </div>
                        </div>

                        {/* Trip type */}
                        <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
                          <p className="text-sm font-medium text-blue-800">
                            Trip: {review.tripType}
                          </p>
                        </div>

                        {/* Review text */}
                        <div className="bg-gray-50 rounded-lg p-4">
                          <p className="text-gray-900 leading-relaxed italic">
                            "{review.reviewText}"
                          </p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Profile Tab */}
          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
                <CardDescription>Manage your public profile details</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {isEditing ? (
                  // Edit mode
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <Label htmlFor="firstName">First Name</Label>
                        <Input
                          id="firstName"
                          value={editForm.firstName}
                          onChange={(e) => setEditForm({...editForm, firstName: e.target.value})}
                          placeholder="Enter first name"
                        />
                      </div>
                      <div>
                        <Label htmlFor="lastName">Last Name</Label>
                        <Input
                          id="lastName"
                          value={editForm.lastName}
                          onChange={(e) => setEditForm({...editForm, lastName: e.target.value})}
                          placeholder="Enter last name"
                        />
                      </div>
                      <div>
                        <Label htmlFor="location">Location</Label>
                        <Input
                          id="location"
                          value={editForm.location}
                          onChange={(e) => setEditForm({...editForm, location: e.target.value})}
                          placeholder="Enter your location"
                        />
                      </div>
                      <div>
                        <Label htmlFor="company">Company/Business</Label>
                        <Input
                          id="company"
                          value={editForm.company}
                          onChange={(e) => setEditForm({...editForm, company: e.target.value})}
                          placeholder="Enter company name"
                        />
                      </div>
                      <div>
                        <Label htmlFor="yearsExperience">Years Experience</Label>
                        <Input
                          id="yearsExperience"
                          type="number"
                          value={editForm.yearsExperience}
                          onChange={(e) => setEditForm({...editForm, yearsExperience: parseInt(e.target.value) || 0})}
                          placeholder="Years of experience"
                        />
                      </div>
                      <div>
                        <Label htmlFor="nextHoliday">Next Holiday Recommendation</Label>
                        <Input
                          id="nextHoliday"
                          value={editForm.nextHoliday}
                          onChange={(e) => setEditForm({...editForm, nextHoliday: e.target.value})}
                          placeholder="Where should clients visit next?"
                        />
                      </div>
                    </div>

                    <div>
                      <Label htmlFor="bio">About Me Bio</Label>
                      <Textarea
                        id="bio"
                        value={editForm.bio}
                        onChange={(e) => setEditForm({...editForm, bio: e.target.value})}
                        placeholder="Tell clients about yourself, your experience, and expertise..."
                        rows={6}
                        className="resize-none"
                      />
                      <p className="text-xs text-gray-500 mt-1">{editForm.bio.length} characters</p>
                    </div>

                    <div className="flex justify-end space-x-2">
                      <Button variant="outline" onClick={() => setIsEditing(false)}>
                        Cancel
                      </Button>
                      <Button onClick={saveProfileChanges} className="bg-green-600 hover:bg-green-700">
                        Save Changes
                      </Button>
                    </div>
                  </div>
                ) : (
                  // View mode
                  <>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="font-medium mb-3">Personal Information</h4>
                        <div className="space-y-2 text-sm">
                          <p><span className="font-medium">Name:</span> {profile.firstName} {profile.lastName}</p>
                          <p><span className="font-medium">Email:</span> {profile.email}</p>
                          <p><span className="font-medium">Location:</span> {profile.location}</p>
                          <p><span className="font-medium">Company:</span> {profile.company}</p>
                          <p><span className="font-medium">Experience:</span> {profile.yearsExperience} years</p>
                        </div>
                      </div>
                      
                      <div>
                        <h4 className="font-medium mb-3">Specializations</h4>
                        <div className="flex flex-wrap gap-2">
                          {profile.specializations.map((spec) => (
                            <Badge key={spec} variant="secondary" className="bg-orange-100 text-orange-800">
                              {spec}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium mb-3">Expert Destinations</h4>
                      <div className="flex flex-wrap gap-2">
                        {profile.destinations.map((dest) => (
                          <Badge key={dest} variant="secondary" className="bg-blue-100 text-blue-800">
                            {dest}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium mb-3">Languages</h4>
                      <div className="flex flex-wrap gap-2">
                        {profile.languages.map((lang) => (
                          <Badge key={lang} variant="secondary" className="bg-gray-100 text-gray-800">
                            {lang}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium mb-3">About Me</h4>
                      <p className="text-sm text-gray-600 leading-relaxed">{profile.bio}</p>
                    </div>
                  </>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          {/* Other tabs placeholder */}

          <TabsContent value="enquiries" className="space-y-6">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-gray-900">Customer Enquiries</h2>
                <p className="text-gray-600 mt-1">
                  {enquiries.length === 0 ? 'No enquiries yet' : 
                   unreadCount > 0 ? `${unreadCount} new enquiries` : 'All enquiries read'}
                </p>
              </div>
              <div className="flex items-center gap-3">
                {unreadCount > 0 && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={handleMarkAllAsRead}
                    disabled={markAllEnquiriesAsReadMutation.isPending}
                    className="text-roamah-orange border-roamah-orange hover:bg-roamah-orange hover:text-white"
                  >
                    {markAllEnquiriesAsReadMutation.isPending ? (
                      <>
                        <Clock className="w-4 h-4 mr-2" />
                        Marking...
                      </>
                    ) : (
                      <>
                        <CheckCircle className="w-4 h-4 mr-2" />
                        Mark All as Read
                      </>
                    )}
                  </Button>
                )}
                {unreadCount > 0 && (
                  <Badge className="bg-red-500 text-white px-3 py-1 text-sm">
                    {unreadCount} New
                  </Badge>
                )}
              </div>
            </div>

            {enquiries.length === 0 ? (
              <Card>
                <CardContent className="pt-6">
                  <div className="text-center py-12 text-gray-500">
                    <MessageSquare className="w-16 h-16 mx-auto mb-4 opacity-30" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">No enquiries yet</h3>
                    <p className="text-gray-600 max-w-sm mx-auto">
                      When customers send you enquiries through your profile, they'll appear here. 
                      Make sure your profile is complete to attract more enquiries!
                    </p>
                  </div>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {enquiries.map((enquiry: any) => (
                  <Card 
                    key={enquiry.id} 
                    className={`transition-all duration-200 hover:shadow-md ${
                      !enquiry.isRead ? 'ring-2 ring-roamah-orange/20 bg-roamah-orange/5' : 'hover:bg-gray-50/50'
                    }`}
                  >
                    <CardContent className="pt-6">
                      <div className="space-y-4">
                        {/* Header with customer info and status */}
                        <div className="flex items-start justify-between">
                          <div className="space-y-1">
                            <div className="flex items-center space-x-2">
                              <h3 className="font-semibold text-lg text-gray-900">
                                {enquiry.firstName} {enquiry.lastName}
                              </h3>
                              {!enquiry.isRead && (
                                <Badge className="bg-roamah-orange text-white text-xs px-2 py-0.5">
                                  NEW
                                </Badge>
                              )}
                            </div>
                            <p className="text-gray-600">{enquiry.email}</p>
                            <p className="text-sm text-gray-500">
                              {new Date(enquiry.createdAt).toLocaleDateString('en-US', {
                                year: 'numeric',
                                month: 'long',
                                day: 'numeric',
                                hour: '2-digit',
                                minute: '2-digit'
                              })}
                            </p>
                          </div>
                          {!enquiry.isRead && (
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleMarkAsRead(enquiry.id)}
                              disabled={markEnquiryAsReadMutation.isPending}
                              className="text-roamah-orange border-roamah-orange hover:bg-roamah-orange hover:text-white"
                            >
                              Mark as Read
                            </Button>
                          )}
                        </div>

                        {/* Travel details */}
                        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 py-4 px-4 bg-gray-50 rounded-lg">
                          <div>
                            <p className="text-sm font-medium text-gray-500">Adults</p>
                            <p className="text-sm text-gray-900">{enquiry.numberOfAdults || 0}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-500">Children</p>
                            <p className="text-sm text-gray-900">{enquiry.numberOfChildren || 0}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-500">Budget Per Person</p>
                            <p className="text-sm text-gray-900">{enquiry.budgetPerPerson || 'Not specified'}</p>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-500">Phone</p>
                            <p className="text-sm text-gray-900">{enquiry.phoneNumber || 'Not provided'}</p>
                          </div>
                        </div>

                        {/* Additional Travel Information */}
                        <div className="space-y-4">
                          {/* Children Ages */}
                          {enquiry.childrenAges && enquiry.childrenAges.length > 0 && (
                            <div>
                              <p className="text-sm font-medium text-gray-500 mb-1">Children Ages</p>
                              <div className="flex gap-2">
                                {enquiry.childrenAges.map((age: number, index: number) => (
                                  <Badge key={index} variant="outline" className="text-xs">
                                    {age} years
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Destinations */}
                          {enquiry.destinations && enquiry.destinations.length > 0 && (
                            <div>
                              <p className="text-sm font-medium text-gray-500 mb-2">Interested Destinations</p>
                              <div className="flex flex-wrap gap-2">
                                {enquiry.destinations.map((dest: string, index: number) => (
                                  <Badge key={index} className="bg-blue-50 text-blue-700 border border-blue-200">
                                    📍 {dest}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Holiday Types */}
                          {enquiry.holidayTypes && enquiry.holidayTypes.length > 0 && (
                            <div>
                              <p className="text-sm font-medium text-gray-500 mb-2">Holiday Types</p>
                              <div className="flex flex-wrap gap-2">
                                {enquiry.holidayTypes.map((type: string, index: number) => (
                                  <Badge key={index} className="bg-green-50 text-green-700 border border-green-200">
                                    🌟 {type}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          )}

                          {/* Travel Timing */}
                          {((enquiry.travelMonths && enquiry.travelMonths.length > 0) || enquiry.travelYear) && (
                            <div>
                              <p className="text-sm font-medium text-gray-500 mb-2">Travel Timing</p>
                              <div className="bg-purple-50 border border-purple-200 rounded-lg p-3">
                                <div className="flex items-center gap-2">
                                  <Badge className="bg-purple-100 text-purple-700 border border-purple-200">
                                    📅 {(enquiry.travelMonths && enquiry.travelMonths.length > 0) 
                                      ? enquiry.travelMonths.join(', ') 
                                      : 'Not specified'} {enquiry.travelYear || ''}
                                  </Badge>
                                </div>
                              </div>
                            </div>
                          )}

                          {/* Callback Preferences */}
                          {(enquiry.preferredCallbackTime || enquiry.preferredCallbackDate) && (
                            <div>
                              <p className="text-sm font-medium text-gray-500 mb-2">Callback Preferences</p>
                              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                                {enquiry.preferredCallbackTime && (
                                  <p className="text-sm text-yellow-800">
                                    <strong>Preferred Time:</strong> {enquiry.preferredCallbackTime}
                                  </p>
                                )}
                                {enquiry.preferredCallbackDate && (
                                  <p className="text-sm text-yellow-800">
                                    <strong>Preferred Date:</strong> {enquiry.preferredCallbackDate}
                                  </p>
                                )}
                              </div>
                            </div>
                          )}
                        </div>

                        {/* Enquiry details */}
                        <div>
                          <p className="text-sm font-medium text-gray-500 mb-2">Enquiry Details</p>
                          <div className="bg-white p-4 border border-gray-200 rounded-lg">
                            <p className="text-gray-900 whitespace-pre-wrap">{enquiry.enquiryDetails}</p>
                          </div>
                        </div>

                        {/* Action buttons */}
                        <div className="flex items-center space-x-3 pt-2">
                          <Button 
                            size="sm" 
                            className="bg-roamah-orange hover:bg-roamah-orange/90"
                            onClick={() => {
                              const destinations = enquiry.destinations && enquiry.destinations.length > 0 ? enquiry.destinations.join(', ') : 'your travel plans';
                              const holidayTypes = enquiry.holidayTypes && enquiry.holidayTypes.length > 0 ? enquiry.holidayTypes.join(' and ') : 'holiday';
                              window.open(`mailto:${enquiry.email}?subject=Re: Your Travel Enquiry&body=Hi ${enquiry.firstName},%0A%0AThank you for your enquiry about ${destinations}. I'd be delighted to help you plan your ${holidayTypes} experience.%0A%0ABest regards,%0A${profile?.firstName} ${profile?.lastName}`, '_blank');
                            }}
                          >
                            Reply via Email
                          </Button>
                          <Button variant="outline" size="sm">
                            Save Notes
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>


        </Tabs>
      </div>

      {/* Blog Editor Modal */}
      {blogEditorOpen && (
        <BlogEditor
          onClose={() => {
            setBlogEditorOpen(false);
            setEditingBlog(null);
          }}
          existingPost={editingBlog}
        />
      )}

      {/* Offer Editor Modal */}
      {offerEditorOpen && (
        <OfferEditor
          offer={editingOffer}
          isOpen={offerEditorOpen}
          onClose={() => {
            setOfferEditorOpen(false);
            setEditingOffer(null);
          }}
        />
      )}

      {/* Profile Image Crop Modal */}
      <Dialog open={cropModalOpen} onOpenChange={setCropModalOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-hidden">
          <DialogHeader>
            <DialogTitle>Crop Profile Image</DialogTitle>
            <DialogDescription>
              Adjust your profile image by cropping, rotating, and scaling as needed.
            </DialogDescription>
          </DialogHeader>
          
          <div className="flex flex-col space-y-4 max-h-[70vh] overflow-y-auto">
            {originalImage && (
              <div className="relative">
                <ReactCrop
                  crop={crop}
                  onChange={(c) => setCrop(c)}
                  aspect={1}
                  className="max-h-96"
                >
                  <img
                    src={originalImage}
                    alt="Crop preview"
                    onLoad={onImageLoad}
                    style={{
                      transform: `scale(${scale}) rotate(${rotation}deg)`,
                      maxHeight: '400px',
                      maxWidth: '100%',
                    }}
                  />
                </ReactCrop>
              </div>
            )}
            
            {/* Controls */}
            <div className="space-y-4 px-2">
              <div>
                <Label className="text-sm font-medium">Scale: {scale.toFixed(2)}</Label>
                <Slider
                  value={[scale]}
                  onValueChange={(values) => setScale(values[0])}
                  min={0.5}
                  max={2}
                  step={0.1}
                  className="mt-2"
                />
              </div>
              
              <div className="flex items-center space-x-4">
                <Label className="text-sm font-medium">Rotation:</Label>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setRotation((prev) => (prev - 90) % 360)}
                >
                  <RotateCw className="w-4 h-4 mr-1 transform scale-x-[-1]" />
                  -90°
                </Button>
                <span className="text-sm text-gray-600">{rotation}°</span>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setRotation((prev) => (prev + 90) % 360)}
                >
                  <RotateCw className="w-4 h-4 mr-1" />
                  +90°
                </Button>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setCropModalOpen(false)}
              disabled={uploadingProfileImage}
            >
              <X className="w-4 h-4 mr-2" />
              Cancel
            </Button>
            <Button
              onClick={saveCroppedProfileImage}
              disabled={uploadingProfileImage}
              className="bg-roamah-orange hover:bg-roamah-orange/90"
            >
              {uploadingProfileImage ? (
                <>
                  <Upload className="w-4 h-4 mr-2 animate-spin" />
                  Uploading...
                </>
              ) : (
                <>
                  <Save className="w-4 h-4 mr-2" />
                  Save Profile Image
                </>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Offer Preview Modal */}
      {showOfferPreview && previewOffer && (
        <OfferPreviewModal
          offer={{
            ...previewOffer,
            agentName: `${profile?.firstName} ${profile?.lastName}`,
            agentImage: profile?.profileImage,
            agentLocation: profile?.location,
            agentRating: profile?.rating,
          }}
          isOpen={showOfferPreview}
          onClose={() => {
            setShowOfferPreview(false);
            setPreviewOffer(null);
          }}
        />
      )}
    </div>
  );
}