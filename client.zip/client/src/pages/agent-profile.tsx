import { useState, useRef, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { StarRating } from "@/components/ui/star-rating";
import { EnquiryModal } from "@/components/ui/enquiry-modal";
import { OfferImageCarousel } from "@/components/OfferImageCarousel";
import { MapPin, ArrowRight, Camera, Play, Star, ChevronLeft, ChevronRight, X, Check } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Link } from "wouter";
import type { Agent, Review, BlogPost, Offer } from "@shared/schema";

export default function AgentProfile() {
  const [, params] = useRoute("/agent/:id");
  const agentId = params?.id ? parseInt(params.id) : 0;
  const [enquiryModalOpen, setEnquiryModalOpen] = useState(false);
  const [isExpanded, setIsExpanded] = useState(false);
  const [galleryOpen, setGalleryOpen] = useState(false);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [currentBlogPage, setCurrentBlogPage] = useState(0);
  const [currentReviewIndex, setCurrentReviewIndex] = useState(0);
  const [currentOfferPage, setCurrentOfferPage] = useState(0);
  const [videoThumbnail, setVideoThumbnail] = useState<string | null>(null);
  const [showVideo, setShowVideo] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const { data: agent, isLoading: agentLoading } = useQuery<Agent>({
    queryKey: ["/api/agents", agentId],
    enabled: !!agentId,
  });

  const { data: reviews = [], isLoading: reviewsLoading } = useQuery<Review[]>({
    queryKey: ["/api/agents", agentId, "reviews"],
    enabled: !!agentId,
  });

  const { data: blogPosts = [], isLoading: blogLoading } = useQuery<BlogPost[]>({
    queryKey: ["/api/agents", agentId, "blog"],
    enabled: !!agentId,
  });

  const { data: offers = [], isLoading: offersLoading } = useQuery<Offer[]>({
    queryKey: ["/api/agents", agentId, "offers"],
    enabled: !!agentId,
  });

  // Generate video thumbnail when agent video loads
  useEffect(() => {
    if (agent?.videoUrl && !showVideo) {
      generateVideoThumbnail(agent.videoUrl);
    }
  }, [agent?.videoUrl, showVideo]);

  // Auto-rotate reviews carousel (3 cards at a time)
  useEffect(() => {
    if (reviews.length > 3) {
      const interval = setInterval(() => {
        setCurrentReviewIndex((prev) => {
          const maxIndex = Math.max(0, reviews.length - 3);
          return prev >= maxIndex ? 0 : prev + 1;
        });
      }, 5000); // Rotate every 5 seconds

      return () => clearInterval(interval);
    }
  }, [reviews.length]);

  const nextReview = () => {
    setCurrentReviewIndex((prev) => {
      const maxIndex = Math.max(0, reviews.length - 3);
      return prev >= maxIndex ? 0 : prev + 1;
    });
  };

  const prevReview = () => {
    setCurrentReviewIndex((prev) => {
      const maxIndex = Math.max(0, reviews.length - 3);
      return prev <= 0 ? maxIndex : prev - 1;
    });
  };

  const generateVideoThumbnail = (videoUrl: string) => {
    const video = document.createElement('video');
    video.crossOrigin = 'anonymous';
    video.currentTime = 2; // Capture frame at 2 seconds
    
    video.addEventListener('loadeddata', () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      if (ctx) {
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        ctx.drawImage(video, 0, 0);
        
        const thumbnailDataUrl = canvas.toDataURL('image/jpeg', 0.8);
        setVideoThumbnail(thumbnailDataUrl);
      }
    });
    
    video.src = videoUrl;
    video.load();
  };

  if (agentLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <main className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="animate-pulse">
              <div className="bg-gray-200 h-64 rounded-2xl mb-8"></div>
              <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
                <div>
                  <div className="bg-gray-200 h-96 rounded"></div>
                </div>
                <div className="lg:col-span-3">
                  <div className="bg-gray-200 h-32 rounded mb-4"></div>
                  <div className="bg-gray-200 h-48 rounded"></div>
                </div>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!agent) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <main className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Agent not found</h1>
            <p className="text-gray-600">The agent you're looking for doesn't exist.</p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Left Sidebar */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-2xl p-6 shadow-lg sticky top-8">
                {/* Profile Image */}
                <div className="text-center mb-6">
                  <img
                    src={agent.profileImage || '/default-profile.jpg'}
                    alt={agent.name || 'Agent'}
                    className="w-full aspect-square rounded-xl object-cover mx-auto mb-4 border-4 border-gray-100"
                  />
                  <h1 className="text-2xl font-bold text-black mb-2">{agent.name}</h1>
                  <div className="flex items-center justify-center mb-2">
                    <StarRating 
                      rating={parseFloat(agent.rating)} 
                      reviewCount={agent.reviewCount}
                      showCount={true}
                      size="sm"
                    />
                  </div>
                  <div className="flex items-center justify-center text-black mb-4">
                    <MapPin className="h-4 w-4 mr-1" />
                    <span className="font-bold">{agent.location}</span>
                  </div>
                  <p className="text-sm text-black mb-4 font-bold">{agent.company}</p>
                  
                  {/* Financial Protection */}
                  {agent.hasFinancialProtection && agent.protectionBodies && agent.protectionBodies.length > 0 && (
                    <div className="mb-4 text-center">
                      <div className="space-y-1">
                        {agent.protectionBodies.map((body, index) => {
                          const licenseNumber = agent.licenseNumbers && typeof agent.licenseNumbers === 'object' ? (agent.licenseNumbers as Record<string, string>)[body] : undefined;
                          return (
                            <div key={index} className="flex items-center justify-center text-sm text-green-700">
                              <Check className="w-4 h-4 mr-2 text-green-600" />
                              <span className="font-medium">{body} Protected</span>
                              {licenseNumber && (
                                <span className="font-medium ml-2 text-green-600">({licenseNumber})</span>
                              )}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  )}
                  
                  {agent.nextHoliday && (
                    <p className="text-sm text-black mb-6 font-bold">Next holiday: {agent.nextHoliday}</p>
                  )}
                </div>

                {/* Enquire Button */}
                <Button 
                  className="w-full bg-roamah-orange hover:bg-roamah-orange/90 text-white font-bold mb-6"
                  onClick={() => setEnquiryModalOpen(true)}
                >
                  Send {agent.name?.split(' ')[0] || 'Agent'} an enquiry
                </Button>



                {/* Specialises in */}
                <div className="mb-6">
                  <h3 className="font-bold text-black mb-3">Specialises in</h3>
                  <div className="space-y-2">
                    {agent.specializations?.map((spec, index) => {
                      const holidayColors = [
                        "bg-green-100 text-green-800",
                        "bg-orange-100 text-orange-800",
                        "bg-blue-100 text-blue-800",
                        "bg-purple-100 text-purple-800",
                        "bg-pink-100 text-pink-800"
                      ];
                      return (
                        <div key={index} className={`w-full ${holidayColors[index % holidayColors.length]} text-sm py-2 px-3 rounded-md text-center font-bold`}>
                          {spec}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Expert destinations */}
                <div className="mb-6">
                  <h3 className="font-bold text-black mb-3">Expert destinations</h3>
                  <div className="space-y-2">
                    {agent.destinations?.map((dest, index) => {
                      const destinationColors = [
                        "bg-blue-100 text-blue-800",
                        "bg-purple-100 text-purple-800", 
                        "bg-teal-100 text-teal-800",
                        "bg-pink-100 text-pink-800",
                        "bg-indigo-100 text-indigo-800",
                        "bg-green-100 text-green-800",
                        "bg-orange-100 text-orange-800"
                      ];
                      return (
                        <div key={index} className={`w-full ${destinationColors[index % destinationColors.length]} text-sm py-2 px-3 rounded-md text-center font-bold`}>
                          {dest}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Languages spoken */}
                <div>
                  <h3 className="font-bold text-black mb-3">Languages spoken</h3>
                  <div className="space-y-2">
                    {agent.languages?.map((lang, index) => (
                      <div key={index} className="w-full bg-gray-100 text-black text-sm py-2 px-3 rounded-md text-center font-bold">
                        {lang}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Main Content */}
            <div className="lg:col-span-3 space-y-8">
              {/* 1. About Me */}
              <section className="bg-white rounded-2xl p-8 shadow-lg">
                <h2 className="text-2xl font-bold text-black mb-6">About me</h2>
                <div className="text-black leading-relaxed">
                  <p>
                    {agent.bio && agent.bio.length > 500 && !isExpanded
                      ? agent.bio.substring(0, 500) + '...'
                      : agent.bio}
                  </p>
                  {agent.bio && agent.bio.length > 500 && (
                    <button
                      onClick={() => setIsExpanded(!isExpanded)}
                      className="mt-3 text-roamah-orange hover:text-roamah-orange/80 font-medium transition-colors"
                    >
                      {isExpanded ? 'Show less' : 'Read more'}
                    </button>
                  )}
                </div>
              </section>

              {/* 2. My Travel Experiences */}
              <section className="bg-white rounded-2xl p-8 shadow-lg">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold text-black">My travel experiences</h2>
                  <Button variant="ghost" className="text-roamah-orange">
                    View more photos <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
                
                {agent.photos && agent.photos.length > 0 ? (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {agent.photos.map((photo, index) => (
                      <div 
                        key={index} 
                        className="relative group cursor-pointer"
                        onClick={() => {
                          console.log('Photo clicked:', index);
                          setCurrentImageIndex(index);
                          setGalleryOpen(true);
                        }}
                      >
                        <img
                          src={photo}
                          alt={`Travel photo ${index + 1}`}
                          className="w-full aspect-square object-cover rounded-xl hover:opacity-90 transition-opacity"
                        />
                        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity rounded-xl flex items-center justify-center pointer-events-none">
                          <div className="bg-white/90 px-3 py-1 rounded-full text-sm font-medium">
                            View Full Size
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                    {[1, 2, 3, 4, 5, 6, 7, 8].map((index) => (
                      <div key={index} className="bg-gray-200 rounded-xl aspect-square flex items-center justify-center">
                        <Camera className="w-8 h-8 text-gray-400" />
                      </div>
                    ))}
                  </div>
                )}
                {(!agent.photos || agent.photos.length === 0) && (
                  <p className="text-black text-sm mt-4 text-center">
                    Travel experience photos will be displayed here
                  </p>
                )}
              </section>

              {/* 3. Introduction Video - Only show if video exists */}
              {agent.videoUrl && (
                <section className="bg-white rounded-2xl p-8 shadow-lg">
                  <h2 className="text-2xl font-bold text-black mb-6">Introduction Video</h2>
                  <div className="relative rounded-xl overflow-hidden">
                    {!showVideo ? (
                      // Video Thumbnail with Play Button
                      <div 
                        className="relative h-80 cursor-pointer group"
                        onClick={() => setShowVideo(true)}
                      >
                        {videoThumbnail ? (
                          <img
                            src={videoThumbnail}
                            alt="Video thumbnail"
                            className="w-full h-full object-cover"
                          />
                        ) : (
                          <div className="w-full h-full bg-gray-900 flex items-center justify-center">
                            <div className="text-white text-center">
                              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-white mx-auto mb-2"></div>
                              <p className="text-sm">Loading video...</p>
                            </div>
                          </div>
                        )}
                        
                        {/* Play Button Overlay */}
                        <div className="absolute inset-0 bg-black/20 flex items-center justify-center group-hover:bg-black/30 transition-all duration-300">
                          <div className="w-20 h-20 bg-white/90 rounded-full flex items-center justify-center group-hover:bg-white group-hover:scale-110 transition-all duration-300 shadow-lg">
                            <Play className="w-8 h-8 text-roamah-orange ml-1" />
                          </div>
                        </div>
                        
                        {/* Video Duration Badge (if available) */}
                        <div className="absolute bottom-4 right-4 bg-black/70 text-white px-2 py-1 rounded text-sm">
                          Click to play
                        </div>
                      </div>
                    ) : (
                      // Actual Video Player
                      <video
                        ref={videoRef}
                        src={agent.videoUrl}
                        controls
                        autoPlay
                        className="w-full h-80 object-cover"
                        onEnded={() => setShowVideo(false)}
                      >
                        Your browser does not support the video tag.
                      </video>
                    )}
                    
                    {/* Hidden canvas for thumbnail generation */}
                    <canvas ref={canvasRef} className="hidden" />
                  </div>
                </section>
              )}

              {/* 4. Customer Reviews */}
              <section className="bg-white rounded-2xl p-8 shadow-lg">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold text-black">Customer Reviews</h2>
                  <Button variant="ghost" className="text-roamah-orange">
                    View all reviews <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
                
                {reviews.length > 0 ? (
                  <div className="relative">
                    {/* Carousel Container */}
                    <div className="overflow-hidden">
                      <div 
                        className="flex transition-transform duration-500 ease-in-out"
                        style={{ transform: `translateX(-${currentReviewIndex * (100/3)}%)` }}
                      >
                        {reviews.map((review) => (
                          <div key={review.id} className="w-1/3 flex-shrink-0 px-2">
                            <div className="border border-gray-200 rounded-xl p-4 bg-gradient-to-br from-white to-gray-50 h-full">
                              <div className="flex flex-col space-y-3 h-full">
                                <div className="flex items-center justify-between">
                                  <h4 className="font-semibold text-black text-sm">{review.customerName}</h4>
                                  <div className="flex items-center">
                                    {Array.from({ length: 5 }, (_, i) => (
                                      <Star
                                        key={i}
                                        className={`w-3 h-3 ${
                                          i < review.rating
                                            ? "text-yellow-400 fill-current"
                                            : "text-gray-300"
                                        }`}
                                      />
                                    ))}
                                  </div>
                                </div>
                                <p className="text-black text-sm italic flex-1 line-clamp-4">"{review.reviewText}"</p>
                                <div className="space-y-1">
                                  <p className="text-xs font-medium text-blue-700">{review.tripType}</p>
                                  <div className="flex items-center text-xs text-gray-500">
                                    <span>{new Date(review.createdAt).toLocaleDateString()}</span>
                                    {review.isVerified && (
                                      <>
                                        <span className="mx-1">•</span>
                                        <span className="text-green-600 font-medium">✓ Verified</span>
                                      </>
                                    )}
                                  </div>
                                </div>
                              </div>
                            </div>
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Navigation Controls */}
                    {reviews.length > 3 && (
                      <div className="flex justify-center items-center mt-6 space-x-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={prevReview}
                          disabled={currentReviewIndex === 0}
                          className="bg-white hover:bg-gray-50"
                        >
                          <ChevronLeft className="w-4 h-4 mr-1" />
                          Previous
                        </Button>
                        
                        <div className="flex space-x-2">
                          {Array.from({ length: Math.max(1, reviews.length - 2) }, (_, index) => (
                            <button
                              key={index}
                              onClick={() => setCurrentReviewIndex(index)}
                              className={`w-3 h-3 rounded-full transition-colors ${
                                currentReviewIndex === index ? 'bg-roamah-orange' : 'bg-gray-300 hover:bg-gray-400'
                              }`}
                            />
                          ))}
                        </div>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={nextReview}
                          disabled={currentReviewIndex >= Math.max(0, reviews.length - 3)}
                          className="bg-white hover:bg-gray-50"
                        >
                          Next
                          <ChevronRight className="w-4 h-4 ml-1" />
                        </Button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-black">No reviews available yet</p>
                  </div>
                )}
              </section>

              {/* 5. Top Offers */}
              <section className="bg-white rounded-2xl p-8 shadow-lg">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold text-black">Top Offers</h2>
                  <Button variant="ghost" className="text-roamah-orange">
                    View all offers <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
                
                {offers.length > 0 ? (
                  <div className="relative">
                    {/* Carousel Container */}
                    <div className="overflow-hidden">
                      <div 
                        className="flex transition-transform duration-300 ease-in-out gap-6"
                        style={{ transform: `translateX(-${currentOfferPage * 100}%)` }}
                      >
                        {Array.from({ length: Math.ceil(offers.slice(0, 6).length / 3) }, (_, pageIndex) => (
                          <div key={pageIndex} className="flex-none w-full grid grid-cols-1 md:grid-cols-3 gap-6">
                            {offers.slice(0, 6).slice(pageIndex * 3, pageIndex * 3 + 3).map((offer) => (
                              <div key={offer.id} className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all group h-full flex flex-col">
                                {/* Hero image carousel */}
                                <OfferImageCarousel offer={offer} />
                                
                                <div className="p-6 flex flex-col flex-grow">
                                  {/* Badges */}
                                  <div className="flex flex-wrap gap-2 mb-3">
                                    {offer.destinations?.map((dest, index) => (
                                      <Badge key={`dest-${index}`} className="bg-blue-100 text-blue-800 border-0">
                                        <MapPin className="w-3 h-3 mr-1" />
                                        {dest}
                                      </Badge>
                                    ))}
                                    {offer.holidayTypes?.map((type, index) => (
                                      <Badge key={`type-${index}`} className="bg-green-100 text-green-800 border-0">
                                        {type}
                                      </Badge>
                                    ))}
                                  </div>
                                  
                                  <h4 className="font-bold text-xl text-black mb-2 line-clamp-2">
                                    {offer.title}
                                  </h4>
                                  
                                  <p className="text-black text-sm mb-4 line-clamp-2">
                                    {offer.briefDescription}
                                  </p>
                                  
                                  {/* Offer messages as bullet points */}
                                  <div className="mb-4 space-y-1 flex-grow">
                                    {offer.offerMessage1 && (
                                      <div className="flex items-start text-sm text-black">
                                        <span className="w-1.5 h-1.5 bg-roamah-orange rounded-full mr-2 mt-1.5 flex-shrink-0"></span>
                                        <span className="line-clamp-1">{offer.offerMessage1}</span>
                                      </div>
                                    )}
                                    {offer.offerMessage2 && (
                                      <div className="flex items-start text-sm text-black">
                                        <span className="w-1.5 h-1.5 bg-roamah-orange rounded-full mr-2 mt-1.5 flex-shrink-0"></span>
                                        <span className="line-clamp-1">{offer.offerMessage2}</span>
                                      </div>
                                    )}
                                    {offer.offerMessage3 && (
                                      <div className="flex items-start text-sm text-black">
                                        <span className="w-1.5 h-1.5 bg-roamah-orange rounded-full mr-2 mt-1.5 flex-shrink-0"></span>
                                        <span className="line-clamp-1">{offer.offerMessage3}</span>
                                      </div>
                                    )}
                                  </div>
                                  
                                  <Link href={`/offer/${offer.id}`}>
                                    <Button className="w-full bg-roamah-orange hover:bg-roamah-orange/90 text-white font-semibold mt-auto">
                                      View Offer Details
                                    </Button>
                                  </Link>
                                </div>
                              </div>
                            ))}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Navigation Controls */}
                    {offers.length > 3 && (
                      <div className="flex justify-center items-center mt-6 space-x-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setCurrentOfferPage(Math.max(0, currentOfferPage - 1))}
                          disabled={currentOfferPage === 0}
                          className="bg-white hover:bg-gray-50"
                        >
                          <ChevronLeft className="w-4 h-4 mr-1" />
                          Previous
                        </Button>
                        
                        <div className="flex space-x-2">
                          {Array.from({ length: Math.ceil(offers.slice(0, 6).length / 3) }, (_, index) => (
                            <button
                              key={index}
                              onClick={() => setCurrentOfferPage(index)}
                              className={`w-3 h-3 rounded-full transition-colors ${
                                currentOfferPage === index ? 'bg-roamah-orange' : 'bg-gray-300 hover:bg-gray-400'
                              }`}
                            />
                          ))}
                        </div>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setCurrentOfferPage(Math.min(Math.ceil(offers.slice(0, 6).length / 3) - 1, currentOfferPage + 1))}
                          disabled={currentOfferPage === Math.ceil(offers.slice(0, 6).length / 3) - 1}
                          className="bg-white hover:bg-gray-50"
                        >
                          Next
                          <ChevronRight className="w-4 h-4 ml-1" />
                        </Button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-black">No offers available yet</p>
                  </div>
                )}
              </section>

              {/* 6. Blog Posts & Content */}
              <section className="bg-white rounded-2xl p-8 shadow-lg">
                <div className="flex justify-between items-center mb-6">
                  <h2 className="text-2xl font-bold text-black">Blog Posts & Content</h2>
                  <Link href="/blogs">
                    <Button variant="ghost" className="text-roamah-orange">
                      View all blogs <ArrowRight className="ml-2 h-4 w-4" />
                    </Button>
                  </Link>
                </div>
                
                {blogPosts.length > 0 ? (
                  <div className="relative">
                    {/* Carousel Container */}
                    <div className="overflow-hidden">
                      <div 
                        className="flex transition-transform duration-300 ease-in-out gap-6"
                        style={{ transform: `translateX(-${currentBlogPage * 100}%)` }}
                      >
                        {Array.from({ length: Math.ceil(blogPosts.length / 2) }, (_, pageIndex) => (
                          <div key={pageIndex} className="flex-none w-full grid grid-cols-1 md:grid-cols-2 gap-6">
                            {blogPosts.slice(pageIndex * 2, pageIndex * 2 + 2).map((post) => (
                              <Card key={post.id} className="group hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col h-full">
                                <Link href={`/blog/${post.slug}`}>
                                  <div className="cursor-pointer flex-1 flex flex-col">
                                    <div className="relative overflow-hidden">
                                      <img
                                        src={post.heroImage ?? 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=600&h=400&fit=crop'}
                                        alt={post.title}
                                        className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
                                      />
                                    </div>
                                    <CardContent className="p-6 flex-1 flex flex-col">
                                      {/* Tags */}
                                      <div className="flex flex-wrap gap-2 mb-3 min-h-[32px]">
                                        {post.holidayTypes?.slice(0, 2).map((type) => (
                                          <Badge key={type} variant="secondary" className="bg-green-100 text-green-800 text-xs h-5 font-normal">
                                            {type}
                                          </Badge>
                                        ))}
                                        {post.destinations?.slice(0, 1).map((dest) => (
                                          <Badge key={dest} variant="secondary" className="bg-blue-100 text-blue-800 text-xs h-5 font-normal">
                                            {dest}
                                          </Badge>
                                        ))}
                                        {(!post.holidayTypes || post.holidayTypes.length === 0) && 
                                         (!post.destinations || post.destinations.length === 0) && (
                                          <Badge variant="secondary" className="bg-green-100 text-green-800 text-xs h-5 font-normal">
                                            Travel Tips
                                          </Badge>
                                        )}
                                      </div>

                                      <h3 className="text-xl font-semibold text-black mb-3 group-hover:text-roamah-orange transition-colors line-clamp-2 min-h-[56px]">
                                        {post.title}
                                      </h3>
                                      <p className="text-black mb-4 line-clamp-3 flex-1">{post.excerpt}</p>
                                    </CardContent>
                                  </div>
                                </Link>
                                
                                {/* Author Info - Fixed at bottom */}
                                <div className="px-6 pb-6 border-t bg-gray-50/50 mt-auto">
                                  <div className="flex items-center pt-4">
                                    <img
                                      src={agent?.profileImage ?? 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face'}
                                      alt={agent?.name ?? 'Agent'}
                                      className="w-10 h-10 rounded-full mr-3 aspect-square object-cover"
                                    />
                                    <div>
                                      <p className="text-sm font-semibold text-black">
                                        {agent?.name ?? 'Travel Agent'}
                                      </p>
                                      <p className="text-xs text-black">
                                        {post.publishedAt ? new Date(post.publishedAt).toLocaleDateString() : new Date(post.createdAt).toLocaleDateString()}
                                      </p>
                                    </div>
                                  </div>
                                </div>
                              </Card>
                            ))}
                          </div>
                        ))}
                      </div>
                    </div>

                    {/* Navigation Controls */}
                    {blogPosts.length > 2 && (
                      <div className="flex justify-center items-center mt-6 space-x-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setCurrentBlogPage(Math.max(0, currentBlogPage - 1))}
                          disabled={currentBlogPage === 0}
                          className="bg-white hover:bg-gray-50"
                        >
                          <ChevronLeft className="w-4 h-4 mr-1" />
                          Previous
                        </Button>
                        
                        <div className="flex space-x-2">
                          {Array.from({ length: Math.ceil(blogPosts.length / 2) }, (_, index) => (
                            <button
                              key={index}
                              onClick={() => setCurrentBlogPage(index)}
                              className={`w-3 h-3 rounded-full transition-colors ${
                                currentBlogPage === index ? 'bg-roamah-orange' : 'bg-gray-300 hover:bg-gray-400'
                              }`}
                            />
                          ))}
                        </div>
                        
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setCurrentBlogPage(Math.min(Math.ceil(blogPosts.length / 2) - 1, currentBlogPage + 1))}
                          disabled={currentBlogPage === Math.ceil(blogPosts.length / 2) - 1}
                          className="bg-white hover:bg-gray-50"
                        >
                          Next
                          <ChevronRight className="w-4 h-4 ml-1" />
                        </Button>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-black">No blog posts available yet</p>
                  </div>
                )}
              </section>
            </div>
          </div>
        </main>

        <Footer />
      </div>

      <EnquiryModal
        isOpen={enquiryModalOpen}
        onClose={() => setEnquiryModalOpen(false)}
        agent={agent}
      />

      {/* Photo Gallery Modal */}
      <Dialog open={galleryOpen} onOpenChange={setGalleryOpen}>
        <DialogContent className="max-w-6xl max-h-[95vh] p-0 bg-black/95">
          <DialogHeader className="absolute top-4 left-4 z-10">
            <DialogTitle className="text-white text-lg">
              Photo {currentImageIndex + 1} of {agent?.photos?.length || 0}
            </DialogTitle>
          </DialogHeader>
          
          <button
            onClick={() => setGalleryOpen(false)}
            className="absolute top-4 right-4 z-10 text-white hover:text-gray-300 transition-colors"
          >
            <X className="w-8 h-8" />
          </button>
          
          <div className="relative h-[85vh] flex items-center justify-center">
            {agent?.photos && agent.photos.length > 0 && (
              <>
                <img
                  src={agent.photos[currentImageIndex]}
                  alt={`Travel photo ${currentImageIndex + 1}`}
                  className="max-w-full max-h-full object-contain"
                />
                
                {/* Navigation Controls */}
                {agent.photos.length > 1 && (
                  <>
                    <button
                      onClick={() => setCurrentImageIndex(
                        currentImageIndex === 0 ? agent.photos!.length - 1 : currentImageIndex - 1
                      )}
                      className="absolute left-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full transition-colors"
                    >
                      <ChevronLeft className="w-6 h-6" />
                    </button>
                    
                    <button
                      onClick={() => setCurrentImageIndex(
                        currentImageIndex === agent.photos!.length - 1 ? 0 : currentImageIndex + 1
                      )}
                      className="absolute right-4 top-1/2 -translate-y-1/2 bg-black/50 hover:bg-black/70 text-white p-3 rounded-full transition-colors"
                    >
                      <ChevronRight className="w-6 h-6" />
                    </button>
                  </>
                )}
              </>
            )}
          </div>
          
          {/* Thumbnail Navigation */}
          {agent?.photos && agent.photos.length > 1 && (
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-2 bg-black/50 p-2 rounded-full">
              {agent.photos.map((photo, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentImageIndex(index)}
                  className={`w-12 h-12 rounded-full overflow-hidden border-2 transition-colors ${
                    index === currentImageIndex ? 'border-white' : 'border-transparent hover:border-gray-400'
                  }`}
                >
                  <img
                    src={photo}
                    alt={`Thumbnail ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}