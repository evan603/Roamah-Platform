import React from 'react';
import { useQuery, useMutation } from '@tanstack/react-query';
import { useLocation } from 'wouter';
import { apiRequest, queryClient } from '@/lib/queryClient';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Mail, Users, BarChart3, Clock, CheckCircle, AlertCircle, ArrowLeft } from 'lucide-react';

interface EmailStats {
  totalEnquiries: number;
  reviewEmailsSent: number;
  reviewsReceived: number;
  conversionRate: string;
}

interface Enquiry {
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  agentName: string;
  destinations: string[];
  holidayTypes: string[];
  budgetPerPerson: string;
  createdAt: string;
  status: string;
}

export default function EmailAutomation() {
  const { toast } = useToast();
  const [, setLocation] = useLocation();

  // Fetch email statistics
  const { data: emailStats, isLoading: statsLoading } = useQuery<EmailStats>({
    queryKey: ['/api/email/stats'],
  });

  // Fetch all enquiries for review workflow management
  const { data: enquiries, isLoading: enquiriesLoading } = useQuery<Enquiry[]>({
    queryKey: ['/api/admin/enquiries'],
  });

  // Trigger review workflow mutation
  const triggerReviewMutation = useMutation({
    mutationFn: async ({ enquiryId, tripType }: { enquiryId: number; tripType: string }) => {
      return apiRequest(`/api/email/trigger-review/${enquiryId}`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('agentToken')}`,
        },
        body: JSON.stringify({ tripType }),
      });
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Review request email sent successfully",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/email/stats'] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to send review request",
        variant: "destructive",
      });
    },
  });

  const handleTriggerReview = (enquiryId: number, tripType: string) => {
    triggerReviewMutation.mutate({ enquiryId, tripType });
  };

  if (statsLoading || enquiriesLoading) {
    return (
      <div className="p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 bg-gray-200 rounded w-1/4"></div>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {[...Array(4)].map((_, i) => (
              <div key={i} className="h-32 bg-gray-200 rounded"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <Button 
            variant="outline" 
            onClick={() => setLocation('/admin/dashboard')}
            className="mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Admin Dashboard
          </Button>
          <h1 className="text-3xl font-bold text-gray-900">Email Automation</h1>
          <p className="text-gray-600 mt-2">Manage automated email workflows and customer segmentation</p>
        </div>
      </div>

      {/* Email Statistics Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Enquiries</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{emailStats?.totalEnquiries || 0}</div>
            <p className="text-xs text-muted-foreground">Customers in Mailchimp</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Review Emails Sent</CardTitle>
            <Mail className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{emailStats?.reviewEmailsSent || 0}</div>
            <p className="text-xs text-muted-foreground">Automated follow-ups</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Reviews Received</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{emailStats?.reviewsReceived || 0}</div>
            <p className="text-xs text-muted-foreground">Customer feedback</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Conversion Rate</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{emailStats?.conversionRate || '0.0'}%</div>
            <p className="text-xs text-muted-foreground">Email to review</p>
          </CardContent>
        </Card>
      </div>

      {/* Customer Segmentation Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Users className="h-5 w-5" />
            Customer Segmentation
          </CardTitle>
          <CardDescription>
            Customers are automatically segmented in Mailchimp by budget, holiday type, and destination preferences
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <h3 className="font-semibold text-blue-900">Budget Segments</h3>
              <div className="text-sm text-blue-700 mt-1 space-y-1">
                <div><strong>Budget:</strong> Under £1,500 per person</div>
                <div><strong>Mid-range:</strong> £1,500 - £3,000 per person</div>
                <div><strong>Premium:</strong> £3,000 - £6,000 per person</div>
                <div><strong>Luxury:</strong> Over £6,000 per person</div>
              </div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <h3 className="font-semibold text-green-900">Holiday Types</h3>
              <p className="text-sm text-green-700 mt-1">Adventure, Beach, City Breaks, etc.</p>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <h3 className="font-semibold text-purple-900">Destinations</h3>
              <p className="text-sm text-purple-700 mt-1">Country-specific targeting</p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Review Workflow Management */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Review Request Workflows
          </CardTitle>
          <CardDescription>
            Trigger review collection emails for completed enquiries
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {enquiries?.slice(0, 10).map((enquiry) => (
              <div key={enquiry.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="font-medium">{enquiry.firstName} {enquiry.lastName}</span>
                    <Badge variant="outline">{enquiry.agentName}</Badge>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <span>{enquiry.destinations.join(', ')}</span>
                    <span>•</span>
                    <span>{enquiry.holidayTypes.join(', ')}</span>
                    <span>•</span>
                    <span>{enquiry.budgetPerPerson}</span>
                  </div>
                  <div className="text-xs text-gray-500">
                    Enquiry #{enquiry.id} • {new Date(enquiry.createdAt).toLocaleDateString()}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={enquiry.status === 'pending' ? 'secondary' : 'default'}>
                    {enquiry.status}
                  </Badge>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleTriggerReview(enquiry.id, enquiry.holidayTypes[0] || 'Travel Experience')}
                    disabled={triggerReviewMutation.isPending}
                  >
                    {triggerReviewMutation.isPending ? (
                      <Clock className="h-4 w-4" />
                    ) : (
                      <Mail className="h-4 w-4" />
                    )}
                    Send Review Request
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* GDPR Compliance Information */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <AlertCircle className="h-5 w-5" />
            GDPR Compliance
          </CardTitle>
          <CardDescription>
            All email automation follows GDPR guidelines with automatic unsubscribe management
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-2 text-sm">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Automatic consent tracking for all email subscriptions</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>One-click unsubscribe links in all automated emails</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Data retention controls and deletion workflows</span>
            </div>
            <div className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Customer data segmentation with privacy protection</span>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}