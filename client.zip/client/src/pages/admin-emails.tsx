import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { AdminNavbar } from "@/components/admin/admin-navbar";
import { VisualEmailEditor } from "@/components/email-visual-editor";
import { 
  Mail, 
  Save, 
  Eye, 
  RefreshCcw, 
  Send,
  FileText,
  Calendar,
  Star,
  Users,
  Palette,
  Download,
  ExternalLink
} from "lucide-react";

interface EmailTemplate {
  id: string;
  name: string;
  type: 'transactional' | 'marketing';
  subject: string;
  htmlContent: string;
  textContent: string;
  description: string;
  isActive: boolean;
  createdAt: string;
  updatedAt: string;
}

interface MailchimpTemplate {
  id: number;
  name: string;
  type: string;
  thumbnail: string;
  date_created: string;
  date_edited: string;
  folder_id?: string;
  content_type: string;
}

export function AdminEmails() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedTemplate, setSelectedTemplate] = useState<EmailTemplate | null>(null);
  const [editingTemplate, setEditingTemplate] = useState<EmailTemplate | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [showVisualEditor, setShowVisualEditor] = useState(false);
  const [selectedTab, setSelectedTab] = useState("templates");

  // Check admin authentication
  useEffect(() => {
    const adminToken = localStorage.getItem('adminToken');
    if (!adminToken) {
      setLocation('/admin/login');
      return;
    }
  }, [setLocation]);

  const { data: templates, isLoading } = useQuery({
    queryKey: ['/api/admin/email-templates'],
    enabled: !!localStorage.getItem('adminToken'),
    retry: (failureCount, error: any) => {
      if (error?.message?.includes('401') || error?.message?.includes('403')) {
        localStorage.removeItem('adminToken');
        setLocation('/admin/login');
        return false;
      }
      return failureCount < 3;
    },
  });

  const { data: mailchimpTemplates, isLoading: isLoadingMailchimp } = useQuery<MailchimpTemplate[]>({
    queryKey: ['/api/admin/mailchimp-templates'],
    enabled: !!localStorage.getItem('adminToken') && selectedTab === 'mailchimp',
    retry: (failureCount, error: any) => {
      if (error?.message?.includes('401') || error?.message?.includes('403')) {
        localStorage.removeItem('adminToken');
        setLocation('/admin/login');
        return false;
      }
      return failureCount < 3;
    },
  });

  const updateTemplateMutation = useMutation({
    mutationFn: async (template: EmailTemplate) => {
      const response = await fetch(`/api/admin/email-templates/${template.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        },
        body: JSON.stringify(template)
      });
      
      if (!response.ok) {
        throw new Error('Failed to update template');
      }
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/email-templates'] });
      toast({
        title: "Template Updated",
        description: "Email template has been successfully updated.",
      });
      setEditingTemplate(null);
    },
    onError: () => {
      toast({
        title: "Update Failed",
        description: "Failed to update email template. Please try again.",
        variant: "destructive",
      });
    },
  });

  const testEmailMutation = useMutation({
    mutationFn: async (templateId: string) => {
      const response = await fetch(`/api/admin/email-templates/${templateId}/test`, {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to send test email');
      }
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Test Email Sent",
        description: "Test email has been sent successfully.",
      });
    },
    onError: () => {
      toast({
        title: "Test Failed",
        description: "Failed to send test email. Please try again.",
        variant: "destructive",
      });
    },
  });

  const syncMailchimpTemplatesMutation = useMutation({
    mutationFn: async () => {
      const response = await fetch('/api/admin/mailchimp-templates/sync', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('adminToken')}`
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to sync Mailchimp templates');
      }
      return response.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ['/api/admin/email-templates'] });
      toast({
        title: "Templates Synced",
        description: `Successfully synced ${data.synced} templates from Mailchimp`,
      });
    },
    onError: () => {
      toast({
        title: "Sync Failed",
        description: "Failed to sync Mailchimp templates. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Helper functions
  const getTemplateIcon = (type: string) => {
    switch (type) {
      case 'transactional':
        return <Send className="h-4 w-4 text-blue-500" />;
      case 'marketing':
        return <Star className="h-4 w-4 text-purple-500" />;
      default:
        return <Mail className="h-4 w-4 text-gray-500" />;
    }
  };

  const getTemplateTypeLabel = (type: string) => {
    switch (type) {
      case 'transactional':
        return 'Transactional';
      case 'marketing':
        return 'Marketing';
      default:
        return 'Unknown';
    }
  };

  const handleEditTemplate = (template: EmailTemplate) => {
    setEditingTemplate({ ...template });
  };

  const handleSaveTemplate = () => {
    if (editingTemplate) {
      updateTemplateMutation.mutate(editingTemplate);
    }
  };

  const handlePreviewTemplate = (template: EmailTemplate) => {
    // Open a new window with the email preview
    const previewWindow = window.open('', '_blank');
    if (previewWindow) {
      previewWindow.document.write(`
        <html>
          <head><title>Email Preview - ${template.name}</title></head>
          <body style="margin: 0; padding: 20px; font-family: Arial, sans-serif;">
            <h2>Subject: ${template.subject}</h2>
            <hr>
            ${template.htmlContent}
          </body>
        </html>
      `);
      previewWindow.document.close();
    }
  };



  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-roamah-cream to-white p-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center py-12">
            <RefreshCcw className="h-8 w-8 animate-spin mx-auto mb-4 text-roamah-orange" />
            <p className="text-roamah-gray">Loading email templates...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-roamah-cream to-white">
      <AdminNavbar />
      
      <div className="max-w-7xl mx-auto p-6">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-roamah-dark mb-2">
            Email Template Management
          </h1>
          <p className="text-roamah-gray">
            Manage automated email templates and browse Mailchimp templates
          </p>
        </div>

        {/* Tabs */}
        <div className="mb-6">
          <div className="flex space-x-1 bg-white rounded-lg p-1 border">
            <button
              onClick={() => setSelectedTab("templates")}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                selectedTab === "templates"
                  ? "bg-roamah-orange text-white"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              <Mail className="h-4 w-4 inline mr-2" />
              Current Templates
            </button>
            <button
              onClick={() => setSelectedTab("mailchimp")}
              className={`px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                selectedTab === "mailchimp"
                  ? "bg-roamah-orange text-white"
                  : "text-gray-500 hover:text-gray-700"
              }`}
            >
              <ExternalLink className="h-4 w-4 inline mr-2" />
              Mailchimp Templates
            </button>
          </div>
        </div>

        {selectedTab === "templates" ? (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Template List */}
          <div className="lg:col-span-1">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Mail className="h-5 w-5" />
                  <span>Email Templates</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="mb-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                  <div className="flex items-center space-x-2 text-green-700">
                    <div className="w-2 h-2 bg-green-500 rounded-full"></div>
                    <span className="font-medium text-sm">Live Templates Only</span>
                  </div>
                  <p className="text-xs text-green-600 mt-1">
                    Showing only templates currently used in active email workflows
                  </p>
                </div>
                <div className="space-y-3">
                  {templates?.map((template: EmailTemplate) => (
                    <div
                      key={template.id}
                      className={`p-3 border rounded-lg cursor-pointer transition-colors ${
                        selectedTemplate?.id === template.id
                          ? 'border-roamah-orange bg-orange-50'
                          : 'border-gray-200 hover:border-gray-300'
                      }`}
                      onClick={() => setSelectedTemplate(template)}
                    >
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          {getTemplateIcon(template.type)}
                          <span className="font-medium text-sm">{template.name}</span>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge variant="default" className="bg-green-100 text-green-800 border-green-200">
                            Live
                          </Badge>
                          <Badge variant={template.isActive ? "default" : "secondary"}>
                            {template.isActive ? "Active" : "Inactive"}
                          </Badge>
                        </div>
                      </div>
                      <p className="text-xs text-gray-600 mb-2">{template.description}</p>
                      <div className="flex items-center justify-between text-xs text-gray-500">
                        <span>{getTemplateTypeLabel(template.type)}</span>
                        <span>Modified {new Date(template.updatedAt).toLocaleDateString()}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Template Editor */}
          <div className="lg:col-span-2">
            {selectedTemplate ? (
              <div className="space-y-4">
                {/* Template Actions */}
                <Card>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="flex items-center space-x-2">
                        {getTemplateIcon(selectedTemplate.type)}
                        <span>{selectedTemplate.name}</span>
                      </CardTitle>
                      <div className="flex space-x-2">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => handlePreviewTemplate(selectedTemplate)}
                        >
                          <Eye className="h-4 w-4 mr-2" />
                          Preview
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => testEmailMutation.mutate(selectedTemplate.id)}
                          disabled={testEmailMutation.isPending}
                        >
                          <Send className="h-4 w-4 mr-2" />
                          Test Email
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setShowVisualEditor(true)}
                        >
                          <Palette className="h-4 w-4 mr-2" />
                          Visual Editor
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => handleEditTemplate(selectedTemplate)}
                          className="bg-roamah-orange hover:bg-roamah-orange/90"
                        >
                          <FileText className="h-4 w-4 mr-2" />
                          Edit
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 gap-4 text-sm">
                      <div>
                        <span className="font-medium">Type:</span> {getTemplateTypeLabel(selectedTemplate.type)}
                      </div>
                      <div>
                        <span className="font-medium">Status:</span> {selectedTemplate.isActive ? "Active" : "Inactive"}
                      </div>
                      <div className="col-span-2">
                        <span className="font-medium">Subject:</span> {selectedTemplate.subject}
                      </div>
                    </div>
                  </CardContent>
                </Card>

                {/* Template Content */}
                {editingTemplate ? (
                  <Card>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <CardTitle>Editing Template</CardTitle>
                        <div className="flex space-x-2">
                          <Button
                            variant="outline"
                            onClick={() => setEditingTemplate(null)}
                          >
                            Cancel
                          </Button>
                          <Button
                            onClick={handleSaveTemplate}
                            disabled={updateTemplateMutation.isPending}
                            className="bg-roamah-orange hover:bg-roamah-orange/90"
                          >
                            <Save className="h-4 w-4 mr-2" />
                            {updateTemplateMutation.isPending ? 'Saving...' : 'Save Changes'}
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <div>
                        <label className="block text-sm font-medium mb-2">Template Name</label>
                        <Input
                          value={editingTemplate.name}
                          onChange={(e) => setEditingTemplate({
                            ...editingTemplate,
                            name: e.target.value
                          })}
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium mb-2">Subject Line</label>
                        <Input
                          value={editingTemplate.subject}
                          onChange={(e) => setEditingTemplate({
                            ...editingTemplate,
                            subject: e.target.value
                          })}
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium mb-2">HTML Content</label>
                        <Textarea
                          rows={12}
                          value={editingTemplate.htmlContent}
                          onChange={(e) => setEditingTemplate({
                            ...editingTemplate,
                            htmlContent: e.target.value
                          })}
                          className="font-mono text-sm"
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium mb-2">Plain Text Content</label>
                        <Textarea
                          rows={8}
                          value={editingTemplate.textContent}
                          onChange={(e) => setEditingTemplate({
                            ...editingTemplate,
                            textContent: e.target.value
                          })}
                        />
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium mb-2">Description</label>
                        <Input
                          value={editingTemplate.description}
                          onChange={(e) => setEditingTemplate({
                            ...editingTemplate,
                            description: e.target.value
                          })}
                        />
                      </div>
                    </CardContent>
                  </Card>
                ) : (
                  <Card>
                    <CardHeader>
                      <CardTitle>Template Preview</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div>
                          <h4 className="font-medium mb-2">Subject:</h4>
                          <p className="text-gray-700">{selectedTemplate.subject}</p>
                        </div>
                        
                        <div>
                          <h4 className="font-medium mb-2">HTML Content:</h4>
                          <div 
                            className="border rounded p-4 bg-gray-50 max-h-96 overflow-y-auto"
                            dangerouslySetInnerHTML={{ __html: selectedTemplate.htmlContent }}
                          />
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                )}
              </div>
            ) : (
              <Card>
                <CardContent className="text-center py-12">
                  <Mail className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">
                    Select an Email Template
                  </h3>
                  <p className="text-gray-600">
                    Choose a template from the list to view and edit its content
                  </p>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
        ) : (
          /* Mailchimp Templates Tab */
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center space-x-2">
                    <ExternalLink className="h-5 w-5" />
                    <span>Mailchimp Templates</span>
                  </CardTitle>
                  <Button
                    onClick={() => syncMailchimpTemplatesMutation.mutate()}
                    disabled={syncMailchimpTemplatesMutation.isPending}
                    className="bg-roamah-orange hover:bg-roamah-orange/90"
                  >
                    <Download className="h-4 w-4 mr-2" />
                    {syncMailchimpTemplatesMutation.isPending ? "Syncing..." : "Sync Templates"}
                  </Button>
                </div>
                <p className="text-sm text-gray-600">
                  Browse and import email templates from your Mailchimp account. Design templates in Mailchimp's visual editor, then sync them here.
                </p>
              </CardHeader>
              <CardContent>
                {isLoadingMailchimp ? (
                  <div className="text-center py-8">
                    <RefreshCcw className="h-8 w-8 animate-spin mx-auto mb-4 text-roamah-orange" />
                    <p className="text-gray-600">Loading Mailchimp templates...</p>
                  </div>
                ) : mailchimpTemplates?.length > 0 ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {mailchimpTemplates.map((template: MailchimpTemplate) => (
                      <div key={template.id} className="border rounded-lg p-4 hover:border-gray-300 transition-colors">
                        <div className="flex items-center justify-between mb-2">
                          <h3 className="font-medium text-sm truncate">{template.name}</h3>
                          <Badge variant="outline" className="text-xs">
                            {template.type}
                          </Badge>
                        </div>
                        
                        <div className="mb-3">
                          {template.thumbnail && template.thumbnail.trim() && template.thumbnail.startsWith('http') ? (
                            <img 
                              src={template.thumbnail} 
                              alt={template.name}
                              className="w-full h-32 object-cover rounded border"
                              style={{ display: 'block' }}
                              onLoad={() => console.log(`✅ Thumbnail displayed for: ${template.name}`)}
                              onError={() => console.log(`❌ Thumbnail failed for: ${template.name}`)}
                            />
                          ) : (
                            <div className="bg-gray-100 rounded border h-32 flex items-center justify-center">
                              <div className="text-center text-gray-500">
                                <Mail className="h-8 w-8 mx-auto mb-2" />
                                <span className="text-xs">No Preview</span>
                              </div>
                            </div>
                          )}
                        </div>
                        
                        <div className="flex items-center justify-between text-xs text-gray-500 mb-3">
                          <span>Content: {template.content_type}</span>
                          <span>Created: {new Date(template.date_created).toLocaleDateString()}</span>
                        </div>
                        
                        <div className="flex space-x-2">
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="flex-1"
                            onClick={() => {
                              // Handle different template types with appropriate URLs
                              let templateUrl;
                              
                              if (template.content_type === 'multichannel') {
                                // For multichannel templates, provide direct guidance
                                console.log(`Multichannel template access: ${template.name} (ID: ${template.id})`);
                                
                                // Open Mailchimp login and provide specific instructions
                                templateUrl = `https://login.mailchimp.com/`;
                                
                                toast({
                                  title: "Multichannel Template Access",
                                  description: `Login to Mailchimp, go to Content → Email templates, find "${template.name}" and click Edit to modify this template.`,
                                  duration: 12000,
                                });
                                
                                // Also log instructions for copy-paste
                                console.log(`INSTRUCTIONS: After logging in to Mailchimp:`);
                                console.log(`1. Navigate to: Content → Email templates`);
                                console.log(`2. Search for: "${template.name}"`);
                                console.log(`3. Click "Edit" to modify the template`);
                                console.log(`4. Template ID: ${template.id}`);
                                
                              } else if (template.content_type === 'template') {
                                // For regular drag-and-drop templates, try direct edit URL
                                templateUrl = `https://us21.admin.mailchimp.com/templates/edit?id=${template.id}`;
                                console.log(`Opening classic template: ${template.name} (ID: ${template.id})`);
                                
                                // If this fails, they'll need to login first
                                setTimeout(() => {
                                  console.log(`If the direct link doesn't work, login at: https://login.mailchimp.com/`);
                                }, 3000);
                                
                              } else {
                                // Fallback - go to login page
                                templateUrl = `https://login.mailchimp.com/`;
                                console.log(`Opening login page for template: ${template.name} (ID: ${template.id})`);
                                
                                toast({
                                  title: "Template Access",
                                  description: `Login to Mailchimp and navigate to Templates to find "${template.name}".`,
                                  duration: 8000,
                                });
                              }
                              
                              console.log(`Opening URL: ${templateUrl}`);
                              window.open(templateUrl, '_blank');
                            }}
                          >
                            <Eye className="h-3 w-3 mr-1" />
                            View
                          </Button>
                          <Button 
                            size="sm" 
                            className="flex-1 bg-roamah-orange hover:bg-roamah-orange/90"
                            onClick={async () => {
                              try {
                                const response = await fetch(`/api/admin/mailchimp-templates/${template.id}/import`, {
                                  method: 'POST',
                                  headers: {
                                    'Authorization': `Bearer ${localStorage.getItem('adminToken')}`,
                                    'Content-Type': 'application/json'
                                  }
                                });

                                if (response.ok) {
                                  toast({
                                    title: "Success",
                                    description: `Template "${template.name}" imported successfully!`,
                                  });
                                  // Refresh local templates
                                  queryClient.invalidateQueries({ queryKey: ['/api/admin/email-templates'] });
                                } else {
                                  const error = await response.json();
                                  toast({
                                    title: "Import Failed",
                                    description: error.error || "Failed to import template",
                                    variant: "destructive",
                                  });
                                }
                              } catch (error) {
                                toast({
                                  title: "Error",
                                  description: "Failed to import template",
                                  variant: "destructive",
                                });
                              }
                            }}
                          >
                            <Download className="h-3 w-3 mr-1" />
                            Import
                          </Button>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <ExternalLink className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                    <h3 className="text-lg font-medium text-gray-900 mb-2">
                      No Mailchimp Templates Found
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Create email templates in your Mailchimp account first, then sync them here.
                    </p>
                    <Button
                      onClick={() => window.open('https://us21.admin.mailchimp.com/templates/', '_blank')}
                      variant="outline"
                    >
                      <ExternalLink className="h-4 w-4 mr-2" />
                      Go to Mailchimp Templates
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        )}
      </div>
      
      {/* Visual Editor Modal */}
      {showVisualEditor && selectedTemplate && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg w-full max-w-6xl mx-4 max-h-[90vh] overflow-auto">
            <VisualEmailEditor
              template={selectedTemplate}
              onSave={(updatedTemplate) => {
                const fullTemplate = { ...selectedTemplate, ...updatedTemplate };
                updateTemplateMutation.mutate(fullTemplate);
                setShowVisualEditor(false);
              }}
              onCancel={() => setShowVisualEditor(false)}
            />
          </div>
        </div>
      )}
    </div>
  );
}

export default AdminEmails;