import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { agentRegistrationSchema, type AgentRegistration, LANGUAGES } from "@shared/schema";
import { UK_CITIES } from "@/lib/constants";
import { useQuery, useMutation } from "@tanstack/react-query";
import { X, CheckCircle, ArrowRight, User, MapPin, Globe, Star, Camera, Play } from "lucide-react";
import { z } from "zod";

// Step 1 schema - just email and password
const step1Schema = z.object({
  email: z.string().email("Invalid email address"),
  password: z.string().min(8, "Password must be at least 8 characters"),
});

type Step1Data = z.infer<typeof step1Schema>;

export default function AgentOnboarding() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const [step1Data, setStep1Data] = useState<Step1Data | null>(null);
  const [selectedSpecializations, setSelectedSpecializations] = useState<string[]>([]);
  const [selectedDestinations, setSelectedDestinations] = useState<string[]>([]);
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>([]);
  const [hasFinancialProtection, setHasFinancialProtection] = useState<boolean>(true);
  const [selectedProtectionBodies, setSelectedProtectionBodies] = useState<string[]>(['ATOL', 'ABTA']);
  const [licenseNumbers, setLicenseNumbers] = useState<Record<string, string>>({});

  const step1Form = useForm<Step1Data>({
    resolver: zodResolver(step1Schema),
    defaultValues: {
      email: "",
      password: "",
    },
  });

  // Simplified form schema for step 3 (without email/password validation)
  const step3Schema = z.object({
    firstName: z.string().min(1, "First name is required"),
    lastName: z.string().min(1, "Last name is required"),
    location: z.string().min(1, "Location is required"),
    company: z.string().min(1, "Business name is required"),
    bio: z.string().min(50, "Bio must be at least 50 characters"),
    yearsExperience: z.number().min(0, "Years of experience must be positive"),
  });

  const PROTECTION_BODIES = ['ATOL', 'ABTA', 'ABTOT', 'TTA'];

  const mainForm = useForm({
    resolver: zodResolver(step3Schema),
    defaultValues: {
      firstName: "",
      lastName: "",
      location: "",
      company: "",
      nextHoliday: "",
      bio: "",
      yearsExperience: 0,
    },
  });

  // Fetch holiday types and destinations
  const { data: holidayTypes } = useQuery({
    queryKey: ['/api/holiday-types'],
  });

  const { data: destinationsData } = useQuery({
    queryKey: ['/api/destinations'],
  });

  const registrationMutation = useMutation({
    mutationFn: async (data: AgentRegistration) => {
      return apiRequest('/api/agents/register', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: (response: any) => {
      localStorage.setItem('agentToken', response.token);
      toast({
        title: "Registration Complete!",
        description: "Welcome to Roamah! Redirecting to your dashboard...",
      });
      setLocation("/agent-dashboard");
    },
    onError: (error: any) => {
      toast({
        title: "Registration Failed",
        description: error.message || "Please try again",
        variant: "destructive",
      });
    },
  });

  const handleStep1Submit = (data: Step1Data) => {
    setStep1Data(data);
    setCurrentStep(2);
  };

  const handleStep2Continue = () => {
    setCurrentStep(3);
  };

  const handleStep3Submit = (data: any) => {
    console.log("Form submit triggered", { data, step1Data });
    if (!step1Data) {
      toast({
        title: "Session Error",
        description: "Please start from step 1",
        variant: "destructive",
      });
      setCurrentStep(1);
      return;
    }

    // Validate minimum requirements
    if (selectedLanguages.length === 0) {
      toast({
        title: "Language Required",
        description: "Please select at least one language",
        variant: "destructive",
      });
      return;
    }

    // Validate financial protection
    if (!hasFinancialProtection) {
      toast({
        title: "Financial Protection Required",
        description: "Financial protection is mandatory for travel businesses",
        variant: "destructive",
      });
      return;
    }

    if (selectedProtectionBodies.length === 0) {
      toast({
        title: "Protection Body Required",
        description: "Please select at least one protection body (ATOL, ABTA, ABTOT, or TTA)",
        variant: "destructive",
      });
      return;
    }

    // Validate all selected protection bodies have license numbers
    for (const body of selectedProtectionBodies) {
      if (!licenseNumbers[body] || licenseNumbers[body].trim() === '') {
        toast({
          title: "License Number Required",
          description: `Please provide your ${body} license number`,
          variant: "destructive",
        });
        return;
      }
    }
    
    const finalData = {
      ...data,
      email: step1Data.email,
      password: step1Data.password,
      specializations: selectedSpecializations,
      destinations: selectedDestinations,
      languages: selectedLanguages,
      hasFinancialProtection,
      protectionBodies: selectedProtectionBodies,
      licenseNumbers,
    };

    console.log("Final registration data:", finalData);
    registrationMutation.mutate(finalData);
  };

  const steps = [
    { number: 1, title: "Account Setup", description: "Email & Password" },
    { number: 2, title: "Profile Preview", description: "See What's Needed" },
    { number: 3, title: "Complete Profile", description: "Your Information" },
    { number: 4, title: "Dashboard", description: "Start Getting Bookings" },
  ];

  const renderStepIndicator = () => (
    <div className="mb-8">
      <div className="flex items-center justify-between max-w-3xl mx-auto">
        {steps.map((step, index) => (
          <div key={step.number} className="flex items-center">
            <div className={`flex flex-col items-center ${index < steps.length - 1 ? 'flex-1' : ''}`}>
              <div className={`w-10 h-10 rounded-full flex items-center justify-center font-semibold ${
                currentStep >= step.number 
                  ? 'bg-roamah-orange text-white' 
                  : 'bg-gray-200 text-gray-600'
              }`}>
                {currentStep > step.number ? <CheckCircle className="w-6 h-6" /> : step.number}
              </div>
              <div className="text-center mt-2">
                <div className="text-sm font-medium text-roamah-dark">{step.title}</div>
                <div className="text-xs text-gray-500">{step.description}</div>
              </div>
            </div>
            {index < steps.length - 1 && (
              <div className={`flex-1 h-0.5 mx-4 ${
                currentStep > step.number ? 'bg-roamah-orange' : 'bg-gray-200'
              }`} />
            )}
          </div>
        ))}
      </div>
    </div>
  );

  const renderStep1 = () => (
    <Card className="max-w-md mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl text-roamah-dark">Join Roamah as a Travel Agent</CardTitle>
        <CardDescription>
          Start by creating your account. We'll guide you through setting up your professional profile.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...step1Form}>
          <form onSubmit={step1Form.handleSubmit(handleStep1Submit)} className="space-y-4">
            <FormField
              control={step1Form.control}
              name="email"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Email Address</FormLabel>
                  <FormControl>
                    <Input placeholder="your.email@example.com" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={step1Form.control}
              name="password"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Password</FormLabel>
                  <FormControl>
                    <Input type="password" placeholder="At least 8 characters" {...field} />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            <Button type="submit" className="w-full bg-roamah-orange hover:bg-roamah-orange/90">
              Continue <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </form>
        </Form>
      </CardContent>
    </Card>
  );

  const renderStep2 = () => (
    <div className="max-w-6xl mx-auto">
      <Card className="mb-6">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl text-roamah-dark">Let's Build Your Professional Profile</CardTitle>
          <CardDescription>
            Here's an example of what your completed profile will look like. We'll collect this information in the next step.
          </CardDescription>
        </CardHeader>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
        {/* Left Sidebar - Example Profile */}
        <div className="lg:col-span-1">
          <div className="bg-white rounded-2xl p-6 shadow-lg">
            {/* Profile Image */}
            <div className="text-center mb-6">
              <img
                src="/uploads/profileImage-1753373885647-278634131.jpg"
                alt="Evan Desmond"
                className="w-32 h-32 rounded-full object-cover mx-auto mb-4 border-4 border-gray-100"
              />
              <h1 className="text-2xl font-bold text-roamah-dark mb-2">Evan Desmond</h1>
              <div className="flex items-center justify-center mb-2">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-yellow-500 fill-current" />
                  <span className="text-sm font-semibold">4.8 (11 reviews)</span>
                </div>
              </div>
              <div className="flex items-center justify-center text-roamah-gray mb-4">
                <MapPin className="h-4 w-4 mr-1" />
                <span className="font-bold">Bolton, UK</span>
              </div>
              <p className="text-sm text-roamah-gray mb-4 font-bold">The Luxury Travel Insider</p>
              <p className="text-sm text-roamah-gray mb-6 font-bold">Next holiday: Dubai and Maldives, I can't wait!</p>
            </div>

            {/* Enquire Button */}
            <Button className="w-full bg-roamah-orange hover:bg-roamah-orange/90 text-white font-bold mb-6">
              Send Evan an enquiry
            </Button>

            {/* Specialises in */}
            <div className="mb-6">
              <h3 className="font-bold text-roamah-dark mb-3">Specialises in</h3>
              <div className="space-y-2">
                <div className="w-full bg-orange-100 text-orange-800 text-sm py-2 px-3 rounded-md text-center font-bold">
                  Luxury Holidays
                </div>
                <div className="w-full bg-blue-100 text-blue-800 text-sm py-2 px-3 rounded-md text-center font-bold">
                  Beach Holidays
                </div>
                <div className="w-full bg-pink-100 text-pink-800 text-sm py-2 px-3 rounded-md text-center font-bold">
                  Honeymoons
                </div>
                <div className="w-full bg-green-100 text-green-800 text-sm py-2 px-3 rounded-md text-center font-bold">
                  Golf Holidays
                </div>
              </div>
            </div>

            {/* Expert destinations */}
            <div className="mb-6">
              <h3 className="font-bold text-roamah-dark mb-3">Expert destinations</h3>
              <div className="space-y-2">
                <div className="w-full bg-blue-100 text-blue-800 text-sm py-2 px-3 rounded-md text-center font-bold">
                  Maldives
                </div>
                <div className="w-full bg-purple-100 text-purple-800 text-sm py-2 px-3 rounded-md text-center font-bold">
                  Dubai
                </div>
                <div className="w-full bg-teal-100 text-teal-800 text-sm py-2 px-3 rounded-md text-center font-bold">
                  Bali
                </div>
                <div className="w-full bg-indigo-100 text-indigo-800 text-sm py-2 px-3 rounded-md text-center font-bold">
                  Santorini
                </div>
                <div className="w-full bg-yellow-100 text-yellow-800 text-sm py-2 px-3 rounded-md text-center font-bold">
                  Jordan
                </div>
              </div>
            </div>

            {/* Languages spoken */}
            <div>
              <h3 className="font-bold text-roamah-dark mb-3">Languages spoken</h3>
              <div className="space-y-2">
                <div className="w-full bg-gray-100 text-gray-800 text-sm py-2 px-3 rounded-md text-center font-bold">
                  English
                </div>
                <div className="w-full bg-gray-100 text-gray-800 text-sm py-2 px-3 rounded-md text-center font-bold">
                  Spanish
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content Area - Example Profile Sections */}
        <div className="lg:col-span-2 space-y-6">
          {/* About Me Section */}
          <section className="bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-2xl font-bold text-roamah-dark mb-6">About me</h2>
            <div className="text-roamah-gray leading-relaxed">
              <p>
                Passionate luxury travel specialist with 15 years of experience creating unforgettable journeys to the world's most exclusive destinations. 
                I specialise in luxury beach holidays, romantic honeymoons, and premium golf experiences. My expertise spans across the Maldives, Dubai, Bali, Santorini, and Jordan, 
                where I've personally crafted bespoke travel experiences for discerning clients. Having worked extensively with luxury resorts and private villas, 
                I understand the importance of attention to detail and personalised service that makes each journey truly special...
              </p>
            </div>
          </section>

          {/* Travel Experiences Section */}
          <section className="bg-white rounded-2xl p-8 shadow-lg">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-roamah-dark">My travel experiences</h2>
              <Button variant="ghost" className="text-roamah-orange">
                View more photos <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {[
                "/uploads/photos-1753383581168-642702898.jpeg",
                "/uploads/photos-1753383741543-69539797.JPG", 
                "/uploads/photos-1753383751992-942682595.JPG",
                "/uploads/photos-1753383757853-557983569.JPG",
                "/uploads/photos-1753383771702-282366659.JPG",
                "/uploads/photos-1753438133631-503750449.jpeg",
                "/uploads/photos-1753438139132-258181862.JPG",
                "/uploads/photos-1753438163875-411173650.jpeg"
              ].map((photo, index) => (
                <div key={index} className="rounded-xl h-24 overflow-hidden">
                  <img 
                    src={photo} 
                    alt={`Travel experience ${index + 1}`}
                    className="w-full h-full object-cover hover:scale-105 transition-transform cursor-pointer"
                  />
                </div>
              ))}
            </div>
            <p className="text-gray-500 text-sm mt-4 text-center">
              Stunning travel experiences from luxury destinations worldwide
            </p>
          </section>

          {/* Introduction Video Section */}
          <section className="bg-white rounded-2xl p-8 shadow-lg">
            <h2 className="text-2xl font-bold text-roamah-dark mb-6">Introduction video</h2>
            <div className="bg-black rounded-xl h-64 flex items-center justify-center relative overflow-hidden">
              <video 
                className="w-full h-full object-cover"
                poster="/uploads/photos-1753383581168-642702898.jpeg"
                controls={false}
              >
                <source src="/uploads/video-1753377284401-813466190.mp4" type="video/mp4" />
              </video>
              <div className="absolute inset-0 flex items-center justify-center bg-black bg-opacity-40 hover:bg-opacity-30 transition-all cursor-pointer">
                <Play className="w-16 h-16 text-white" />
              </div>
            </div>
            <p className="text-gray-500 text-sm mt-4 text-center">
              Personal introduction video from Evan
            </p>
          </section>

          {/* Blog Posts & Content Section */}
          <section className="bg-white rounded-2xl p-8 shadow-lg">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-roamah-dark">Blog posts & content</h2>
              <Button variant="ghost" className="text-roamah-orange">
                View all posts <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
            
            <div className="bg-gradient-to-br from-blue-50 to-indigo-50 rounded-xl p-6 border border-blue-100">
              <div className="flex gap-4">
                <img 
                  src="https://images.unsplash.com/photo-1545569341-9eb8b30979d9?w=120&h=80&fit=crop"
                  alt="Japanese Culture Blog"
                  className="w-20 h-16 rounded-lg object-cover flex-shrink-0"
                />
                <div className="flex-1">
                  <h3 className="font-bold text-roamah-dark mb-2 line-clamp-2">
                    Hidden Gems of Japanese Culture: Beyond the Tourist Trail
                  </h3>
                  <p className="text-sm text-roamah-gray mb-3 line-clamp-2">
                    Discover the authentic heart of Japanese culture through unique experiences beyond the typical tourist trail, from master craftsman workshops to local festival participation.
                  </p>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-medium">
                      City Breaks
                    </span>
                    <span className="bg-purple-100 text-purple-800 text-xs px-2 py-1 rounded-full font-medium">
                      Japan
                    </span>
                  </div>
                </div>
              </div>
            </div>
            <p className="text-gray-500 text-sm mt-4 text-center">
              Share travel insights and attract customers through expert content
            </p>
          </section>

          {/* Top Offers Section */}
          <section className="bg-white rounded-2xl p-8 shadow-lg">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-roamah-dark">Top offers</h2>
              <Button variant="ghost" className="text-roamah-orange">
                View all offers <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </div>
            
            <div className="bg-gradient-to-br from-orange-50 to-red-50 rounded-xl p-6 border border-orange-100">
              <div className="flex gap-4">
                <img 
                  src="https://images.unsplash.com/photo-1573843981267-be1999ff37cd?w=120&h=80&fit=crop&crop=center"
                  alt="Luxury Maldives Escape"
                  className="w-20 h-16 rounded-lg object-cover flex-shrink-0"
                />
                <div className="flex-1">
                  <h3 className="font-bold text-roamah-dark mb-2">
                    Luxury Maldives Escape
                  </h3>
                  <p className="text-sm text-roamah-gray mb-3 line-clamp-2">
                    Exclusive 7-day luxury resort experience with overwater villas and world-class amenities
                  </p>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-lg font-bold text-roamah-orange">£2,999 per person</span>
                  </div>
                  <div className="flex items-center gap-2 mb-2">
                    <span className="bg-pink-100 text-pink-800 text-xs px-2 py-1 rounded-full font-medium">
                      Honeymoons
                    </span>
                    <span className="bg-blue-100 text-blue-800 text-xs px-2 py-1 rounded-full font-medium">
                      Beach Holidays
                    </span>
                    <span className="bg-teal-100 text-teal-800 text-xs px-2 py-1 rounded-full font-medium">
                      Maldives
                    </span>
                  </div>
                  <div className="bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full inline-block font-bold">
                    Save £500 on bookings made this month
                  </div>
                </div>
              </div>
            </div>
            <p className="text-gray-500 text-sm mt-4 text-center">
              Showcase your best travel packages and special deals
            </p>
          </section>

          {/* Customer Reviews Section */}
          <section className="bg-white rounded-2xl p-8 shadow-lg">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-roamah-dark">Customer reviews</h2>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1">
                  <Star className="w-4 h-4 text-yellow-500 fill-current" />
                  <span className="text-sm font-semibold">4.8 average</span>
                </div>
                <span className="text-sm text-gray-500">(11 reviews)</span>
              </div>
            </div>
            
            <div className="space-y-4">
              <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-6 border border-green-100">
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                      <span className="text-green-800 font-bold text-sm">SC</span>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="font-bold text-roamah-dark text-sm">Sarah Chen</span>
                      <div className="flex items-center gap-1">
                        {[1,2,3,4,5].map((star) => (
                          <Star key={star} className="w-3 h-3 text-yellow-500 fill-current" />
                        ))}
                      </div>
                    </div>
                    <p className="text-sm text-roamah-gray mb-2">
                      "Evan planned the most incredible honeymoon to the Maldives. Every detail was perfect, from the overwater villa to the sunset dinners. Absolutely magical experience!"
                    </p>
                    <span className="text-xs text-gray-500">Maldives Honeymoon • 2 months ago</span>
                  </div>
                </div>
              </div>

              <div className="bg-gradient-to-br from-blue-50 to-sky-50 rounded-xl p-6 border border-blue-100">
                <div className="flex items-start gap-4">
                  <div className="flex-shrink-0">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-blue-800 font-bold text-sm">MT</span>
                    </div>
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="font-bold text-roamah-dark text-sm">Michael Turner</span>
                      <div className="flex items-center gap-1">
                        {[1,2,3,4,5].map((star) => (
                          <Star key={star} className="w-3 h-3 text-yellow-500 fill-current" />
                        ))}
                      </div>
                    </div>
                    <p className="text-sm text-roamah-gray mb-2">
                      "Outstanding service! Evan's expertise in luxury travel really shows. Our Dubai trip exceeded all expectations with premium accommodations and exclusive experiences."
                    </p>
                    <span className="text-xs text-gray-500">Dubai Luxury Trip • 1 month ago</span>
                  </div>
                </div>
              </div>
            </div>
            <p className="text-gray-500 text-sm mt-4 text-center">
              Build trust and credibility with authentic customer feedback
            </p>
          </section>
        </div>

        {/* Right Column - Information We'll Collect */}
        <div className="lg:col-span-1">
          <div className="sticky top-8 space-y-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Information We'll Collect</CardTitle>
                <CardDescription>We'll guide you through each section</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-3 p-3 bg-roamah-peach rounded-lg">
                  <User className="w-5 h-5 text-roamah-orange" />
                  <div>
                    <div className="font-medium text-sm">Personal Details</div>
                    <div className="text-xs text-gray-600">Name, location, company</div>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
                  <Star className="w-5 h-5 text-blue-600" />
                  <div>
                    <div className="font-medium text-sm">Expertise & Bio</div>
                    <div className="text-xs text-gray-600">Experience & story</div>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
                  <MapPin className="w-5 h-5 text-green-600" />
                  <div>
                    <div className="font-medium text-sm">Specializations</div>
                    <div className="text-xs text-gray-600">Holiday types you offer</div>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-purple-50 rounded-lg">
                  <Globe className="w-5 h-5 text-purple-600" />
                  <div>
                    <div className="font-medium text-sm">Destinations</div>
                    <div className="text-xs text-gray-600">Places you organise trips to</div>
                  </div>
                </div>
                <div className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                  <Globe className="w-5 h-5 text-gray-600" />
                  <div>
                    <div className="font-medium text-sm">Languages</div>
                    <div className="text-xs text-gray-600">Languages you speak</div>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="text-center">
                  <h4 className="font-semibold text-roamah-dark mb-2">Ready to create your profile?</h4>
                  <p className="text-sm text-roamah-gray mb-4">
                    This will take about 3-5 minutes to complete.
                  </p>
                  <Button 
                    onClick={handleStep2Continue}
                    className="w-full bg-roamah-orange hover:bg-roamah-orange/90 font-bold text-[16px]"
                  >
                    Let's Get Started <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>


          </div>
        </div>
      </div>

      {/* Floating Sticky Continue Button - Only visible while scrolling through step 2 content */}
      <div className="fixed bottom-6 left-1/2 transform -translate-x-1/2 z-50">
        <Button 
          onClick={handleStep2Continue}
          className="bg-roamah-orange hover:bg-roamah-orange/90 text-white font-bold px-8 py-4 rounded-full shadow-2xl border-4 border-white hover:scale-105 transition-all duration-300"
          size="lg"
        >
          <ArrowRight className="mr-2 h-5 w-5" />
          Continue to Create Profile
          <ArrowRight className="ml-2 h-5 w-5" />
        </Button>
      </div>
    </div>
  );

  const renderStep3 = () => (
    <div className="max-w-4xl mx-auto">
      <Card>
        <CardHeader className="text-center">
          <CardTitle className="text-2xl text-roamah-dark">Complete Your Profile</CardTitle>
          <CardDescription>
            Tell us about yourself so travelers can find and connect with you.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...mainForm}>
            <form onSubmit={mainForm.handleSubmit(handleStep3Submit, (errors) => {
              console.log("Form validation errors:", errors);
              toast({
                title: "Form Validation Error",
                description: "Please check all required fields",
                variant: "destructive",
              });
            })} className="space-y-6">
              {/* Personal Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={mainForm.control}
                  name="firstName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>First Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Sarah" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={mainForm.control}
                  name="lastName"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Last Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Johnson" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={mainForm.control}
                  name="location"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Location</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select your city" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent className="max-h-60">
                          {UK_CITIES.map((city) => (
                            <SelectItem key={city} value={city}>
                              {city}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={mainForm.control}
                  name="company"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Business Name</FormLabel>
                      <FormControl>
                        <Input placeholder="Adventure Travel Co." {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={mainForm.control}
                name="yearsExperience"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Years of Experience</FormLabel>
                    <FormControl>
                      <Input 
                        type="number" 
                        placeholder="5" 
                        {...field}
                        onChange={(e) => field.onChange(parseInt(e.target.value))}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={mainForm.control}
                name="bio"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>About You (Bio) - Minimum 50 characters</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Tell travelers about your experience, passion for travel, and what makes you unique..."
                        className="min-h-24"
                        {...field}
                      />
                    </FormControl>
                    <div className="text-sm text-gray-500 mt-1">
                      {field.value?.length || 0}/50 characters minimum
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Specializations */}
              <div>
                <Label className="text-base font-semibold">Specialisations</Label>
                <p className="text-sm text-gray-600 mb-3">What types of holidays do you specialise in? (Select up to 5)</p>
                {selectedSpecializations.length >= 5 && (
                  <div className="text-orange-600 text-sm mb-2">Maximum 5 specialisations selected</div>
                )}
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
                  {Array.isArray(holidayTypes) && holidayTypes.map((type: any) => (
                    <div key={type.slug} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={type.slug}
                        checked={selectedSpecializations.includes(type.slug)}
                        onChange={(e) => {
                          if (e.target.checked && selectedSpecializations.length < 5) {
                            setSelectedSpecializations([...selectedSpecializations, type.slug]);
                          } else if (!e.target.checked) {
                            setSelectedSpecializations(selectedSpecializations.filter(s => s !== type.slug));
                          }
                        }}
                        disabled={!selectedSpecializations.includes(type.slug) && selectedSpecializations.length >= 5}
                        className="rounded border-gray-300"
                      />
                      <label htmlFor={type.slug} className="text-sm">{type.name}</label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Destinations */}
              <div>
                <Label className="text-base font-semibold">Top Destinations</Label>
                <p className="text-sm text-gray-600 mb-3">Which destinations do you organise trips to? (Select up to 5)</p>
                {selectedDestinations.length >= 5 && (
                  <div className="text-orange-600 text-sm mb-2">Maximum 5 destinations selected</div>
                )}
                <div className="grid grid-cols-2 md:grid-cols-3 gap-2 max-h-48 overflow-y-auto">
                  {Array.isArray(destinationsData) && destinationsData.map((dest: any) => (
                    <div key={dest.slug} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={dest.slug}
                        checked={selectedDestinations.includes(dest.slug)}
                        onChange={(e) => {
                          if (e.target.checked && selectedDestinations.length < 5) {
                            setSelectedDestinations([...selectedDestinations, dest.slug]);
                          } else if (!e.target.checked) {
                            setSelectedDestinations(selectedDestinations.filter(d => d !== dest.slug));
                          }
                        }}
                        disabled={!selectedDestinations.includes(dest.slug) && selectedDestinations.length >= 5}
                        className="rounded border-gray-300"
                      />
                      <label htmlFor={dest.slug} className="text-sm">{dest.name}</label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Languages */}
              <div>
                <Label className="text-base font-semibold">Languages (Required - Select at least 1)</Label>
                <p className="text-sm text-gray-600 mb-3">What languages do you speak?</p>
                {selectedLanguages.length === 0 && (
                  <div className="text-red-500 text-sm mb-2">Please select at least one language</div>
                )}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                  {LANGUAGES.map((lang) => (
                    <div key={lang} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        id={lang}
                        checked={selectedLanguages.includes(lang)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedLanguages([...selectedLanguages, lang]);
                          } else {
                            setSelectedLanguages(selectedLanguages.filter(l => l !== lang));
                          }
                        }}
                        className="rounded border-gray-300"
                      />
                      <label htmlFor={lang} className="text-sm capitalize">{lang}</label>
                    </div>
                  ))}
                </div>
              </div>

              {/* Financial Protection */}
              <div className="border-t pt-6">
                <Label className="text-base font-semibold">Financial Protection (Required)</Label>
                <div className="mt-3">
                  <div className="flex items-center space-x-2">
                    <input
                      type="checkbox"
                      id="hasFinancialProtection"
                      checked={hasFinancialProtection}
                      onChange={(e) => {
                        setHasFinancialProtection(e.target.checked);
                        if (!e.target.checked) {
                          setSelectedProtectionBodies([]);
                          setLicenseNumbers({});
                        }
                      }}
                      className="rounded border-gray-300"
                    />
                    <label htmlFor="hasFinancialProtection" className="text-sm font-medium">
                      Are your holidays protected by ATOL, ABTA, ABTOT or TTA? *
                    </label>
                  </div>
                  
                  {!hasFinancialProtection && (
                    <div className="text-red-500 text-sm mt-2">This field is required - financial protection is mandatory for travel businesses</div>
                  )}
                  
                  {hasFinancialProtection && (
                    <div className="mt-4 space-y-4">
                      <p className="text-sm text-gray-600">Please select your protection body(ies) and provide license numbers:</p>
                      
                      {PROTECTION_BODIES.map((body) => (
                        <div key={body} className="space-y-2">
                          <div className="flex items-center space-x-2">
                            <input
                              type="checkbox"
                              id={`protection-${body}`}
                              checked={selectedProtectionBodies.includes(body)}
                              onChange={(e) => {
                                if (e.target.checked) {
                                  setSelectedProtectionBodies([...selectedProtectionBodies, body]);
                                } else {
                                  setSelectedProtectionBodies(selectedProtectionBodies.filter(b => b !== body));
                                  // Remove license number when unchecking
                                  const newLicenseNumbers = { ...licenseNumbers };
                                  delete newLicenseNumbers[body];
                                  setLicenseNumbers(newLicenseNumbers);
                                }
                              }}
                              className="rounded border-gray-300"
                            />
                            <label htmlFor={`protection-${body}`} className="text-sm font-medium">
                              {body}
                            </label>
                          </div>
                          
                          {selectedProtectionBodies.includes(body) && (
                            <div className="ml-6">
                              <Input
                                placeholder={`Enter your ${body} license number`}
                                value={licenseNumbers[body] || ''}
                                onChange={(e) => {
                                  setLicenseNumbers({
                                    ...licenseNumbers,
                                    [body]: e.target.value
                                  });
                                }}
                                className="max-w-md"
                              />
                              {selectedProtectionBodies.includes(body) && !licenseNumbers[body] && (
                                <div className="text-red-500 text-xs mt-1">License number is required</div>
                              )}
                            </div>
                          )}
                        </div>
                      ))}
                      
                      {selectedProtectionBodies.length === 0 && (
                        <div className="text-red-500 text-sm">Please select at least one protection body</div>
                      )}
                    </div>
                  )}
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <Button 
                  type="button"
                  variant="outline"
                  onClick={() => setCurrentStep(2)}
                  className="flex-1"
                >
                  Back
                </Button>
                <Button 
                  type="submit" 
                  disabled={registrationMutation.isPending}
                  className="flex-1 bg-roamah-orange hover:bg-roamah-orange/90 font-bold text-[16px]"
                  onClick={() => {
                    console.log("Button clicked", { 
                      formState: mainForm.formState,
                      values: mainForm.getValues(),
                      errors: mainForm.formState.errors 
                    });
                  }}
                >
                  {registrationMutation.isPending ? "Creating Profile..." : "Complete Registration"}
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <main className="container mx-auto px-4 py-8">
        {renderStepIndicator()}
        
        {currentStep === 1 && renderStep1()}
        {currentStep === 2 && renderStep2()}
        {currentStep === 3 && renderStep3()}
      </main>
      <Footer />
    </div>
  );
}