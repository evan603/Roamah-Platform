import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { Heart, Mountain, Users, Palmtree, Camera, Plane } from "lucide-react";
import type { HolidayType } from "@shared/schema";

const holidayTypeIcons: Record<string, any> = {
  romantic: Heart,
  adventure: Mountain,
  family: Users,
  beach: Palmtree,
  cultural: Camera,
  luxury: Plane,
};

export default function BrowseHolidayTypes() {
  const { data: holidayTypes, isLoading } = useQuery<HolidayType[]>({
    queryKey: ["/api/holiday-types"],
  });

  if (isLoading) {
    return (
      <>
        <Navbar />
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-roamah-orange mx-auto mb-4"></div>
            <p className="text-roamah-gray">Loading holiday types...</p>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        
        <main className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Hero Section */}
            <div className="bg-gradient-to-r from-orange-50 to-pink-50 rounded-2xl p-8 mb-12">
              <div className="text-center">
                <h1 className="text-4xl font-bold text-roamah-dark mb-4">Holiday Types</h1>
                <p className="text-xl text-roamah-gray mb-0 max-w-4xl mx-auto">You may not know where you want to go but you do know the type of holiday you want to go on. Cruising for the first time? Or maybe it's your first family holiday and you need a bit of help, whatever you need, our travel experts can help you with it all.</p>
              </div>
            </div>

            {/* Results */}
            <div className="mb-6">
              <p className="text-roamah-gray">
                {holidayTypes?.length || 0} holiday types available
              </p>
            </div>

            {/* Holiday Types Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {holidayTypes?.map((holidayType) => {
                const IconComponent = holidayTypeIcons[holidayType.slug] || Plane;
                
                return (
                  <Link 
                    key={holidayType.id} 
                    href={`/holiday-type/${holidayType.slug}`}
                    className="group"
                  >
                    <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                      <div className="relative h-48 bg-gradient-to-br from-gray-100 to-gray-200 overflow-hidden">
                        <img 
                          src={holidayType.image}
                          alt={holidayType.name}
                          className="w-full h-full object-cover"
                          onError={(e) => {
                            // Fallback to gradient background with icon if image fails to load
                            const target = e.target as HTMLImageElement;
                            target.style.display = 'none';
                            target.parentElement!.innerHTML = `
                              <div class="absolute inset-0 bg-gradient-to-br from-roamah-orange to-roamah-cream flex items-center justify-center">
                                <div class="absolute inset-0 bg-black bg-opacity-10"></div>
                                <div class="relative z-10 bg-white rounded-full p-6 shadow-lg">
                                  <div class="h-12 w-12 text-roamah-orange"></div>
                                </div>
                              </div>
                            `;
                          }}
                        />
                        <div className="absolute inset-0 bg-black bg-opacity-20"></div>
                      </div>
                      <div className="p-6">
                        <h3 className="text-xl font-semibold text-roamah-dark mb-2 group-hover:text-roamah-orange transition-colors">
                          {holidayType.name}
                        </h3>
                        <p className="text-roamah-gray mb-4 line-clamp-3">
                          {holidayType.tagline}
                        </p>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-roamah-orange font-medium">
                            Find your travel expert →
                          </span>
                        </div>
                      </div>
                    </div>
                  </Link>
                );
              })}
            </div>

            {(!holidayTypes || holidayTypes.length === 0) && (
              <div className="text-center py-12">
                <div className="text-roamah-gray mb-4">
                  <p className="text-lg">No holiday types available</p>
                  <p className="text-sm">Please try again later</p>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
      <Footer />
    </>
  );
}