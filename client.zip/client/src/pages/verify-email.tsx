import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, XCircle, Loader2, Mail } from "lucide-react";
import { apiRequest } from "@/lib/queryClient";

export default function VerifyEmail() {
  const [location, setLocation] = useLocation();
  const [status, setStatus] = useState<'verifying' | 'success' | 'error'>('verifying');
  const [message, setMessage] = useState('');
  const [agent, setAgent] = useState<any>(null);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const token = urlParams.get('token');

    if (!token) {
      setStatus('error');
      setMessage('No verification token provided');
      return;
    }

    const verifyEmail = async () => {
      try {
        const response = await apiRequest(`/api/agents/verify-email?token=${token}`);
        
        if (response.token) {
          localStorage.setItem('token', response.token);
        }
        
        setStatus('success');
        setMessage(response.message);
        setAgent(response.agent);
        
        // Redirect to profile completion after 3 seconds
        setTimeout(() => {
          setLocation('/agent/complete-profile');
        }, 3000);
        
      } catch (error: any) {
        setStatus('error');
        setMessage(error.message || 'Email verification failed');
      }
    };

    verifyEmail();
  }, [setLocation]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center space-y-4">
          {status === 'verifying' && (
            <>
              <div className="mx-auto w-16 h-16 bg-orange-100 rounded-full flex items-center justify-center">
                <Loader2 className="w-8 h-8 text-orange-600 animate-spin" />
              </div>
              <CardTitle className="text-2xl font-bold text-gray-900">
                Verifying Email
              </CardTitle>
              <CardDescription>
                Please wait while we verify your email address...
              </CardDescription>
            </>
          )}
          
          {status === 'success' && (
            <>
              <div className="mx-auto w-16 h-16 bg-green-100 rounded-full flex items-center justify-center">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <CardTitle className="text-2xl font-bold text-gray-900">
                Email Verified!
              </CardTitle>
              <CardDescription>
                Great! Your email has been successfully verified.
              </CardDescription>
            </>
          )}
          
          {status === 'error' && (
            <>
              <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center">
                <XCircle className="w-8 h-8 text-red-600" />
              </div>
              <CardTitle className="text-2xl font-bold text-gray-900">
                Verification Failed
              </CardTitle>
              <CardDescription>
                There was a problem verifying your email address.
              </CardDescription>
            </>
          )}
        </CardHeader>
        
        <CardContent className="space-y-4">
          <div className="text-center">
            <p className="text-gray-600 mb-4">{message}</p>
            
            {status === 'success' && (
              <div className="space-y-4">
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center space-x-2 text-green-800">
                    <Mail className="w-4 h-4" />
                    <span className="text-sm font-medium">Email: {agent?.email}</span>
                  </div>
                </div>
                
                <p className="text-sm text-gray-600">
                  You'll be redirected to complete your profile in a few seconds...
                </p>
                
                <Button 
                  onClick={() => setLocation('/agent/complete-profile')}
                  className="w-full bg-orange-600 hover:bg-orange-700"
                >
                  Complete Profile Now
                </Button>
              </div>
            )}
            
            {status === 'error' && (
              <div className="space-y-4">
                <Button 
                  onClick={() => setLocation('/agent/register')}
                  className="w-full bg-orange-600 hover:bg-orange-700"
                >
                  Try Again
                </Button>
                
                <Button 
                  variant="outline"
                  onClick={() => setLocation('/')}
                  className="w-full"
                >
                  Back to Home
                </Button>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}