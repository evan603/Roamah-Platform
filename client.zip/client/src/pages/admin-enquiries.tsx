import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Mail, Phone, Users, Calendar, MapPin, Star, Search, Download, Filter, Image as ImageIcon, LogOut } from "lucide-react";

interface EnquiryData {
  id: number;
  agentId: number;
  agentName: string;
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  numberOfAdults: number;
  numberOfChildren: number;
  childrenAges: number[];
  budgetPerPerson: string;
  destinations: string[];
  holidayTypes: string[];
  travelMonths: string[];
  travelYear: number;
  preferredCallbackTime: string;
  preferredCallbackDate: string;
  enquiryDetails: string;
  status: string;
  isRead: boolean;
  createdAt: string;
}

export function AdminEnquiries() {
  const [, setLocation] = useLocation();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [agentFilter, setAgentFilter] = useState("all");

  // Check admin authentication
  useEffect(() => {
    const adminToken = localStorage.getItem('adminToken');
    if (!adminToken) {
      setLocation('/admin/login');
      return;
    }
  }, [setLocation]);

  const { data: enquiries, isLoading } = useQuery({
    queryKey: ['/api/admin/enquiries'],
    enabled: !!localStorage.getItem('adminToken'),
    retry: (failureCount, error: any) => {
      if (error?.message?.includes('401') || error?.message?.includes('403')) {
        localStorage.removeItem('adminToken');
        setLocation('/admin/login');
        return false;
      }
      return failureCount < 3;
    },
  });

  const { data: agents } = useQuery({
    queryKey: ['/api/agents'],
  });

  const filteredEnquiries = (enquiries || []).filter((enquiry: EnquiryData) => {
    const matchesSearch = 
      enquiry.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      enquiry.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      enquiry.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      enquiry.agentName.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || enquiry.status === statusFilter;
    const matchesAgent = agentFilter === "all" || enquiry.agentId.toString() === agentFilter;
    
    return matchesSearch && matchesStatus && matchesAgent;
  }) || [];

  const exportToCSV = () => {
    if (!filteredEnquiries || filteredEnquiries.length === 0) {
      alert('No enquiries to export');
      return;
    }
    
    // Find maximum number of destinations, holiday types, and travel months in any enquiry
    let maxDestinations = 0;
    let maxHolidayTypes = 0;
    let maxTravelMonths = 0;
    
    filteredEnquiries.forEach((enquiry: EnquiryData) => {
      if (enquiry.destinations && Array.isArray(enquiry.destinations)) {
        maxDestinations = Math.max(maxDestinations, enquiry.destinations.length);
      }
      if (enquiry.holidayTypes && Array.isArray(enquiry.holidayTypes)) {
        maxHolidayTypes = Math.max(maxHolidayTypes, enquiry.holidayTypes.length);
      }
      if (enquiry.travelMonths && Array.isArray(enquiry.travelMonths)) {
        maxTravelMonths = Math.max(maxTravelMonths, enquiry.travelMonths.length);
      }
    });
    
    // Create dynamic headers based on maximum selections
    const destinationHeaders = Array.from({length: maxDestinations}, (_, i) => `Destination ${i + 1}`);
    const holidayTypeHeaders = Array.from({length: maxHolidayTypes}, (_, i) => `Holiday Type ${i + 1}`);
    const travelMonthHeaders = Array.from({length: maxTravelMonths}, (_, i) => `Travel Month ${i + 1}`);
    
    const headers = [
      "Enquiry ID",
      "Date Created", 
      "Agent Name",
      "First Name",
      "Last Name", 
      "Email",
      "Phone Number",
      "Number of Adults",
      "Number of Children", 
      "Children Ages",
      "Budget Per Person",
      ...destinationHeaders,
      ...holidayTypeHeaders,
      "Preferred Callback Time",
      "Preferred Callback Date",
      ...travelMonthHeaders,
      "Travel Year",
      "Enquiry Details",
      "Status",
      "Is Read"
    ];
    
    // Create data rows with selected destination/holiday type names only
    const csvData = filteredEnquiries.map((enquiry: EnquiryData) => {
      const baseData = [
        enquiry.id || '',
        enquiry.createdAt ? new Date(enquiry.createdAt).toLocaleDateString() : '',
        enquiry.agentName || '',
        enquiry.firstName || '',
        enquiry.lastName || '',
        enquiry.email || '',
        enquiry.phoneNumber || '',
        enquiry.numberOfAdults || 0,
        enquiry.numberOfChildren || 0,
        (enquiry.childrenAges && Array.isArray(enquiry.childrenAges)) ? enquiry.childrenAges.join(', ') : '',
        enquiry.budgetPerPerson || ''
      ];
      
      // Add selected destinations (just the names, empty cells for unused columns)
      const destinationData = Array.from({length: maxDestinations}, (_, i) => {
        if (enquiry.destinations && Array.isArray(enquiry.destinations) && enquiry.destinations[i]) {
          return enquiry.destinations[i];
        }
        return '';
      });
      
      // Add selected holiday types (just the names, empty cells for unused columns)
      const holidayTypeData = Array.from({length: maxHolidayTypes}, (_, i) => {
        if (enquiry.holidayTypes && Array.isArray(enquiry.holidayTypes) && enquiry.holidayTypes[i]) {
          return enquiry.holidayTypes[i];
        }
        return '';
      });
      
      // Add callback data
      const callbackData = [
        enquiry.preferredCallbackTime || '',
        enquiry.preferredCallbackDate || ''
      ];
      
      // Add selected travel months (each month in its own column)
      const travelMonthData = Array.from({length: maxTravelMonths}, (_, i) => {
        if (enquiry.travelMonths && Array.isArray(enquiry.travelMonths) && enquiry.travelMonths[i]) {
          return enquiry.travelMonths[i];
        }
        return '';
      });
      
      const endData = [
        enquiry.travelYear || '',
        (enquiry.enquiryDetails || '').replace(/"/g, '""'),
        enquiry.status || '',
        enquiry.isRead ? 'Yes' : 'No'
      ];
      
      return [...baseData, ...destinationData, ...holidayTypeData, ...callbackData, ...travelMonthData, ...endData];
    });
    
    // Create CSV content with proper quoting
    const csvContent = [headers, ...csvData]
      .map(row => row.map(cell => `"${String(cell)}"`).join(','))
      .join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `roamah-enquiries-${new Date().toISOString().split('T')[0]}.csv`;
    a.style.visibility = 'hidden';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    window.URL.revokeObjectURL(url);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-roamah-cream to-white p-6">
        <div className="max-w-7xl mx-auto">
          <div className="text-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-roamah-orange mx-auto"></div>
            <p className="mt-4 text-roamah-gray">Loading enquiry data...</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-roamah-cream to-white p-6">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-3xl font-bold text-roamah-dark mb-2">
                Admin: All Customer Enquiries
              </h1>
              <p className="text-roamah-gray">
                Complete access to all enquiry data across all travel agents
              </p>
            </div>
            <div className="flex gap-3">
              <Button 
                variant="outline"
                onClick={() => setLocation('/admin/agents')}
                className="flex items-center space-x-2"
              >
                <Users className="h-4 w-4" />
                <span>Agents</span>
              </Button>
              <Button 
                variant="outline"
                onClick={() => setLocation('/admin/images')}
                className="flex items-center space-x-2"
              >
                <ImageIcon className="h-4 w-4" />
                <span>Images</span>
              </Button>
              <Button 
                variant="outline"
                onClick={() => setLocation('/admin/email-automation')}
                className="flex items-center space-x-2"
              >
                <Mail className="h-4 w-4" />
                <span>Email Automation</span>
              </Button>
              <Button 
                variant="outline"
                onClick={() => {
                  localStorage.removeItem('adminToken');
                  setLocation('/admin/login');
                }}
                className="text-red-600 border-red-200 hover:bg-red-50"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Sign Out
              </Button>
            </div>
          </div>
        </div>

        {/* Controls */}
        <Card className="mb-6">
          <CardContent className="p-6">
            <div className="flex flex-wrap gap-4 items-center justify-between">
              <div className="flex flex-wrap gap-4 items-center">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder="Search customers, emails, agents..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 w-64"
                  />
                </div>
                
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-40">
                    <Filter className="h-4 w-4 mr-2" />
                    <SelectValue placeholder="Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="contacted">Contacted</SelectItem>
                    <SelectItem value="completed">Completed</SelectItem>
                  </SelectContent>
                </Select>

                <Select value={agentFilter} onValueChange={setAgentFilter}>
                  <SelectTrigger className="w-48">
                    <SelectValue placeholder="All Agents" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Agents</SelectItem>
                    {agents?.map((agent: any) => (
                      <SelectItem key={agent.id} value={agent.id.toString()}>
                        {agent.name || `${agent.firstName} ${agent.lastName}`}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex gap-2">
                <Badge variant="secondary" className="px-3 py-1">
                  Total: {filteredEnquiries.length} enquiries
                </Badge>
                <Button
                  onClick={exportToCSV}
                  className="bg-roamah-orange hover:bg-roamah-orange/90"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Export CSV
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Enquiries Grid */}
        <div className="grid gap-6">
          {(filteredEnquiries || []).map((enquiry: EnquiryData) => (
            <Card key={enquiry.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-4">
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="text-xl text-roamah-dark">
                      {enquiry.firstName} {enquiry.lastName}
                    </CardTitle>
                    <p className="text-sm text-roamah-gray">
                      Enquiry #{enquiry.id} • {new Date(enquiry.createdAt).toLocaleDateString()} at {new Date(enquiry.createdAt).toLocaleTimeString()}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    <Badge 
                      variant={enquiry.status === 'pending' ? 'destructive' : 'default'}
                      className="capitalize"
                    >
                      {enquiry.status}
                    </Badge>
                    <Badge 
                      variant={enquiry.isRead ? 'default' : 'secondary'}
                    >
                      {enquiry.isRead ? 'Read' : 'Unread'}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              
              <CardContent className="space-y-4">
                {/* Contact Information */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold text-roamah-dark">Contact Information</h4>
                    <div className="flex items-center gap-2 text-sm">
                      <Mail className="h-4 w-4 text-roamah-orange" />
                      <a href={`mailto:${enquiry.email}`} className="text-blue-600 hover:underline">
                        {enquiry.email}
                      </a>
                    </div>
                    <div className="flex items-center gap-2 text-sm">
                      <Phone className="h-4 w-4 text-roamah-orange" />
                      <a href={`tel:${enquiry.phoneNumber}`} className="text-blue-600 hover:underline">
                        {enquiry.phoneNumber}
                      </a>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-semibold text-roamah-dark">Assigned Agent</h4>
                    <div className="flex items-center gap-2 text-sm">
                      <Star className="h-4 w-4 text-roamah-orange" />
                      <span>{enquiry.agentName}</span>
                    </div>
                  </div>
                </div>

                {/* Travel Details */}
                <div className="grid md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <h4 className="font-semibold text-roamah-dark">Travel Party</h4>
                    <div className="flex items-center gap-2 text-sm">
                      <Users className="h-4 w-4 text-roamah-orange" />
                      <span>
                        {enquiry.numberOfAdults} adult{enquiry.numberOfAdults !== 1 ? 's' : ''}
                        {enquiry.numberOfChildren > 0 && (
                          <>, {enquiry.numberOfChildren} child{enquiry.numberOfChildren !== 1 ? 'ren' : ''} 
                          (ages: {(enquiry.childrenAges || []).join(', ')})</>
                        )}
                      </span>
                    </div>
                    <div className="text-sm">
                      <span className="font-medium">Budget per person:</span> {enquiry.budgetPerPerson}
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <h4 className="font-semibold text-roamah-dark">Callback Preferences</h4>
                    {enquiry.preferredCallbackTime && (
                      <div className="flex items-center gap-2 text-sm">
                        <Calendar className="h-4 w-4 text-roamah-orange" />
                        <span>{enquiry.preferredCallbackTime}</span>
                      </div>
                    )}
                    {enquiry.preferredCallbackDate && (
                      <div className="text-sm">
                        <span className="font-medium">Preferred date:</span> {enquiry.preferredCallbackDate}
                      </div>
                    )}
                  </div>
                </div>

                {/* Destinations & Holiday Types */}
                <div className="space-y-2">
                  <h4 className="font-semibold text-roamah-dark">Travel Preferences</h4>
                  <div className="space-y-2">
                    <div>
                      <span className="text-sm font-medium text-roamah-gray">Destinations:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {(enquiry.destinations || []).map((dest, index) => (
                          <Badge key={index} variant="outline" className="text-xs">
                            <MapPin className="h-3 w-3 mr-1" />
                            {dest}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <span className="text-sm font-medium text-roamah-gray">Holiday Types:</span>
                      <div className="flex flex-wrap gap-1 mt-1">
                        {(enquiry.holidayTypes || []).map((type, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {type}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <div>
                      <span className="text-sm font-medium text-roamah-gray">Travel Time:</span>
                      <div className="flex items-center gap-2 text-sm mt-1">
                        <Calendar className="h-4 w-4 text-roamah-orange" />
                        <span>
                          {(enquiry.travelMonths && enquiry.travelMonths.length > 0) 
                            ? enquiry.travelMonths.join(', ') 
                            : 'Not specified'} {enquiry.travelYear || ''}
                        </span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Enquiry Details */}
                <div className="space-y-2">
                  <h4 className="font-semibold text-roamah-dark">Customer Requirements</h4>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-sm text-roamah-dark whitespace-pre-wrap">
                      {enquiry.enquiryDetails}
                    </p>
                  </div>
                </div>

                {/* Quick Actions */}
                <div className="flex gap-2 pt-2 border-t">
                  <Button 
                    size="sm" 
                    className="bg-roamah-orange hover:bg-roamah-orange/90"
                    onClick={() => window.open(`mailto:${enquiry.email}?subject=Re: Your Travel Enquiry #${enquiry.id}&body=Dear ${enquiry.firstName},\n\nThank you for your enquiry about ${(enquiry.destinations || []).join(', ')}. I'd be delighted to help you plan your ${(enquiry.holidayTypes || []).join(' and ')} experience.\n\nBest regards,\n${enquiry.agentName}`, '_blank')}
                  >
                    <Mail className="h-4 w-4 mr-1" />
                    Reply via Email
                  </Button>
                  <Button 
                    size="sm" 
                    variant="outline"
                    onClick={() => window.open(`tel:${enquiry.phoneNumber}`, '_blank')}
                  >
                    <Phone className="h-4 w-4 mr-1" />
                    Call Customer
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {filteredEnquiries.length === 0 && (
          <Card>
            <CardContent className="text-center py-12">
              <Search className="h-12 w-12 text-gray-300 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-roamah-dark mb-2">No enquiries found</h3>
              <p className="text-roamah-gray">
                {searchTerm || statusFilter !== "all" || agentFilter !== "all" 
                  ? "Try adjusting your search or filters" 
                  : "No enquiries have been submitted yet"}
              </p>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}