import { useQuery } from "@tanstack/react-query";
import { useParams, Link } from "wouter";
import { ArrowLeft, Clock } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { BlogReactions } from "@/components/BlogReactions";
import type { BlogPost, Agent } from "@shared/schema";

type BlogPostWithAgent = BlogPost & { agent: Agent };

export default function BlogDetail() {
  const { slug } = useParams();
  
  const { data: post, isLoading } = useQuery<BlogPostWithAgent>({
    queryKey: [`/api/blog/${slug}`],
  });

  const formatDate = (date: string | Date) => {
    const d = new Date(date);
    return d.toLocaleDateString('en-US', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded mb-4 w-32"></div>
            <div className="h-12 bg-gray-200 rounded mb-6"></div>
            <div className="h-64 bg-gray-200 rounded mb-8"></div>
            <div className="space-y-4">
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2"></div>
            </div>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  if (!post) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Blog post not found</h1>
            <Link href="/">
              <Button>Return Home</Button>
            </Link>
          </div>
        </div>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      
      <article className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back button */}
        <Link href="/">
          <Button variant="ghost" className="mb-6 text-roamah-orange hover:text-roamah-orange/80">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Home
          </Button>
        </Link>

        {/* Blog header */}
        <header className="mb-8">
          {/* Tags */}
          <div className="flex flex-wrap gap-2 mb-4">
            {post.holidayTypes?.map((type) => (
              <Badge key={type} variant="secondary" className="bg-green-100 text-green-800">
                {type}
              </Badge>
            ))}
            {post.destinations?.map((dest) => (
              <Badge key={dest} variant="secondary" className="bg-blue-100 text-blue-800">
                {dest}
              </Badge>
            ))}
          </div>

          {/* Title */}
          <h1 className="text-4xl font-bold text-roamah-dark mb-4">{post.title}</h1>
          
          {/* Excerpt */}
          <p className="text-xl text-roamah-gray mb-6">{post.excerpt}</p>

          {/* Author and date */}
          <div className="flex items-center justify-between border-b border-gray-200 pb-6">
            <Link href={`/agent/${post.agent.id}`}>
              <div className="flex items-center cursor-pointer hover:opacity-80 transition-opacity">
                <img
                  src={post.agent.profileImage ?? 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face'}
                  alt={post.agent.name ?? 'Agent'}
                  className="w-12 h-12 rounded-full mr-4 aspect-square object-cover"
                />
                <div>
                  <p className="font-semibold text-roamah-dark">{post.agent.name ?? 'Travel Agent'}</p>
                  <p className="text-sm text-roamah-gray">Travel Expert</p>
                </div>
              </div>
            </Link>
            
            <div className="flex items-center text-roamah-gray">
              <Clock className="h-4 w-4 mr-2" />
              <span className="text-sm">
                {post.publishedAt ? formatDate(post.publishedAt) : formatDate(post.createdAt)}
              </span>
            </div>
          </div>
        </header>

        {/* Hero image */}
        {post.heroImage && (
          <div className="mb-8">
            <img
              src={post.heroImage}
              alt={post.title}
              className="w-full h-96 object-cover rounded-lg shadow-lg"
            />
          </div>
        )}

        {/* Content */}
        <div className="prose prose-lg max-w-none">
          <div 
            className="text-roamah-dark leading-relaxed"
            dangerouslySetInnerHTML={{ __html: post.content }}
          />
        </div>

        {/* Blog Reactions */}
        <div className="mt-8">
          <BlogReactions blogPostId={post.id} />
        </div>

        {/* Call to action */}
        <div className="mt-12 p-6 bg-roamah-orange/10 rounded-lg">
          <div className="text-center">
            <h3 className="text-2xl font-bold text-roamah-dark mb-4">
              Interested in this destination?
            </h3>
            <p className="text-roamah-gray mb-6">
              Get in touch with {post.agent.name} to plan your perfect trip
            </p>
            <Link href={`/agent/${post.agent.id}`}>
              <Button className="bg-roamah-orange hover:bg-roamah-orange/90 text-white">
                View {post.agent.name}'s Profile
              </Button>
            </Link>
          </div>
        </div>
      </article>

      <Footer />
    </div>
  );
}