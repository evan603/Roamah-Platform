import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useLocation } from "wouter";
import { 
  Search, 
  Users, 
  MessageCircle, 
  CheckCircle,
  Star,
  Globe,
  Shield,
  Clock,
  Award,
  Heart
} from "lucide-react";

export default function HowItWorks() {
  const [, setLocation] = useLocation();

  const travelerSteps = [
    {
      icon: Search,
      title: "Browse & Discover",
      description: "Search for travel experts by destination, holiday type, or expertise. Filter by ratings, specializations, and location to find your perfect match."
    },
    {
      icon: Users,
      title: "View Expert Profiles",
      description: "Explore detailed expert profiles featuring their specializations, customer reviews, blog posts, and exclusive holiday offers."
    },
    {
      icon: MessageCircle,
      title: "Send Enquiry",
      description: "Submit your travel requirements directly to your chosen expert. Include dates, preferences, budget, and any special requests."
    },
    {
      icon: CheckCircle,
      title: "Get Personalised Service",
      description: "Your expert will contact you directly to create a customised travel experience tailored to your needs and preferences."
    }
  ];

  const agentSteps = [
    {
      icon: Award,
      title: "Create Your Profile",
      description: "Set up your professional profile with specializations, experience, and showcase your expertise to attract travelers."
    },
    {
      icon: Globe,
      title: "Tag Destinations & Holiday Types",
      description: "Select up to 5 destinations and 5 holiday types that match your expertise to appear in relevant searches."
    },
    {
      icon: Heart,
      title: "Receive Enquiries",
      description: "Get matched with travelers looking for your specific expertise and receive enquiries directly through the platform."
    },
    {
      icon: Star,
      title: "Build Your Reputation",
      description: "Deliver exceptional service, earn reviews, and grow your business through the Roamah marketplace."
    }
  ];

  const benefits = [
    {
      icon: Shield,
      title: "Trusted Platform",
      description: "All experts are verified professionals with transparent ratings and reviews from real customers."
    },
    {
      icon: Clock,
      title: "Save Time",
      description: "Find the right travel expert quickly without endless research or comparison shopping."
    },
    {
      icon: Star,
      title: "Expert Knowledge",
      description: "Connect with specialists who have deep knowledge of your chosen destination or holiday type."
    },
    {
      icon: Heart,
      title: "Personalised Service",
      description: "Get customised travel planning that matches your preferences, budget, and travel style."
    }
  ];

  return (
    <>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        
        <main>
          {/* Hero Section */}
          <section className="bg-roamah-peach py-20">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
              <h1 className="text-5xl font-bold mb-6 text-roamah-dark">How Roamah Works</h1>
              <p className="text-xl max-w-3xl mx-auto mb-8 text-roamah-gray">
                Connecting travelers with travel experts for personalised holiday experiences. 
                Whether you're planning your dream vacation or growing your travel business, we make it simple.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  className="bg-roamah-orange text-white hover:bg-roamah-orange/90 font-bold px-8 py-3"
                  onClick={() => setLocation("/browse-agents")}
                >
                  Find Travel Experts
                </Button>
                <Button 
                  variant="outline" 
                  className="border-roamah-orange text-roamah-orange hover:bg-roamah-orange hover:text-white font-bold px-8 py-3"
                >
                  Register as Expert
                </Button>
              </div>
            </div>
          </section>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
            {/* For Travelers Section */}
            <section className="mb-20">
              <div className="text-center mb-12">
                <h2 className="text-4xl font-bold text-roamah-dark mb-4">For Travelers</h2>
                <p className="text-xl text-roamah-gray max-w-3xl mx-auto">
                  Find and connect with travel experts who specialise in your dream destination or holiday type
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {travelerSteps.map((step, index) => {
                  const IconComponent = step.icon;
                  return (
                    <Card key={index} className="relative border-0 shadow-lg hover:shadow-xl transition-shadow">
                      <CardHeader className="text-center pb-4">
                        <div className="mx-auto w-16 h-16 bg-roamah-orange rounded-full flex items-center justify-center mb-4">
                          <IconComponent className="h-8 w-8 text-white" />
                        </div>
                        <div className="absolute -top-3 -left-3 w-8 h-8 bg-roamah-dark text-white rounded-full flex items-center justify-center font-bold text-lg">
                          {index + 1}
                        </div>
                        <CardTitle className="text-xl text-roamah-dark">{step.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <CardDescription className="text-roamah-gray text-center">
                          {step.description}
                        </CardDescription>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </section>

            {/* For Travel Experts Section */}
            <section className="mb-20">
              <div className="text-center mb-12">
                <h2 className="text-4xl font-bold text-roamah-dark mb-4">For Travel Experts</h2>
                <p className="text-xl text-roamah-gray max-w-3xl mx-auto">
                  Grow your travel business by connecting with travelers looking for your specific expertise
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {agentSteps.map((step, index) => {
                  const IconComponent = step.icon;
                  return (
                    <Card key={index} className="relative border-0 shadow-lg hover:shadow-xl transition-shadow">
                      <CardHeader className="text-center pb-4">
                        <div className="mx-auto w-16 h-16 bg-blue-200 rounded-full flex items-center justify-center mb-4">
                          <IconComponent className="h-8 w-8 text-blue-700" />
                        </div>
                        <div className="absolute -top-3 -left-3 w-8 h-8 bg-roamah-dark text-white rounded-full flex items-center justify-center font-bold text-lg">
                          {index + 1}
                        </div>
                        <CardTitle className="text-xl text-roamah-dark">{step.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <CardDescription className="text-roamah-gray text-center">
                          {step.description}
                        </CardDescription>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </section>

            {/* Why Choose Roamah Section */}
            <section className="mb-20">
              <div className="text-center mb-12">
                <h2 className="text-4xl font-bold text-roamah-dark mb-4">Why Choose Roamah?</h2>
                <p className="text-xl text-roamah-gray max-w-3xl mx-auto">
                  Experience the benefits of connecting with specialist travel experts through our trusted platform
                </p>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {benefits.map((benefit, index) => {
                  const IconComponent = benefit.icon;
                  return (
                    <Card key={index} className="border-0 shadow-lg hover:shadow-xl transition-shadow">
                      <CardHeader className="text-center">
                        <div className="mx-auto w-16 h-16 bg-orange-200 rounded-full flex items-center justify-center mb-4">
                          <IconComponent className="h-8 w-8 text-orange-700" />
                        </div>
                        <CardTitle className="text-xl text-roamah-dark">{benefit.title}</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <CardDescription className="text-roamah-gray text-center">
                          {benefit.description}
                        </CardDescription>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </section>

            {/* CTA Section */}
            <section className="bg-gradient-to-r from-roamah-peach to-orange-50 rounded-2xl p-12 text-center">
              <h2 className="text-3xl font-bold text-roamah-dark mb-4">Ready to Get Started?</h2>
              <p className="text-xl text-roamah-gray mb-8 max-w-2xl mx-auto">
                Join thousands of travelers and travel agents who trust Roamah for exceptional holiday experiences
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button 
                  className="bg-roamah-orange hover:bg-roamah-orange/90 font-bold px-8 py-3"
                  onClick={() => setLocation("/browse-agents")}
                >
                  Start Planning Your Trip
                </Button>
                <Button 
                  variant="outline" 
                  className="border-roamah-orange text-roamah-orange hover:bg-roamah-orange hover:text-white font-bold px-8 py-3"
                  onClick={() => setLocation("/agent-register")}
                >
                  Join as Travel Agent
                </Button>
              </div>
            </section>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
}