import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { AgentCard } from "@/components/ui/agent-card";
import { EnquiryModal } from "@/components/ui/enquiry-modal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search } from "lucide-react";
import type { Agent } from "@shared/schema";
import { UK_CITIES } from "@/lib/constants";

export default function BrowseAgents() {
  const [location] = useLocation();
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);
  const [enquiryModalOpen, setEnquiryModalOpen] = useState(false);
  
  // Parse URL parameters and handle holiday type route
  const params = new URLSearchParams(location.split('?')[1] || '');
  const pathParts = location.split('/');
  const isHolidayTypeRoute = pathParts[1] === 'holiday-type' && pathParts[2];
  
  // Convert holiday type slug back to display name for filtering
  const getHolidayTypeFromSlug = (slug: string) => {
    const mapping: { [key: string]: string } = {
      'luxury-holidays': 'Luxury Holidays',
      'honeymoons': 'Honeymoons', 
      'cruises': 'Cruises',
      'beach-holidays': 'Beach Holidays',
      'safari-holidays': 'Safari Holidays',
      'family-holidays': 'Family Holidays',
      'adventure-holidays': 'Adventure Holidays',
      'city-breaks': 'City Breaks',
      'romantic-holidays': 'Romantic Holidays',
      'cultural-holidays': 'Cultural Holidays',
      'wellness-holidays': 'Wellness Holidays',
      'group-holidays': 'Group Holidays'
    };
    return mapping[slug] || '';
  };
  
  const initialHolidayType = isHolidayTypeRoute 
    ? getHolidayTypeFromSlug(pathParts[2]) 
    : (params.get('holidayType') || '');
  
  const [searchQuery, setSearchQuery] = useState(params.get('search') || '');
  const [filters, setFilters] = useState({
    location: params.get('location') || '',
    holidayType: initialHolidayType,
    destination: params.get('destination') || '',
    speciality: params.get('speciality') || '',
    sort: params.get('sort') || 'top-rated',
  });

  // Fetch holiday types and destinations from API
  const { data: holidayTypes } = useQuery<any[]>({
    queryKey: ["/api/holiday-types"],
  });

  const { data: destinations } = useQuery<any[]>({
    queryKey: ["/api/destinations"],
  });

  const { data: agents, isLoading } = useQuery<Agent[]>({
    queryKey: ["/api/agents", { ...filters, search: searchQuery }],
    queryFn: async () => {
      const params = new URLSearchParams();
      
      if (searchQuery) params.append('search', searchQuery);
      if (filters.location && filters.location !== 'all') params.append('location', filters.location);
      if (filters.holidayType && filters.holidayType !== 'all') params.append('holidayType', filters.holidayType);
      if (filters.destination && filters.destination !== 'all') params.append('destination', filters.destination);
      if (filters.speciality && filters.speciality !== 'all') params.append('speciality', filters.speciality);
      if (filters.sort) params.append('sort', filters.sort);
      
      const url = `/api/agents${params.toString() ? `?${params.toString()}` : ''}`;
      const response = await fetch(url, { 
        credentials: 'include',
        cache: 'no-cache',
        headers: {
          'Cache-Control': 'no-cache, no-store, must-revalidate',
          'Pragma': 'no-cache',
          'Expires': '0'
        }
      });
      
      if (!response.ok) {
        throw new Error(`${response.status}: ${response.statusText}`);
      }
      
      return response.json();
    },
    staleTime: 0, // Always refetch to ensure fresh data
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // The query will automatically refetch due to dependency on searchQuery
  };

  const handleEnquire = (agent: Agent) => {
    setSelectedAgent(agent);
    setEnquiryModalOpen(true);
  };

  const clearFilters = () => {
    setSearchQuery('');
    setFilters({
      location: 'all',
      holidayType: 'all',
      destination: 'all',
      speciality: 'all',
      sort: 'top-rated',
    });
  };

  return (
    <>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        
        <main className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Hero Section */}
            <div className="bg-gradient-to-r from-orange-50 to-pink-50 rounded-2xl p-8 mb-12">
              <div className="text-center">
                <h1 className="text-4xl font-bold text-roamah-dark mb-4">
                  {isHolidayTypeRoute ? `${getHolidayTypeFromSlug(pathParts[2])} Specialists` : 'Browse Travel Experts'}
                </h1>
                <p className="text-xl text-roamah-gray mb-8">
                  {isHolidayTypeRoute 
                    ? `Find expert travel experts who specialise in ${getHolidayTypeFromSlug(pathParts[2]).toLowerCase()} and can create your perfect getaway`
                    : 'Find experienced travel experts who specialise in your dream destination and holiday type. Browse profiles, read reviews, and connect with the perfect expert for your next adventure.'
                  }
                </p>
              
                {/* Search Bar */}
                <form onSubmit={handleSearch} className="max-w-xl mx-auto">
                  <div className="flex rounded-lg shadow-sm overflow-hidden">
                    <Input
                      type="text"
                      placeholder="Search by name"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="flex-1 rounded-none border-r-0"
                    />
                    <Button type="submit" className="bg-roamah-orange hover:bg-roamah-orange/90 rounded-none">
                      <Search className="h-4 w-4" />
                    </Button>
                  </div>
                </form>
              </div>
            </div>

            {/* Filters */}
            <div className="bg-white rounded-lg p-6 shadow-sm mb-8">
              <div className="grid grid-cols-1 md:grid-cols-5 gap-4 items-end">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Agent location</label>
                  <Select value={filters.location} onValueChange={(value) => setFilters({ ...filters, location: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Any location" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Any location</SelectItem>
                      {UK_CITIES.map((city) => (
                        <SelectItem key={city} value={city}>{city}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Holiday type</label>
                  <Select value={filters.holidayType} onValueChange={(value) => setFilters({ ...filters, holidayType: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Any type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Any type</SelectItem>
                      {holidayTypes?.sort((a: any, b: any) => a.name.localeCompare(b.name)).map((type: any) => (
                        <SelectItem key={type.slug} value={type.name}>{type.name}</SelectItem>
                      )) || []}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Destination</label>
                  <Select value={filters.destination} onValueChange={(value) => setFilters({ ...filters, destination: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Any destination" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Any destination</SelectItem>
                      {destinations?.map((dest) => dest.name).sort((a, b) => a.localeCompare(b)).map((dest) => (
                        <SelectItem key={dest} value={dest}>{dest}</SelectItem>
                      )) || []}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Sort by</label>
                  <Select value={filters.sort} onValueChange={(value) => setFilters({ ...filters, sort: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="top-rated">Top rated</SelectItem>
                      <SelectItem value="recommended">Recommended</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex gap-2">
                  <Button 
                    variant="outline" 
                    onClick={clearFilters}
                    className="flex-1 font-bold"
                  >
                    Clear
                  </Button>
                </div>
              </div>
            </div>

            {/* Results count */}
            <div className="mb-6">
              <p className="text-roamah-gray">
                {isLoading ? 'Loading...' : `${agents?.length || 0} travel experts found`}
              </p>
            </div>

            {/* All agents grid */}
            {isLoading ? (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <div key={i} className="animate-pulse">
                    <div className="bg-white rounded-2xl p-6 shadow-lg">
                      <div className="bg-gray-200 rounded-xl h-48 mb-4"></div>
                      <div className="h-4 bg-gray-200 rounded mb-2"></div>
                      <div className="h-4 bg-gray-200 rounded w-3/4"></div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {agents?.map((agent) => (
                  <AgentCard
                    key={agent.id}
                    agent={agent}
                    onEnquire={handleEnquire}
                  />
                ))}
              </div>
            )}

            {!isLoading && (!agents || agents.length === 0) && (
              <div className="text-center py-12">
                <h3 className="text-xl font-semibold text-gray-600 mb-2">No agents found</h3>
                <p className="text-gray-500 mb-4">Try adjusting your search criteria</p>
                <Button onClick={clearFilters} className="font-bold">Clear all filters</Button>
              </div>
            )}
          </div>
        </main>

        <Footer />
      </div>

      <EnquiryModal
        isOpen={enquiryModalOpen}
        onClose={() => setEnquiryModalOpen(false)}
        agent={selectedAgent}
      />
    </>
  );
}
