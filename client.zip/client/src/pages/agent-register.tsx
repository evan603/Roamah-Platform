import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { agentRegistrationSchema, type AgentRegistration, LANGUAGES } from "@shared/schema";
import { UK_CITIES } from "@/lib/constants";
import { useQuery, useMutation } from "@tanstack/react-query";
import { X } from "lucide-react";

export default function AgentRegister() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [selectedSpecializations, setSelectedSpecializations] = useState<string[]>([]);
  const [selectedDestinations, setSelectedDestinations] = useState<string[]>([]);
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>([]);

  const form = useForm<AgentRegistration>({
    resolver: zodResolver(agentRegistrationSchema),
    defaultValues: {
      email: "",
      password: "",
      firstName: "",
      lastName: "",
      location: "",
      company: "",
      nextHoliday: "",
      specializations: [],
      destinations: [],
      languages: [],
      bio: "",
      yearsExperience: 0,
    },
  });

  // Fetch holiday types and destinations
  const { data: holidayTypes } = useQuery({
    queryKey: ['/api/holiday-types'],
  });

  const { data: destinationsData } = useQuery({
    queryKey: ['/api/destinations'],
  });

  const registrationMutation = useMutation({
    mutationFn: async (data: AgentRegistration) => {
      return apiRequest('/api/agents/register', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },
    onSuccess: (response: any) => {
      // Store token in localStorage for auto-login
      localStorage.setItem('agentToken', response.token);
      
      toast({
        title: "Registration Successful!",
        description: "Welcome to Roamah! Redirecting to your dashboard...",
      });
      setLocation("/agent-dashboard");
    },
    onError: (error: any) => {
      toast({
        title: "Registration Failed",
        description: error.message || "Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSpecializationToggle = (specialization: string) => {
    const updated = selectedSpecializations.includes(specialization)
      ? selectedSpecializations.filter(s => s !== specialization)
      : selectedSpecializations.length < 5 
        ? [...selectedSpecializations, specialization]
        : selectedSpecializations;
    
    setSelectedSpecializations(updated);
    form.setValue('specializations', updated);
  };

  const handleDestinationToggle = (destination: string) => {
    const updated = selectedDestinations.includes(destination)
      ? selectedDestinations.filter(d => d !== destination)
      : selectedDestinations.length < 5 
        ? [...selectedDestinations, destination]
        : selectedDestinations;
    
    setSelectedDestinations(updated);
    form.setValue('destinations', updated);
  };

  const handleLanguageToggle = (language: string) => {
    const updated = selectedLanguages.includes(language)
      ? selectedLanguages.filter(l => l !== language)
      : [...selectedLanguages, language];
    
    setSelectedLanguages(updated);
    form.setValue('languages', updated);
  };

  const onSubmit = (data: AgentRegistration) => {
    registrationMutation.mutate(data);
  };

  return (
    <>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        
        <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center mb-8">
            <h1 className="text-3xl font-bold text-roamah-dark mb-4">Join Roamah as a Travel Expert</h1>
            <p className="text-lg text-roamah-gray">
              Create your professional profile and start connecting with travelers worldwide
            </p>
          </div>

          <Card className="shadow-lg">
            <CardHeader>
              <CardTitle className="text-2xl text-roamah-dark">Expert Registration</CardTitle>
              <CardDescription>
                Fill out your profile information to get started. All fields marked with * are required.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                  {/* Personal Information */}
                  <div className="space-y-6">
                    <h3 className="text-lg font-semibold text-roamah-dark border-b pb-2">Personal Information</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="firstName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>First Name *</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your first name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="lastName"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Last Name *</FormLabel>
                            <FormControl>
                              <Input placeholder="Enter your last name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="email"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Email Address *</FormLabel>
                            <FormControl>
                              <Input type="email" placeholder="your.email@example.com" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="password"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Password *</FormLabel>
                            <FormControl>
                              <Input type="password" placeholder="Minimum 8 characters" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  {/* Business Information */}
                  <div className="space-y-6">
                    <h3 className="text-lg font-semibold text-roamah-dark border-b pb-2">Business Information</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="company"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Business Name *</FormLabel>
                            <FormControl>
                              <Input placeholder="Your travel expert business name" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="location"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Location *</FormLabel>
                            <Select onValueChange={field.onChange} value={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select your city" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                {UK_CITIES.map((city) => (
                                  <SelectItem key={city} value={city}>{city}</SelectItem>
                                ))}
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField
                        control={form.control}
                        name="yearsExperience"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Years of Experience *</FormLabel>
                            <FormControl>
                              <Input 
                                type="number" 
                                min="0" 
                                placeholder="0" 
                                {...field} 
                                onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                              />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="nextHoliday"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Next Holiday Destination</FormLabel>
                            <FormControl>
                              <Input placeholder="e.g., Santorini, Greece" {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>

                  {/* Specializations */}
                  <div className="space-y-6">
                    <h3 className="text-lg font-semibold text-roamah-dark border-b pb-2">Holiday Specializations (Max 5) *</h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                      {holidayTypes?.map((type: any) => (
                        <div key={type.name} className="flex items-center space-x-2">
                          <Checkbox
                            id={`spec-${type.slug}`}
                            checked={selectedSpecializations.includes(type.name)}
                            onCheckedChange={() => handleSpecializationToggle(type.name)}
                            disabled={!selectedSpecializations.includes(type.name) && selectedSpecializations.length >= 5}
                          />
                          <label htmlFor={`spec-${type.slug}`} className="text-sm font-medium">
                            {type.name}
                          </label>
                        </div>
                      ))}
                    </div>
                    {selectedSpecializations.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {selectedSpecializations.map((spec) => (
                          <Badge key={spec} variant="secondary" className="bg-orange-100 text-orange-800">
                            {spec}
                            <button 
                              type="button" 
                              onClick={() => handleSpecializationToggle(spec)}
                              className="ml-1 hover:text-orange-600"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Expert Destinations */}
                  <div className="space-y-6">
                    <h3 className="text-lg font-semibold text-roamah-dark border-b pb-2">Expert Destinations (Max 5) *</h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                      {destinationsData?.map((dest: any) => (
                        <div key={dest.name} className="flex items-center space-x-2">
                          <Checkbox
                            id={`dest-${dest.slug}`}
                            checked={selectedDestinations.includes(dest.name)}
                            onCheckedChange={() => handleDestinationToggle(dest.name)}
                            disabled={!selectedDestinations.includes(dest.name) && selectedDestinations.length >= 5}
                          />
                          <label htmlFor={`dest-${dest.slug}`} className="text-sm font-medium">
                            {dest.name}
                          </label>
                        </div>
                      ))}
                    </div>
                    {selectedDestinations.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {selectedDestinations.map((dest) => (
                          <Badge key={dest} variant="secondary" className="bg-blue-100 text-blue-800">
                            {dest}
                            <button 
                              type="button" 
                              onClick={() => handleDestinationToggle(dest)}
                              className="ml-1 hover:text-blue-600"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Languages */}
                  <div className="space-y-6">
                    <h3 className="text-lg font-semibold text-roamah-dark border-b pb-2">Languages Spoken *</h3>
                    <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                      {LANGUAGES.map((language) => (
                        <div key={language} className="flex items-center space-x-2">
                          <Checkbox
                            id={`lang-${language}`}
                            checked={selectedLanguages.includes(language)}
                            onCheckedChange={() => handleLanguageToggle(language)}
                          />
                          <label htmlFor={`lang-${language}`} className="text-sm font-medium">
                            {language}
                          </label>
                        </div>
                      ))}
                    </div>
                    {selectedLanguages.length > 0 && (
                      <div className="flex flex-wrap gap-2">
                        {selectedLanguages.map((lang) => (
                          <Badge key={lang} variant="secondary" className="bg-gray-100 text-gray-800">
                            {lang}
                            <button 
                              type="button" 
                              onClick={() => handleLanguageToggle(lang)}
                              className="ml-1 hover:text-gray-600"
                            >
                              <X className="w-3 h-3" />
                            </button>
                          </Badge>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* About Me */}
                  <div className="space-y-6">
                    <h3 className="text-lg font-semibold text-roamah-dark border-b pb-2">About Me *</h3>
                    <FormField
                      control={form.control}
                      name="bio"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tell us about yourself and your travel expertise (50-2000 characters) *</FormLabel>
                          <FormControl>
                            <Textarea 
                              placeholder="Share your travel experience, expertise, and what makes you unique as a travel expert..."
                              className="min-h-32"
                              {...field}
                            />
                          </FormControl>
                          <div className="text-sm text-gray-500">
                            {field.value?.length || 0}/2000 characters
                          </div>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Submit Button */}
                  <div className="flex justify-end space-x-4 pt-6 border-t">
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setLocation("/")}
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      className="bg-roamah-orange hover:bg-roamah-orange/90 px-8"
                      disabled={registrationMutation.isPending}
                    >
                      {registrationMutation.isPending ? "Creating Account..." : "Create Expert Account"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </main>

        <Footer />
      </div>
    </>
  );
}