import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { AgentCard } from "@/components/ui/agent-card";
import { EnquiryModal } from "@/components/ui/enquiry-modal";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, MapPin } from "lucide-react";
import type { Destination, Agent } from "@shared/schema";


export default function DestinationPage() {
  const [, params] = useRoute("/destination/:slug");
  const slug = params?.slug || "";
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);
  const [enquiryModalOpen, setEnquiryModalOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [filters, setFilters] = useState({
    holidayType: "",
    speciality: "",
    sort: "top-rated",
  });

  const { data: destination, isLoading: destinationLoading } = useQuery<Destination>({
    queryKey: ["/api/destinations", slug],
    enabled: !!slug,
  });

  // Fetch holiday types from API
  const { data: holidayTypes } = useQuery({
    queryKey: ["/api/holiday-types"],
  });

  const { data: agents = [], isLoading: agentsLoading } = useQuery<Agent[]>({
    queryKey: ["/api/destinations", slug, "agents"],
    enabled: !!slug,
  });

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    // Filter agents based on search query
  };

  const handleEnquire = (agent: Agent) => {
    setSelectedAgent(agent);
    setEnquiryModalOpen(true);
  };

  const clearFilters = () => {
    setSearchQuery("");
    setFilters({
      holidayType: "",
      speciality: "",
      sort: "top-rated",
    });
  };

  // Filter agents based on current filters and search
  const filteredAgents = agents.filter(agent => {
    if (searchQuery && !agent.name?.toLowerCase().includes(searchQuery.toLowerCase()) &&
        !agent.bio?.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    
    if (filters.holidayType && !agent.specializations?.some(spec => 
      spec.toLowerCase().includes(filters.holidayType.toLowerCase()))) {
      return false;
    }

    return true;
  }).sort((a, b) => {
    if (filters.sort === "top-rated") {
      return parseFloat(b.rating) - parseFloat(a.rating);
    }
    return 0;
  });

  if (destinationLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <main>
          <div className="animate-pulse">
            <div className="bg-gray-200 h-96"></div>
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
              <div className="bg-gray-200 h-32 rounded mb-8"></div>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3].map((i) => (
                  <div key={i} className="bg-gray-200 h-64 rounded"></div>
                ))}
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!destination) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <main className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Destination not found</h1>
            <p className="text-gray-600">The destination you're looking for doesn't exist.</p>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        
        <main>
          {/* Hero Section */}
          <section 
            className="relative h-96 bg-cover bg-center"
            style={{ backgroundImage: `url(${destination.image})` }}
          >
            <div className="absolute inset-0 bg-black/50"></div>
            <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-full flex items-center">
              <div className="text-white max-w-2xl">
                <h1 className="text-5xl font-bold mb-4">{destination.name}</h1>
                <p className="text-xl mb-6">{destination.description}</p>
                <div className="flex items-center">
                  <MapPin className="h-5 w-5 mr-2" />
                  <span className="text-lg">{destination.continent}</span>
                  <span className="ml-6 bg-white/20 backdrop-blur px-3 py-1 rounded-full">
                    {agents?.length || 0} agents available
                  </span>
                </div>
              </div>
            </div>
          </section>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            {/* Search and Filters */}
            <div className="bg-white rounded-lg p-6 shadow-sm mb-8">
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Search agents</label>
                  <form onSubmit={handleSearch} className="flex">
                    <Input
                      type="text"
                      placeholder="Search by name or expertise"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="flex-1 rounded-r-none"
                    />
                    <Button type="submit" className="bg-roamah-orange hover:bg-roamah-orange/90 rounded-l-none">
                      <Search className="h-4 w-4" />
                    </Button>
                  </form>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Holiday type</label>
                  <Select value={filters.holidayType} onValueChange={(value) => setFilters({ ...filters, holidayType: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Any type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Any type</SelectItem>
                      {holidayTypes?.sort((a: any, b: any) => a.name.localeCompare(b.name)).map((type: any) => (
                        <SelectItem key={type.slug} value={type.name}>{type.name}</SelectItem>
                      )) || []}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Sort by</label>
                  <Select value={filters.sort} onValueChange={(value) => setFilters({ ...filters, sort: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="top-rated">Top rated</SelectItem>
                      <SelectItem value="recommended">Recommended</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Button 
                    variant="outline" 
                    onClick={clearFilters}
                    className="w-full"
                  >
                    Clear filters
                  </Button>
                </div>
              </div>
            </div>

            {/* Agents Section */}
            <section>
              <div className="flex items-center justify-between mb-8">
                <div>
                  <h2 className="text-3xl font-bold text-roamah-dark">
                    {destination.name} Specialists
                  </h2>
                  <p className="text-roamah-gray mt-2">
                    {filteredAgents.length} expert{filteredAgents.length !== 1 ? 's' : ''} found
                  </p>
                </div>
              </div>

              {agentsLoading ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {[1, 2, 3, 4, 5, 6].map((i) => (
                    <div key={i} className="animate-pulse">
                      <div className="bg-white rounded-2xl p-6 shadow-lg">
                        <div className="bg-gray-200 rounded-xl h-48 mb-4"></div>
                        <div className="h-4 bg-gray-200 rounded mb-2"></div>
                        <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                        <div className="h-20 bg-gray-200 rounded mb-4"></div>
                        <div className="h-8 bg-gray-200 rounded"></div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : filteredAgents.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {filteredAgents.map((agent) => (
                    <AgentCard
                      key={agent.id}
                      agent={agent}
                      onEnquire={handleEnquire}
                    />
                  ))}
                </div>
              ) : (
                <div className="text-center py-12">
                  <h3 className="text-xl font-semibold text-gray-600 mb-2">
                    No agents found
                  </h3>
                  <p className="text-gray-500 mb-4">
                    Try adjusting your search criteria or clearing filters
                  </p>
                  <Button onClick={clearFilters}>Clear all filters</Button>
                </div>
              )}
            </section>

            {/* Destination Info */}
            <section className="mt-16">
              <div className="bg-white rounded-2xl p-8 shadow-lg">
                <h3 className="text-2xl font-bold text-roamah-dark mb-6">
                  About {destination.name}
                </h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                  <div>
                    <p className="text-roamah-gray leading-relaxed mb-6">
                      {destination.description}
                    </p>
                    <div className="space-y-4">
                      <div className="flex items-center">
                        <MapPin className="h-5 w-5 text-roamah-orange mr-3" />
                        <span className="text-roamah-dark font-semibold">Location:</span>
                        <span className="text-roamah-gray ml-2">{destination.continent}</span>
                      </div>
                      <div className="flex items-center">
                        <Search className="h-5 w-5 text-roamah-orange mr-3" />
                        <span className="text-roamah-dark font-semibold">Available Agents:</span>
                        <span className="text-roamah-gray ml-2">{agents?.length || 0}</span>
                      </div>
                    </div>
                  </div>
                  <div>
                    <img
                      src={destination.image}
                      alt={destination.name}
                      className="w-full h-64 object-cover rounded-xl"
                    />
                  </div>
                </div>
              </div>
            </section>
          </div>
        </main>

        <Footer />
      </div>

      <EnquiryModal
        isOpen={enquiryModalOpen}
        onClose={() => setEnquiryModalOpen(false)}
        agent={selectedAgent}
      />
    </>
  );
}
