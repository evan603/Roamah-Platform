import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";

export default function Cookies() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="pt-20 pb-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-lg shadow-lg p-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-8">Cookie Policy</h1>
            <p className="text-sm text-gray-500 mb-8">Last updated: July 2025</p>
            
            <div className="prose prose-lg max-w-none">
              <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">What Are Cookies?</h2>
              <p className="text-gray-600 mb-6">
                Cookies are small text files that are placed on your computer or mobile device when you visit our website. They help us provide you with a better experience by remembering your preferences and improving our services.
              </p>
              
              <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">How We Use Cookies</h2>
              <p className="text-gray-600 mb-4">We use cookies for the following purposes:</p>
              
              <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">Essential Cookies</h3>
              <p className="text-gray-600 mb-4">These cookies are necessary for the website to function properly and cannot be switched off:</p>
              <ul className="list-disc pl-6 space-y-2 text-gray-600 mb-6">
                <li>Session management for logged-in users</li>
                <li>Security and authentication</li>
                <li>Website functionality and navigation</li>
                <li>Form submission and data processing</li>
              </ul>
              
              <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">Analytics Cookies</h3>
              <p className="text-gray-600 mb-4">These cookies help us understand how visitors use our website:</p>
              <ul className="list-disc pl-6 space-y-2 text-gray-600 mb-6">
                <li>Page views and user behaviour</li>
                <li>Popular content and features</li>
                <li>Website performance monitoring</li>
                <li>Error tracking and improvements</li>
              </ul>
              
              <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">Preference Cookies</h3>
              <p className="text-gray-600 mb-4">These cookies remember your choices and preferences:</p>
              <ul className="list-disc pl-6 space-y-2 text-gray-600 mb-6">
                <li>Language and location settings</li>
                <li>Display preferences and customisation</li>
                <li>Search filters and sorting options</li>
                <li>Saved favourites and bookmarks</li>
              </ul>
              
              <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">Third-Party Cookies</h2>
              <p className="text-gray-600 mb-4">We may use third-party services that place cookies on your device:</p>
              <ul className="list-disc pl-6 space-y-2 text-gray-600 mb-6">
                <li><strong>Google Analytics:</strong> For website analytics and user behaviour insights</li>
                <li><strong>Mailchimp:</strong> For email marketing and newsletter management</li>
                <li><strong>Social Media:</strong> For social sharing functionality</li>
              </ul>
              
              <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">Managing Your Cookie Preferences</h2>
              <p className="text-gray-600 mb-4">
                You can control and manage cookies in several ways:
              </p>
              
              <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">Browser Settings</h3>
              <p className="text-gray-600 mb-4">Most browsers allow you to:</p>
              <ul className="list-disc pl-6 space-y-2 text-gray-600 mb-6">
                <li>View and delete cookies</li>
                <li>Block cookies from specific websites</li>
                <li>Block third-party cookies</li>
                <li>Clear all cookies when you close the browser</li>
              </ul>
              
              <h3 className="text-xl font-semibold text-gray-900 mt-6 mb-3">Cookie Settings by Browser</h3>
              <div className="bg-gray-50 p-4 rounded-lg mb-6">
                <ul className="space-y-2 text-gray-600">
                  <li><strong>Chrome:</strong> Settings → Privacy and Security → Cookies and other site data</li>
                  <li><strong>Firefox:</strong> Options → Privacy & Security → Cookies and Site Data</li>
                  <li><strong>Safari:</strong> Preferences → Privacy → Cookies and website data</li>
                  <li><strong>Edge:</strong> Settings → Site permissions → Cookies and site data</li>
                </ul>
              </div>
              
              <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">Impact of Disabling Cookies</h2>
              <p className="text-gray-600 mb-4">
                Please note that disabling certain cookies may affect your experience on our website:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-gray-600 mb-6">
                <li>You may need to log in more frequently</li>
                <li>Your preferences may not be saved</li>
                <li>Some features may not work properly</li>
                <li>Personalised content may not be available</li>
              </ul>
              
              <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">Cookie Retention</h2>
              <p className="text-gray-600 mb-6">
                Different cookies have different lifespans:
              </p>
              <ul className="list-disc pl-6 space-y-2 text-gray-600 mb-6">
                <li><strong>Session cookies:</strong> Deleted when you close your browser</li>
                <li><strong>Persistent cookies:</strong> Remain for a set period (typically 30 days to 2 years)</li>
                <li><strong>Authentication cookies:</strong> Usually expire after 7 days of inactivity</li>
              </ul>
              
              <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">Updates to This Policy</h2>
              <p className="text-gray-600 mb-6">
                We may update this Cookie Policy from time to time to reflect changes in our practices or for legal compliance. We will notify you of any significant changes by posting the updated policy on our website.
              </p>
              
              <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">Contact Us</h2>
              <p className="text-gray-600">
                If you have any questions about our Cookie Policy or how we use cookies, please contact us at:
              </p>
              <div className="bg-gray-50 p-4 rounded-lg mt-4">
                <p className="text-gray-700">
                  <strong>Email:</strong> privacy@roamah.com<br />
                  <strong>Address:</strong> Roamah Ltd, 123 Travel House, London, EC1A 1BB, United Kingdom
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}