import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";

export default function About() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="pt-20 pb-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white rounded-lg shadow-lg p-8">
            <h1 className="text-4xl font-bold text-gray-900 mb-8">About Roamah</h1>
            
            <div className="prose prose-lg max-w-none">
              <p className="text-xl text-gray-600 mb-6">
                Roamah is the UK's leading travel marketplace, connecting discerning travellers with verified travel experts who specialise in creating unforgettable holiday experiences worldwide.
              </p>
              
              <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">Our Mission</h2>
              <p className="text-gray-600 mb-6">
                We believe that every traveller deserves personalised service and expert guidance when planning their perfect holiday. Our mission is to connect you with travel professionals who understand your unique needs and can craft bespoke experiences that exceed your expectations.
              </p>
              
              <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">Why Choose Roamah?</h2>
              <ul className="space-y-3 text-gray-600 mb-6">
                <li><strong>Verified Experts:</strong> All our travel agents are thoroughly vetted and hold proper UK financial protection</li>
                <li><strong>Personalised Service:</strong> Get tailored recommendations based on your preferences and budget</li>
                <li><strong>Comprehensive Coverage:</strong> From luxury escapes to adventure holidays, we cover all types of travel</li>
                <li><strong>Trusted Platform:</strong> Secure enquiry system with transparent reviews and ratings</li>
                <li><strong>UK Based:</strong> Supporting British travel businesses with local expertise</li>
              </ul>
              
              <h2 className="text-2xl font-bold text-gray-900 mt-8 mb-4">Our Story</h2>
              <p className="text-gray-600 mb-6">
                Founded with a passion for exceptional travel experiences, Roamah was created to bridge the gap between travellers seeking expertise and travel professionals offering specialised knowledge. We recognised that in an age of online booking platforms, there was still immense value in human expertise and personalised service.
              </p>
              
              <p className="text-gray-600">
                Today, we're proud to support hundreds of UK travel experts whilst helping thousands of travellers discover their perfect holidays through our platform.
              </p>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}