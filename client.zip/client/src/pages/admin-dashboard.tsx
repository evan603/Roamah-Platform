import { useEffect } from "react";
import { useLocation, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { AdminNavbar } from "@/components/admin/admin-navbar";
import { 
  Users, 
  Mail, 
  Image, 
  BarChart3, 
  MessageSquare, 
  Settings,
  FileText,
  Calendar,
  Star,
  TrendingUp,
  Activity
} from "lucide-react";

interface AdminStats {
  totalAgents: number;
  pendingAgents: number;
  approvedAgents: number;
  totalEnquiries: number;
  totalReviews: number;
  totalOffers: number;
  totalDestinations: number;
  totalHolidayTypes: number;
}

interface EmailStats {
  reviewEmailsSent: number;
  totalEnquiries: number;
  confirmationEmailsSent: number;
  totalAutomatedEmails: number;
}

interface HealthComponent {
  status: 'connected' | 'active' | 'operational' | 'accessible' | 'warning' | 'error';
  message: string;
}

interface HealthStatus {
  database: HealthComponent;
  sessionStorage: HealthComponent;
  fileStorage: HealthComponent;
  mailchimp: HealthComponent;
  mailchimpData: HealthComponent;
  agentIntegration: HealthComponent;
  emailTemplates: HealthComponent;
  tagCleanupSystem: HealthComponent;
}

export function AdminDashboard() {
  const [, setLocation] = useLocation();

  // Check admin authentication
  useEffect(() => {
    const adminToken = localStorage.getItem('adminToken');
    if (!adminToken) {
      setLocation('/admin/login');
      return;
    }
  }, [setLocation]);

  // Fetch dashboard stats
  const { data: stats } = useQuery({
    queryKey: ['/api/admin/stats'],
    enabled: !!localStorage.getItem('adminToken'),
    retry: (failureCount, error: any) => {
      if (error?.message?.includes('401') || error?.message?.includes('403')) {
        localStorage.removeItem('adminToken');
        setLocation('/admin/login');
        return false;
      }
      return failureCount < 3;
    },
  }) as { data?: AdminStats };

  const { data: emailStats } = useQuery({
    queryKey: ['/api/admin/email-stats'],
    enabled: !!localStorage.getItem('adminToken'),
  }) as { data?: EmailStats };

  const { data: healthStatus } = useQuery({
    queryKey: ['/api/admin/health'],
    enabled: !!localStorage.getItem('adminToken'),
    refetchInterval: 30000, // Refresh every 30 seconds
    staleTime: 0, // Always consider data stale
    gcTime: 0, // Don't cache the data
  }) as { data?: HealthStatus };

  const { data: healthLogs } = useQuery({
    queryKey: ['/api/admin/health-logs'],
    enabled: !!localStorage.getItem('adminToken'),
    refetchInterval: 30000, // Refresh every 30 seconds
  }) as { data?: Array<{
    id: number;
    status: string;
    message: string;
    details: string;
    createdAt: string;
  }> };

  const dashboardCards = [
    {
      title: "Agent Management",
      description: "Manage all travel experts, approvals, and profiles",
      icon: Users,
      href: "/admin/agents",
      color: "bg-blue-500",
      stats: stats ? `${stats.totalAgents || 0} agents` : "Loading...",
      subStats: stats ? `${stats.pendingAgents || 0} pending approval` : ""
    },
    {
      title: "Customer Enquiries", 
      description: "View and manage all customer enquiries and bookings",
      icon: MessageSquare,
      href: "/admin/enquiries",
      color: "bg-green-500",
      stats: emailStats ? `${emailStats.totalEnquiries || 0} enquiries` : "Loading...",
      subStats: stats ? `${stats.totalReviews || 0} reviews` : ""
    },
    {
      title: "Content Images",
      description: "Manage destination and holiday type images",
      icon: Image,
      href: "/admin/images", 
      color: "bg-purple-500",
      stats: stats ? `${stats.totalDestinations || 0} destinations` : "Loading...",
      subStats: stats ? `${stats.totalHolidayTypes || 0} holiday types` : ""
    },
    {
      title: "Email Templates",
      description: "Edit automated email content and templates", 
      icon: FileText,
      href: "/admin/emails",
      color: "bg-orange-500",
      stats: "3 templates",
      subStats: "All active"
    },
    {
      title: "Email Automation",
      description: "Monitor email workflows and delivery stats",
      icon: Mail,
      href: "/admin/email-automation",
      color: "bg-indigo-500", 
      stats: emailStats ? `${emailStats.totalAutomatedEmails || 0} emails sent` : "Loading...",
      subStats: "Mailchimp integrated"
    },
    {
      title: "Platform Analytics",
      description: "View website performance and user metrics",
      icon: BarChart3,
      href: "/admin/analytics",
      color: "bg-teal-500",
      stats: stats ? `${stats.totalOffers || 0} active offers` : "Loading...",
      subStats: "Advanced metrics"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <AdminNavbar />
      
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Admin Dashboard</h1>
          <p className="text-gray-600">
            Manage your travel platform, agents, and customer communications
          </p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Agents</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {stats?.totalAgents || 0}
                  </p>
                </div>
                <div className="p-3 bg-blue-100 rounded-full">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total Enquiries</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {emailStats?.totalEnquiries || 0}
                  </p>
                </div>
                <div className="p-3 bg-green-100 rounded-full">
                  <MessageSquare className="h-6 w-6 text-green-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Reviews</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {stats?.totalReviews || 0}
                  </p>
                </div>
                <div className="p-3 bg-yellow-100 rounded-full">
                  <Star className="h-6 w-6 text-yellow-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Active Offers</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {stats?.totalOffers || 0}
                  </p>
                </div>
                <div className="p-3 bg-purple-100 rounded-full">
                  <TrendingUp className="h-6 w-6 text-purple-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Main Dashboard Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {dashboardCards.map((card, index) => {
            const IconComponent = card.icon;
            return (
              <Card key={index} className="hover:shadow-lg transition-shadow cursor-pointer">
                <Link href={card.href}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className={`p-3 rounded-lg ${card.color}`}>
                        <IconComponent className="h-6 w-6 text-white" />
                      </div>
                      <Badge variant="secondary" className="text-xs">
                        Active
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <CardTitle className="text-lg mb-2">{card.title}</CardTitle>
                    <CardDescription className="text-sm text-gray-600 mb-4">
                      {card.description}
                    </CardDescription>
                    <div className="space-y-1">
                      <p className="text-sm font-semibold text-gray-900">{card.stats}</p>
                      {card.subStats && (
                        <p className="text-xs text-gray-500">{card.subStats}</p>
                      )}
                    </div>
                  </CardContent>
                </Link>
              </Card>
            );
          })}
        </div>

        {/* System Status */}
        <div className="mt-8">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                System Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <div className={`flex items-center justify-between p-4 rounded-lg ${
                  healthStatus?.database.status === 'connected' ? 'bg-green-50' : 
                  healthStatus?.database.status === 'warning' ? 'bg-yellow-50' : 'bg-red-50'
                }`}>
                  <div>
                    <p className={`font-medium ${
                      healthStatus?.database.status === 'connected' ? 'text-green-900' : 
                      healthStatus?.database.status === 'warning' ? 'text-yellow-900' : 'text-red-900'
                    }`}>Database</p>
                    <p className={`text-sm ${
                      healthStatus?.database.status === 'connected' ? 'text-green-700' : 
                      healthStatus?.database.status === 'warning' ? 'text-yellow-700' : 'text-red-700'
                    }`}>{healthStatus?.database.message || "Checking..."}</p>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${
                    healthStatus?.database.status === 'connected' ? 'bg-green-500' : 
                    healthStatus?.database.status === 'warning' ? 'bg-yellow-500' : 'bg-red-500'
                  }`}></div>
                </div>
                
                <div className={`flex items-center justify-between p-4 rounded-lg ${
                  healthStatus?.mailchimp.status === 'active' ? 'bg-green-50' : 
                  healthStatus?.mailchimp.status === 'warning' ? 'bg-yellow-50' : 'bg-red-50'
                }`}>
                  <div>
                    <p className={`font-medium ${
                      healthStatus?.mailchimp.status === 'active' ? 'text-green-900' : 
                      healthStatus?.mailchimp.status === 'warning' ? 'text-yellow-900' : 'text-red-900'
                    }`}>Mailchimp API</p>
                    <p className={`text-sm ${
                      healthStatus?.mailchimp.status === 'active' ? 'text-green-700' : 
                      healthStatus?.mailchimp.status === 'warning' ? 'text-yellow-700' : 'text-red-700'
                    }`}>{healthStatus?.mailchimp.message || "Checking..."}</p>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${
                    healthStatus?.mailchimp.status === 'active' ? 'bg-green-500' : 
                    healthStatus?.mailchimp.status === 'warning' ? 'bg-yellow-500' : 'bg-red-500'
                  }`}></div>
                </div>
                
                <div className={`flex items-center justify-between p-4 rounded-lg ${
                  healthStatus?.emailTemplates.status === 'operational' ? 'bg-green-50' : 
                  healthStatus?.emailTemplates.status === 'warning' ? 'bg-yellow-50' : 'bg-red-50'
                }`}>
                  <div>
                    <p className={`font-medium ${
                      healthStatus?.emailTemplates.status === 'operational' ? 'text-green-900' : 
                      healthStatus?.emailTemplates.status === 'warning' ? 'text-yellow-900' : 'text-red-900'
                    }`}>Email Templates</p>
                    <p className={`text-sm ${
                      healthStatus?.emailTemplates.status === 'operational' ? 'text-green-700' : 
                      healthStatus?.emailTemplates.status === 'warning' ? 'text-yellow-700' : 'text-red-700'
                    }`}>{healthStatus?.emailTemplates.message || "Checking..."}</p>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${
                    healthStatus?.emailTemplates.status === 'operational' ? 'bg-green-500' : 
                    healthStatus?.emailTemplates.status === 'warning' ? 'bg-yellow-500' : 'bg-red-500'
                  }`}></div>
                </div>

                <div className={`flex items-center justify-between p-4 rounded-lg ${
                  healthStatus?.sessionStorage.status === 'connected' ? 'bg-green-50' : 
                  healthStatus?.sessionStorage.status === 'warning' ? 'bg-yellow-50' : 'bg-red-50'
                }`}>
                  <div>
                    <p className={`font-medium ${
                      healthStatus?.sessionStorage.status === 'connected' ? 'text-green-900' : 
                      healthStatus?.sessionStorage.status === 'warning' ? 'text-yellow-900' : 'text-red-900'
                    }`}>Session Storage</p>
                    <p className={`text-sm ${
                      healthStatus?.sessionStorage.status === 'connected' ? 'text-green-700' : 
                      healthStatus?.sessionStorage.status === 'warning' ? 'text-yellow-700' : 'text-red-700'
                    }`}>{healthStatus?.sessionStorage.message || "Checking..."}</p>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${
                    healthStatus?.sessionStorage.status === 'connected' ? 'bg-green-500' : 
                    healthStatus?.sessionStorage.status === 'warning' ? 'bg-yellow-500' : 'bg-red-500'
                  }`}></div>
                </div>

                <div className={`flex items-center justify-between p-4 rounded-lg ${
                  healthStatus?.fileStorage.status === 'accessible' ? 'bg-green-50' : 
                  healthStatus?.fileStorage.status === 'warning' ? 'bg-yellow-50' : 'bg-red-50'
                }`}>
                  <div>
                    <p className={`font-medium ${
                      healthStatus?.fileStorage.status === 'accessible' ? 'text-green-900' : 
                      healthStatus?.fileStorage.status === 'warning' ? 'text-yellow-900' : 'text-red-900'
                    }`}>File Storage</p>
                    <p className={`text-sm ${
                      healthStatus?.fileStorage.status === 'accessible' ? 'text-green-700' : 
                      healthStatus?.fileStorage.status === 'warning' ? 'text-yellow-700' : 'text-red-700'
                    }`}>{healthStatus?.fileStorage.message || "Checking..."}</p>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${
                    healthStatus?.fileStorage.status === 'accessible' ? 'bg-green-500' : 
                    healthStatus?.fileStorage.status === 'warning' ? 'bg-yellow-500' : 'bg-red-500'
                  }`}></div>
                </div>

                <div className={`flex items-center justify-between p-4 rounded-lg ${
                  healthStatus?.mailchimpData.status === 'accessible' ? 'bg-green-50' : 
                  healthStatus?.mailchimpData.status === 'warning' ? 'bg-yellow-50' : 'bg-red-50'
                }`}>
                  <div>
                    <p className={`font-medium ${
                      healthStatus?.mailchimpData.status === 'accessible' ? 'text-green-900' : 
                      healthStatus?.mailchimpData.status === 'warning' ? 'text-yellow-900' : 'text-red-900'
                    }`}>Customer Data</p>
                    <p className={`text-sm ${
                      healthStatus?.mailchimpData.status === 'accessible' ? 'text-green-700' : 
                      healthStatus?.mailchimpData.status === 'warning' ? 'text-yellow-700' : 'text-red-700'
                    }`}>{healthStatus?.mailchimpData.message || "Checking..."}</p>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${
                    healthStatus?.mailchimpData.status === 'accessible' ? 'bg-green-500' : 
                    healthStatus?.mailchimpData.status === 'warning' ? 'bg-yellow-500' : 'bg-red-500'
                  }`}></div>
                </div>

                <div className={`flex items-center justify-between p-4 rounded-lg ${
                  healthStatus?.agentIntegration.status === 'operational' ? 'bg-green-50' : 
                  healthStatus?.agentIntegration.status === 'warning' ? 'bg-yellow-50' : 'bg-red-50'
                }`}>
                  <div>
                    <p className={`font-medium ${
                      healthStatus?.agentIntegration.status === 'operational' ? 'text-green-900' : 
                      healthStatus?.agentIntegration.status === 'warning' ? 'text-yellow-900' : 'text-red-900'
                    }`}>Agent Integration</p>
                    <p className={`text-sm ${
                      healthStatus?.agentIntegration.status === 'operational' ? 'text-green-700' : 
                      healthStatus?.agentIntegration.status === 'warning' ? 'text-yellow-700' : 'text-red-700'
                    }`}>{healthStatus?.agentIntegration.message || "Checking..."}</p>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${
                    healthStatus?.agentIntegration.status === 'operational' ? 'bg-green-500' : 
                    healthStatus?.agentIntegration.status === 'warning' ? 'bg-yellow-500' : 'bg-red-500'
                  }`}></div>
                </div>

                <div className={`flex items-center justify-between p-4 rounded-lg ${
                  healthStatus?.tagCleanupSystem.status === 'operational' ? 'bg-green-50' : 
                  healthStatus?.tagCleanupSystem.status === 'warning' ? 'bg-yellow-50' : 'bg-red-50'
                }`}>
                  <div>
                    <p className={`font-medium ${
                      healthStatus?.tagCleanupSystem.status === 'operational' ? 'text-green-900' : 
                      healthStatus?.tagCleanupSystem.status === 'warning' ? 'text-yellow-900' : 'text-red-900'
                    }`}>Tag Cleanup System</p>
                    <p className={`text-sm ${
                      healthStatus?.tagCleanupSystem.status === 'operational' ? 'text-green-700' : 
                      healthStatus?.tagCleanupSystem.status === 'warning' ? 'text-yellow-700' : 'text-red-700'
                    }`}>{healthStatus?.tagCleanupSystem.message || "Checking..."}</p>
                  </div>
                  <div className={`w-3 h-3 rounded-full ${
                    healthStatus?.tagCleanupSystem.status === 'operational' ? 'bg-green-500' : 
                    healthStatus?.tagCleanupSystem.status === 'warning' ? 'bg-yellow-500' : 'bg-red-500'
                  }`}></div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Health Check Logs */}
        {healthLogs && healthLogs.length > 0 && (
          <div className="mt-8">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Activity className="h-5 w-5" />
                  Health Check History
                  <Badge variant="secondary" className="text-xs">
                    Last 5 checks
                  </Badge>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {healthLogs.map((log) => (
                    <div 
                      key={log.id} 
                      className={`p-3 rounded-lg border-l-4 ${
                        log.status === 'healthy' ? 'border-green-500 bg-green-50' : 
                        log.status === 'warning' ? 'border-yellow-500 bg-yellow-50' : 
                        'border-red-500 bg-red-50'
                      }`}
                    >
                      <div className="flex items-center justify-between mb-1">
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${
                            log.status === 'healthy' ? 'bg-green-500' : 
                            log.status === 'warning' ? 'bg-yellow-500' : 
                            'bg-red-500'
                          }`}></div>
                          <span className={`text-sm font-medium ${
                            log.status === 'healthy' ? 'text-green-900' : 
                            log.status === 'warning' ? 'text-yellow-900' : 
                            'text-red-900'
                          }`}>
                            {log.status === 'healthy' ? 'System Healthy' : 
                             log.status === 'warning' ? 'System Warning' : 
                             'System Error'}
                          </span>
                        </div>
                        <span className="text-xs text-gray-500">
                          {new Date(log.createdAt).toLocaleString()}
                        </span>
                      </div>
                      <p className={`text-sm ${
                        log.status === 'healthy' ? 'text-green-700' : 
                        log.status === 'warning' ? 'text-yellow-700' : 
                        'text-red-700'
                      }`}>
                        {log.message}
                      </p>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
}

export default AdminDashboard;