import { useState } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { CheckCircle, Mail, User, ArrowRight } from "lucide-react";

export default function TestWorkflow() {
  const { toast } = useToast();
  const [currentStep, setCurrentStep] = useState(1);
  const [testData, setTestData] = useState({
    email: `test-${Date.now()}@roamah.com`,
    password: "testpassword123",
    token: "",
    agentId: null as number | null,
  });

  const stepTitles = [
    "1. Agent Signup",
    "2. Email Verification",
    "3. Profile Completion",
    "4. Dashboard Access"
  ];

  const testSignup = async () => {
    try {
      const response = await apiRequest("/api/agents/signup", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          email: testData.email,
          password: testData.password,
        }),
      });
      
      setTestData(prev => ({ ...prev, agentId: response.agentId }));
      toast({
        title: "Signup Successful!",
        description: `Agent created with ID: ${response.agentId}`,
      });
      setCurrentStep(2);
    } catch (error: any) {
      toast({
        title: "Signup Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const testEmailVerification = async () => {
    try {
      const response = await apiRequest(`/api/agents/verify-email?token=${testData.token}`);
      
      if (response.token) {
        localStorage.setItem('token', response.token);
      }
      
      toast({
        title: "Email Verified!",
        description: "You can now complete your profile",
      });
      setCurrentStep(3);
    } catch (error: any) {
      toast({
        title: "Verification Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const testProfileCompletion = async () => {
    try {
      const profileData = {
        firstName: "Test",
        lastName: "Agent",
        location: "London",
        company: "Test Travel Co",
        bio: "I am a test travel agent with extensive experience in creating amazing travel experiences for clients worldwide. I specialise in adventure and cultural trips.",
        yearsExperience: 5,
        specializations: ["Adventure", "Cultural"],
        destinations: ["Thailand", "Japan"],
        languages: ["English", "Spanish"],
        nextHoliday: "Exploring Tokyo temples"
      };

      const response = await apiRequest("/api/agents/complete-profile", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify(profileData),
      });
      
      toast({
        title: "Profile Completed!",
        description: "Agent profile successfully created",
      });
      setCurrentStep(4);
    } catch (error: any) {
      toast({
        title: "Profile Completion Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const testDashboardAccess = async () => {
    try {
      const response = await apiRequest("/api/agents/profile", {
        headers: {
          "Authorization": `Bearer ${localStorage.getItem('token')}`,
        },
      });
      
      toast({
        title: "Dashboard Access Successful!",
        description: `Welcome ${response.firstName} ${response.lastName}!`,
      });
    } catch (error: any) {
      toast({
        title: "Dashboard Access Failed",
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const generateMockToken = () => {
    // Generate a simple mock token for testing (using btoa instead of Buffer for browser compatibility)
    const mockToken = btoa(`${testData.agentId}-${Date.now()}`).replace(/[^a-f0-9]/g, '');
    setTestData(prev => ({ ...prev, token: mockToken }));
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white py-12 px-4">
      <div className="max-w-4xl mx-auto space-y-8">
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold text-gray-900">
              Email Verification Workflow Test
            </CardTitle>
            <CardDescription className="text-lg">
              Test the complete agent registration and verification process
            </CardDescription>
          </CardHeader>
        </Card>

        {/* Progress Steps */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {stepTitles.map((title, index) => (
            <Card key={index} className={`${currentStep > index + 1 ? 'border-green-500 bg-green-50' : currentStep === index + 1 ? 'border-orange-500 bg-orange-50' : 'border-gray-200'}`}>
              <CardContent className="p-4 text-center">
                <div className={`mx-auto w-8 h-8 rounded-full flex items-center justify-center mb-2 ${currentStep > index + 1 ? 'bg-green-500 text-white' : currentStep === index + 1 ? 'bg-orange-500 text-white' : 'bg-gray-200 text-gray-600'}`}>
                  {currentStep > index + 1 ? <CheckCircle className="w-4 h-4" /> : index + 1}
                </div>
                <p className="text-sm font-medium">{title}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Step 1: Signup */}
        {currentStep === 1 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Mail className="w-5 h-5" />
                <span>Step 1: Agent Signup</span>
              </CardTitle>
              <CardDescription>
                Create a new agent account with email and password
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="email">Test Email</Label>
                  <Input
                    id="email"
                    value={testData.email}
                    onChange={(e) => setTestData(prev => ({ ...prev, email: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="password">Password</Label>
                  <Input
                    id="password"
                    type="password"
                    value={testData.password}
                    onChange={(e) => setTestData(prev => ({ ...prev, password: e.target.value }))}
                  />
                </div>
              </div>
              <Button onClick={testSignup} className="w-full bg-orange-600 hover:bg-orange-700">
                <ArrowRight className="w-4 h-4 mr-2" />
                Test Signup API
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Email Verification */}
        {currentStep === 2 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <CheckCircle className="w-5 h-5" />
                <span>Step 2: Email Verification</span>
              </CardTitle>
              <CardDescription>
                Verify the email with a verification token
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
                <p className="text-blue-800 text-sm">
                  <strong>Agent Created:</strong> ID {testData.agentId}
                </p>
                <p className="text-blue-800 text-sm">
                  <strong>Email:</strong> {testData.email}
                </p>
                <p className="text-blue-700 text-sm mt-2">
                  <strong>Latest Test Token:</strong> 9bfd72bd5da0c68a5a91a9fa6eeeb1067c472260f67ad3ed53092280a4ec92dd
                </p>
                <p className="text-blue-700 text-sm mt-2">
                  In production, check your email for the verification link. For testing, copy the token above or generate a mock one.
                </p>
              </div>
              
              <div>
                <Label htmlFor="token">Verification Token</Label>
                <div className="flex space-x-2">
                  <Input
                    id="token"
                    value={testData.token}
                    onChange={(e) => setTestData(prev => ({ ...prev, token: e.target.value }))}
                    placeholder="Enter verification token"
                  />
                  <Button onClick={generateMockToken} variant="outline">
                    Generate Mock Token
                  </Button>
                </div>
              </div>
              
              <Button 
                onClick={testEmailVerification} 
                className="w-full bg-orange-600 hover:bg-orange-700"
                disabled={!testData.token}
              >
                <ArrowRight className="w-4 h-4 mr-2" />
                Test Email Verification
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Step 3: Profile Completion */}
        {currentStep === 3 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <User className="w-5 h-5" />
                <span>Step 3: Profile Completion</span>
              </CardTitle>
              <CardDescription>
                Complete the agent profile with all required information
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <p className="text-green-800 text-sm">
                  <strong>Email Verified!</strong> Now completing profile with test data...
                </p>
                <ul className="text-green-700 text-sm mt-2 space-y-1">
                  <li>• Name: Test Agent</li>
                  <li>• Location: London</li>
                  <li>• Company: Test Travel Co</li>
                  <li>• Specializations: Adventure, Cultural</li>
                  <li>• Destinations: Thailand, Japan</li>
                  <li>• Languages: English, Spanish</li>
                </ul>
              </div>
              
              <Button onClick={testProfileCompletion} className="w-full bg-orange-600 hover:bg-orange-700">
                <ArrowRight className="w-4 h-4 mr-2" />
                Test Profile Completion
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Step 4: Dashboard Access */}
        {currentStep === 4 && (
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <CheckCircle className="w-5 h-5 text-green-500" />
                <span>Step 4: Dashboard Access</span>
              </CardTitle>
              <CardDescription>
                Test access to the agent dashboard
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                <p className="text-green-800 text-sm">
                  <strong>Profile Completed Successfully!</strong> Testing dashboard access...
                </p>
              </div>
              
              <Button onClick={testDashboardAccess} className="w-full bg-green-600 hover:bg-green-700">
                <ArrowRight className="w-4 h-4 mr-2" />
                Test Dashboard Access
              </Button>
              
              <div className="pt-4 space-y-2">
                <Button onClick={() => setCurrentStep(1)} variant="outline" className="w-full">
                  Reset Test Workflow
                </Button>
                <Button onClick={() => window.location.href = '/agent-signup'} className="w-full bg-orange-600 hover:bg-orange-700">
                  Go to Live Signup Page
                </Button>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Current Status */}
        <Card>
          <CardHeader>
            <CardTitle>Current Test Data</CardTitle>
          </CardHeader>
          <CardContent>
            <pre className="bg-gray-100 p-4 rounded-lg text-sm overflow-auto">
{JSON.stringify(testData, null, 2)}
            </pre>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}