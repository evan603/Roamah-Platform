import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { Mail, Phone, MapPin, Clock } from "lucide-react";

export default function Contact() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar />
      <div className="pt-20 pb-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Contact Us</h1>
            <p className="text-xl text-gray-600">
              Get in touch with our team for any questions or support
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Information */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Get In Touch</h2>
              
              <div className="space-y-6">
                <div className="flex items-start space-x-4">
                  <Mail className="h-6 w-6 text-roamah-orange mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Email</h3>
                    <p className="text-gray-600">hello@roamah.com</p>
                    <p className="text-sm text-gray-500">We'll respond within 24 hours</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Phone className="h-6 w-6 text-roamah-orange mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Phone</h3>
                    <p className="text-gray-600">+44 20 7946 0958</p>
                    <p className="text-sm text-gray-500">Monday to Friday, 9am-6pm GMT</p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <MapPin className="h-6 w-6 text-roamah-orange mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Address</h3>
                    <p className="text-gray-600">
                      Roamah Ltd<br />
                      123 Travel House<br />
                      London, EC1A 1BB<br />
                      United Kingdom
                    </p>
                  </div>
                </div>

                <div className="flex items-start space-x-4">
                  <Clock className="h-6 w-6 text-roamah-orange mt-1" />
                  <div>
                    <h3 className="font-semibold text-gray-900">Business Hours</h3>
                    <p className="text-gray-600">
                      Monday - Friday: 9:00 AM - 6:00 PM GMT<br />
                      Weekend: Emergency support only
                    </p>
                  </div>
                </div>
              </div>
            </div>

            {/* Support Options */}
            <div className="bg-white rounded-lg shadow-lg p-8">
              <h2 className="text-2xl font-bold text-gray-900 mb-6">Support Options</h2>
              
              <div className="space-y-6">
                <div className="border-l-4 border-roamah-orange pl-4">
                  <h3 className="font-semibold text-gray-900 mb-2">For Travellers</h3>
                  <p className="text-gray-600 mb-2">
                    Need help finding the perfect travel expert or have questions about a booking?
                  </p>
                  <p className="text-sm text-roamah-orange font-medium">
                    Email: travellers@roamah.com
                  </p>
                </div>

                <div className="border-l-4 border-blue-500 pl-4">
                  <h3 className="font-semibold text-gray-900 mb-2">For Travel Experts</h3>
                  <p className="text-gray-600 mb-2">
                    Questions about joining our platform or managing your profile?
                  </p>
                  <p className="text-sm text-blue-600 font-medium">
                    Email: experts@roamah.com
                  </p>
                </div>

                <div className="border-l-4 border-green-500 pl-4">
                  <h3 className="font-semibold text-gray-900 mb-2">Technical Support</h3>
                  <p className="text-gray-600 mb-2">
                    Having technical issues with the website or need assistance?
                  </p>
                  <p className="text-sm text-green-600 font-medium">
                    Email: support@roamah.com
                  </p>
                </div>

                <div className="border-l-4 border-purple-500 pl-4">
                  <h3 className="font-semibold text-gray-900 mb-2">Media & Partnerships</h3>
                  <p className="text-gray-600 mb-2">
                    Press enquiries or partnership opportunities?
                  </p>
                  <p className="text-sm text-purple-600 font-medium">
                    Email: partnerships@roamah.com
                  </p>
                </div>
              </div>

              <div className="mt-8 p-4 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-600">
                  <strong>Note:</strong> For urgent travel-related issues outside business hours, 
                  please contact your assigned travel expert directly using the contact details 
                  provided in your booking confirmation.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}