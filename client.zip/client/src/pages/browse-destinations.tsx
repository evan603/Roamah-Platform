import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { MapPin, Users } from "lucide-react";
import type { Destination } from "@shared/schema";

export default function BrowseDestinations() {
  const [continentFilter, setContinentFilter] = useState('all');

  const { data: destinations, isLoading } = useQuery<Destination[]>({
    queryKey: ["/api/destinations"],
  });

  const filteredDestinations = destinations?.filter(dest => {
    return continentFilter === 'all' || dest.continent === continentFilter;
  });

  const continents = Array.from(new Set(destinations?.map(dest => dest.continent) || []));



  if (isLoading) {
    return (
      <>
        <Navbar />
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-roamah-orange mx-auto mb-4"></div>
            <p className="text-roamah-gray">Loading destinations...</p>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        
        <main className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Hero Section */}
            <div className="bg-gradient-to-r from-orange-50 to-pink-50 rounded-2xl p-8 mb-12">
              <div className="text-center">
                <h1 className="text-4xl font-bold text-roamah-dark mb-4">Explore Destinations</h1>
                <p className="text-xl text-roamah-gray mb-0">
                  Discover amazing places around the world with expert travel agents
                </p>
              </div>
            </div>

            {/* Continent Filter Buttons */}
            <div className="mb-8">
              <div className="flex flex-wrap justify-center gap-4">
                <Button
                  variant={continentFilter === 'all' ? 'default' : 'outline'}
                  className={`px-6 py-3 rounded-full font-bold transition-all ${
                    continentFilter === 'all' 
                      ? 'bg-roamah-orange hover:bg-roamah-orange/90 text-white' 
                      : 'bg-white text-roamah-dark hover:bg-gray-50 border-gray-300'
                  }`}
                  onClick={() => setContinentFilter('all')}
                >
                  All Destinations
                </Button>
                {continents.map(continent => (
                  <Button
                    key={continent}
                    variant={continentFilter === continent ? 'default' : 'outline'}
                    className={`px-6 py-3 rounded-full font-bold transition-all ${
                      continentFilter === continent 
                        ? 'bg-roamah-orange hover:bg-roamah-orange/90 text-white' 
                        : 'bg-white text-roamah-dark hover:bg-gray-50 border-gray-300'
                    }`}
                    onClick={() => setContinentFilter(continent)}
                  >
                    {continent}
                  </Button>
                ))}
              </div>
            </div>

            {/* Results */}
            <div className="mb-6">
              <p className="text-roamah-gray">
                {filteredDestinations?.length || 0} destinations found
              </p>
            </div>

            {/* Destinations Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredDestinations?.map((destination) => (
                <Link 
                  key={destination.id} 
                  href={`/destination/${destination.slug}`}
                  className="group"
                >
                  <div className="bg-white rounded-lg shadow-md overflow-hidden hover:shadow-lg transition-shadow">
                    <div className="relative h-48">
                      <img
                        src={destination.image}
                        alt={destination.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute top-4 right-4 bg-white rounded-full px-3 py-1 text-sm font-medium text-roamah-dark">
                        {destination.continent}
                      </div>
                    </div>
                    <div className="p-6">
                      <h3 className="text-xl font-semibold text-roamah-dark mb-2 group-hover:text-roamah-orange transition-colors">
                        {destination.name}
                      </h3>
                      <p className="text-roamah-gray mb-4 line-clamp-2">
                        {destination.description}
                      </p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center text-sm text-roamah-gray font-bold">
                          <Users className="h-4 w-4 mr-1" />
                          {destination.agentCount} travel experts
                        </div>
                        <div className="flex items-center text-sm text-roamah-orange">
                          <MapPin className="h-4 w-4 mr-1" />
                          Explore
                        </div>
                      </div>
                    </div>
                  </div>
                </Link>
              ))}
            </div>

            {filteredDestinations?.length === 0 && (
              <div className="text-center py-12">
                <div className="text-roamah-gray mb-4">
                  <MapPin className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p className="text-lg">No destinations found</p>
                  <p className="text-sm">Try selecting a different continent</p>
                </div>
              </div>
            )}
          </div>
        </main>
      </div>
      
      <Footer />
    </>
  );
}