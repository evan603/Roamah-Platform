import { useState, useMemo } from "react";
import { useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { OfferImageCarousel } from "@/components/OfferImageCarousel";
import { Search, MapPin, Star, Filter } from "lucide-react";
import type { Offer, Destination, HolidayType, Agent } from "@shared/schema";

type OfferWithAgent = Offer & { agent: Agent };

export default function BrowseOffers() {
  const [, setLocation] = useLocation();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedDestination, setSelectedDestination] = useState<string>('all');
  const [selectedHolidayType, setSelectedHolidayType] = useState<string>('all');
  const [priceRange, setPriceRange] = useState<string>('all');
  const [sortBy, setSortBy] = useState<string>('newest');

  const { data: offers, isLoading: offersLoading } = useQuery<OfferWithAgent[]>({
    queryKey: ["/api/offers"],
  });

  const { data: destinations } = useQuery<Destination[]>({
    queryKey: ["/api/destinations"],
  });

  const { data: holidayTypes } = useQuery<HolidayType[]>({
    queryKey: ["/api/holiday-types"],
  });

  // Get available destinations and holiday types from actual offers
  const availableDestinations = useMemo(() => {
    if (!offers) return [];
    const destinationSet = new Set<string>();
    offers.forEach(offer => {
      offer.destinations?.forEach(dest => destinationSet.add(dest));
    });
    return Array.from(destinationSet).sort();
  }, [offers]);

  const availableHolidayTypes = useMemo(() => {
    if (!offers) return [];
    const holidayTypeSet = new Set<string>();
    offers.forEach(offer => {
      offer.holidayTypes?.forEach(type => holidayTypeSet.add(type));
    });
    return Array.from(holidayTypeSet).sort();
  }, [offers]);

  const filteredOffers = useMemo(() => {
    if (!offers) return [];

    let filtered = offers.filter(offer => {
      const matchesSearch = !searchQuery || 
        offer.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        offer.briefDescription?.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesDestination = selectedDestination === 'all' || 
        offer.destinations?.includes(selectedDestination);
      
      const matchesHolidayType = selectedHolidayType === 'all' || 
        offer.holidayTypes?.includes(selectedHolidayType);

      let matchesPrice = true;
      if (priceRange !== 'all' && offer.fromPrice) {
        const price = parseFloat(offer.fromPrice.replace(/[£,]/g, '').split(' ')[0]);
        switch (priceRange) {
          case 'under-1000':
            matchesPrice = price < 1000;
            break;
          case '1000-2500':
            matchesPrice = price >= 1000 && price <= 2500;
            break;
          case '2500-5000':
            matchesPrice = price >= 2500 && price <= 5000;
            break;
          case 'over-5000':
            matchesPrice = price > 5000;
            break;
        }
      }

      return matchesSearch && matchesDestination && matchesHolidayType && matchesPrice;
    });

    // Sort offers
    switch (sortBy) {
      case 'price-low':
        filtered.sort((a, b) => {
          const priceA = parseFloat(a.fromPrice?.replace(/[£,]/g, '').split(' ')[0] || '0');
          const priceB = parseFloat(b.fromPrice?.replace(/[£,]/g, '').split(' ')[0] || '0');
          return priceA - priceB;
        });
        break;
      case 'price-high':
        filtered.sort((a, b) => {
          const priceA = parseFloat(a.fromPrice?.replace(/[£,]/g, '').split(' ')[0] || '0');
          const priceB = parseFloat(b.fromPrice?.replace(/[£,]/g, '').split(' ')[0] || '0');
          return priceB - priceA;
        });
        break;
      case 'newest':
      default:
        filtered.sort((a, b) => new Date(b.createdAt || '').getTime() - new Date(a.createdAt || '').getTime());
        break;
    }

    return filtered;
  }, [offers, searchQuery, selectedDestination, selectedHolidayType, priceRange, sortBy]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
  };

  if (offersLoading) {
    return (
      <>
        <Navbar />
        <div className="min-h-screen bg-gray-50 flex items-center justify-center">
          <div className="text-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-roamah-orange mx-auto mb-4"></div>
            <p className="text-roamah-gray">Loading offers...</p>
          </div>
        </div>
        <Footer />
      </>
    );
  }

  return (
    <>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        
        <main className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Hero Section */}
            <div className="bg-gradient-to-r from-orange-50 to-pink-50 rounded-2xl p-8 mb-12">
              <div className="text-center">
                <h1 className="text-4xl font-bold text-roamah-dark mb-4">Holiday Offers</h1>
                <p className="text-xl text-roamah-gray mb-0 max-w-4xl mx-auto">
                  Discover amazing holiday deals from our expert travel agents. From tropical escapes to cultural adventures, find your perfect getaway at an unbeatable price.
                </p>
              </div>
            </div>

            {/* Search and Filters */}
            <div className="bg-white rounded-lg shadow-sm p-6 mb-8">
              <form onSubmit={handleSearch} className="mb-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-5 w-5" />
                  <Input
                    type="text"
                    placeholder="Search offers by title or description..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10 pr-4 py-3 w-full"
                  />
                </div>
              </form>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Destination</label>
                  <Select value={selectedDestination} onValueChange={setSelectedDestination}>
                    <SelectTrigger>
                      <SelectValue placeholder="All destinations" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All destinations</SelectItem>
                      {availableDestinations.map((destination) => (
                        <SelectItem key={destination} value={destination}>
                          {destination}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Holiday Type</label>
                  <Select value={selectedHolidayType} onValueChange={setSelectedHolidayType}>
                    <SelectTrigger>
                      <SelectValue placeholder="All holiday types" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All holiday types</SelectItem>
                      {availableHolidayTypes.map((type) => (
                        <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Price Range</label>
                  <Select value={priceRange} onValueChange={setPriceRange}>
                    <SelectTrigger>
                      <SelectValue placeholder="All prices" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All prices</SelectItem>
                      <SelectItem value="under-1000">Under £1,000</SelectItem>
                      <SelectItem value="1000-2500">£1,000 - £2,500</SelectItem>
                      <SelectItem value="2500-5000">£2,500 - £5,000</SelectItem>
                      <SelectItem value="over-5000">Over £5,000</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">Sort by</label>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger>
                      <SelectValue placeholder="Sort by" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="newest">Newest first</SelectItem>
                      <SelectItem value="price-low">Price: Low to High</SelectItem>
                      <SelectItem value="price-high">Price: High to Low</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>

            {/* Results */}
            <div className="mb-6">
              <p className="text-roamah-gray">
                {filteredOffers.length} {filteredOffers.length === 1 ? 'offer' : 'offers'} found
              </p>
            </div>

            {/* Offers Grid */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {filteredOffers.map((offer) => (
                <div key={offer.id} className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all group h-full flex flex-col">
                  {/* Hero image carousel */}
                  <OfferImageCarousel offer={offer} />
                  
                  <div className="p-6 flex flex-col flex-grow">
                    {/* Badges */}
                    <div className="flex flex-wrap gap-2 mb-3">
                      {offer.destinations?.map((dest, index) => (
                        <Badge key={`dest-${index}`} className="bg-blue-100 text-blue-800 border-0">
                          <MapPin className="w-3 h-3 mr-1" />
                          {dest}
                        </Badge>
                      ))}
                      {offer.holidayTypes?.map((type, index) => (
                        <Badge key={`type-${index}`} className="bg-green-100 text-green-800 border-0">
                          {type}
                        </Badge>
                      ))}
                    </div>
                    
                    <h4 className="font-bold text-xl text-roamah-dark mb-2 line-clamp-2">
                      {offer.title}
                    </h4>
                    
                    <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                      {offer.briefDescription}
                    </p>
                    
                    {/* Offer messages as bullet points */}
                    <div className="mb-4 space-y-1 flex-grow">
                      {offer.offerMessage1 && (
                        <div className="flex items-start text-sm text-gray-700">
                          <span className="w-1.5 h-1.5 bg-roamah-orange rounded-full mr-2 mt-1.5 flex-shrink-0"></span>
                          <span className="line-clamp-1">{offer.offerMessage1}</span>
                        </div>
                      )}
                      {offer.offerMessage2 && (
                        <div className="flex items-start text-sm text-gray-700">
                          <span className="w-1.5 h-1.5 bg-roamah-orange rounded-full mr-2 mt-1.5 flex-shrink-0"></span>
                          <span className="line-clamp-1">{offer.offerMessage2}</span>
                        </div>
                      )}
                      {offer.offerMessage3 && (
                        <div className="flex items-start text-sm text-gray-700">
                          <span className="w-1.5 h-1.5 bg-roamah-orange rounded-full mr-2 mt-1.5 flex-shrink-0"></span>
                          <span className="line-clamp-1">{offer.offerMessage3}</span>
                        </div>
                      )}
                    </div>
                    
                    {/* Agent info */}
                    <div className="flex items-center gap-3 mb-4 pt-3 border-t border-gray-100 mt-auto">
                      <img
                        src={offer.agent?.profileImage || "/api/placeholder/40/40"}
                        alt={`${offer.agent?.firstName || ''} ${offer.agent?.lastName || ''}`}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-roamah-dark text-sm truncate">
                          {offer.agent?.firstName} {offer.agent?.lastName}
                        </p>
                        <div className="flex items-center gap-1 text-xs text-gray-500">
                          <MapPin className="w-3 h-3" />
                          <span className="truncate">{offer.agent?.location || 'UK'}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 text-xs text-yellow-600">
                        <Star className="w-3 h-3 fill-current" />
                        <span>{offer.agent?.rating || '5.0'}</span>
                      </div>
                    </div>
                    
                    <Button 
                      className="w-full bg-roamah-orange hover:bg-roamah-orange/90 text-white font-semibold"
                      onClick={() => setLocation(`/offer/${offer.id}`)}
                    >
                      View Offer Details
                    </Button>
                  </div>
                </div>
              ))}
            </div>

            {filteredOffers.length === 0 && (
              <div className="text-center py-12">
                <div className="text-gray-400 mb-4">
                  <Filter className="h-16 w-16 mx-auto" />
                </div>
                <h3 className="text-xl font-semibold text-gray-600 mb-2">No offers found</h3>
                <p className="text-gray-500">Try adjusting your filters to see more results.</p>
              </div>
            )}
          </div>
        </main>
      </div>
      <Footer />
    </>
  );
}