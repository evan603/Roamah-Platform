import { useQuery } from "@tanstack/react-query";
import { useRoute } from "wouter";
import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Star, MapPin, Calendar, Users, Clock, ArrowLeft } from "lucide-react";
import { useLocation } from "wouter";
import { OfferImageCarousel } from "@/components/OfferImageCarousel";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { EnquiryModal } from "@/components/ui/enquiry-modal";
import { Offer } from "@shared/schema";

export default function OfferDetails() {
  const [, params] = useRoute("/offer/:id");
  const [, setLocation] = useLocation();
  const [timeLeft, setTimeLeft] = useState<string>("");
  const [enquiryModalOpen, setEnquiryModalOpen] = useState(false);
  const offerId = params?.id;

  const { data: offer, isLoading } = useQuery<Offer & { agent: any }>({
    queryKey: ["/api/offers", offerId],
    queryFn: async () => {
      const response = await fetch(`/api/offers/${offerId}`);
      if (!response.ok) throw new Error("Failed to fetch offer");
      return response.json();
    },
    enabled: !!offerId,
  });

  useEffect(() => {
    if (!offer?.bookToDate) {
      console.log("No bookToDate found:", offer?.bookToDate);
      return;
    }

    const updateCountdown = () => {
      const now = new Date().getTime();
      const expiry = new Date(offer.bookToDate!).getTime();
      const difference = expiry - now;
      
      console.log("Countdown calculation:", {
        now: new Date(now),
        expiry: new Date(expiry),
        difference,
        differenceInDays: difference / (1000 * 60 * 60 * 24)
      });

      if (difference > 0) {
        const days = Math.floor(difference / (1000 * 60 * 60 * 24));
        const hours = Math.floor((difference % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        
        if (days > 0) {
          setTimeLeft(`${days} day${days === 1 ? '' : 's'}`);
        } else if (hours > 0) {
          setTimeLeft(`${hours} hour${hours === 1 ? '' : 's'}`);
        } else {
          setTimeLeft("Less than 1 hour");
        }
      } else {
        setTimeLeft("Expired");
      }
    };

    updateCountdown();
    const interval = setInterval(updateCountdown, 60000); // Update every minute

    return () => clearInterval(interval);
  }, [offer?.bookToDate]);

  const formatDate = (dateValue: string | Date | null) => {
    if (!dateValue) return "Not specified";
    const date = typeof dateValue === 'string' ? new Date(dateValue) : dateValue;
    return date.toLocaleDateString("en-GB", {
      day: "numeric",
      month: "long",
      year: "numeric"
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-roamah-orange mx-auto mb-4"></div>
          <p className="text-gray-600">Loading offer details...</p>
        </div>
      </div>
    );
  }

  if (!offer) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Offer Not Found</h2>
          <p className="text-gray-600 mb-6">The offer you're looking for doesn't exist or has been removed.</p>
          <Button onClick={() => setLocation("/browse-offers")}>
            Browse All Offers
          </Button>
        </div>
      </div>
    );
  }

  return (
    <>
      <Navbar />
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white shadow-sm">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="sm"
                onClick={() => window.history.back()}
                className="flex items-center gap-2"
              >
                <ArrowLeft className="w-4 h-4" />
                Back
              </Button>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">{offer.title}</h1>
                <p className="text-gray-600">{offer.briefDescription}</p>
              </div>
            </div>
          </div>
        </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Image Carousel */}
            <div className="bg-white rounded-lg shadow-sm overflow-hidden">
              <OfferImageCarousel offer={offer} />
            </div>

            {/* Description */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-semibold mb-4">About This Offer</h2>
              <div className="prose prose-gray max-w-none">
                <p className="text-gray-700 leading-relaxed whitespace-pre-line">
                  {offer.description}
                </p>
              </div>
            </div>

            {/* Special Messages */}
            {(offer.offerMessage1 || offer.offerMessage2 || offer.offerMessage3) && (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h2 className="text-xl font-semibold mb-4">Special Offer Details</h2>
                <div className="space-y-3">
                  {offer.offerMessage1 && (
                    <div className="bg-orange-100 text-orange-800 border border-orange-200 rounded-lg p-4 font-semibold">
                      <p>{offer.offerMessage1}</p>
                    </div>
                  )}
                  {offer.offerMessage2 && (
                    <div className="bg-blue-100 text-blue-800 border border-blue-200 rounded-lg p-4 font-semibold">
                      <p>{offer.offerMessage2}</p>
                    </div>
                  )}
                  {offer.offerMessage3 && (
                    <div className="bg-green-100 text-green-800 border border-green-200 rounded-lg p-4 font-semibold">
                      <p>{offer.offerMessage3}</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* Travel Details */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h2 className="text-xl font-semibold mb-4">Travel Information</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-medium text-gray-900 mb-2 flex items-center gap-2">
                    <Calendar className="w-4 h-4" />
                    Booking Period
                  </h3>
                  <p className="text-gray-600">
                    From: {formatDate(offer.bookFromDate)}
                  </p>
                  <p className="text-gray-600">
                    Until: {formatDate(offer.bookToDate)}
                  </p>
                </div>
                <div>
                  <h3 className="font-medium text-gray-900 mb-2 flex items-center gap-2">
                    <Clock className="w-4 h-4" />
                    Travel Period
                  </h3>
                  <p className="text-gray-600">
                    From: {formatDate(offer.travelFromDate)}
                  </p>
                  <p className="text-gray-600">
                    Until: {formatDate(offer.travelToDate)}
                  </p>
                </div>
              </div>
              {offer.validUntil && (
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <p className="text-sm text-gray-600">
                    <span className="font-medium">Offer valid until:</span> {formatDate(offer.validUntil)}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Price & Booking */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="text-center mb-6">
                <div className="text-3xl font-bold text-roamah-orange mb-2">
                  {offer.fromPrice}
                </div>
                <p className="text-gray-600">Starting price</p>
              </div>

              <Button 
                size="lg" 
                className="w-full bg-roamah-orange hover:bg-roamah-orange/90 text-white font-semibold"
                onClick={() => setEnquiryModalOpen(true)}
              >
                Enquire with {offer.agent?.name?.split(' ')[0] || 'Agent'}
              </Button>
            </div>

            {/* Agent Information */}
            {offer.agent && (
              <div className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold mb-4">Your Travel Expert</h3>
                <div className="flex items-start gap-4">
                  <img
                    src={offer.agent.profileImage}
                    alt={offer.agent.name}
                    className="w-16 h-16 rounded-full object-cover"
                  />
                  <div className="flex-1">
                    <h4 className="font-medium text-gray-900">{offer.agent.name}</h4>
                    <div className="flex items-center gap-2 mt-1">
                      <MapPin className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-600">{offer.agent.location}</span>
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <Star className="w-4 h-4 text-yellow-400 fill-current" />
                      <span className="text-sm text-gray-600">
                        {offer.agent.rating} ({offer.agent.reviewCount} reviews)
                      </span>
                    </div>
                  </div>
                </div>
                <Button
                  variant="outline"
                  size="sm"
                  className="w-full mt-4"
                  onClick={() => setLocation(`/agent/${offer.agentId}`)}
                >
                  View Agent Profile
                </Button>
              </div>
            )}

            {/* Destinations & Holiday Types */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <h3 className="text-lg font-semibold mb-4">Trip Details</h3>
              
              <div className="space-y-4">
                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Destinations</h4>
                  <div className="flex flex-wrap gap-2">
                    {offer.destinations.map((destination, index) => {
                      const destinationColors = [
                        "bg-blue-100 text-blue-800",
                        "bg-purple-100 text-purple-800", 
                        "bg-teal-100 text-teal-800",
                        "bg-pink-100 text-pink-800",
                        "bg-indigo-100 text-indigo-800",
                        "bg-green-100 text-green-800",
                        "bg-orange-100 text-orange-800"
                      ];
                      return (
                        <Badge key={index} variant="secondary" className={`${destinationColors[index % destinationColors.length]} font-semibold`}>
                          {destination}
                        </Badge>
                      );
                    })}
                  </div>
                </div>
                
                <div>
                  <h4 className="text-sm font-medium text-gray-900 mb-2">Holiday Types</h4>
                  <div className="flex flex-wrap gap-2">
                    {offer.holidayTypes.map((type, index) => {
                      const holidayColors = [
                        "bg-green-100 text-green-800",
                        "bg-orange-100 text-orange-800",
                        "bg-blue-100 text-blue-800",
                        "bg-purple-100 text-purple-800",
                        "bg-pink-100 text-pink-800"
                      ];
                      return (
                        <Badge key={index} variant="secondary" className={`${holidayColors[index % holidayColors.length]} font-semibold`}>
                          {type}
                        </Badge>
                      );
                    })}
                  </div>
                </div>
              </div>
            </div>

            {/* Offer Status */}
            <div className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex items-center justify-between mb-3">
                <span className="text-sm font-medium text-gray-900">Status:</span>
                <Badge 
                  variant={offer.status === 'published' ? 'default' : 'secondary'}
                  className={offer.status === 'published' ? 'bg-green-100 text-green-800' : ''}
                >
                  {offer.status === 'published' ? 'Available' : 'Draft'}
                </Badge>
              </div>
              
              {/* Countdown Timer */}
              {offer.bookToDate && timeLeft && (
                <div className="pt-3 border-t border-gray-200">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium text-gray-900 flex items-center gap-2">
                      <Clock className="w-4 h-4" />
                      Expires:
                    </span>
                    <div className={`text-sm font-semibold ${
                      timeLeft === "Expired" 
                        ? "text-red-600" 
                        : timeLeft.includes("hour") || (timeLeft.includes("day") && parseInt(timeLeft) <= 3)
                        ? "text-orange-600" 
                        : "text-green-600"
                    }`}>
                      {timeLeft === "Expired" ? "Offer Expired" : `Offer expires in ${timeLeft}`}
                    </div>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
      </div>
      <Footer />

      <EnquiryModal
        isOpen={enquiryModalOpen}
        onClose={() => setEnquiryModalOpen(false)}
        agent={offer?.agent}
      />
    </>
  );
}