import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { agentProfileCompletionSchema, type AgentProfileCompletion } from "@shared/schema";
import { UK_CITIES } from "@/lib/constants";

const HOLIDAY_TYPES = [
  "Adventure", "Romantic", "Family", "Luxury", "Budget", "Cultural",
  "Beach", "City Break", "Wildlife", "Culinary", "Wellness", "Group"
];

const DESTINATIONS = [
  "Thailand", "Vietnam", "Cambodia", "Laos", "Myanmar", "Singapore", "Malaysia", "Indonesia",
  "Philippines", "Japan", "South Korea", "China", "India", "Nepal", "Sri Lanka", "Maldives",
  "Turkey", "Greece", "Croatia", "Italy", "Spain", "Portugal", "France", "Switzerland",
  "Austria", "Germany", "Netherlands", "Belgium", "Czech Republic", "Hungary", "Poland",
  "United Kingdom", "Ireland", "Iceland", "Norway", "Sweden", "Denmark", "Finland",
  "Russia", "Ukraine", "Romania", "Bulgaria", "Serbia", "Montenegro", "Albania",
  "Morocco", "Egypt", "Tunisia", "Kenya", "Tanzania", "South Africa", "Madagascar",
  "USA", "Canada", "Mexico", "Costa Rica", "Panama", "Peru", "Ecuador", "Colombia",
  "Brazil", "Argentina", "Chile", "Uruguay", "Bolivia", "Venezuela",
  "Australia", "New Zealand", "Fiji", "Vanuatu", "Papua New Guinea", "Solomon Islands"
];

const LANGUAGES = [
  "English", "Spanish", "French", "German", "Italian", "Portuguese", "Dutch", "Russian",
  "Chinese (Mandarin)", "Japanese", "Korean", "Thai", "Vietnamese", "Arabic", "Hindi",
  "Bengali", "Urdu", "Turkish", "Greek", "Polish", "Czech", "Hungarian", "Swedish",
  "Norwegian", "Danish", "Finnish", "Hebrew", "Swahili", "Amharic"
];

export default function CompleteProfile() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [selectedSpecializations, setSelectedSpecializations] = useState<string[]>([]);
  const [selectedDestinations, setSelectedDestinations] = useState<string[]>([]);
  const [selectedLanguages, setSelectedLanguages] = useState<string[]>([]);

  const form = useForm<AgentProfileCompletion>({
    resolver: zodResolver(agentProfileCompletionSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      location: "",
      company: "",
      nextHoliday: "",
      specializations: [],
      destinations: [],
      languages: [],
      bio: "",
      yearsExperience: 0,
    },
  });

  const completeProfileMutation = useMutation({
    mutationFn: async (data: AgentProfileCompletion) => {
      return apiRequest("/api/agents/complete-profile", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem('token')}`,
        },
        body: JSON.stringify(data),
      });
    },
    onSuccess: (response) => {
      toast({
        title: "Profile Completed!",
        description: "Your travel expert profile has been successfully created.",
      });
      setLocation("/agent/dashboard");
    },
    onError: (error: any) => {
      toast({
        title: "Profile Completion Failed",
        description: error.message || "Failed to complete profile. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: AgentProfileCompletion) => {
    const formData = {
      ...data,
      specializations: selectedSpecializations,
      destinations: selectedDestinations,
      languages: selectedLanguages,
    };
    completeProfileMutation.mutate(formData);
  };

  const handleSpecializationChange = (specialization: string) => {
    if (selectedSpecializations.includes(specialization)) {
      setSelectedSpecializations(selectedSpecializations.filter(s => s !== specialization));
    } else if (selectedSpecializations.length < 5) {
      setSelectedSpecializations([...selectedSpecializations, specialization]);
    }
  };

  const handleDestinationChange = (destination: string) => {
    if (selectedDestinations.includes(destination)) {
      setSelectedDestinations(selectedDestinations.filter(d => d !== destination));
    } else if (selectedDestinations.length < 5) {
      setSelectedDestinations([...selectedDestinations, destination]);
    }
  };

  const handleLanguageChange = (language: string) => {
    if (selectedLanguages.includes(language)) {
      setSelectedLanguages(selectedLanguages.filter(l => l !== language));
    } else {
      setSelectedLanguages([...selectedLanguages, language]);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-orange-50 to-white py-12 px-4">
      <div className="max-w-4xl mx-auto">
        <Card>
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold text-gray-900">
              Complete Your Agent Profile
            </CardTitle>
            <CardDescription className="text-lg">
              Tell us about your travel expertise to start receiving client enquiries
            </CardDescription>
          </CardHeader>
          
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8">
                {/* Personal Information */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="firstName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>First Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your first name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="lastName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Last Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter your last name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Business Information */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="company"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Business Name</FormLabel>
                        <FormControl>
                          <Input placeholder="Your travel business name" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  
                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Location</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select your city" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {UK_CITIES.map((city) => (
                              <SelectItem key={city} value={city}>
                                {city}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="yearsExperience"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Years of Experience</FormLabel>
                      <FormControl>
                        <Input
                          type="number"
                          min="0"
                          placeholder="Years in travel industry"
                          {...field}
                          onChange={(e) => field.onChange(parseInt(e.target.value) || 0)}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                {/* Holiday Specializations */}
                <div className="space-y-3">
                  <FormLabel>Holiday Specializations (Choose up to 5)</FormLabel>
                  <FormDescription>
                    Select the types of holidays you specialise in
                  </FormDescription>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                    {HOLIDAY_TYPES.map((type) => (
                      <div key={type} className="flex items-center space-x-2">
                        <Checkbox
                          id={`specialization-${type}`}
                          checked={selectedSpecializations.includes(type)}
                          onCheckedChange={() => handleSpecializationChange(type)}
                          disabled={!selectedSpecializations.includes(type) && selectedSpecializations.length >= 5}
                        />
                        <label
                          htmlFor={`specialization-${type}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {type}
                        </label>
                      </div>
                    ))}
                  </div>
                  <p className="text-sm text-gray-600">
                    Selected: {selectedSpecializations.length}/5
                  </p>
                </div>

                {/* Destination Expertise */}
                <div className="space-y-3">
                  <FormLabel>Destination Expertise (Choose up to 5)</FormLabel>
                  <FormDescription>
                    Select the destinations you have expertise in
                  </FormDescription>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                    {DESTINATIONS.map((destination) => (
                      <div key={destination} className="flex items-center space-x-2">
                        <Checkbox
                          id={`destination-${destination}`}
                          checked={selectedDestinations.includes(destination)}
                          onCheckedChange={() => handleDestinationChange(destination)}
                          disabled={!selectedDestinations.includes(destination) && selectedDestinations.length >= 5}
                        />
                        <label
                          htmlFor={`destination-${destination}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {destination}
                        </label>
                      </div>
                    ))}
                  </div>
                  <p className="text-sm text-gray-600">
                    Selected: {selectedDestinations.length}/5
                  </p>
                </div>

                {/* Languages */}
                <div className="space-y-3">
                  <FormLabel>Languages Spoken</FormLabel>
                  <FormDescription>
                    Select all languages you can communicate in
                  </FormDescription>
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
                    {LANGUAGES.map((language) => (
                      <div key={language} className="flex items-center space-x-2">
                        <Checkbox
                          id={`language-${language}`}
                          checked={selectedLanguages.includes(language)}
                          onCheckedChange={() => handleLanguageChange(language)}
                        />
                        <label
                          htmlFor={`language-${language}`}
                          className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                        >
                          {language}
                        </label>
                      </div>
                    ))}
                  </div>
                  <p className="text-sm text-gray-600">
                    Selected: {selectedLanguages.length} languages
                  </p>
                </div>

                {/* Bio */}
                <FormField
                  control={form.control}
                  name="bio"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Professional Bio</FormLabel>
                      <FormDescription>
                        Tell potential clients about your experience and passion for travel (minimum 50 characters)
                      </FormDescription>
                      <FormControl>
                        <Textarea
                          placeholder="Describe your travel expertise, experience, and what makes you unique as a travel agent..."
                          className="min-h-[120px]"
                          {...field}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="nextHoliday"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Next Holiday (Optional)</FormLabel>
                      <FormDescription>
                        Where are you traveling next? This helps build trust with clients
                      </FormDescription>
                      <FormControl>
                        <Input placeholder="e.g., Exploring the temples of Kyoto, Japan" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button
                  type="submit"
                  className="w-full bg-orange-600 hover:bg-orange-700 text-white py-3 text-lg"
                  disabled={completeProfileMutation.isPending}
                >
                  {completeProfileMutation.isPending ? "Creating Profile..." : "Complete Profile & Start Receiving Enquiries"}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}