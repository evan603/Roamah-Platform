import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";

export default function TermsOfUse() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-roamah-cream to-white">
      <Navbar />
      
      <div className="max-w-4xl mx-auto px-6 py-16">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-bold text-roamah-dark mb-8">Terms of Use</h1>
          <p className="text-sm text-roamah-gray mb-8">Last updated: July 24, 2025</p>
          
          <div className="space-y-6 text-roamah-dark">
            <section>
              <h2 className="text-xl font-semibold mb-3">1. Acceptance of Terms</h2>
              <p className="mb-3">
                By accessing and using Roamah ("we," "our," or "us"), you accept and agree to be bound by the terms and provision of this agreement.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">2. Use License</h2>
              <p className="mb-3">
                Permission is granted to temporarily access Roamah for personal, non-commercial transitory viewing only. This is the grant of a license, not a transfer of title, and under this license you may not:
              </p>
              <ul className="list-disc pl-6 mb-3 space-y-1">
                <li>modify or copy the materials</li>
                <li>use the materials for any commercial purpose or for any public display</li>
                <li>attempt to reverse engineer any software contained on Roamah</li>
                <li>remove any copyright or other proprietary notations from the materials</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">3. Travel Services</h2>
              <p className="mb-3">
                Roamah acts as a platform connecting travelers with independent travel experts. We do not directly provide travel services but facilitate connections between customers and qualified travel professionals.
              </p>
              <ul className="list-disc pl-6 mb-3 space-y-1">
                <li>All bookings and arrangements are made directly between you and the selected travel expert</li>
                <li>We are not responsible for the actions, services, or pricing of independent travel experts</li>
                <li>Travel experts are independent contractors and not employees of Roamah</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">4. User Responsibilities</h2>
              <p className="mb-3">When using Roamah, you agree to:</p>
              <ul className="list-disc pl-6 mb-3 space-y-1">
                <li>Provide accurate and truthful information in all enquiries</li>
                <li>Respect the time and expertise of travel experts</li>
                <li>Communicate professionally and courteously</li>
                <li>Not use the platform for illegal or fraudulent activities</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">5. Data Collection and Use</h2>
              <p className="mb-3">
                When you submit enquiries through Roamah, we collect and store your personal information to facilitate communication between you and travel experts. This includes:
              </p>
              <ul className="list-disc pl-6 mb-3 space-y-1">
                <li>Contact information (name, email, phone number)</li>
                <li>Travel preferences and requirements</li>
                <li>Communication preferences</li>
              </ul>
              <p className="mb-3">
                This information is shared with your selected travel expert to provide personalised service. See our Privacy Policy for detailed information handling practices.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">6. Disclaimer</h2>
              <p className="mb-3">
                The materials on Roamah are provided on an 'as is' basis. Roamah makes no warranties, expressed or implied, and hereby disclaims and negates all other warranties including without limitation, implied warranties or conditions of merchantability, fitness for a particular purpose, or non-infringement of intellectual property or other violation of rights.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">7. Limitations</h2>
              <p className="mb-3">
                In no event shall Roamah or its suppliers be liable for any damages (including, without limitation, damages for loss of data or profit, or due to business interruption) arising out of the use or inability to use the materials on Roamah, even if Roamah or a Roamah authorized representative has been notified orally or in writing of the possibility of such damage.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">8. Revisions and Errata</h2>
              <p className="mb-3">
                The materials appearing on Roamah could include technical, typographical, or photographic errors. Roamah does not warrant that any of the materials on its website are accurate, complete, or current. Roamah may make changes to the materials contained on its website at any time without notice.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">9. Governing Law</h2>
              <p className="mb-3">
                These terms and conditions are governed by and construed in accordance with the laws of the United Kingdom and you irrevocably submit to the exclusive jurisdiction of the courts in that state or location.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">10. Contact Information</h2>
              <p className="mb-3">
                If you have any questions about these Terms of Use, please contact us at:
              </p>
              <div className="bg-roamah-cream p-4 rounded-lg">
                <p><strong>Roamah Travel Platform</strong></p>
                <p>Email: legal@roamah.com</p>
                <p>Address: London, United Kingdom</p>
              </div>
            </section>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}