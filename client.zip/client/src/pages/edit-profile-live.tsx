import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { StarRating } from "@/components/ui/star-rating";
import { useToast } from "@/hooks/use-toast";
import { UK_CITIES } from "@/lib/constants";
import { LANGUAGES } from "@shared/schema";

// Financial Protection Bodies
const PROTECTION_BODIES = ['ATOL', 'ABTA', 'ABTOT', 'TTA'];
import { ImageCropUpload } from "@/components/ImageCropUpload";
import { MultipleCropUpload } from "@/components/MultipleCropUpload";
import { MapPin, Save, X, Camera, Play, Star, Edit2, CheckCircle, Plus, Check } from "lucide-react";

interface AgentProfile {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
  name: string;
  location: string;
  bio: string;
  profileImage: string;
  company: string;
  nextHoliday: string;
  specializations: string[];
  destinations: string[];
  languages: string[];
  photos: string[];
  videoUrl?: string;
  yearsExperience: number;
  rating: string;
  reviewCount: number;
  hasFinancialProtection?: boolean;
  protectionBodies?: string[];
  licenseNumbers?: Record<string, string>;
}

export default function EditProfileLive() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isSaving, setIsSaving] = useState(false);
  const [uploadingProfileImage, setUploadingProfileImage] = useState(false);
  const [uploadingPhotos, setUploadingPhotos] = useState(false);
  const [editingField, setEditingField] = useState<string | null>(null);
  
  const [editForm, setEditForm] = useState({
    firstName: "",
    lastName: "",
    location: "",
    company: "",
    bio: "",
    nextHoliday: "",
    yearsExperience: 0,
    specializations: [] as string[],
    destinations: [] as string[],
    languages: [] as string[],
    hasFinancialProtection: false,
    protectionBodies: [] as string[],
    licenseNumbers: {} as Record<string, string>
  });

  // Check authentication
  useEffect(() => {
    const token = localStorage.getItem('agentToken');
    if (!token) {
      setLocation('/agent-login');
    }
  }, [setLocation]);

  // Fetch holiday types and destinations from API
  const { data: holidayTypes } = useQuery<any[]>({
    queryKey: ["/api/holiday-types"],
  });

  const { data: destinations } = useQuery<any[]>({
    queryKey: ["/api/destinations"],
  });

  // Fetch profile data
  const { data: profile, isLoading } = useQuery<AgentProfile>({
    queryKey: ['/api/agents/profile'],
    queryFn: async () => {
      const token = localStorage.getItem('agentToken');
      if (!token) throw new Error('No auth token');
      
      const response = await fetch('/api/agents/profile', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      
      if (!response.ok) {
        throw new Error('Failed to fetch profile');
      }
      
      return response.json();
    },
  });

  // Initialize edit form when profile loads
  useEffect(() => {
    if (profile) {
      setEditForm({
        firstName: profile.firstName || "",
        lastName: profile.lastName || "",
        location: profile.location || "",
        company: profile.company || "",
        bio: profile.bio || "",
        nextHoliday: profile.nextHoliday || "",
        yearsExperience: profile.yearsExperience || 0,
        specializations: profile.specializations || [],
        destinations: profile.destinations || [],
        languages: profile.languages || [],
        hasFinancialProtection: profile.hasFinancialProtection || false,
        protectionBodies: profile.protectionBodies || [],
        licenseNumbers: profile.licenseNumbers || {}
      });
    }
  }, [profile]);

  // Save profile changes
  const saveProfileChanges = async () => {
    setIsSaving(true);
    try {
      const token = localStorage.getItem('agentToken');
      const response = await fetch('/api/agents/profile', {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(editForm),
      });

      if (!response.ok) {
        throw new Error('Failed to update profile');
      }

      toast({
        title: "Profile updated",
        description: "Your profile has been updated successfully",
      });

      queryClient.invalidateQueries({ queryKey: ['/api/agents/profile'] });
      queryClient.invalidateQueries({ queryKey: ['/api/agents', profile?.id] });
      setEditingField(null);
    } catch (error) {
      toast({
        title: "Update failed",
        description: "Failed to update profile. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSaving(false);
    }
  };

  // Profile image upload with cropping
  const handleProfileImageUpdate = async (croppedFile: File) => {
    setUploadingProfileImage(true);
    try {
      const token = localStorage.getItem('agentToken');
      const formData = new FormData();
      formData.append('profileImage', croppedFile);

      const response = await fetch('/api/agents/upload/profile-image', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Failed to upload profile image');
      }

      toast({
        title: "Profile image updated",
        description: "Your profile image has been updated successfully",
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/agents/profile'] });
      
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Failed to upload profile image. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploadingProfileImage(false);
    }
  };

  // Photos upload with cropping
  const handlePhotosUpdate = async (croppedFiles: File[]) => {
    if (croppedFiles.length === 0) return;

    setUploadingPhotos(true);
    try {
      const token = localStorage.getItem('agentToken');
      const formData = new FormData();
      
      croppedFiles.forEach((file) => {
        formData.append('photos', file);
      });

      const response = await fetch('/api/agents/upload/photos', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Failed to upload photos');
      }

      const result = await response.json();
      
      toast({
        title: "Photos uploaded successfully",
        description: `${result.photos.length} photo(s) added to your profile`,
      });
      
      queryClient.invalidateQueries({ queryKey: ['/api/agents/profile'] });
      
    } catch (error) {
      toast({
        title: "Upload failed",
        description: "Failed to upload photos. Please try again.",
        variant: "destructive",
      });
    } finally {
      setUploadingPhotos(false);
    }
  };

  // Delete photo handler
  const handlePhotoDelete = async (photoUrl: string) => {
    try {
      const token = localStorage.getItem('agentToken');
      const response = await fetch('/api/agents/upload/photos', {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ photoUrl }),
      });

      if (!response.ok) {
        throw new Error('Failed to delete photo');
      }

      toast({
        title: "Photo deleted",
        description: "Photo removed successfully",
      });

      queryClient.invalidateQueries({ queryKey: ['/api/agents/profile'] });
    } catch (error) {
      toast({
        title: "Delete failed",
        description: "Failed to delete photo. Please try again.",
        variant: "destructive",
      });
    }
  };

  // Replace photo handler
  const handlePhotoReplace = async (oldPhotoUrl: string, newFile: File) => {
    try {
      const token = localStorage.getItem('agentToken');
      const formData = new FormData();
      formData.append('photo', newFile);
      formData.append('oldPhotoUrl', oldPhotoUrl);

      const response = await fetch('/api/agents/upload/photos', {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
        },
        body: formData,
      });

      if (!response.ok) {
        throw new Error('Failed to replace photo');
      }

      toast({
        title: "Photo replaced",
        description: "Photo updated successfully",
      });

      queryClient.invalidateQueries({ queryKey: ['/api/agents/profile'] });
    } catch (error) {
      toast({
        title: "Replace failed",
        description: "Failed to replace photo. Please try again.",
        variant: "destructive",
      });
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <main className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="animate-pulse">
              <div className="bg-gray-200 h-64 rounded-2xl mb-8"></div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        <main className="py-8">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h1 className="text-2xl font-bold text-gray-900 mb-4">Profile not found</h1>
            <Button onClick={() => setLocation('/agent-dashboard')} className="mt-4">
              Back to Dashboard
            </Button>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <>
      <div className="min-h-screen bg-gray-50">
        <Navbar />
        
        {/* Edit Mode Header */}
        <div className="bg-orange-600 text-white">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center">
                <Edit2 className="w-5 h-5 mr-2" />
                <span className="font-medium">Live Profile Editing Mode</span>
                <Badge variant="secondary" className="ml-2 bg-white/20 text-white">
                  Changes save automatically
                </Badge>
              </div>
              <div className="flex items-center space-x-3">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setLocation('/agent-dashboard')}
                  className="bg-white/10 border-white/30 text-white hover:bg-white/20"
                >
                  <X className="w-4 h-4 mr-1" />
                  Exit Edit Mode
                </Button>
              </div>
            </div>
          </div>
        </div>
        
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
            {/* Left Sidebar - Editable */}
            <div className="lg:col-span-1">
              <div className="bg-white rounded-2xl p-6 shadow-lg sticky top-8">
                {/* Profile Image - Editable with Crop Tool */}
                <div className="text-center mb-6">
                  <div className="relative">
                    {uploadingProfileImage && (
                      <div className="absolute inset-0 bg-black/50 rounded-xl flex items-center justify-center z-10">
                        <div className="animate-spin w-8 h-8 border-2 border-white border-t-transparent rounded-full" />
                      </div>
                    )}
                    <ImageCropUpload
                      currentImage={profile.profileImage}
                      onImageUpdate={handleProfileImageUpdate}
                      aspectRatio={1}
                      cropSize={{ width: 400, height: 400 }}
                    />
                  </div>
                  
                  {/* Name - Editable */}
                  {editingField === 'name' ? (
                    <div className="space-y-2">
                      <Input
                        value={editForm.firstName}
                        onChange={(e) => setEditForm({...editForm, firstName: e.target.value})}
                        placeholder="First name"
                        className="text-center"
                      />
                      <Input
                        value={editForm.lastName}
                        onChange={(e) => setEditForm({...editForm, lastName: e.target.value})}
                        placeholder="Last name"
                        className="text-center"
                      />
                      <div className="flex justify-center space-x-2">
                        <Button size="sm" onClick={saveProfileChanges} disabled={isSaving}>
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Save
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => setEditingField(null)}>
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="group cursor-pointer" onClick={() => setEditingField('name')}>
                      <h1 className="text-2xl font-bold text-roamah-dark mb-2 group-hover:text-orange-600 transition-colors">
                        {editForm.firstName} {editForm.lastName}
                        <Edit2 className="w-4 h-4 ml-2 inline opacity-0 group-hover:opacity-100 transition-opacity" />
                      </h1>
                    </div>
                  )}
                  
                  <div className="flex items-center justify-center mb-2">
                    <StarRating 
                      rating={parseFloat(profile.rating)} 
                      reviewCount={profile.reviewCount}
                      showCount={true}
                      size="sm"
                    />
                  </div>
                  
                  {/* Location - Editable */}
                  {editingField === 'location' ? (
                    <div className="space-y-2">
                      <Select 
                        value={editForm.location} 
                        onValueChange={(value) => setEditForm({...editForm, location: value})}
                      >
                        <SelectTrigger className="text-center">
                          <SelectValue placeholder="Select your city" />
                        </SelectTrigger>
                        <SelectContent>
                          {UK_CITIES.map((city) => (
                            <SelectItem key={city} value={city}>{city}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <div className="flex justify-center space-x-2">
                        <Button size="sm" onClick={saveProfileChanges} disabled={isSaving}>
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Save
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => setEditingField(null)}>
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div 
                      className="flex items-center justify-center text-roamah-gray mb-4 group cursor-pointer hover:text-orange-600 transition-colors"
                      onClick={() => setEditingField('location')}
                    >
                      <MapPin className="h-4 w-4 mr-1" />
                      <span className="font-bold">{editForm.location}</span>
                      <Edit2 className="w-3 h-3 ml-2 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  )}
                  
                  {/* Company - Editable */}
                  {editingField === 'company' ? (
                    <div className="space-y-2">
                      <Input
                        value={editForm.company}
                        onChange={(e) => setEditForm({...editForm, company: e.target.value})}
                        placeholder="Your company"
                        className="text-center"
                      />
                      <div className="flex justify-center space-x-2">
                        <Button size="sm" onClick={saveProfileChanges} disabled={isSaving}>
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Save
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => setEditingField(null)}>
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div 
                      className="text-sm text-roamah-gray mb-4 font-bold group cursor-pointer hover:text-orange-600 transition-colors"
                      onClick={() => setEditingField('company')}
                    >
                      {editForm.company}
                      <Edit2 className="w-3 h-3 ml-2 inline opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  )}
                  
                  {/* Financial Protection - Editable */}
                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-3">
                      <h3 className="font-bold text-roamah-dark text-sm">Financial Protection</h3>
                      {editingField !== 'financialProtection' && (
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => setEditingField('financialProtection')}
                        >
                          <Edit2 className="w-3 h-3 mr-1" />
                          Edit
                        </Button>
                      )}
                    </div>
                    
                    {editingField === 'financialProtection' ? (
                      <div className="space-y-3">
                        <div className="space-y-2">
                          <Label className="text-xs">Protection Bodies</Label>
                          <div className="grid grid-cols-2 gap-2">
                            {PROTECTION_BODIES.map((body) => (
                              <div key={body} className="flex items-center space-x-2">
                                <Checkbox
                                  id={body}
                                  checked={editForm.protectionBodies.includes(body)}
                                  onCheckedChange={(checked) => {
                                    if (checked) {
                                      setEditForm({
                                        ...editForm,
                                        protectionBodies: [...editForm.protectionBodies, body],
                                        hasFinancialProtection: true
                                      });
                                    } else {
                                      const newBodies = editForm.protectionBodies.filter(b => b !== body);
                                      const newLicenseNumbers = { ...editForm.licenseNumbers };
                                      delete newLicenseNumbers[body];
                                      setEditForm({
                                        ...editForm,
                                        protectionBodies: newBodies,
                                        licenseNumbers: newLicenseNumbers,
                                        hasFinancialProtection: newBodies.length > 0
                                      });
                                    }
                                  }}
                                />
                                <Label htmlFor={body} className="text-xs cursor-pointer">
                                  {body}
                                </Label>
                              </div>
                            ))}
                          </div>
                        </div>
                        
                        {editForm.protectionBodies.length > 0 && (
                          <div className="space-y-2">
                            <Label className="text-xs">License Numbers</Label>
                            {editForm.protectionBodies.map((body) => (
                              <div key={body} className="space-y-1">
                                <Label className="text-xs text-gray-600">{body} License Number</Label>
                                <Input
                                  value={editForm.licenseNumbers[body] || ''}
                                  onChange={(e) => setEditForm({
                                    ...editForm,
                                    licenseNumbers: {
                                      ...editForm.licenseNumbers,
                                      [body]: e.target.value
                                    }
                                  })}
                                  placeholder={`Enter ${body} license number`}
                                  className="text-xs"
                                />
                              </div>
                            ))}
                          </div>
                        )}
                        
                        <div className="flex justify-end space-x-2 pt-2">
                          <Button size="sm" onClick={saveProfileChanges} disabled={isSaving}>
                            <CheckCircle className="w-3 h-3 mr-1" />
                            Save
                          </Button>
                          <Button size="sm" variant="outline" onClick={() => setEditingField(null)}>
                            Cancel
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <div className="text-center">
                        {editForm.hasFinancialProtection && editForm.protectionBodies.length > 0 ? (
                          <div className="space-y-1">
                            {editForm.protectionBodies.map((body, index) => {
                              const licenseNumber = editForm.licenseNumbers?.[body];
                              return (
                                <div key={index} className="flex items-center justify-center text-sm text-green-700">
                                  <Check className="w-4 h-4 mr-2 text-green-600" />
                                  <span className="font-medium">{body} Protected</span>
                                  {licenseNumber && (
                                    <span className="font-medium ml-2 text-green-600">({licenseNumber})</span>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        ) : (
                          <span className="text-gray-500 text-sm italic">Click edit to add financial protection</span>
                        )}
                      </div>
                    )}
                  </div>
                  
                  {/* Next Holiday - Editable */}
                  {editingField === 'nextHoliday' ? (
                    <div className="space-y-2">
                      <Input
                        value={editForm.nextHoliday}
                        onChange={(e) => setEditForm({...editForm, nextHoliday: e.target.value})}
                        placeholder="Next holiday recommendation"
                        className="text-center"
                      />
                      <div className="flex justify-center space-x-2">
                        <Button size="sm" onClick={saveProfileChanges} disabled={isSaving}>
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Save
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => setEditingField(null)}>
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div 
                      className="text-sm text-roamah-gray mb-6 font-bold group cursor-pointer hover:text-orange-600 transition-colors"
                      onClick={() => setEditingField('nextHoliday')}
                    >
                      My next holiday is to: {editForm.nextHoliday || "Click to add"}
                      <Edit2 className="w-3 h-3 ml-2 inline opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                  )}
                </div>

                {/* Preview Button */}
                <Button 
                  className="w-full bg-roamah-orange hover:bg-roamah-orange/90 text-white font-bold mb-6"
                  onClick={() => window.open(`/agent/${profile.id}`, '_blank')}
                >
                  Preview Public Profile
                </Button>

                {/* Specializations - Editable */}
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-bold text-roamah-dark">Specialises in</h3>
                    {editingField !== 'specializations' && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setEditingField('specializations')}
                      >
                        <Edit2 className="w-3 h-3 mr-1" />
                        Edit
                      </Button>
                    )}
                  </div>
                  
                  {editingField === 'specializations' ? (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto">
                        {holidayTypes?.map((type) => (
                          <div key={type.name} className="flex items-center space-x-2">
                            <Checkbox
                              id={type.slug}
                              checked={editForm.specializations.includes(type.name)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setEditForm({
                                    ...editForm, 
                                    specializations: [...editForm.specializations, type.name]
                                  });
                                } else {
                                  setEditForm({
                                    ...editForm, 
                                    specializations: editForm.specializations.filter(s => s !== type.name)
                                  });
                                }
                              }}
                            />
                            <Label htmlFor={type.slug} className="text-xs cursor-pointer">
                              {type.name}
                            </Label>
                          </div>
                        ))}
                      </div>
                      <div className="flex justify-end space-x-2 pt-2">
                        <Button size="sm" onClick={saveProfileChanges} disabled={isSaving}>
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Save
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => setEditingField(null)}>
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {profile.specializations.map((spec) => (
                        <Badge key={spec} variant="secondary" className="bg-orange-100 text-orange-800 text-xs">
                          {spec}
                        </Badge>
                      ))}
                      {profile.specializations.length === 0 && (
                        <span className="text-gray-500 text-sm italic">Click edit to add specializations</span>
                      )}
                    </div>
                  )}
                </div>

                {/* Destinations - Editable */}
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-bold text-roamah-dark">Expert destinations</h3>
                    {editingField !== 'destinations' && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setEditingField('destinations')}
                      >
                        <Edit2 className="w-3 h-3 mr-1" />
                        Edit
                      </Button>
                    )}
                  </div>
                  
                  {editingField === 'destinations' ? (
                    <div className="space-y-3">
                      <div className="grid grid-cols-2 gap-2 max-h-40 overflow-y-auto">
                        {destinations?.map((destination) => (
                          <div key={destination.name} className="flex items-center space-x-2">
                            <Checkbox
                              id={destination.slug}
                              checked={editForm.destinations.includes(destination.name)}
                              onCheckedChange={(checked) => {
                                if (checked) {
                                  setEditForm({
                                    ...editForm, 
                                    destinations: [...editForm.destinations, destination.name]
                                  });
                                } else {
                                  setEditForm({
                                    ...editForm, 
                                    destinations: editForm.destinations.filter(d => d !== destination.name)
                                  });
                                }
                              }}
                            />
                            <Label htmlFor={destination.slug} className="text-xs cursor-pointer">
                              {destination.name}
                            </Label>
                          </div>
                        ))}
                      </div>
                      <div className="flex justify-end space-x-2 pt-2">
                        <Button size="sm" onClick={saveProfileChanges} disabled={isSaving}>
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Save
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => setEditingField(null)}>
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {profile.destinations.map((dest) => (
                        <Badge key={dest} variant="secondary" className="bg-blue-100 text-blue-800 text-xs">
                          {dest}
                        </Badge>
                      ))}
                      {profile.destinations.length === 0 && (
                        <span className="text-gray-500 text-sm italic">Click edit to add destinations</span>
                      )}
                    </div>
                  )}
                </div>

                {/* Languages - Editable */}
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-bold text-roamah-dark">Languages</h3>
                    {editingField !== 'languages' && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setEditingField('languages')}
                      >
                        <Edit2 className="w-3 h-3 mr-1" />
                        Edit
                      </Button>
                    )}
                  </div>
                  
                  {editingField === 'languages' ? (
                    <div className="space-y-3">
                      <div className="space-y-2">
                        {editForm.languages.map((lang, index) => (
                          <div key={index} className="flex items-center space-x-2">
                            <Input
                              value={lang}
                              onChange={(e) => {
                                const newLanguages = [...editForm.languages];
                                newLanguages[index] = e.target.value;
                                setEditForm({...editForm, languages: newLanguages});
                              }}
                              placeholder="Language"
                              className="flex-1"
                            />
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                const newLanguages = editForm.languages.filter((_, i) => i !== index);
                                setEditForm({...editForm, languages: newLanguages});
                              }}
                            >
                              ×
                            </Button>
                          </div>
                        ))}
                        <Select 
                          value="" 
                          onValueChange={(value) => {
                            if (value && !editForm.languages.includes(value)) {
                              setEditForm({...editForm, languages: [...editForm.languages, value]});
                            }
                          }}
                        >
                          <SelectTrigger className="w-full">
                            <SelectValue placeholder="Add Language" />
                          </SelectTrigger>
                          <SelectContent>
                            {LANGUAGES.filter(lang => !editForm.languages.includes(lang)).map((language) => (
                              <SelectItem key={language} value={language}>{language}</SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                      <div className="flex justify-end space-x-2 pt-2">
                        <Button size="sm" onClick={saveProfileChanges} disabled={isSaving}>
                          <CheckCircle className="w-3 h-3 mr-1" />
                          Save
                        </Button>
                        <Button size="sm" variant="outline" onClick={() => setEditingField(null)}>
                          Cancel
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <div className="flex flex-wrap gap-2">
                      {profile.languages.map((lang) => (
                        <Badge key={lang} variant="secondary" className="bg-gray-100 text-gray-800 text-xs">
                          {lang}
                        </Badge>
                      ))}
                      {profile.languages.length === 0 && (
                        <span className="text-gray-500 text-sm italic">Click edit to add languages</span>
                      )}
                    </div>
                  )}
                </div>
              </div>
            </div>

            {/* Main Content Area */}
            <div className="lg:col-span-3">
              <div className="space-y-8">
                {/* About Me - Editable */}
                <div className="bg-white rounded-2xl p-8 shadow-lg">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-roamah-dark">About Me</h2>
                    {editingField !== 'bio' && (
                      <Button 
                        variant="outline" 
                        size="sm"
                        onClick={() => setEditingField('bio')}
                      >
                        <Edit2 className="w-4 h-4 mr-1" />
                        Edit
                      </Button>
                    )}
                  </div>
                  
                  {editingField === 'bio' ? (
                    <div className="space-y-4">
                      <Textarea
                        value={editForm.bio}
                        onChange={(e) => setEditForm({...editForm, bio: e.target.value})}
                        placeholder="Tell clients about yourself, your experience, and expertise..."
                        rows={8}
                        className="resize-none"
                      />
                      <div className="flex justify-between items-center">
                        <p className="text-xs text-gray-500">{editForm.bio.length} characters</p>
                        <div className="flex space-x-2">
                          <Button onClick={saveProfileChanges} disabled={isSaving}>
                            <CheckCircle className="w-4 h-4 mr-1" />
                            {isSaving ? 'Saving...' : 'Save Changes'}
                          </Button>
                          <Button variant="outline" onClick={() => setEditingField(null)}>
                            Cancel
                          </Button>
                        </div>
                      </div>
                    </div>
                  ) : (
                    <div className="prose max-w-none">
                      <p className="text-roamah-gray leading-relaxed">
                        {editForm.bio || "Click 'Edit' to add your bio..."}
                      </p>
                    </div>
                  )}
                </div>

                {/* Travel Photos - Editable with Crop Upload */}
                <div className="bg-white rounded-2xl p-8 shadow-lg">
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-2xl font-bold text-roamah-dark">My Travel Experiences</h2>
                    {uploadingPhotos && (
                      <div className="flex items-center text-sm text-gray-500">
                        <div className="animate-spin w-4 h-4 border-2 border-gray-400 border-t-transparent rounded-full mr-2" />
                        Uploading photos...
                      </div>
                    )}
                  </div>
                  
                  <MultipleCropUpload
                    currentPhotos={profile.photos || []}
                    onPhotosUpdate={handlePhotosUpdate}
                    onPhotoDelete={handlePhotoDelete}
                    onPhotoReplace={handlePhotoReplace}
                    aspectRatio={3/2}
                    maxPhotos={8}
                  />
                  
                  {(!profile.photos || profile.photos.length === 0) && (
                    <div className="text-center py-8 text-gray-500 mt-4">
                      <Camera className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>No photos uploaded yet</p>
                      <p className="text-sm">Add photos to showcase your travel experiences</p>
                    </div>
                  )}
                </div>

                {/* Introduction Video */}
                <div className="bg-white rounded-2xl p-8 shadow-lg">
                  <h2 className="text-2xl font-bold text-roamah-dark mb-6">Introduction Video</h2>
                  {profile.videoUrl ? (
                    <video
                      src={profile.videoUrl}
                      controls
                      className="w-full h-64 object-cover rounded-lg"
                    >
                      Your browser does not support the video tag.
                    </video>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <Play className="w-12 h-12 mx-auto mb-2 opacity-50" />
                      <p>No introduction video uploaded</p>
                      <p className="text-sm">Upload a video from your dashboard</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    </>
  );
}