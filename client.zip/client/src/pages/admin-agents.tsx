import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";
import { 
  ArrowLeft, 
  Check, 
  X, 
  Edit, 
  Eye, 
  Search,
  UserCheck,
  UserX,
  Clock,
  Mail,
  MapPin,
  Calendar,
  User,
  Camera,
  Image as ImageIcon,
  Upload,
  Trash2
} from "lucide-react";

interface Agent {
  id: number;
  email: string;
  firstName: string | null;
  lastName: string | null;
  name: string | null;
  location: string | null;
  bio: string | null;
  profileImage: string | null;
  profileCompleted: boolean;
  approvalStatus: string;
  approvedAt: string | null;
  approvedBy: string | null;
  createdAt: string;
  destinations: string[] | null;
  specializations: string[] | null;
  languages: string[] | null;
  photos: string[] | null;
  yearsExperience: number;
  videoUrl: string | null;
  nextHoliday: string | null;
  hasFinancialProtection: boolean | null;
  protectionBodies: string[] | null;
  licenseNumbers: Record<string, string> | null;
}

export default function AdminAgents() {
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [editingAgent, setEditingAgent] = useState<Agent | null>(null);
  const [showEditDialog, setShowEditDialog] = useState(false);
  const [showImageDialog, setShowImageDialog] = useState(false);
  const [uploadingImage, setUploadingImage] = useState(false);

  // Fetch all agents for admin
  const { data: agents = [], isLoading } = useQuery<Agent[]>({
    queryKey: ["/api/admin/agents"],
    retry: false,
  });

  // Filter agents based on search and status
  const filteredAgents = agents.filter(agent => {
    const matchesSearch = !searchTerm || 
      agent.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      agent.name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      agent.firstName?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      agent.lastName?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === "all" || agent.approvalStatus === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  // Approve agent mutation
  const approveAgent = useMutation({
    mutationFn: async (agentId: number) => {
      return apiRequest(`/api/admin/agents/${agentId}/approve`, {
        method: "PUT",
        headers: {
          "Authorization": `Bearer ${localStorage.getItem('adminToken')}`,
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/agents"] });
      toast({
        title: "Success",
        description: "Agent approved successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to approve agent",
        variant: "destructive",
      });
    },
  });

  // Reject agent mutation
  const rejectAgent = useMutation({
    mutationFn: async (agentId: number) => {
      return apiRequest(`/api/admin/agents/${agentId}/reject`, {
        method: "PUT",
        headers: {
          "Authorization": `Bearer ${localStorage.getItem('adminToken')}`,
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/agents"] });
      toast({
        title: "Success",
        description: "Agent rejected",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to reject agent",
        variant: "destructive",
      });
    },
  });

  // Update agent profile mutation
  const updateAgentProfile = useMutation({
    mutationFn: async (data: { id: number; updates: Partial<Agent> }) => {
      return apiRequest(`/api/admin/agents/${data.id}/profile`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem('adminToken')}`,
        },
        body: JSON.stringify(data.updates),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/agents"] });
      toast({
        title: "Success",
        description: "Agent profile updated successfully",
      });
      setShowEditDialog(false);
      setEditingAgent(null);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update agent profile",
        variant: "destructive",
      });
    },
  });

  // Upload profile image mutation
  const uploadProfileImage = useMutation({
    mutationFn: async (data: { agentId: number; file: File }) => {
      const formData = new FormData();
      formData.append('profileImage', data.file);
      
      const response = await fetch(`/api/admin/agents/${data.agentId}/profile-image`, {
        method: 'POST',
        headers: {
          "Authorization": `Bearer ${localStorage.getItem('adminToken')}`,
        },
        body: formData
      });
      
      if (!response.ok) {
        throw new Error('Failed to upload image');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/agents"] });
      toast({
        title: "Success",
        description: "Profile image updated successfully",
      });
      setUploadingImage(false);
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to upload profile image",
        variant: "destructive",
      });
      setUploadingImage(false);
    },
  });

  // Upload travel photo mutation
  const uploadTravelPhoto = useMutation({
    mutationFn: async (data: { agentId: number; file: File }) => {
      const formData = new FormData();
      formData.append('photo', data.file);
      
      const response = await fetch(`/api/admin/agents/${data.agentId}/travel-photo`, {
        method: 'POST',
        headers: {
          "Authorization": `Bearer ${localStorage.getItem('adminToken')}`,
        },
        body: formData
      });
      
      if (!response.ok) {
        throw new Error('Failed to upload photo');
      }
      
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/agents"] });
      toast({
        title: "Success",
        description: "Travel photo added successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to upload travel photo",
        variant: "destructive",
      });
    },
  });

  // Delete travel photo mutation
  const deleteTravelPhoto = useMutation({
    mutationFn: async (data: { agentId: number; photoUrl: string }) => {
      return apiRequest(`/api/admin/agents/${data.agentId}/travel-photo`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${localStorage.getItem('adminToken')}`,
        },
        body: JSON.stringify({ photoUrl: data.photoUrl }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/admin/agents"] });
      toast({
        title: "Success",
        description: "Travel photo deleted successfully",
      });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete travel photo",
        variant: "destructive",
      });
    },
  });

  const handleProfileImageUpload = (agentId: number, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      setUploadingImage(true);
      uploadProfileImage.mutate({ agentId, file });
    }
  };

  const handleTravelPhotoUpload = (agentId: number, event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      uploadTravelPhoto.mutate({ agentId, file });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "approved":
        return <Badge className="bg-green-100 text-green-800 border-green-200"><UserCheck className="w-3 h-3 mr-1" />Approved</Badge>;
      case "rejected":
        return <Badge className="bg-red-100 text-red-800 border-red-200"><UserX className="w-3 h-3 mr-1" />Rejected</Badge>;
      case "pending":
      default:
        return <Badge className="bg-yellow-100 text-yellow-800 border-yellow-200"><Clock className="w-3 h-3 mr-1" />Pending</Badge>;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="animate-pulse">
            <div className="bg-gray-200 h-8 rounded w-64 mb-8"></div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[...Array(6)].map((_, i) => (
                <div key={i} className="bg-gray-200 h-64 rounded-lg"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center space-x-4">
            <Link href="/admin/enquiries">
              <Button variant="outline" size="sm">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Admin
              </Button>
            </Link>
            <h1 className="text-3xl font-bold text-gray-900">Agent Management</h1>
          </div>
          <div className="text-sm text-gray-600">
            Total Agents: {agents.length}
          </div>
        </div>

        {/* Filters */}
        <Card className="mb-8">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label htmlFor="search">Search Agents</Label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    id="search"
                    placeholder="Search by name or email..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              <div>
                <Label htmlFor="status">Filter by Status</Label>
                <select
                  id="status"
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value)}
                  className="w-full p-2 border border-gray-300 rounded-md"
                >
                  <option value="all">All Statuses</option>
                  <option value="pending">Pending Approval</option>
                  <option value="approved">Approved</option>
                  <option value="rejected">Rejected</option>
                </select>
              </div>
              <div className="flex items-end">
                <div className="text-sm text-gray-600">
                  Showing {filteredAgents.length} of {agents.length} agents
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Agents Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredAgents.map((agent) => (
            <Card key={agent.id} className="hover:shadow-lg transition-shadow">
              <CardHeader className="pb-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <img
                      src={agent.profileImage || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face"}
                      alt={agent.name || "Agent"}
                      className="w-12 h-12 rounded-full object-cover"
                    />
                    <div>
                      <CardTitle className="text-lg">
                        {agent.name || `${agent.firstName || ""} ${agent.lastName || ""}`.trim() || "Unnamed Agent"}
                      </CardTitle>
                      <p className="text-sm text-gray-600">ID: {agent.id}</p>
                    </div>
                  </div>
                  {getStatusBadge(agent.approvalStatus)}
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center text-sm text-gray-600">
                    <Mail className="w-4 h-4 mr-2" />
                    {agent.email}
                  </div>
                  
                  {agent.location && (
                    <div className="flex items-center text-sm text-gray-600">
                      <MapPin className="w-4 h-4 mr-2" />
                      {agent.location}
                    </div>
                  )}

                  <div className="flex items-center text-sm text-gray-600">
                    <Calendar className="w-4 h-4 mr-2" />
                    Joined: {new Date(agent.createdAt).toLocaleDateString()}
                  </div>

                  <div className="flex items-center text-sm text-gray-600">
                    <User className="w-4 h-4 mr-2" />
                    Profile: {agent.profileCompleted ? "Complete" : "Incomplete"}
                  </div>

                  {/* Financial Protection Information */}
                  <div className="mt-3 p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <h4 className="text-sm font-semibold text-blue-900 mb-2">Financial Protection</h4>
                    {agent.hasFinancialProtection ? (
                      <div className="space-y-2">
                        <div className="flex items-center text-sm text-green-700">
                          <Check className="w-4 h-4 mr-2" />
                          Protected by: {agent.protectionBodies?.join(", ") || "None specified"}
                        </div>
                        {agent.licenseNumbers && Object.keys(agent.licenseNumbers).length > 0 && (
                          <div className="text-xs text-gray-600">
                            <strong>License Numbers:</strong>
                            <div className="ml-2 mt-1">
                              {Object.entries(agent.licenseNumbers).map(([body, license]) => (
                                <div key={body} className="flex justify-between">
                                  <span>{body}:</span>
                                  <span className="font-mono">{license}</span>
                                </div>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    ) : (
                      <div className="flex items-center text-sm text-red-700">
                        <X className="w-4 h-4 mr-2" />
                        No financial protection declared
                      </div>
                    )}
                  </div>

                  {agent.specializations && agent.specializations.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {agent.specializations.slice(0, 2).map((spec, index) => (
                        <Badge key={index} variant="outline" className="text-xs">
                          {spec}
                        </Badge>
                      ))}
                      {agent.specializations.length > 2 && (
                        <Badge variant="outline" className="text-xs">
                          +{agent.specializations.length - 2} more
                        </Badge>
                      )}
                    </div>
                  )}
                </div>

                {/* Action Buttons */}
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setEditingAgent(agent);
                        setShowEditDialog(true);
                      }}
                    >
                      <Edit className="w-4 h-4 mr-1" />
                      Edit
                    </Button>
                    
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        setEditingAgent(agent);
                        setShowImageDialog(true);
                      }}
                    >
                      <Camera className="w-4 h-4 mr-1" />
                      Images
                    </Button>
                    
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => window.open(`/agent/${agent.id}`, '_blank')}
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View
                    </Button>
                  </div>

                  {agent.approvalStatus === "pending" && (
                    <div className="flex gap-2 mt-2">
                      <Button
                        size="sm"
                        onClick={() => approveAgent.mutate(agent.id)}
                        disabled={approveAgent.isPending}
                        className="bg-green-600 hover:bg-green-700 text-white flex-1"
                      >
                        <Check className="w-4 h-4 mr-1" />
                        Approve
                      </Button>
                      <Button
                        size="sm"
                        variant="destructive"
                        onClick={() => rejectAgent.mutate(agent.id)}
                        disabled={rejectAgent.isPending}
                        className="flex-1"
                      >
                        <X className="w-4 h-4 mr-1" />
                        Reject
                      </Button>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Image Management Dialog */}
        {showImageDialog && editingAgent && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-semibold">Manage {editingAgent.name}'s Images</h2>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setShowImageDialog(false);
                      setEditingAgent(null);
                    }}
                  >
                    ×
                  </Button>
                </div>
                
                {/* Profile Image Section */}
                <div className="mb-8">
                  <h3 className="text-lg font-semibold mb-4">Profile Image</h3>
                  <div className="flex items-center space-x-4">
                    <img
                      src={editingAgent.profileImage || "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face"}
                      alt="Current profile"
                      className="w-24 h-24 rounded-full object-cover border-2 border-gray-200"
                    />
                    <div>
                      <Label htmlFor={`profile-upload-${editingAgent.id}`} className="cursor-pointer">
                        <Button
                          variant="outline"
                          className="w-full"
                          disabled={uploadingImage}
                          asChild
                        >
                          <span>
                            <Upload className="w-4 h-4 mr-2" />
                            {uploadingImage ? "Uploading..." : "Change Profile Image"}
                          </span>
                        </Button>
                      </Label>
                      <Input
                        id={`profile-upload-${editingAgent.id}`}
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => handleProfileImageUpload(editingAgent.id, e)}
                      />
                    </div>
                  </div>
                </div>

                {/* Travel Photos Section */}
                <div>
                  <h3 className="text-lg font-semibold mb-4">Travel Photos</h3>
                  
                  {/* Add New Photo */}
                  <div className="mb-6">
                    <Label htmlFor={`travel-upload-${editingAgent.id}`} className="cursor-pointer">
                      <Button
                        variant="outline"
                        className="w-full border-dashed border-2 h-32"
                        disabled={uploadTravelPhoto.isPending}
                        asChild
                      >
                        <div className="flex flex-col items-center justify-center">
                          <Camera className="w-8 h-8 mb-2 text-gray-400" />
                          <span className="text-sm text-gray-600">
                            {uploadTravelPhoto.isPending ? "Uploading..." : "Add Travel Photo"}
                          </span>
                        </div>
                      </Button>
                    </Label>
                    <Input
                      id={`travel-upload-${editingAgent.id}`}
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={(e) => handleTravelPhotoUpload(editingAgent.id, e)}
                    />
                  </div>

                  {/* Existing Photos Grid */}
                  {editingAgent.photos && editingAgent.photos.length > 0 && (
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      {editingAgent.photos.map((photo, index) => (
                        <div key={index} className="relative group">
                          <img
                            src={photo}
                            alt={`Travel photo ${index + 1}`}
                            className="w-full h-32 object-cover rounded-lg border border-gray-200"
                          />
                          <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <Button
                              size="sm"
                              variant="destructive"
                              className="w-8 h-8 p-0"
                              onClick={() => deleteTravelPhoto.mutate({ agentId: editingAgent.id, photoUrl: photo })}
                              disabled={deleteTravelPhoto.isPending}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}

                  {(!editingAgent.photos || editingAgent.photos.length === 0) && (
                    <div className="text-center py-8 text-gray-500">
                      <ImageIcon className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                      <p>No travel photos yet</p>
                      <p className="text-sm">Upload photos to showcase travel experiences</p>
                    </div>
                  )}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Edit Agent Dialog */}
        {showEditDialog && editingAgent && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
            <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
              <div className="p-6">
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-2xl font-semibold">Edit Agent Profile</h2>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => {
                      setShowEditDialog(false);
                      setEditingAgent(null);
                    }}
                  >
                    ×
                  </Button>
                </div>
                
                <div className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label htmlFor="firstName">First Name</Label>
                      <Input
                        id="firstName"
                        value={editingAgent.firstName || ""}
                        onChange={(e) => setEditingAgent(prev => prev ? { ...prev, firstName: e.target.value } : null)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="lastName">Last Name</Label>
                      <Input
                        id="lastName"
                        value={editingAgent.lastName || ""}
                        onChange={(e) => setEditingAgent(prev => prev ? { ...prev, lastName: e.target.value } : null)}
                      />
                    </div>
                  </div>

                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={editingAgent.email}
                      onChange={(e) => setEditingAgent(prev => prev ? { ...prev, email: e.target.value } : null)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="location">Location</Label>
                    <Input
                      id="location"
                      value={editingAgent.location || ""}
                      onChange={(e) => setEditingAgent(prev => prev ? { ...prev, location: e.target.value } : null)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="bio">Bio</Label>
                    <Textarea
                      id="bio"
                      rows={4}
                      value={editingAgent.bio || ""}
                      onChange={(e) => setEditingAgent(prev => prev ? { ...prev, bio: e.target.value } : null)}
                    />
                  </div>

                  <div>
                    <Label htmlFor="yearsExperience">Years of Experience</Label>
                    <Input
                      id="yearsExperience"
                      type="number"
                      min="0"
                      value={editingAgent.yearsExperience}
                      onChange={(e) => setEditingAgent(prev => prev ? { ...prev, yearsExperience: parseInt(e.target.value) || 0 } : null)}
                    />
                  </div>
                </div>
                
                <div className="flex justify-end space-x-3 mt-8 pt-6 border-t">
                  <Button
                    variant="outline"
                    onClick={() => {
                      setShowEditDialog(false);
                      setEditingAgent(null);
                    }}
                  >
                    Cancel
                  </Button>
                  <Button
                    onClick={() => {
                      if (editingAgent) {
                        updateAgentProfile.mutate({
                          id: editingAgent.id,
                          updates: {
                            firstName: editingAgent.firstName,
                            lastName: editingAgent.lastName,
                            email: editingAgent.email,
                            location: editingAgent.location,
                            bio: editingAgent.bio,
                            yearsExperience: editingAgent.yearsExperience,
                            name: `${editingAgent.firstName} ${editingAgent.lastName}`.trim()
                          }
                        });
                      }
                    }}
                    disabled={updateAgentProfile.isPending}
                    className="bg-roamah-orange hover:bg-roamah-orange/90"
                  >
                    {updateAgentProfile.isPending ? "Updating..." : "Update Agent"}
                  </Button>
                </div>
              </div>
            </div>
          </div>
        )}

        {filteredAgents.length === 0 && !isLoading && (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No agents found matching your criteria.</p>
          </div>
        )}
      </div>
    </div>
  );
}