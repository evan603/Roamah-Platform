import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";
import { HeroSection } from "@/components/sections/hero-section";
import { TrendingDestinations } from "@/components/sections/trending-destinations";
import { FeaturedAgents } from "@/components/sections/featured-agents";
import { HolidayOffers } from "@/components/sections/holiday-offers";
import { Testimonials } from "@/components/sections/testimonials";
import { BlogSection } from "@/components/sections/blog-section";
import { Newsletter } from "@/components/sections/newsletter";

export default function Home() {
  return (
    <div className="min-h-screen bg-roamah-peach">
      <Navbar />
      <main>
        <HeroSection />
        <TrendingDestinations />
        <FeaturedAgents />
        <HolidayOffers />
        <Testimonials />
        <BlogSection />
        <Newsletter />
      </main>
      <Footer />
    </div>
  );
}
