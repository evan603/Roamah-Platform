import { Navbar } from "@/components/layout/navbar";
import { Footer } from "@/components/layout/footer";

export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-roamah-cream to-white">
      <Navbar />
      
      <div className="max-w-4xl mx-auto px-6 py-16">
        <div className="bg-white rounded-lg shadow-lg p-8">
          <h1 className="text-3xl font-bold text-roamah-dark mb-8">Privacy Policy</h1>
          <p className="text-sm text-roamah-gray mb-8">Last updated: July 24, 2025</p>
          
          <div className="space-y-6 text-roamah-dark">
            <section>
              <h2 className="text-xl font-semibold mb-3">1. Introduction</h2>
              <p className="mb-3">
                Roamah ("we," "our," or "us") is committed to protecting your privacy. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you use our travel platform and services.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">2. Information We Collect</h2>
              
              <h3 className="text-lg font-medium mb-2 mt-4">Personal Information</h3>
              <p className="mb-3">When you submit enquiries through Roamah, we collect:</p>
              <ul className="list-disc pl-6 mb-3 space-y-1">
                <li><strong>Contact Details:</strong> Full name, email address, telephone number</li>
                <li><strong>Travel Information:</strong> Number of adults and children, ages of children, budget preferences</li>
                <li><strong>Preferences:</strong> Destination interests, holiday types, callback preferences</li>
                <li><strong>Communication:</strong> Enquiry details and specific travel requirements</li>
              </ul>

              <h3 className="text-lg font-medium mb-2 mt-4">Technical Information</h3>
              <ul className="list-disc pl-6 mb-3 space-y-1">
                <li>IP address and browser information</li>
                <li>Device type and operating system</li>
                <li>Website usage patterns and preferences</li>
                <li>Cookies and similar tracking technologies</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">3. How We Use Your Information</h2>
              <p className="mb-3">We use your information to:</p>
              <ul className="list-disc pl-6 mb-3 space-y-1">
                <li><strong>Connect You with Travel Agents:</strong> Share your enquiry details with selected travel professionals</li>
                <li><strong>Facilitate Communication:</strong> Enable travel agents to contact you directly</li>
                <li><strong>Improve Our Services:</strong> Analyze usage patterns to enhance user experience</li>
                <li><strong>Customer Support:</strong> Respond to your questions and resolve issues</li>
                <li><strong>Legal Compliance:</strong> Meet regulatory requirements and protect our rights</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">4. Information Sharing</h2>
              
              <h3 className="text-lg font-medium mb-2 mt-4">With Travel Agents</h3>
              <p className="mb-3">
                When you submit an enquiry, we share your personal information with the selected travel agent to enable them to provide personalised service. This includes all information from your enquiry form.
              </p>

              <h3 className="text-lg font-medium mb-2 mt-4">Third Party Services</h3>
              <p className="mb-3">We may share information with:</p>
              <ul className="list-disc pl-6 mb-3 space-y-1">
                <li>Email service providers for communication delivery</li>
                <li>Analytics services to understand website usage</li>
                <li>Cloud storage providers for data security</li>
                <li>Legal authorities when required by law</li>
              </ul>

              <h3 className="text-lg font-medium mb-2 mt-4">We Do Not Sell Your Data</h3>
              <p className="mb-3">
                We never sell, rent, or trade your personal information to third parties for marketing purposes.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">5. Data Security</h2>
              <p className="mb-3">We implement appropriate security measures to protect your information:</p>
              <ul className="list-disc pl-6 mb-3 space-y-1">
                <li>SSL encryption for data transmission</li>
                <li>Secure database storage with access controls</li>
                <li>Regular security assessments and updates</li>
                <li>Staff training on data protection practices</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">6. Data Retention</h2>
              <p className="mb-3">
                We retain your personal information for as long as necessary to provide our services and fulfill the purposes outlined in this policy. Enquiry data is typically retained for:
              </p>
              <ul className="list-disc pl-6 mb-3 space-y-1">
                <li><strong>Active Enquiries:</strong> Until resolved or 12 months, whichever is longer</li>
                <li><strong>Communication Records:</strong> Up to 7 years for business and legal requirements</li>
                <li><strong>Analytics Data:</strong> Anonymized data may be retained for service improvement</li>
              </ul>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">7. Your Rights</h2>
              <p className="mb-3">Under applicable data protection laws, you have the right to:</p>
              <ul className="list-disc pl-6 mb-3 space-y-1">
                <li><strong>Access:</strong> Request copies of your personal data</li>
                <li><strong>Rectification:</strong> Correct inaccurate or incomplete information</li>
                <li><strong>Erasure:</strong> Request deletion of your personal data</li>
                <li><strong>Restriction:</strong> Limit how we process your information</li>
                <li><strong>Portability:</strong> Receive your data in a portable format</li>
                <li><strong>Objection:</strong> Object to certain types of processing</li>
              </ul>
              <p className="mb-3">
                To exercise these rights, please contact us at privacy@roamah.com.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">8. Cookies and Tracking</h2>
              <p className="mb-3">
                We use cookies and similar technologies to enhance your experience:
              </p>
              <ul className="list-disc pl-6 mb-3 space-y-1">
                <li><strong>Essential Cookies:</strong> Required for website functionality</li>
                <li><strong>Analytics Cookies:</strong> Help us understand website usage</li>
                <li><strong>Preference Cookies:</strong> Remember your settings and choices</li>
              </ul>
              <p className="mb-3">
                You can control cookies through your browser settings, though some features may not work properly if disabled.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">9. Children's Privacy</h2>
              <p className="mb-3">
                Our services are not directed to children under 16. We do not knowingly collect personal information from children under 16. If you believe we have collected information from a child under 16, please contact us immediately.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">10. International Transfers</h2>
              <p className="mb-3">
                Your information may be transferred to and processed in countries outside your residence. We ensure appropriate safeguards are in place to protect your data during international transfers.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">11. Changes to This Policy</h2>
              <p className="mb-3">
                We may update this Privacy Policy periodically. We will notify you of significant changes by posting the new policy on our website and updating the "Last updated" date.
              </p>
            </section>

            <section>
              <h2 className="text-xl font-semibold mb-3">12. Contact Information</h2>
              <p className="mb-3">
                If you have questions about this Privacy Policy or our data practices, please contact us:
              </p>
              <div className="bg-roamah-cream p-4 rounded-lg">
                <p><strong>Data Protection Officer</strong></p>
                <p>Email: privacy@roamah.com</p>
                <p>Address: Roamah Travel Platform, London, United Kingdom</p>
                <p>Phone: +44 (0) 20 7946 0958</p>
              </div>
            </section>
          </div>
        </div>
      </div>
      
      <Footer />
    </div>
  );
}