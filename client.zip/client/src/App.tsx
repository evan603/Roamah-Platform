import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "./contexts/AuthContext";
import { CookieBanner } from "@/components/ui/cookie-banner";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import BrowseAgents from "@/pages/browse-agents";
import BrowseDestinations from "@/pages/browse-destinations";
import BrowseHolidayTypes from "@/pages/browse-holiday-types";
import BrowseOffers from "@/pages/browse-offers";
import HowItWorks from "@/pages/how-it-works";
import AgentProfile from "@/pages/agent-profile";
import EditProfileLive from "@/pages/edit-profile-live";
import AgentRegister from "@/pages/agent-register";
import AgentOnboarding from "@/pages/agent-onboarding";
import AgentLogin from "@/pages/agent-login";
import AgentDashboard from "@/pages/agent-dashboard";
import TestWorkflow from "@/pages/test-workflow";
import Destination from "@/pages/destination";
import BlogDetail from "@/pages/blog-detail";
import Blogs from "@/pages/blogs";
import { AdminEnquiries } from "@/pages/admin-enquiries";
import AdminLogin from "@/pages/admin-login";
import AdminImages from "@/pages/admin-images";
import AdminAgents from "@/pages/admin-agents";
import AdminEmails from "@/pages/admin-emails";
import AdminDashboard from "@/pages/admin-dashboard";
import EmailAutomation from "@/pages/email-automation";
import TermsOfUse from "@/pages/terms-of-use";
import PrivacyPolicy from "@/pages/privacy-policy";
import OfferDetails from "@/pages/offer-details";
import About from "@/pages/about";
import Contact from "@/pages/contact";
import MarketingTools from "@/pages/marketing-tools";
import Cookies from "@/pages/cookies";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/browse-agents" component={BrowseAgents} />
      <Route path="/browse-destinations" component={BrowseDestinations} />
      <Route path="/browse-holiday-types" component={BrowseHolidayTypes} />
      <Route path="/browse-offers" component={BrowseOffers} />
      <Route path="/offer/:id" component={OfferDetails} />
      <Route path="/how-it-works" component={HowItWorks} />
      <Route path="/holiday-type/:slug" component={BrowseAgents} />
      <Route path="/agent/:id" component={AgentProfile} />
      <Route path="/agent-register" component={AgentOnboarding} />
      <Route path="/agent-register-old" component={AgentRegister} />
      <Route path="/agent-login" component={AgentLogin} />
      <Route path="/agent-dashboard" component={AgentDashboard} />
      <Route path="/edit-profile-live" component={EditProfileLive} />
      <Route path="/test-workflow" component={TestWorkflow} />
      <Route path="/destination/:slug" component={Destination} />
      <Route path="/blog/:slug" component={BlogDetail} />
      <Route path="/blog" component={Blogs} />
      <Route path="/blogs" component={Blogs} />
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route path="/admin/enquiries" component={AdminEnquiries} />
      <Route path="/admin/agents" component={AdminAgents} />
      <Route path="/admin/images" component={AdminImages} />
      <Route path="/admin/emails" component={AdminEmails} />
      <Route path="/admin/email-automation" component={EmailAutomation} />
      <Route path="/terms-of-use" component={TermsOfUse} />
      <Route path="/privacy-policy" component={PrivacyPolicy} />
      <Route path="/about" component={About} />
      <Route path="/contact" component={Contact} />
      <Route path="/marketing-tools" component={MarketingTools} />
      <Route path="/cookies" component={Cookies} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Toaster />
          <Router />
          <CookieBanner />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
