import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { apiRequest } from "@/lib/queryClient";

interface AuthContextType {
  isAuthenticated: boolean;
  agentProfile: any | null;
  isLoading: boolean;
  login: (token: string) => void;
  logout: () => void;
  checkAuth: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [agentProfile, setAgentProfile] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  const checkAuth = async () => {
    const token = localStorage.getItem('agentToken');
    if (!token) {
      setIsLoading(false);
      return;
    }

    try {
      const profile = await apiRequest('/api/agents/profile', {
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      
      setIsAuthenticated(true);
      setAgentProfile(profile);
    } catch (error) {
      // Token is invalid or expired
      localStorage.removeItem('agentToken');
      setIsAuthenticated(false);
      setAgentProfile(null);
    } finally {
      setIsLoading(false);
    }
  };

  const login = (token: string) => {
    localStorage.setItem('agentToken', token);
    setIsAuthenticated(true);
    checkAuth(); // Fetch profile after login
  };

  const logout = () => {
    localStorage.removeItem('agentToken');
    setIsAuthenticated(false);
    setAgentProfile(null);
  };

  useEffect(() => {
    checkAuth();
  }, []);

  return (
    <AuthContext.Provider value={{
      isAuthenticated,
      agentProfile,
      isLoading,
      login,
      logout,
      checkAuth
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}