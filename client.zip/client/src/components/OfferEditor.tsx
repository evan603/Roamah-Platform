import { useState, useEffect, useRef } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Calendar, Upload, Eye, Save, X, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { insertOfferSchema, type InsertOffer, type Offer, type Destination, type HolidayType } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";
// import { MultipleSelector } from "@/components/ui/multiple-selector";
import { OfferPreviewModal } from "@/components/OfferPreviewModal";

interface OfferEditorProps {
  offer?: Offer;
  isOpen: boolean;
  onClose: () => void;
}

export function OfferEditor({ offer, isOpen, onClose }: OfferEditorProps) {
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [previewUrls, setPreviewUrls] = useState<string[]>([]);
  const [selectedDestinations, setSelectedDestinations] = useState<string[]>([]);
  const [selectedHolidayTypes, setSelectedHolidayTypes] = useState<string[]>([]);
  const [showPreview, setShowPreview] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm<InsertOffer>({
    resolver: zodResolver(insertOfferSchema),
    defaultValues: {
      title: "",
      description: "",
      briefDescription: "",
      fromPrice: "",
      destinations: [],
      holidayTypes: [],
      offerMessage1: "",
      offerMessage2: "",
      offerMessage3: "",
      status: "published",
    },
  });

  const { data: destinations = [] } = useQuery<Destination[]>({
    queryKey: ["/api/destinations"],
  });

  const { data: holidayTypes = [] } = useQuery<HolidayType[]>({
    queryKey: ["/api/holiday-types"],
  });

  // Create offer mutation
  const createOfferMutation = useMutation({
    mutationFn: async (data: InsertOffer) => {
      const formData = new FormData();
      
      // Append all form fields to FormData
      Object.entries(data).forEach(([key, value]) => {
        if (Array.isArray(value)) {
          formData.append(key, JSON.stringify(value));
        } else if (value instanceof Date) {
          formData.append(key, value.toISOString());
        } else if (value !== undefined && value !== null) {
          formData.append(key, value.toString());
        }
      });
      
      // Append image files if selected (up to 3)
      selectedFiles.forEach((file, index) => {
        if (index === 0) {
          formData.append('heroImage', file);
        }
        formData.append(`image${index + 1}`, file);
      });
      
      const token = localStorage.getItem('agentToken');
      const response = await fetch("/api/agents/offers", {
        method: "POST",
        body: formData,
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Offer created successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/agents"] });
      queryClient.invalidateQueries({ queryKey: ["/api/agents/offers"] });
      onClose();
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error?.message || "Failed to create offer",
        variant: "destructive",
      });
    },
  });

  // Update offer mutation
  const updateOfferMutation = useMutation({
    mutationFn: async (data: InsertOffer) => {
      const formData = new FormData();
      
      Object.entries(data).forEach(([key, value]) => {
        if (Array.isArray(value)) {
          formData.append(key, JSON.stringify(value));
        } else if (value instanceof Date) {
          formData.append(key, value.toISOString());
        } else if (value !== undefined && value !== null) {
          formData.append(key, value.toString());
        }
      });
      
      // Append image files if selected (up to 3)
      selectedFiles.forEach((file, index) => {
        if (index === 0) {
          formData.append('heroImage', file);
        }
        formData.append(`image${index + 1}`, file);
      });
      
      const token = localStorage.getItem('agentToken');
      const response = await fetch(`/api/agents/offers/${offer!.id}`, {
        method: "PUT",
        body: formData,
        headers: {
          'Authorization': `Bearer ${token}`,
        },
      });
      
      if (!response.ok) {
        throw new Error(`HTTP error! status: ${response.status}`);
      }
      
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Offer updated successfully",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/agents"] });
      queryClient.invalidateQueries({ queryKey: ["/api/agents/offers"] });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error?.message || "Failed to update offer",
        variant: "destructive",
      });
    },
  });

  // Set form values when offer prop changes
  useEffect(() => {
    if (offer) {
      form.reset({
        title: offer.title,
        description: offer.description,
        briefDescription: offer.briefDescription,
        fromPrice: offer.fromPrice,
        destinations: offer.destinations,
        holidayTypes: offer.holidayTypes,
        offerMessage1: offer.offerMessage1 || "",
        offerMessage2: offer.offerMessage2 || "",
        offerMessage3: offer.offerMessage3 || "",
        bookFromDate: offer.bookFromDate || undefined,
        bookToDate: offer.bookToDate || undefined,
        travelFromDate: offer.travelFromDate || undefined,
        travelToDate: offer.travelToDate || undefined,
        status: "published",
      });
      
      setSelectedDestinations(offer.destinations);
      setSelectedHolidayTypes(offer.holidayTypes);
      
      // Set preview URLs from existing images array or hero image
      if (offer.images && offer.images.length > 0) {
        setPreviewUrls(offer.images);
      } else if (offer.heroImage) {
        setPreviewUrls([offer.heroImage]);
      }
    } else {
      form.reset({
        title: "",
        description: "",
        briefDescription: "",
        fromPrice: "",
        destinations: [],
        holidayTypes: [],
        offerMessage1: "",
        offerMessage2: "",
        offerMessage3: "",
        status: "published",
      });
      setSelectedDestinations([]);
      setSelectedHolidayTypes([]);
      setPreviewUrls([]);
      setSelectedFiles([]);
    }
  }, [offer, form]);

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    if (files.length > 0) {
      // Limit to 3 images
      const newFiles = [...selectedFiles, ...files].slice(0, 3);
      setSelectedFiles(newFiles);
      
      const newUrls = newFiles.map(file => URL.createObjectURL(file));
      setPreviewUrls(newUrls);
    }
  };

  const removeImage = (index: number) => {
    const newFiles = selectedFiles.filter((_, i) => i !== index);
    const newUrls = previewUrls.filter((_, i) => i !== index);
    setSelectedFiles(newFiles);
    setPreviewUrls(newUrls);
  };

  const triggerFileInput = () => {
    fileInputRef.current?.click();
  };

  const onSubmit = async (data: InsertOffer) => {
    // Helper function to convert date to string
    const formatDateForSubmission = (date: any): string | null => {
      if (!date) return null;
      if (typeof date === 'string') return date;
      if (date instanceof Date) return date.toISOString().split('T')[0];
      return null;
    };

    const submitData = {
      ...data,
      destinations: selectedDestinations,
      holidayTypes: selectedHolidayTypes,
      // Convert dates to strings to match schema expectations
      bookFromDate: formatDateForSubmission(data.bookFromDate),
      bookToDate: formatDateForSubmission(data.bookToDate),
      travelFromDate: formatDateForSubmission(data.travelFromDate),
      travelToDate: formatDateForSubmission(data.travelToDate),
    };

    if (offer) {
      updateOfferMutation.mutate(submitData);
    } else {
      createOfferMutation.mutate(submitData);
    }
  };

  const handleDestinationChange = (values: string[]) => {
    setSelectedDestinations(values);
    form.setValue("destinations", values);
  };

  const handleHolidayTypeChange = (values: string[]) => {
    setSelectedHolidayTypes(values);
    form.setValue("holidayTypes", values);
  };

  const handlePreview = () => {
    const formData = form.getValues();
    const previewData = {
      ...formData,
      destinations: selectedDestinations,
      holidayTypes: selectedHolidayTypes,
      heroImage: previewUrls[0] || null,
      id: offer?.id || 0,
      agentId: offer?.agentId || 0,
      createdAt: new Date(),
      updatedAt: new Date(),
    };
    setShowPreview(true);
  };

  const formatDateForInput = (date: Date | string | null | undefined): string => {
    if (!date) return "";
    if (typeof date === 'string') return date;
    const d = new Date(date);
    return d.toISOString().split('T')[0];
  };

  const parseInputDate = (dateString: string): Date | undefined => {
    if (!dateString) return undefined;
    return new Date(dateString);
  };

  return (
    <>
      <Dialog open={isOpen} onOpenChange={onClose}>
        <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>
              {offer ? "Edit Offer" : "Create New Offer"}
            </DialogTitle>
          </DialogHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              
              {/* Basic Information */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Offer Title</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., Luxury Maldives Getaway" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="fromPrice"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>From Price</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g., £2,500 per person" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <FormField
                control={form.control}
                name="briefDescription"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Brief Description (200 chars max)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="A short description for offer cards..."
                        maxLength={200}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Full Description</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Detailed description of your offer..."
                        rows={6}
                        {...field}
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Hero Image Upload */}
              <div className="space-y-4">
                <Label>Offer Images (Up to 3)</Label>
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                  <Input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    multiple
                    onChange={handleFileSelect}
                    className="hidden"
                    disabled={selectedFiles.length >= 3}
                  />
                  <Button 
                    type="button" 
                    size="sm" 
                    variant="outline" 
                    onClick={triggerFileInput}
                    disabled={selectedFiles.length >= 3}
                    className="w-full sm:w-auto whitespace-nowrap"
                  >
                    <Upload className="w-4 h-4 mr-2" />
                    {selectedFiles.length >= 3 ? "Max 3 Images" : "Upload Images"}
                  </Button>
                </div>
                {previewUrls.length > 0 && (
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    {previewUrls.map((url, index) => (
                      <div key={index} className="relative w-full h-48 rounded-lg overflow-hidden border">
                        <img 
                          src={url} 
                          alt={`Preview ${index + 1}`} 
                          className="w-full h-full object-cover"
                        />
                        <button
                          type="button"
                          onClick={() => removeImage(index)}
                          className="absolute top-2 right-2 bg-red-500 text-white rounded-full w-6 h-6 flex items-center justify-center hover:bg-red-600"
                        >
                          ×
                        </button>
                      </div>
                    ))}
                  </div>
                )}
                <p className="text-sm text-gray-500">
                  Upload up to 3 images. First image will be used as hero image.
                </p>
              </div>

              {/* Destinations and Holiday Types */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Destinations</Label>
                  <div className="max-h-60 overflow-y-auto border rounded-md p-3 space-y-2">
                    {destinations
                      .sort((a, b) => a.name.localeCompare(b.name))
                      .map(dest => (
                        <div key={dest.id} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id={`dest-${dest.id}`}
                          checked={selectedDestinations.includes(dest.name)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              handleDestinationChange([...selectedDestinations, dest.name]);
                            } else {
                              handleDestinationChange(selectedDestinations.filter(d => d !== dest.name));
                            }
                          }}
                          className="rounded border-gray-300"
                        />
                        <Label htmlFor={`dest-${dest.id}`} className="text-sm">
                          {dest.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Holiday Types</Label>
                  <div className="max-h-60 overflow-y-auto border rounded-md p-3 space-y-2">
                    {holidayTypes
                      .sort((a, b) => a.name.localeCompare(b.name))
                      .map(type => (
                        <div key={type.id} className="flex items-center space-x-2">
                        <input
                          type="checkbox"
                          id={`type-${type.id}`}
                          checked={selectedHolidayTypes.includes(type.name)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              handleHolidayTypeChange([...selectedHolidayTypes, type.name]);
                            } else {
                              handleHolidayTypeChange(selectedHolidayTypes.filter(t => t !== type.name));
                            }
                          }}
                          className="rounded border-gray-300"
                        />
                        <Label htmlFor={`type-${type.id}`} className="text-sm">
                          {type.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Offer Messages */}
              <div className="space-y-4">
                <Label>Offer Messages (Optional - displayed as bullet points)</Label>
                <div className="grid grid-cols-1 gap-3">
                  <FormField
                    control={form.control}
                    name="offerMessage1"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input placeholder="e.g., 25% discount" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="offerMessage2"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input placeholder="e.g., Free seaplane transfers" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="offerMessage3"
                    render={({ field }) => (
                      <FormItem>
                        <FormControl>
                          <Input placeholder="e.g., Half board included" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </div>

              {/* Date Ranges */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <Label className="text-base font-semibold">Booking Period</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <FormField
                      control={form.control}
                      name="bookFromDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Book From</FormLabel>
                          <FormControl>
                            <Input
                              type="date"
                              value={formatDateForInput(field.value)}
                              onChange={(e) => field.onChange(parseInputDate(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="bookToDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Book To</FormLabel>
                          <FormControl>
                            <Input
                              type="date"
                              value={formatDateForInput(field.value)}
                              onChange={(e) => field.onChange(parseInputDate(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                <div className="space-y-4">
                  <Label className="text-base font-semibold">Travel Period</Label>
                  <div className="grid grid-cols-2 gap-3">
                    <FormField
                      control={form.control}
                      name="travelFromDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Travel From</FormLabel>
                          <FormControl>
                            <Input
                              type="date"
                              value={formatDateForInput(field.value)}
                              onChange={(e) => field.onChange(parseInputDate(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="travelToDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Travel To</FormLabel>
                          <FormControl>
                            <Input
                              type="date"
                              value={formatDateForInput(field.value)}
                              onChange={(e) => field.onChange(parseInputDate(e.target.value))}
                            />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
              </div>

              {/* Status - Hidden field set to published by default */}
              <FormField
                control={form.control}
                name="status"
                render={({ field }) => (
                  <FormItem className="hidden">
                    <FormControl>
                      <input type="hidden" {...field} value="published" />
                    </FormControl>
                  </FormItem>
                )}
              />

              <DialogFooter className="gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={handlePreview}
                  className="flex items-center gap-2"
                >
                  <Eye className="w-4 h-4" />
                  Preview
                </Button>
                <Button type="button" variant="outline" onClick={onClose}>
                  <X className="w-4 h-4 mr-2" />
                  Cancel
                </Button>
                <Button 
                  type="submit" 
                  disabled={createOfferMutation.isPending || updateOfferMutation.isPending}
                  className="bg-roamah-orange hover:bg-roamah-orange/90"
                >
                  {createOfferMutation.isPending || updateOfferMutation.isPending ? (
                    <>
                      <Upload className="w-4 h-4 mr-2 animate-spin" />
                      {offer ? "Publishing..." : "Publishing..."}
                    </>
                  ) : (
                    <>
                      <Save className="w-4 h-4 mr-2" />
                      {offer ? "Publish Changes" : "Publish Offer"}
                    </>
                  )}
                </Button>
              </DialogFooter>
            </form>
          </Form>
        </DialogContent>
      </Dialog>

      {/* Preview Modal */}
      {showPreview && (
        <OfferPreviewModal
          offer={{
            ...form.getValues(),
            destinations: selectedDestinations,
            holidayTypes: selectedHolidayTypes,
            heroImage: previewUrls[0] || null,
            images: previewUrls.length > 0 ? previewUrls : null,
            id: offer?.id || 0,
            agentId: offer?.agentId || 0,
            createdAt: new Date(),
            updatedAt: new Date(),
            // Convert any string dates back to Date objects for preview
            bookFromDate: (() => {
              const val = form.getValues().bookFromDate;
              if (!val) return null;
              if (val instanceof Date) return val;
              return new Date(val as string);
            })(),
            bookToDate: (() => {
              const val = form.getValues().bookToDate;
              if (!val) return null;
              if (val instanceof Date) return val;
              return new Date(val as string);
            })(),
            travelFromDate: (() => {
              const val = form.getValues().travelFromDate;
              if (!val) return null;
              if (val instanceof Date) return val;
              return new Date(val as string);
            })(),
            travelToDate: (() => {
              const val = form.getValues().travelToDate;
              if (!val) return null;
              if (val instanceof Date) return val;
              return new Date(val as string);
            })(),
            validUntil: (() => {
              const val = form.getValues().validUntil;
              if (!val) return null;
              if (val instanceof Date) return val;
              return new Date(val as string);
            })(),
            agentName: "Your Name",
            agentImage: "/placeholder-avatar.jpg",
            agentLocation: "Your Location",
            agentRating: 5,
          }}
          isOpen={showPreview}
          onClose={() => setShowPreview(false)}
        />
      )}
    </>
  );
}