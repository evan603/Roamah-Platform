import { Link } from "wouter";
import { Facebook, Twitter, Instagram, Linkedin } from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";

export function Footer() {
  const { isAuthenticated } = useAuth();
  
  return (
    <footer className="text-white py-16 bg-[#ffffff]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <h4 className="text-2xl font-bold text-roamah-orange mb-4">Roamah</h4>
            <p className="text-gray-400 mb-6">
              Connecting travellers with travel experts for unforgettable holiday experiences worldwide.
            </p>
            <div className="flex space-x-4">
              <Link href="#">
                <Facebook className="h-5 w-5 text-gray-400 hover:text-white transition-colors cursor-pointer" />
              </Link>
              <Link href="#">
                <Twitter className="h-5 w-5 text-gray-400 hover:text-white transition-colors cursor-pointer" />
              </Link>
              <Link href="#">
                <Instagram className="h-5 w-5 text-gray-400 hover:text-white transition-colors cursor-pointer" />
              </Link>
              <Link href="#">
                <Linkedin className="h-5 w-5 text-gray-400 hover:text-white transition-colors cursor-pointer" />
              </Link>
            </div>
          </div>

          {/* For Travellers */}
          <div>
            <h5 className="font-semibold mb-4">For Travellers</h5>
            <ul className="space-y-2">
              <li>
                <Link href="/browse-agents">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                    Browse Travel Experts
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/browse-destinations">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                    Destinations
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/browse-holiday-types">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                    Holiday Types
                  </span>
                </Link>
              </li>
            </ul>
          </div>

          {/* For Travel Experts */}
          <div>
            <h5 className="font-semibold mb-4">For Travel Experts</h5>
            <ul className="space-y-2">
              <li>
                <Link href="/agent-register">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                    Join as Expert
                  </span>
                </Link>
              </li>
              {isAuthenticated && (
                <li>
                  <Link href="/agent-dashboard">
                    <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                      Expert Dashboard
                    </span>
                  </Link>
                </li>
              )}
              <li>
                <Link href="/marketing-tools">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                    Marketing Tools
                  </span>
                </Link>
              </li>
            </ul>
          </div>

          {/* Company */}
          <div>
            <h5 className="font-semibold mb-4">Company</h5>
            <ul className="space-y-2">
              <li>
                <Link href="/browse-offers">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                    Special Offers
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/about">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                    About Us
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/how-it-works">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                    How It Works
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/blogs">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                    Blog
                  </span>
                </Link>
              </li>
              <li>
                <Link href="/contact">
                  <span className="text-gray-400 hover:text-white transition-colors cursor-pointer">
                    Contact Us
                  </span>
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 mt-12 pt-8 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm">© 2024 Roamah. All rights reserved.</p>
          <div className="flex space-x-6 mt-4 md:mt-0">
            <Link href="/privacy-policy">
              <span className="text-gray-400 hover:text-white text-sm transition-colors cursor-pointer">
                Privacy Policy
              </span>
            </Link>
            <Link href="/terms-of-use">
              <span className="text-gray-400 hover:text-white text-sm transition-colors cursor-pointer">
                Terms of Service
              </span>
            </Link>
            <Link href="/cookies">
              <span className="text-gray-400 hover:text-white text-sm transition-colors cursor-pointer">
                Cookie Policy
              </span>
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
