import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Search, User, LogOut } from "lucide-react";
import { useEffect, useState } from "react";

export function Navbar() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    // Check if agent is logged in by checking for token
    const token = localStorage.getItem('agentToken');
    setIsLoggedIn(!!token);
  }, []);

  const handleLogout = () => {
    // Clear the auth token
    localStorage.removeItem('agentToken');
    setIsLoggedIn(false);
    // Redirect to home page
    window.location.href = '/';
  };

  return (
    <nav className="bg-white shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <Link href="/">
              <h1 className="text-2xl font-bold text-roamah-orange cursor-pointer">
                Roamah
              </h1>
            </Link>
          </div>
          
          <div className="hidden md:flex items-center space-x-8">
            <Link href="/browse-agents">
              <span className="text-roamah-dark hover:text-roamah-orange transition-colors cursor-pointer">
                Browse all Travel Experts
              </span>
            </Link>
            <Link href="/browse-destinations">
              <span className="text-roamah-dark hover:text-roamah-orange transition-colors cursor-pointer">
                Destinations
              </span>
            </Link>
            <Link href="/browse-holiday-types">
              <span className="text-roamah-dark hover:text-roamah-orange transition-colors cursor-pointer">
                Holiday Types
              </span>
            </Link>
            <Link href="/browse-offers">
              <span className="text-roamah-dark hover:text-roamah-orange transition-colors cursor-pointer">
                Offers
              </span>
            </Link>
            <Link href="/how-it-works">
              <span className="text-roamah-dark hover:text-roamah-orange transition-colors cursor-pointer">
                How It Works
              </span>
            </Link>
            <Link href="/blog">
              <span className="text-roamah-dark hover:text-roamah-orange transition-colors cursor-pointer">
                Blog
              </span>
            </Link>
          </div>

          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm">
              <Search className="h-4 w-4" />
            </Button>
            {!isLoggedIn ? (
              <>
                <Link href="/agent-register">
                  <Button variant="outline" size="sm">
                    Register as an Expert
                  </Button>
                </Link>
                <Link href="/agent-login">
                  <Button size="sm" className="bg-roamah-orange hover:bg-roamah-orange/90">
                    Log In
                  </Button>
                </Link>
              </>
            ) : (
              <div className="flex items-center space-x-2">
                <Link href="/agent-dashboard">
                  <Button size="sm" className="bg-roamah-orange hover:bg-roamah-orange/90">
                    <User className="h-4 w-4 mr-2" />
                    My Profile
                  </Button>
                </Link>
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={handleLogout}
                  className="border-roamah-orange text-roamah-orange hover:bg-roamah-orange hover:text-white"
                >
                  <LogOut className="h-4 w-4 mr-2" />
                  Log Out
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
}
