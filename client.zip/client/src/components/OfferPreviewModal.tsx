import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { X, MapPin, Calendar, Star, Eye } from "lucide-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import type { Offer } from "@shared/schema";

interface OfferPreviewModalProps {
  offer: Partial<Offer> & {
    agentName?: string;
    agentImage?: string;
    agentLocation?: string;
    agentRating?: number;
  };
  isOpen: boolean;
  onClose: () => void;
}

export function OfferPreviewModal({ offer, isOpen, onClose }: OfferPreviewModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Eye className="w-5 h-5 text-roamah-orange" />
            Offer Preview
          </DialogTitle>
          <Button
            variant="ghost"
            size="sm"
            className="absolute top-2 right-2"
            onClick={onClose}
          >
            <X className="w-4 h-4" />
          </Button>
        </DialogHeader>

        <Tabs defaultValue="card" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="card">Offer Card View</TabsTrigger>
            <TabsTrigger value="fullscreen">Full-Screen View</TabsTrigger>
          </TabsList>

          {/* Offer Card Preview */}
          <TabsContent value="card" className="mt-6">
            <div className="border rounded-lg p-4 bg-gray-50">
              <h3 className="text-lg font-medium mb-4 text-center">How this offer will appear on your profile and offers page:</h3>
              
              <div className="bg-white rounded-lg shadow-md overflow-hidden max-w-sm mx-auto">
                {offer.heroImage && (
                  <div className="aspect-square relative">
                    <img
                      src={offer.heroImage}
                      alt={offer.title}
                      className="w-full h-full object-cover"
                    />
                    {offer.offerMessage1 && (
                      <div className="absolute top-3 left-3">
                        <Badge className="bg-green-600 text-white px-2 py-1 text-xs font-semibold">
                          {offer.offerMessage1}
                        </Badge>
                      </div>
                    )}
                  </div>
                )}
                
                <div className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <div className="flex-1">
                      <h3 className="font-bold text-lg text-gray-900 mb-1">{offer.title || "Offer Title"}</h3>
                      <p className="text-gray-600 text-sm line-clamp-2">{offer.briefDescription || "Brief description will appear here"}</p>
                    </div>
                  </div>

                  {/* Offer Messages as Bullet Points */}
                  {(offer.offerMessage1 || offer.offerMessage2 || offer.offerMessage3) && (
                    <div className="mb-3 space-y-1">
                      {offer.offerMessage1 && (
                        <div className="flex items-center text-sm text-green-700">
                          <span className="w-1.5 h-1.5 bg-green-600 rounded-full mr-2"></span>
                          {offer.offerMessage1}
                        </div>
                      )}
                      {offer.offerMessage2 && (
                        <div className="flex items-center text-sm text-green-700">
                          <span className="w-1.5 h-1.5 bg-green-600 rounded-full mr-2"></span>
                          {offer.offerMessage2}
                        </div>
                      )}
                      {offer.offerMessage3 && (
                        <div className="flex items-center text-sm text-green-700">
                          <span className="w-1.5 h-1.5 bg-green-600 rounded-full mr-2"></span>
                          {offer.offerMessage3}
                        </div>
                      )}
                    </div>
                  )}

                  {/* Destinations and Holiday Types */}
                  <div className="flex flex-wrap gap-1 mb-3">
                    {offer.destinations?.slice(0, 2).map((dest, index) => (
                      <Badge key={index} variant="outline" className="text-xs bg-blue-50 text-blue-700">
                        {dest}
                      </Badge>
                    ))}
                    {offer.destinations && offer.destinations.length > 2 && (
                      <Badge variant="outline" className="text-xs">
                        +{offer.destinations.length - 2} more
                      </Badge>
                    )}
                  </div>

                  {/* Agent info */}
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-2">
                      <img
                        src={offer.agentImage || "/api/placeholder/32/32"}
                        alt={offer.agentName || "Agent"}
                        className="w-8 h-8 rounded-full object-cover"
                      />
                      <div>
                        <p className="text-sm font-medium text-gray-900">{offer.agentName || "Agent Name"}</p>
                        <div className="flex items-center space-x-1">
                          <MapPin className="w-3 h-3 text-gray-400" />
                          <span className="text-xs text-gray-500">{offer.agentLocation || "Location"}</span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-roamah-orange">{offer.fromPrice || "£0"}</p>
                      <p className="text-xs text-gray-500">per person</p>
                    </div>
                  </div>

                  <Button className="w-full mt-3 bg-roamah-orange hover:bg-roamah-orange/90">
                    View Details
                  </Button>
                </div>
              </div>
            </div>
          </TabsContent>

          {/* Full-Screen Preview */}
          <TabsContent value="fullscreen" className="mt-6">
            <div className="border rounded-lg p-6 bg-white">
              <h3 className="text-lg font-medium mb-6 text-center">Full offer details page preview:</h3>
              
              <div className="max-w-4xl mx-auto">
                {/* Hero Section */}
                {offer.heroImage && (
                  <div className="relative h-64 mb-6 rounded-lg overflow-hidden">
                    <img
                      src={offer.heroImage}
                      alt={offer.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute bottom-4 right-4 bg-white rounded-lg px-4 py-2">
                      <p className="text-2xl font-bold text-roamah-orange">{offer.fromPrice || "£0"}</p>
                      <p className="text-sm text-gray-600">per person</p>
                    </div>
                  </div>
                )}

                {/* Offer Messages Below Image */}
                {(offer.offerMessage1 || offer.offerMessage2 || offer.offerMessage3) && (
                  <div className="mb-6 bg-green-50 rounded-lg p-4 border border-green-200">
                    <h4 className="font-semibold text-green-800 mb-3">What's Included:</h4>
                    <div className="space-y-2">
                      {offer.offerMessage1 && (
                        <div className="flex items-center text-green-700">
                          <span className="w-2 h-2 bg-green-600 rounded-full mr-3"></span>
                          <span className="text-sm font-medium">{offer.offerMessage1}</span>
                        </div>
                      )}
                      {offer.offerMessage2 && (
                        <div className="flex items-center text-green-700">
                          <span className="w-2 h-2 bg-green-600 rounded-full mr-3"></span>
                          <span className="text-sm font-medium">{offer.offerMessage2}</span>
                        </div>
                      )}
                      {offer.offerMessage3 && (
                        <div className="flex items-center text-green-700">
                          <span className="w-2 h-2 bg-green-600 rounded-full mr-3"></span>
                          <span className="text-sm font-medium">{offer.offerMessage3}</span>
                        </div>
                      )}
                    </div>
                  </div>
                )}

                {/* Title and Status */}
                <div className="mb-6">
                  <div className="flex items-center justify-between mb-4">
                    <div>
                      <h1 className="text-3xl font-bold text-gray-900 mb-2">{offer.title || "Offer Title"}</h1>
                      <p className="text-gray-600">{offer.briefDescription || "Brief description will appear here"}</p>
                    </div>
                    <Badge className={`px-3 py-1 ${
                      offer.status === 'published' 
                        ? 'bg-green-100 text-green-800 border border-green-200' 
                        : 'bg-gray-100 text-gray-600 border border-gray-200'
                    }`}>
                      {offer.status === 'published' ? 'Published' : 'Draft'}
                    </Badge>
                  </div>

                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {offer.destinations?.map((dest, index) => (
                      <Badge key={index} variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                        <MapPin className="w-3 h-3 mr-1" />
                        {dest}
                      </Badge>
                    ))}
                    {offer.holidayTypes?.map((type, index) => (
                      <Badge key={index} variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
                        <Calendar className="w-3 h-3 mr-1" />
                        {type}
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Description */}
                <div className="mb-8">
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">About This Offer</h2>
                  <div className="prose max-w-none">
                    <p className="text-gray-700 leading-relaxed whitespace-pre-wrap">
                      {offer.description || "Full description will appear here. This is where you can provide detailed information about your offer, including itinerary, inclusions, and other important details."}
                    </p>
                  </div>
                </div>

                {/* Agent Section */}
                <div className="border-t pt-6">
                  <h2 className="text-xl font-semibold text-gray-900 mb-4">Your Travel Expert</h2>
                  <div className="flex items-center space-x-4">
                    <img
                      src={offer.agentImage || "/api/placeholder/64/64"}
                      alt={offer.agentName || "Agent"}
                      className="w-16 h-16 rounded-full object-cover"
                    />
                    <div className="flex-1">
                      <h3 className="text-lg font-semibold text-gray-900">{offer.agentName || "Agent Name"}</h3>
                      <div className="flex items-center space-x-4 text-sm text-gray-600">
                        <div className="flex items-center space-x-1">
                          <MapPin className="w-4 h-4" />
                          <span>{offer.agentLocation || "Location"}</span>
                        </div>
                        {offer.agentRating && (
                          <div className="flex items-center space-x-1">
                            <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                            <span>{offer.agentRating}/5.0</span>
                          </div>
                        )}
                      </div>
                    </div>
                    <Button className="bg-roamah-orange hover:bg-roamah-orange/90">
                      Contact Agent
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}