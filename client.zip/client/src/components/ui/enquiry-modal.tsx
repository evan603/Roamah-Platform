import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import type { Agent } from "@shared/schema";
import { BUDGET_RANGES, CALLBACK_TIMES } from "@/lib/constants";
import { useQuery } from "@tanstack/react-query";
import { MultiSelect } from "@/components/ui/multi-select";
import { Link } from "wouter";
import { ExternalLink } from "lucide-react";

interface EnquiryModalProps {
  isOpen: boolean;
  onClose: () => void;
  agent: Agent | null;
}

export function EnquiryModal({ isOpen, onClose, agent }: EnquiryModalProps) {
  const { toast } = useToast();
  
  // Fetch holiday types and destinations from API
  const { data: holidayTypes } = useQuery<any[]>({
    queryKey: ["/api/holiday-types"],
  });

  const { data: destinations } = useQuery<any[]>({
    queryKey: ["/api/destinations"],
  });
  
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    email: "",
    phoneNumber: "",
    numberOfAdults: 2,
    numberOfChildren: 0,
    childrenAges: [] as number[],
    budgetPerPerson: "",
    destinations: [] as string[],
    holidayTypes: [] as string[],
    preferredCallbackTime: "",
    preferredCallbackDate: "",
    travelMonths: [] as string[],
    travelYear: "",
    enquiryDetails: "",
  });

  const [agreedToTerms, setAgreedToTerms] = useState(false);

  const enquiryMutation = useMutation({
    mutationFn: async (data: typeof formData) => {
      if (!agent) throw new Error("No agent selected");
      
      return apiRequest("/api/enquiries", {
        method: "POST",
        body: JSON.stringify({
          ...data,
          agentId: agent.id,
        }),
        headers: {
          "Content-Type": "application/json",
        },
      });
    },
    onSuccess: () => {
      toast({
        title: "Enquiry Sent!",
        description: "Your enquiry has been sent to the travel agent. They will contact you soon.",
      });
      onClose();
      setFormData({
        firstName: "",
        lastName: "",
        email: "",
        phoneNumber: "",
        numberOfAdults: 2,
        numberOfChildren: 0,
        childrenAges: [],
        budgetPerPerson: "",
        destinations: [],
        holidayTypes: [],
        preferredCallbackTime: "",
        preferredCallbackDate: "",
        travelMonths: [],
        travelYear: "",
        enquiryDetails: "",
      });
      setAgreedToTerms(false);
    },
    onError: (error: any) => {
      console.error("Enquiry submission error:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to send enquiry. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!formData.firstName.trim()) {
      toast({
        title: "Error",
        description: "First name is required.",
        variant: "destructive",
      });
      return;
    }
    
    if (!formData.lastName.trim()) {
      toast({
        title: "Error",
        description: "Surname is required.",
        variant: "destructive",
      });
      return;
    }
    
    if (!formData.email.trim()) {
      toast({
        title: "Error",
        description: "Email is required.",
        variant: "destructive",
      });
      return;
    }
    
    if (!formData.phoneNumber.trim()) {
      toast({
        title: "Error",
        description: "Telephone number is required.",
        variant: "destructive",
      });
      return;
    }
    
    if (formData.numberOfAdults < 1) {
      toast({
        title: "Error",
        description: "Number of adults is required and must be at least 1.",
        variant: "destructive",
      });
      return;
    }
    
    if (formData.destinations.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one destination.",
        variant: "destructive",
      });
      return;
    }
    
    if (formData.holidayTypes.length === 0) {
      toast({
        title: "Error", 
        description: "Please select at least one holiday type.",
        variant: "destructive",
      });
      return;
    }
    
    if (!formData.enquiryDetails.trim()) {
      toast({
        title: "Error",
        description: "Enquiry details are required.",
        variant: "destructive",
      });
      return;
    }

    if (formData.travelMonths.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one month of travel.",
        variant: "destructive",
      });
      return;
    }

    if (!formData.travelYear) {
      toast({
        title: "Error",
        description: "Please select a year of travel.",
        variant: "destructive",
      });
      return;
    }
    
    if (formData.numberOfChildren > 0 && formData.childrenAges.some(age => !age)) {
      toast({
        title: "Error",
        description: "Please enter ages for all children.",
        variant: "destructive",
      });
      return;
    }

    if (!agreedToTerms) {
      toast({
        title: "Error",
        description: "Please agree to our Terms of Use and Privacy Policy to continue.",
        variant: "destructive",
      });
      return;
    }
    
    enquiryMutation.mutate(formData);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-roamah-dark">
            Enquiry Form
          </DialogTitle>
          {agent && (
            <p className="text-roamah-gray">
              Send an enquiry to {agent.name} in {agent.location}
            </p>
          )}
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Personal Information */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-roamah-dark border-b pb-2">Personal Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="firstName" className="text-sm font-semibold text-roamah-dark">
                  First name *
                </Label>
                <Input
                  id="firstName"
                  placeholder=""
                  value={formData.firstName}
                  onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                  required
                  className="focus-ring"
                />
              </div>
              <div>
                <Label htmlFor="lastName" className="text-sm font-semibold text-roamah-dark">
                  Surname *
                </Label>
                <Input
                  id="lastName"
                  placeholder=""
                  value={formData.lastName}
                  onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                  required
                  className="focus-ring"
                />
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="email" className="text-sm font-semibold text-roamah-dark">
                  Email *
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder=""
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  className="focus-ring"
                />
              </div>
              <div>
                <Label htmlFor="phoneNumber" className="text-sm font-semibold text-roamah-dark">
                  Telephone number *
                </Label>
                <Input
                  id="phoneNumber"
                  type="tel"
                  placeholder=""
                  value={formData.phoneNumber}
                  onChange={(e) => setFormData({ ...formData, phoneNumber: e.target.value })}
                  required
                  className="focus-ring"
                />
              </div>
            </div>
          </div>

          {/* Travel Details */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-roamah-dark border-b pb-2">Travel Details</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="numberOfAdults" className="text-sm font-semibold text-roamah-dark">
                  Number of adults *
                </Label>
                <Input
                  id="numberOfAdults"
                  type="number"
                  min="1"
                  max="20"
                  value={formData.numberOfAdults}
                  onChange={(e) => setFormData({ ...formData, numberOfAdults: parseInt(e.target.value) || 1 })}
                  required
                  className="focus-ring"
                />
              </div>
              <div>
                <Label htmlFor="numberOfChildren" className="text-sm font-semibold text-roamah-dark">
                  Number of children *
                </Label>
                <Input
                  id="numberOfChildren"
                  type="number"
                  min="0"
                  max="10"
                  value={formData.numberOfChildren}
                  onChange={(e) => {
                    const childCount = parseInt(e.target.value) || 0;
                    setFormData({ 
                      ...formData, 
                      numberOfChildren: childCount,
                      childrenAges: childCount === 0 ? [] : Array(childCount).fill(0)
                    });
                  }}
                  className="focus-ring"
                />
              </div>
            </div>

            {/* Children Ages */}
            {formData.numberOfChildren > 0 && (
              <div>
                <Label className="text-sm font-semibold text-roamah-dark">
                  Children's ages
                </Label>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-2">
                  {Array.from({ length: formData.numberOfChildren }, (_, index) => (
                    <div key={index}>
                      <Label htmlFor={`childAge${index}`} className="text-xs text-roamah-gray">
                        Child {index + 1} age
                      </Label>
                      <Input
                        id={`childAge${index}`}
                        type="number"
                        min="0"
                        max="17"
                        placeholder={`${index + 1}`}
                        value={formData.childrenAges[index] || ""}
                        onChange={(e) => {
                          const newAges = [...formData.childrenAges];
                          newAges[index] = parseInt(e.target.value) || 0;
                          setFormData({ ...formData, childrenAges: newAges });
                        }}
                        required
                        className="focus-ring text-sm"
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div>
              <Label htmlFor="budgetPerPerson" className="text-sm font-semibold text-roamah-dark">
                Budget per person
              </Label>
              <Select
                value={formData.budgetPerPerson}
                onValueChange={(value) => setFormData({ ...formData, budgetPerPerson: value })}
                required
              >
                <SelectTrigger className="focus-ring">
                  <SelectValue placeholder="£5,000 - £10,000" />
                </SelectTrigger>
                <SelectContent>
                  {BUDGET_RANGES.map((range) => (
                    <SelectItem key={range} value={range}>
                      {range}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label className="text-sm font-semibold text-roamah-dark">
                Interested in travelling to (select up to 5) *
              </Label>
              <MultiSelect
                options={destinations?.map(dest => dest.name).sort() || []}
                selected={formData.destinations}
                onChange={(selected) => setFormData({ ...formData, destinations: selected })}
                placeholder="Select destinations..."
                maxSelections={5}
                className="mt-2"
              />
            </div>

            <div>
              <Label className="text-sm font-semibold text-roamah-dark">
                Preferred holiday types (select up to 5) *
              </Label>
              <MultiSelect
                options={holidayTypes?.map(type => type.name).sort() || []}
                selected={formData.holidayTypes}
                onChange={(selected) => setFormData({ ...formData, holidayTypes: selected })}
                placeholder="Select holiday types..."
                maxSelections={5}
                className="mt-2"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label className="text-sm font-semibold text-roamah-dark">
                  Month of travel (select up to 2) *
                </Label>
                <MultiSelect
                  options={[
                    "January", "February", "March", "April", "May", "June",
                    "July", "August", "September", "October", "November", "December"
                  ]}
                  selected={formData.travelMonths}
                  onChange={(selected) => setFormData({ ...formData, travelMonths: selected })}
                  placeholder="Select months..."
                  maxSelections={2}
                  className="mt-2"
                />
              </div>
              <div>
                <Label htmlFor="travelYear" className="text-sm font-semibold text-roamah-dark">
                  Year of travel *
                </Label>
                <Select
                  value={formData.travelYear}
                  onValueChange={(value) => setFormData({ ...formData, travelYear: value })}
                  required
                >
                  <SelectTrigger className="focus-ring mt-2">
                    <SelectValue placeholder="Select year..." />
                  </SelectTrigger>
                  <SelectContent>
                    {Array.from({ length: 6 }, (_, i) => {
                      const year = new Date().getFullYear() + i;
                      return (
                        <SelectItem key={year} value={year.toString()}>
                          {year}
                        </SelectItem>
                      );
                    })}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Callback Preferences */}
          <div className="space-y-4">
            <h3 className="text-lg font-semibold text-roamah-dark border-b pb-2">Callback Preferences</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="preferredCallbackTime" className="text-sm font-semibold text-roamah-dark">
                  Preferred callback time
                </Label>
                <Select
                  value={formData.preferredCallbackTime}
                  onValueChange={(value) => setFormData({ ...formData, preferredCallbackTime: value })}
                >
                  <SelectTrigger className="focus-ring">
                    <SelectValue placeholder="Anytime" />
                  </SelectTrigger>
                  <SelectContent>
                    {CALLBACK_TIMES.map((time) => (
                      <SelectItem key={time} value={time}>
                        {time}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label htmlFor="preferredCallbackDate" className="text-sm font-semibold text-roamah-dark">
                  Preferred callback date
                </Label>
                <Input
                  id="preferredCallbackDate"
                  type="date"
                  value={formData.preferredCallbackDate}
                  onChange={(e) => setFormData({ ...formData, preferredCallbackDate: e.target.value })}
                  className="focus-ring"
                  min={new Date().toISOString().split('T')[0]}
                />
              </div>
            </div>
          </div>

          {/* Enquiry Details */}
          <div>
            <Label htmlFor="enquiryDetails" className="text-sm font-semibold text-roamah-dark">
              Enquiry details *
            </Label>
            <Textarea
              id="enquiryDetails"
              placeholder="Tell us more about your travel plans, preferences, and any special requirements..."
              value={formData.enquiryDetails}
              onChange={(e) => setFormData({ ...formData, enquiryDetails: e.target.value })}
              required
              className="min-h-[120px] focus-ring mt-2"
            />
          </div>

          {/* Terms Agreement */}
          <div className="space-y-4 pt-4 border-t">
            <div className="flex items-start space-x-3">
              <Checkbox
                id="terms-agreement"
                checked={agreedToTerms}
                onCheckedChange={(checked) => setAgreedToTerms(checked as boolean)}
                className="mt-1"
              />
              <div className="space-y-1 leading-none">
                <label
                  htmlFor="terms-agreement"
                  className="text-sm font-medium leading-relaxed peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  I agree to Roamah's{" "}
                  <Link 
                    href="/terms-of-use" 
                    className="text-roamah-orange hover:underline inline-flex items-center gap-1"
                    target="_blank"
                  >
                    Terms of Use
                    <ExternalLink className="h-3 w-3" />
                  </Link>
                  {" "}and{" "}
                  <Link 
                    href="/privacy-policy" 
                    className="text-roamah-orange hover:underline inline-flex items-center gap-1"
                    target="_blank"
                  >
                    Privacy Policy
                    <ExternalLink className="h-3 w-3" />
                  </Link>
                </label>
                <p className="text-xs text-roamah-gray">
                  By submitting this enquiry, you consent to us sharing your information with the selected travel expert to provide personalised service.
                </p>
              </div>
            </div>
          </div>

          <div className="flex justify-end space-x-4 pt-4 border-t">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="px-6 py-2"
            >
              Cancel
            </Button>
            <Button
              type="submit"
              disabled={enquiryMutation.isPending}
              className="px-6 py-2 bg-roamah-orange hover:bg-roamah-orange/90 text-white"
            >
              {enquiryMutation.isPending ? "Sending..." : "Submit"}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}