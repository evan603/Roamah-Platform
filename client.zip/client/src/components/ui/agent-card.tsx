import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { StarRating } from "@/components/ui/star-rating";
import { MapPin } from "lucide-react";
import { HOLIDAY_TYPES } from "@/lib/constants";
import type { Agent } from "@shared/schema";

interface AgentCardProps {
  agent: Agent;
  onEnquire?: (agent: Agent) => void;
}

export function AgentCard({ agent, onEnquire }: AgentCardProps) {
  // Since specializations are now standardized holiday types, use them directly
  const holidayTypeNames = HOLIDAY_TYPES.map(ht => ht.name);
  const holidayTypes = (agent.specializations || []).filter(spec => 
    holidayTypeNames.includes(spec)
  );

  // Get first name from full name, handle null names
  const firstName = agent.name ? agent.name.split(' ')[0] : agent.firstName || 'Agent';

  return (
    <div className="bg-white rounded-2xl p-6 shadow-lg hover:shadow-xl transition-all group h-full flex flex-col">
      <div className="relative mb-4">
        {parseFloat(agent.rating) >= 4.8 && (
          <span className="absolute top-2 right-2 bg-blue-500 text-white text-xs px-2 py-1 rounded-full z-10">
            Top rated
          </span>
        )}
        <Link href={`/agent/${agent.id}`}>
          <img
            src={agent.profileImage || '/placeholder-agent.jpg'}
            alt={agent.name || 'Travel Expert'}
            className="w-full aspect-square rounded-xl object-cover cursor-pointer hover:opacity-90 transition-opacity border-4 border-gray-100"
          />
        </Link>
      </div>
      
      <div className="flex items-center mb-2">
        <MapPin className="h-4 w-4 text-green-500 mr-2" />
        <span className="text-sm text-roamah-gray">{agent.location}</span>
        <div className="ml-auto">
          <StarRating 
            rating={parseFloat(agent.rating)} 
            reviewCount={agent.reviewCount}
            size="sm"
          />
        </div>
      </div>

      <Link href={`/agent/${agent.id}`}>
        <h4 className="text-xl font-semibold text-roamah-dark mb-2 cursor-pointer hover:text-roamah-orange transition-colors">
          {agent.name || `${agent.firstName || ''} ${agent.lastName || ''}`.trim() || 'Travel Expert'}
        </h4>
      </Link>
      <p className="text-sm text-roamah-gray mb-3">{agent.company}</p>
      <p className="text-sm text-roamah-gray mb-4 line-clamp-3">{agent.bio}</p>

      <div className="mb-6 flex-grow">
        <p className="text-sm font-semibold text-roamah-dark mb-2">I'm an expert in</p>
        
        {/* Holiday types - show up to 6 tags across 2 lines */}
        <div className="flex flex-wrap gap-2 mb-3">
          {holidayTypes.slice(0, 6).map((type, index) => {
            const holidayColors = [
              "bg-green-100 text-green-800",
              "bg-orange-100 text-orange-800",
              "bg-red-100 text-red-800",
              "bg-yellow-100 text-yellow-800"
            ];
            return (
              <Badge
                key={index}
                variant="secondary"
                className={holidayColors[index % holidayColors.length]}
              >
                {type}
              </Badge>
            );
          })}
          {holidayTypes.length > 6 && (
            <Badge variant="secondary" className="bg-gray-100 text-gray-800">
              +{holidayTypes.length - 6} more
            </Badge>
          )}
        </div>
        
        <p className="text-sm font-semibold text-roamah-dark mb-2">and these destinations</p>
        
        {/* Destinations - show up to 8 tags across 2 lines */}
        <div className="flex flex-wrap gap-2">
          {(agent.destinations || []).slice(0, 8).map((destination, index) => {
            const destinationColors = [
              "bg-blue-100 text-blue-800",
              "bg-purple-100 text-purple-800", 
              "bg-teal-100 text-teal-800",
              "bg-pink-100 text-pink-800"
            ];
            return (
              <Badge
                key={index}
                variant="secondary"
                className={destinationColors[index % destinationColors.length]}
              >
                {destination}
              </Badge>
            );
          })}
          {(agent.destinations || []).length > 8 && (
            <Badge variant="secondary" className="bg-gray-100 text-gray-800">
              +{(agent.destinations || []).length - 8} more
            </Badge>
          )}
        </div>
      </div>

      <Link href={`/agent/${agent.id}`} className="mt-auto">
        <Button className="w-full bg-roamah-orange hover:bg-roamah-orange/90 font-bold">
          Visit {firstName}'s profile
        </Button>
      </Link>
    </div>
  );
}
