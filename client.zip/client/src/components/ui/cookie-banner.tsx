import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { X, Settings, Cookie } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';

interface CookieConsent {
  essential: boolean;
  analytics: boolean;
  marketing: boolean;
  preferences: boolean;
}

const COOKIE_CONSENT_KEY = 'roamah-cookie-consent';
const COOKIE_BANNER_SHOWN_KEY = 'roamah-cookie-banner-shown';

export function CookieBanner() {
  const [showBanner, setShowBanner] = useState(false);
  const [showPreferences, setShowPreferences] = useState(false);
  const [consent, setConsent] = useState<CookieConsent>({
    essential: true, // Always required
    analytics: false,
    marketing: false,
    preferences: false,
  });

  useEffect(() => {
    // Check if user has already given consent
    const existingConsent = localStorage.getItem(COOKIE_CONSENT_KEY);
    const bannerShown = localStorage.getItem(COOKIE_BANNER_SHOWN_KEY);
    
    if (!existingConsent && !bannerShown) {
      setShowBanner(true);
    } else if (existingConsent) {
      setConsent(JSON.parse(existingConsent));
    }
  }, []);

  const saveConsent = (consentData: CookieConsent) => {
    localStorage.setItem(COOKIE_CONSENT_KEY, JSON.stringify(consentData));
    localStorage.setItem(COOKIE_BANNER_SHOWN_KEY, 'true');
    setConsent(consentData);
    setShowBanner(false);
    setShowPreferences(false);
    
    // Apply consent preferences
    applyConsentPreferences(consentData);
  };

  const applyConsentPreferences = (consentData: CookieConsent) => {
    // Handle analytics consent
    if (!consentData.analytics) {
      // Disable analytics if user declined
      if (typeof window !== 'undefined' && (window as any).gtag) {
        (window as any).gtag('consent', 'update', {
          'analytics_storage': 'denied'
        });
      }
    }

    // Handle marketing consent  
    if (!consentData.marketing) {
      // Clear marketing cookies if declined
      document.cookie.split(";").forEach(cookie => {
        const eqPos = cookie.indexOf("=");
        const name = eqPos > -1 ? cookie.substr(0, eqPos).trim() : cookie.trim();
        if (name.includes('_fbp') || name.includes('_ga') || name.includes('_gid')) {
          document.cookie = `${name}=;expires=Thu, 01 Jan 1970 00:00:00 GMT;path=/`;
        }
      });
    }
  };

  const acceptAll = () => {
    const allAccepted = {
      essential: true,
      analytics: true,
      marketing: true,
      preferences: true,
    };
    saveConsent(allAccepted);
  };

  const acceptEssentialOnly = () => {
    const essentialOnly = {
      essential: true,
      analytics: false,
      marketing: false,
      preferences: false,
    };
    saveConsent(essentialOnly);
  };

  const handleCustomConsent = () => {
    saveConsent(consent);
  };

  if (!showBanner) return null;

  return (
    <>
      {/* Cookie Banner */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 shadow-lg z-50">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex items-start gap-3 flex-1">
              <Cookie className="h-6 w-6 text-roamah-orange mt-1 flex-shrink-0" />
              <div>
                <h3 className="font-semibold text-gray-900 mb-2">We use cookies to enhance your experience</h3>
                <p className="text-sm text-gray-600 mb-3">
                  We use cookies to keep you logged in, remember your preferences, and improve our services. 
                  You can choose which cookies to accept.{' '}
                  <a href="/cookies" className="text-roamah-orange hover:underline" target="_blank">
                    Learn more about our cookies
                  </a>
                </p>
                <div className="flex flex-wrap gap-2">
                  <Button 
                    onClick={acceptAll}
                    className="bg-roamah-orange hover:bg-roamah-orange/90 text-white text-sm px-4 py-2"
                  >
                    Accept All
                  </Button>
                  <Button 
                    onClick={acceptEssentialOnly}
                    variant="outline"
                    className="text-sm px-4 py-2"
                  >
                    Essential Only
                  </Button>
                  <Button 
                    onClick={() => setShowPreferences(true)}
                    variant="outline"
                    className="text-sm px-4 py-2"
                  >
                    <Settings className="h-4 w-4 mr-1" />
                    Customize
                  </Button>
                </div>
              </div>
            </div>
            <Button
              onClick={() => setShowBanner(false)}
              variant="ghost"
              size="sm"
              className="flex-shrink-0"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Cookie Preferences Modal */}
      <Dialog open={showPreferences} onOpenChange={setShowPreferences}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Cookie className="h-5 w-5 text-roamah-orange" />
              Cookie Preferences
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-6 mt-4">
            <p className="text-gray-600">
              Manage your cookie preferences below. Essential cookies are required for the website to function properly.
            </p>

            {/* Essential Cookies */}
            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-gray-900">Essential Cookies</h4>
                <span className="text-sm bg-green-100 text-green-800 px-2 py-1 rounded">Always Active</span>
              </div>
              <p className="text-sm text-gray-600 mb-2">
                These cookies are necessary for the website to function and cannot be switched off. They enable core functionality like security, authentication, and basic website operations.
              </p>
              <p className="text-xs text-gray-500">
                Examples: Login sessions, security tokens, website preferences
              </p>
            </div>

            {/* Analytics Cookies */}
            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-gray-900">Analytics Cookies</h4>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={consent.analytics}
                    onChange={(e) => setConsent({ ...consent, analytics: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-orange-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-roamah-orange"></div>
                </label>
              </div>
              <p className="text-sm text-gray-600 mb-2">
                These cookies help us understand how visitors use our website by collecting anonymous usage statistics.
              </p>
              <p className="text-xs text-gray-500">
                Examples: Page views, user behavior, website performance
              </p>
            </div>

            {/* Marketing Cookies */}
            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-gray-900">Marketing Cookies</h4>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={consent.marketing}
                    onChange={(e) => setConsent({ ...consent, marketing: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-orange-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-roamah-orange"></div>
                </label>
              </div>
              <p className="text-sm text-gray-600 mb-2">
                These cookies are used to deliver personalized advertisements and track the effectiveness of our marketing campaigns.
              </p>
              <p className="text-xs text-gray-500">
                Examples: Social media tracking, email marketing, targeted advertisements
              </p>
            </div>

            {/* Preference Cookies */}
            <div className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-gray-900">Preference Cookies</h4>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input
                    type="checkbox"
                    checked={consent.preferences}
                    onChange={(e) => setConsent({ ...consent, preferences: e.target.checked })}
                    className="sr-only peer"
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-orange-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-roamah-orange"></div>
                </label>
              </div>
              <p className="text-sm text-gray-600 mb-2">
                These cookies remember your choices and preferences to provide a more personalized experience.
              </p>
              <p className="text-xs text-gray-500">
                Examples: Language settings, display preferences, saved filters
              </p>
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                onClick={handleCustomConsent}
                className="flex-1 bg-roamah-orange hover:bg-roamah-orange/90 text-white"
              >
                Save Preferences
              </Button>
              <Button
                onClick={acceptAll}
                variant="outline"
                className="flex-1"
              >
                Accept All
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}