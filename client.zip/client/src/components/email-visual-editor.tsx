import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { 
  Bold, 
  Italic, 
  Underline, 
  Type, 
  Palette, 
  AlignLeft, 
  AlignCenter, 
  AlignRight,
  Link,
  List
} from "lucide-react";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface EmailTemplate {
  id: string;
  name: string;
  type: string;
  subject: string;
  htmlContent: string;
  textContent: string;
  description: string;
  isActive: boolean;
}

interface VisualEmailEditorProps {
  template: EmailTemplate;
  onSave: (updatedTemplate: Partial<EmailTemplate>) => void;
  onCancel: () => void;
}

export function VisualEmailEditor({ template, onSave, onCancel }: VisualEmailEditorProps) {
  const [subject, setSubject] = useState(template.subject);
  const [description, setDescription] = useState(template.description);
  const [selectedElement, setSelectedElement] = useState<string | null>(null);
  const editorRef = useRef<HTMLDivElement>(null);
  
  // Extract editable content from HTML template
  const [emailContent, setEmailContent] = useState(() => {
    try {
      // Parse the template to extract main content sections
      const parser = new DOMParser();
      const doc = parser.parseFromString(template.htmlContent, 'text/html');
      
      return {
        headerTitle: doc.querySelector('h1')?.textContent || "Roamah Travel",
        headerSubtitle: doc.querySelector('h1 + p')?.textContent || "Your travel experts",
        mainHeading: doc.querySelector('h2')?.textContent || "Email Title",
        mainMessage: doc.querySelector('div p')?.textContent?.slice(0, 200) || "Main email message...",
        buttonText: doc.querySelector('a[style*="color: white"]')?.textContent || "Click Here",
        buttonUrl: doc.querySelector('a[style*="color: white"]')?.getAttribute('href') || "#",
        footerText: "Best regards, The Roamah Travel Team"
      };
    } catch (error) {
      console.error('Error parsing template:', error);
      return {
        headerTitle: "Roamah Travel",
        headerSubtitle: "Your travel experts",
        mainHeading: "Email Title",
        mainMessage: "Main email message...",
        buttonText: "Click Here",
        buttonUrl: "#",
        footerText: "Best regards, The Roamah Travel Team"
      };
    }
  });

  const formatCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    if (editorRef.current) {
      setEmailContent(prev => ({
        ...prev,
        mainMessage: editorRef.current?.innerHTML || prev.mainMessage
      }));
    }
  };

  const generateUpdatedHTML = () => {
    return `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff;">
        <div style="background-color: #ff6b35; padding: 20px; text-align: center;">
          <h1 style="color: white; margin: 0; font-size: 28px;">${emailContent.headerTitle}</h1>
          <p style="color: white; margin: 5px 0 0 0; font-size: 16px;">${emailContent.headerSubtitle}</p>
        </div>
        
        <div style="padding: 30px 20px;">
          <h2 style="color: #333; margin-bottom: 20px;">${emailContent.mainHeading}</h2>
          
          <div style="color: #666; line-height: 1.6; margin-bottom: 20px;">
            ${emailContent.mainMessage}
          </div>
          
          <div style="text-align: center; margin: 30px 0;">
            <table style="margin: 0 auto;">
              <tr>
                <td style="background-color: #ff6b35; padding: 15px 30px; text-align: center; border-radius: 5px;">
                  <a href="${emailContent.buttonUrl}" style="color: white; text-decoration: none; font-weight: bold; font-size: 16px;">${emailContent.buttonText}</a>
                </td>
              </tr>
            </table>
          </div>
          
          <p style="color: #666; line-height: 1.6; font-size: 14px; margin-top: 30px;">
            ${emailContent.footerText}
          </p>
        </div>
        
        <div style="background-color: #f8f9fa; padding: 20px; text-align: center; border-top: 1px solid #e9ecef;">
          <p style="color: #999; font-size: 12px; margin: 0;">
            This email was sent by Roamah Travel. If you have any questions, please contact us.
          </p>
        </div>
      </div>
    `;
  };

  const handleSave = () => {
    const updatedHTML = generateUpdatedHTML();
    const textContent = `${emailContent.mainHeading}\n\n${emailContent.mainMessage}\n\n${emailContent.footerText}`;
    
    onSave({
      subject,
      description,
      htmlContent: updatedHTML,
      textContent
    });
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Visual Email Editor</h2>
        <div className="space-x-2">
          <Button variant="outline" onClick={onCancel}>Cancel</Button>
          <Button onClick={handleSave} className="bg-roamah-orange hover:bg-roamah-orange/90">
            Save Template
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Editor Panel */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Email Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="subject">Email Subject</Label>
                <Input
                  id="subject"
                  value={subject}
                  onChange={(e) => setSubject(e.target.value)}
                  placeholder="Enter email subject"
                />
              </div>
              
              <div>
                <Label htmlFor="description">Description</Label>
                <Input
                  id="description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Brief description of this template"
                />
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Email Content</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="headerTitle">Header Title</Label>
                <Input
                  id="headerTitle"
                  value={emailContent.headerTitle}
                  onChange={(e) => setEmailContent(prev => ({ ...prev, headerTitle: e.target.value }))}
                />
              </div>

              <div>
                <Label htmlFor="headerSubtitle">Header Subtitle</Label>
                <Input
                  id="headerSubtitle"
                  value={emailContent.headerSubtitle}
                  onChange={(e) => setEmailContent(prev => ({ ...prev, headerSubtitle: e.target.value }))}
                />
              </div>

              <div>
                <Label htmlFor="mainHeading">Main Heading</Label>
                <Input
                  id="mainHeading"
                  value={emailContent.mainHeading}
                  onChange={(e) => setEmailContent(prev => ({ ...prev, mainHeading: e.target.value }))}
                />
              </div>

              <div>
                <Label htmlFor="mainMessage">Main Message</Label>
                <div className="space-y-2">
                  <div className="flex space-x-1 border rounded p-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => formatCommand('bold')}
                    >
                      <Bold className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => formatCommand('italic')}
                    >
                      <Italic className="h-4 w-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => formatCommand('underline')}
                    >
                      <Underline className="h-4 w-4" />
                    </Button>
                  </div>
                  <div
                    ref={editorRef}
                    contentEditable
                    className="min-h-[100px] p-3 border rounded-md"
                    style={{ lineHeight: '1.6' }}
                    dangerouslySetInnerHTML={{ __html: emailContent.mainMessage }}
                    onInput={(e) => {
                      setEmailContent(prev => ({
                        ...prev,
                        mainMessage: e.currentTarget.innerHTML
                      }));
                    }}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="buttonText">Button Text</Label>
                <Input
                  id="buttonText"
                  value={emailContent.buttonText}
                  onChange={(e) => setEmailContent(prev => ({ ...prev, buttonText: e.target.value }))}
                />
              </div>

              <div>
                <Label htmlFor="buttonUrl">Button URL</Label>
                <Input
                  id="buttonUrl"
                  value={emailContent.buttonUrl}
                  onChange={(e) => setEmailContent(prev => ({ ...prev, buttonUrl: e.target.value }))}
                  placeholder="https://example.com"
                />
              </div>

              <div>
                <Label htmlFor="footerText">Footer Message</Label>
                <Input
                  id="footerText"
                  value={emailContent.footerText}
                  onChange={(e) => setEmailContent(prev => ({ ...prev, footerText: e.target.value }))}
                />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Preview Panel */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Live Preview</CardTitle>
              <Badge variant="secondary">Subject: {subject}</Badge>
            </CardHeader>
            <CardContent>
              <div 
                className="border rounded-lg p-4 bg-white"
                dangerouslySetInnerHTML={{ __html: generateUpdatedHTML() }}
              />
            </CardContent>
          </Card>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Available Variables</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
            <Badge variant="outline">{'{{customerName}}'}</Badge>
            <Badge variant="outline">{'{{agentName}}'}</Badge>
            <Badge variant="outline">{'{{tripType}}'}</Badge>
            <Badge variant="outline">{'{{enquiryId}}'}</Badge>
            <Badge variant="outline">{'{{customerEmail}}'}</Badge>
            <Badge variant="outline">{'{{domain}}'}</Badge>
            <Badge variant="outline">{'{{agentId}}'}</Badge>
          </div>
          <p className="text-sm text-gray-600 mt-2">
            Use these variables in your content - they'll be automatically replaced with actual data when emails are sent.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}