import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { LogOut, Users, FileText, Image as ImageIcon, Mail } from "lucide-react";

export function AdminNavbar() {
  const [location] = useLocation();

  const handleLogout = () => {
    localStorage.removeItem('adminToken');
    window.location.href = '/admin/login';
  };

  const navItems = [
    {
      href: "/admin/enquiries",
      label: "Enquiries",
      icon: FileText,
      active: location === "/admin/enquiries"
    },
    {
      href: "/admin/images", 
      label: "Images",
      icon: ImageIcon,
      active: location === "/admin/images"
    },
    {
      href: "/admin/emails", 
      label: "Email Templates",
      icon: Mail,
      active: location === "/admin/emails"
    }
  ];

  return (
    <nav className="bg-white border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center space-x-8">
            <Link href="/admin/enquiries">
              <div className="flex items-center space-x-2 cursor-pointer">
                <div className="text-2xl font-bold text-roamah-orange">Roamah</div>
                <div className="text-sm font-medium text-gray-500 bg-gray-100 px-2 py-1 rounded">
                  Admin
                </div>
              </div>
            </Link>
            
            <div className="flex space-x-1">
              {navItems.map((item) => {
                const IconComponent = item.icon;
                return (
                  <Link key={item.href} href={item.href}>
                    <Button
                      variant={item.active ? "default" : "ghost"}
                      className={`flex items-center space-x-2 ${
                        item.active 
                          ? "bg-roamah-orange text-white hover:bg-roamah-orange/90" 
                          : "text-gray-600 hover:text-gray-900"
                      }`}
                    >
                      <IconComponent className="h-4 w-4" />
                      <span>{item.label}</span>
                    </Button>
                  </Link>
                );
              })}
            </div>
          </div>

          <div className="flex items-center">
            <Button
              variant="outline"
              onClick={handleLogout}
              className="flex items-center space-x-2 text-gray-600 hover:text-gray-900"
            >
              <LogOut className="h-4 w-4" />
              <span>Logout</span>
            </Button>
          </div>
        </div>
      </div>
    </nav>
  );
}