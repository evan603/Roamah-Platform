import { useState, useEffect } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { X, Upload, Image as ImageIcon, Save, Eye, FileText, Bold, Italic, Underline, Type, Palette, AlignLeft, AlignCenter, AlignRight, AlignJustify, List, ListOrdered, Quote, Code, Link, RotateCw, ZoomIn, ZoomOut, Layout, Copy, Smile } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { insertBlogPostSchema, type InsertBlogPost, type Destination, type HolidayType } from "@shared/schema";
import { z } from "zod";

const blogPostFormSchema = insertBlogPostSchema.extend({
  heroImageFile: z.instanceof(File).optional(),
});

type BlogPostFormData = z.infer<typeof blogPostFormSchema>;

interface BlogEditorProps {
  onClose: () => void;
  existingPost?: any;
}

export function BlogEditor({ onClose, existingPost }: BlogEditorProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [contentImages, setContentImages] = useState<string[]>([]);
  const [heroImagePreview, setHeroImagePreview] = useState<string | null>(existingPost?.heroImage || null);
  const [selectedHolidayTypes, setSelectedHolidayTypes] = useState<string[]>(existingPost?.holidayTypes || []);
  const [selectedDestinations, setSelectedDestinations] = useState<string[]>(existingPost?.destinations || []);
  const [showPreview, setShowPreview] = useState(false);
  const [cursorPosition, setCursorPosition] = useState(0);
  const [contentTextareaRef, setContentTextareaRef] = useState<HTMLDivElement | null>(null);
  const [selectedFontSize, setSelectedFontSize] = useState("16");
  const [selectedFontFamily, setSelectedFontFamily] = useState("Arial");
  const [selectedTextColor, setSelectedTextColor] = useState("#000000");
  const [autoSaveStatus, setAutoSaveStatus] = useState<'idle' | 'saving' | 'saved' | 'error'>('idle');
  const [lastAutoSave, setLastAutoSave] = useState<Date | null>(null);
  const [showTemplates, setShowTemplates] = useState(false);
  const [selectedImage, setSelectedImage] = useState<HTMLImageElement | null>(null);
  const [showEmojiPicker, setShowEmojiPicker] = useState(false);

  // Fetch holiday types and destinations for tagging
  const { data: holidayTypes } = useQuery<HolidayType[]>({
    queryKey: ["/api/holiday-types"],
  });

  const { data: destinations } = useQuery<Destination[]>({
    queryKey: ["/api/destinations"],
  });

  const form = useForm<BlogPostFormData>({
    resolver: zodResolver(blogPostFormSchema),
    defaultValues: {
      title: existingPost?.title || "",
      excerpt: existingPost?.excerpt || "",
      content: existingPost?.content || "",
      status: existingPost?.status || "draft",
      heroImage: existingPost?.heroImage || "",
      images: existingPost?.images || [],
      holidayTypes: existingPost?.holidayTypes || [],
      destinations: existingPost?.destinations || [],
    },
  });

  // Create blog post mutation
  const createBlogMutation = useMutation({
    mutationFn: async (data: BlogPostFormData) => {
      // Always get the latest content from contentEditable before sending
      const currentContent = contentTextareaRef?.innerHTML || data.content || '';
      
      const formData = new FormData();
      
      // Add text fields
      formData.append('title', data.title || '');
      formData.append('excerpt', data.excerpt || '');
      formData.append('content', currentContent);
      formData.append('status', data.status || 'draft');
      formData.append('holidayTypes', JSON.stringify(selectedHolidayTypes));
      formData.append('destinations', JSON.stringify(selectedDestinations));
      
      console.log('Sending blog data:', {
        title: data.title,
        contentLength: currentContent.length,
        status: data.status,
        holidayTypes: selectedHolidayTypes,
        destinations: selectedDestinations
      });
      
      // Add hero image if present
      if (data.heroImageFile) {
        formData.append('heroImage', data.heroImageFile);
      }
      
      // Convert data URLs to File objects and add content images
      contentImages.forEach((imageDataUrl, index) => {
        if (imageDataUrl.startsWith('data:image/')) {
          // Convert data URL to File object
          const [header, base64Data] = imageDataUrl.split(',');
          const mimeType = header.match(/data:([^;]+);/)?.[1] || 'image/jpeg';
          const extension = mimeType.split('/')[1] || 'jpg';
          
          const binaryString = atob(base64Data);
          const bytes = new Uint8Array(binaryString.length);
          for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }
          
          const file = new File([bytes], `content-image-${index}.${extension}`, { type: mimeType });
          formData.append(`contentImage_${index}`, file);
        }
      });

      return fetch(`/api/agents/blog${existingPost ? `/${existingPost.id}` : ''}`, {
        method: existingPost ? 'PUT' : 'POST',
        body: formData,
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('agentToken')}`,
        },
      }).then(res => res.json());
    },
    onSuccess: () => {
      toast({
        title: "Success!",
        description: `Blog post ${existingPost ? 'updated' : 'created'} successfully.`,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/blog"] });
      queryClient.invalidateQueries({ queryKey: ["/api/agents/blog"] });
      onClose();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || `Failed to ${existingPost ? 'update' : 'create'} blog post.`,
        variant: "destructive",
      });
    },
  });

  // Handle hero image selection
  const handleHeroImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      form.setValue('heroImageFile', file);
      const reader = new FileReader();
      reader.onload = (e) => {
        setHeroImagePreview(e.target?.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  // Handle content image uploads with cursor position insertion
  const handleContentImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onload = (e) => {
        const imageUrl = e.target?.result as string;
        setContentImages(prev => [...prev, imageUrl]);
        
        // Insert image at cursor position in contentEditable
        const selection = window.getSelection();
        if (selection && selection.rangeCount > 0) {
          const range = selection.getRangeAt(0);
          
          // Create a container div for the image with delete functionality and resize handles
          const container = document.createElement('div');
          container.className = 'image-container';
          container.style.cssText = `
            position: relative; 
            display: inline-block; 
            margin: 10px 0; 
            border: 2px solid transparent; 
            border-radius: 8px;
            max-width: 100%;
          `;
          
          const img = document.createElement('img');
          img.src = imageUrl;
          img.alt = 'Blog image';
          img.style.cssText = `
            max-width: 100%; 
            height: auto; 
            display: block; 
            border-radius: 6px;
            cursor: pointer;
          `;
          
          // Create delete button
          const deleteBtn = document.createElement('button');
          deleteBtn.innerHTML = '×';
          deleteBtn.className = 'delete-image-btn';
          deleteBtn.style.cssText = `
            position: absolute; 
            top: 4px; 
            right: 4px; 
            background: #ef4444; 
            color: white; 
            border: none; 
            border-radius: 50%; 
            width: 24px; 
            height: 24px; 
            cursor: pointer; 
            display: none; 
            font-size: 14px; 
            font-weight: bold;
            line-height: 1;
            z-index: 10;
          `;
          
          // Create resize handles
          const createResizeHandle = (position: string) => {
            const handle = document.createElement('div');
            handle.className = `resize-handle resize-${position}`;
            handle.style.cssText = `
              position: absolute;
              width: 8px;
              height: 8px;
              background: #3b82f6;
              border: 2px solid white;
              border-radius: 50%;
              cursor: ${position.includes('n') ? 'n' : position.includes('s') ? 's' : ''}${position.includes('e') ? 'e' : position.includes('w') ? 'w' : ''}-resize;
              display: none;
              z-index: 15;
            `;
            
            // Position handles at corners and edges
            switch(position) {
              case 'nw': handle.style.cssText += 'top: -4px; left: -4px;'; break;
              case 'ne': handle.style.cssText += 'top: -4px; right: -4px;'; break;
              case 'sw': handle.style.cssText += 'bottom: -4px; left: -4px;'; break;
              case 'se': handle.style.cssText += 'bottom: -4px; right: -4px;'; break;
            }
            
            return handle;
          };
          
          const handles = ['nw', 'ne', 'sw', 'se'].map(createResizeHandle);
          
          // Add resize functionality
          let isResizing = false;
          let startX = 0;
          let startY = 0;
          let startWidth = 0;
          let startHeight = 0;
          let currentHandle = '';
          
          handles.forEach((handle, index) => {
            const positions = ['nw', 'ne', 'sw', 'se'];
            const position = positions[index];
            
            handle.onmousedown = (e) => {
              e.preventDefault();
              e.stopPropagation();
              isResizing = true;
              currentHandle = position;
              startX = e.clientX;
              startY = e.clientY;
              startWidth = img.offsetWidth;
              startHeight = img.offsetHeight;
              
              document.addEventListener('mousemove', handleResize);
              document.addEventListener('mouseup', stopResize);
            };
          });
          
          const handleResize = (e: MouseEvent) => {
            if (!isResizing) return;
            
            const deltaX = e.clientX - startX;
            const deltaY = e.clientY - startY;
            
            let newWidth = startWidth;
            let newHeight = startHeight;
            
            // Calculate new dimensions based on handle position
            switch(currentHandle) {
              case 'se': // Bottom-right
                newWidth = startWidth + deltaX;
                break;
              case 'sw': // Bottom-left
                newWidth = startWidth - deltaX;
                break;
              case 'ne': // Top-right
                newWidth = startWidth + deltaX;
                break;
              case 'nw': // Top-left
                newWidth = startWidth - deltaX;
                break;
            }
            
            // Maintain aspect ratio and set minimum/maximum sizes
            newWidth = Math.max(100, Math.min(800, newWidth));
            
            img.style.width = newWidth + 'px';
            img.style.height = 'auto';
            
            form.setValue('content', contentTextareaRef?.innerHTML || '');
          };
          
          const stopResize = () => {
            isResizing = false;
            document.removeEventListener('mousemove', handleResize);
            document.removeEventListener('mouseup', stopResize);
          };
          
          // Add delete functionality
          deleteBtn.onclick = (e) => {
            e.preventDefault();
            e.stopPropagation();
            container.remove();
            form.setValue('content', contentTextareaRef?.innerHTML || '');
          };
          
          // Add selection and hover effects
          const showControls = () => {
            deleteBtn.style.display = 'block';
            handles.forEach(handle => handle.style.display = 'block');
            container.style.border = '2px solid #3b82f6';
            container.style.boxShadow = '0 0 0 1px rgba(59, 130, 246, 0.3)';
          };
          
          const hideControls = () => {
            deleteBtn.style.display = 'none';
            handles.forEach(handle => handle.style.display = 'none');
            container.style.border = '2px solid transparent';
            container.style.boxShadow = 'none';
          };
          
          // Image click handling is now done by the content area click handler
          
          // Container hover effects  
          container.onmouseenter = () => {
            if (!container.classList.contains('selected')) {
              container.style.border = '2px solid rgba(59, 130, 246, 0.5)';
            }
          };
          
          container.onmouseleave = () => {
            if (!container.classList.contains('selected')) {
              hideControls();
            }
          };
          
          container.appendChild(img);
          container.appendChild(deleteBtn);
          handles.forEach(handle => container.appendChild(handle));
          range.insertNode(container);
          
          // Move cursor after image container
          range.setStartAfter(container);
          range.setEndAfter(container);
          selection.removeAllRanges();
          selection.addRange(range);
          
          form.setValue('content', contentTextareaRef?.innerHTML || '');
        }
      };
      reader.readAsDataURL(file);
    });
    
    // Clear the file input
    e.target.value = '';
  };

  // Insert image at cursor position
  const insertImageAtCursor = () => {
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/*';
    fileInput.onchange = (e) => {
      const event = e as unknown as React.ChangeEvent<HTMLInputElement>;
      handleContentImageUpload(event);
    };
    fileInput.click();
  };

  // Add resize functionality to existing images
  useEffect(() => {
    if (contentTextareaRef) {
      const existingImages = contentTextareaRef.querySelectorAll('img:not(.resize-enabled)');
      existingImages.forEach((img) => {
        const imageElement = img as HTMLImageElement;
        imageElement.classList.add('resize-enabled');
        
        // Check if image is already in a container
        const existingContainer = imageElement.closest('.image-container');
        if (!existingContainer) {
          // Wrap existing image in container with resize functionality
          const container = document.createElement('div');
          container.className = 'image-container';
          container.style.cssText = `
            position: relative; 
            display: inline-block; 
            margin: 10px 0; 
            border: 2px solid transparent; 
            border-radius: 8px;
            max-width: 100%;
          `;
          
          // Add pointer cursor
          imageElement.style.cursor = 'pointer';
          
          // Create delete button
          const deleteBtn = document.createElement('button');
          deleteBtn.innerHTML = '×';
          deleteBtn.className = 'delete-image-btn';
          deleteBtn.style.cssText = `
            position: absolute; 
            top: 4px; 
            right: 4px; 
            background: #ef4444; 
            color: white; 
            border: none; 
            border-radius: 50%; 
            width: 24px; 
            height: 24px; 
            cursor: pointer; 
            display: none; 
            font-size: 14px; 
            font-weight: bold;
            line-height: 1;
            z-index: 10;
          `;
          
          // Create resize handles
          const createResizeHandle = (position: string) => {
            const handle = document.createElement('div');
            handle.className = `resize-handle resize-${position}`;
            handle.style.cssText = `
              position: absolute;
              width: 8px;
              height: 8px;
              background: #3b82f6;
              border: 2px solid white;
              border-radius: 50%;
              cursor: ${position.includes('n') ? 'n' : position.includes('s') ? 's' : ''}${position.includes('e') ? 'e' : position.includes('w') ? 'w' : ''}-resize;
              display: none;
              z-index: 15;
            `;
            
            switch(position) {
              case 'nw': handle.style.cssText += 'top: -4px; left: -4px;'; break;
              case 'ne': handle.style.cssText += 'top: -4px; right: -4px;'; break;
              case 'sw': handle.style.cssText += 'bottom: -4px; left: -4px;'; break;
              case 'se': handle.style.cssText += 'bottom: -4px; right: -4px;'; break;
            }
            
            return handle;
          };
          
          const handles = ['nw', 'ne', 'sw', 'se'].map(createResizeHandle);
          
          // Add resize functionality
          let isResizing = false;
          let startX = 0;
          let startY = 0;
          let startWidth = 0;
          let startHeight = 0;
          let currentHandle = '';
          
          handles.forEach((handle, index) => {
            const positions = ['nw', 'ne', 'sw', 'se'];
            const position = positions[index];
            
            handle.onmousedown = (e) => {
              e.preventDefault();
              e.stopPropagation();
              isResizing = true;
              currentHandle = position;
              startX = e.clientX;
              startY = e.clientY;
              startWidth = imageElement.offsetWidth;
              startHeight = imageElement.offsetHeight;
              
              document.addEventListener('mousemove', handleResize);
              document.addEventListener('mouseup', stopResize);
            };
          });
          
          const handleResize = (e: MouseEvent) => {
            if (!isResizing) return;
            
            const deltaX = e.clientX - startX;
            let newWidth = startWidth;
            
            switch(currentHandle) {
              case 'se':
              case 'ne':
                newWidth = startWidth + deltaX;
                break;
              case 'sw':
              case 'nw':
                newWidth = startWidth - deltaX;
                break;
            }
            
            newWidth = Math.max(100, Math.min(800, newWidth));
            imageElement.style.width = newWidth + 'px';
            imageElement.style.height = 'auto';
            
            form.setValue('content', contentTextareaRef?.innerHTML || '');
          };
          
          const stopResize = () => {
            isResizing = false;
            document.removeEventListener('mousemove', handleResize);
            document.removeEventListener('mouseup', stopResize);
          };
          
          // Add delete functionality
          deleteBtn.onclick = (e) => {
            e.preventDefault();
            e.stopPropagation();
            container.remove();
            form.setValue('content', contentTextareaRef?.innerHTML || '');
          };
          
          // Control visibility functions
          const showControls = () => {
            deleteBtn.style.display = 'block';
            handles.forEach(handle => handle.style.display = 'block');
            container.style.border = '2px solid #3b82f6';
            container.style.boxShadow = '0 0 0 1px rgba(59, 130, 246, 0.3)';
          };
          
          const hideControls = () => {
            deleteBtn.style.display = 'none';
            handles.forEach(handle => handle.style.display = 'none');
            container.style.border = '2px solid transparent';
            container.style.boxShadow = 'none';
          };
          
          // Image click handling is now done by the content area click handler
          
          // Container hover effects
          container.onmouseenter = () => {
            if (!container.classList.contains('selected')) {
              container.style.border = '2px solid rgba(59, 130, 246, 0.5)';
            }
          };
          
          container.onmouseleave = () => {
            if (!container.classList.contains('selected')) {
              hideControls();
            }
          };
          
          // Wrap the image
          imageElement.parentNode?.insertBefore(container, imageElement);
          container.appendChild(imageElement);
          container.appendChild(deleteBtn);
          handles.forEach(handle => container.appendChild(handle));
        }
      });
    }
  }, [form, contentTextareaRef]);

  // Handle contentEditable changes
  const handleContentChange = (e: React.FormEvent<HTMLDivElement>) => {
    const target = e.target as HTMLDivElement;
    form.setValue('content', target.innerHTML);
  };

  // Handle cursor position updates
  const updateCursorPosition = () => {
    // Update cursor position for contentEditable
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      setCursorPosition(range.startOffset);
    }
  };

  // Format text functions for contentEditable
  const executeCommand = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    // Update form value after command
    if (contentTextareaRef) {
      form.setValue('content', contentTextareaRef.innerHTML);
    }
  };

  const applyBold = () => executeCommand('bold');
  const applyItalic = () => executeCommand('italic');
  const applyUnderline = () => executeCommand('underline');
  
  const applyFontSize = (size: string) => {
    setSelectedFontSize(size);
    executeCommand('fontSize', '3'); // Reset to default first
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      if (!range.collapsed) {
        const span = document.createElement('span');
        span.style.fontSize = `${size}px`;
        try {
          range.surroundContents(span);
        } catch (e) {
          span.appendChild(range.extractContents());
          range.insertNode(span);
        }
        form.setValue('content', contentTextareaRef?.innerHTML || '');
      }
    }
  };
  
  const applyFontFamily = (font: string) => {
    setSelectedFontFamily(font);
    executeCommand('fontName', font);
  };
  
  const applyTextColor = (color: string) => {
    setSelectedTextColor(color);
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      if (!range.collapsed) {
        const span = document.createElement('span');
        span.style.color = color;
        try {
          range.surroundContents(span);
        } catch (e) {
          span.appendChild(range.extractContents());
          range.insertNode(span);
        }
        form.setValue('content', contentTextareaRef?.innerHTML || '');
        // Restore selection
        selection.removeAllRanges();
        const newRange = document.createRange();
        newRange.selectNodeContents(span);
        selection.addRange(newRange);
      }
    }
  };

  const insertHeading = (level: number) => {
    executeCommand('formatBlock', `h${level}`);
  };

  // Advanced formatting functions
  const formatText = (command: string, value?: string) => {
    document.execCommand(command, false, value);
    if (contentTextareaRef) {
      form.setValue('content', contentTextareaRef.innerHTML);
    }
  };

  const alignText = (alignment: string) => {
    // Clear all alignments first
    document.execCommand('justifyLeft', false);
    document.execCommand('justifyCenter', false);
    document.execCommand('justifyRight', false);
    document.execCommand('justifyFull', false);
    
    // Apply the desired alignment
    document.execCommand(`justify${alignment}`, false);
    if (contentTextareaRef) {
      form.setValue('content', contentTextareaRef.innerHTML);
    }
  };

  const insertList = (ordered: boolean) => {
    formatText(ordered ? 'insertOrderedList' : 'insertUnorderedList');
  };

  const insertQuote = () => {
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const blockquote = document.createElement('blockquote');
      blockquote.style.cssText = 'border-left: 4px solid #e5e7eb; padding-left: 16px; margin: 16px 0; font-style: italic; color: #6b7280;';
      
      if (range.collapsed) {
        blockquote.innerHTML = 'Enter your quote here...';
      } else {
        blockquote.appendChild(range.extractContents());
      }
      
      range.insertNode(blockquote);
      form.setValue('content', contentTextareaRef?.innerHTML || '');
    }
  };

  const insertCode = () => {
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const code = document.createElement('code');
      code.style.cssText = 'background-color: #f3f4f6; padding: 2px 4px; border-radius: 4px; font-family: monospace; font-size: 14px;';
      
      if (range.collapsed) {
        code.innerHTML = 'code';
      } else {
        code.appendChild(range.extractContents());
      }
      
      range.insertNode(code);
      form.setValue('content', contentTextareaRef?.innerHTML || '');
    }
  };

  const insertLink = () => {
    const url = prompt('Enter URL:');
    if (url) {
      const text = window.getSelection()?.toString() || 'Link text';
      formatText('createLink', url);
    }
  };

  // Emoji insertion function
  const insertEmoji = (emoji: string) => {
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const textNode = document.createTextNode(emoji);
      range.insertNode(textNode);
      range.setStartAfter(textNode);
      range.setEndAfter(textNode);
      selection.removeAllRanges();
      selection.addRange(range);
      form.setValue('content', contentTextareaRef?.innerHTML || '');
    }
    setShowEmojiPicker(false);
  };

  // Common emojis for travel blogs
  const commonEmojis = [
    '✈️', '🌍', '🌎', '🌏', '🗺️', '🏖️', '🏔️', '🏝️', '🌅', '🌄',
    '🎭', '🏛️', '🗽', '🏰', '🕌', '⛩️', '🎨', '🍽️', '🍷', '☕',
    '📸', '💡', '⭐', '🌟', '💎', '🎯', '🔥', '💫', '✨', '🎉',
    '👍', '❤️', '💖', '😍', '🤩', '😎', '🥳', '💪', '🙌', '👏',
    '🚗', '🚢', '🚁', '🎒', '🧳', '🎫', '💰', '📅', '⏰', '🌞'
  ];

  // Image manipulation functions
  const rotateImage = (degrees: number) => {
    if (selectedImage) {
      const currentRotation = parseInt(selectedImage.getAttribute('data-rotation') || '0');
      const newRotation = currentRotation + degrees;
      selectedImage.style.transform = `rotate(${newRotation}deg)`;
      selectedImage.setAttribute('data-rotation', newRotation.toString());
      form.setValue('content', contentTextareaRef?.innerHTML || '');
    }
  };

  const resizeImage = (scale: number) => {
    if (selectedImage) {
      const currentWidth = selectedImage.offsetWidth || 300;
      const newWidth = Math.max(100, Math.min(800, currentWidth * scale));
      selectedImage.style.width = `${newWidth}px`;
      selectedImage.style.height = 'auto';
      form.setValue('content', contentTextareaRef?.innerHTML || '');
    }
  };

  // Template system
  const blogTemplates = [
    {
      id: 'destination-guide',
      name: 'Destination Guide',
      preview: 'Perfect for detailed destination overviews',
      content: `
        <h1>Ultimate Guide to [Destination Name]</h1>
        <p><em>Discover the magic of [destination] with our comprehensive travel guide.</em></p>
        
        <h2>🌟 Highlights</h2>
        <ul>
          <li>Top attraction 1</li>
          <li>Top attraction 2</li>
          <li>Top attraction 3</li>
        </ul>
        
        <h2>📍 Best Areas to Stay</h2>
        <p>Add your recommendations for the best neighborhoods and accommodations...</p>
        
        <h2>🍽️ Local Cuisine</h2>
        <p>Describe must-try local dishes and restaurant recommendations...</p>
        
        <h2>🚗 Getting Around</h2>
        <p>Transportation tips and options...</p>
        
        <h2>💰 Budget Tips</h2>
        <p>Money-saving advice and cost expectations...</p>
        
        <h2>📅 Best Time to Visit</h2>
        <p>Seasonal recommendations and weather information...</p>
      `
    },
    {
      id: 'travel-tips',
      name: 'Travel Tips & Advice',
      preview: 'Great for sharing expert travel advice',
      content: `
        <h1>[Number] Essential Travel Tips for [Type of Travel]</h1>
        <p><em>Expert advice to make your next trip unforgettable.</em></p>
        
        <h2>✈️ Planning Phase</h2>
        <h3>Tip 1: [Planning Tip Title]</h3>
        <p>Detailed explanation of your first tip...</p>
        
        <h3>Tip 2: [Planning Tip Title]</h3>
        <p>Detailed explanation of your second tip...</p>
        
        <h2>🎒 Packing Essentials</h2>
        <h3>Tip 3: [Packing Tip Title]</h3>
        <p>Packing advice and recommendations...</p>
        
        <h2>🏨 During Your Trip</h2>
        <h3>Tip 4: [Travel Tip Title]</h3>
        <p>On-the-ground advice for travelers...</p>
        
        <blockquote>
          Pro Tip: Add your expert insider knowledge here that clients wouldn't find in guidebooks.
        </blockquote>
        
        <h2>📝 Final Thoughts</h2>
        <p>Wrap up with encouraging words and your contact information...</p>
      `
    },
    {
      id: 'itinerary',
      name: 'Sample Itinerary',
      preview: 'Perfect for showcasing trip planning skills',
      content: `
        <h1>[Number] Days in [Destination]: The Perfect Itinerary</h1>
        <p><em>A carefully crafted itinerary for an unforgettable [destination] experience.</em></p>
        
        <h2>📅 Day 1: Arrival & First Impressions</h2>
        <h3>Morning (9:00 AM - 12:00 PM)</h3>
        <ul>
          <li>Activity 1</li>
          <li>Activity 2</li>
        </ul>
        
        <h3>Afternoon (1:00 PM - 5:00 PM)</h3>
        <ul>
          <li>Activity 3</li>
          <li>Activity 4</li>
        </ul>
        
        <h3>Evening (6:00 PM onwards)</h3>
        <ul>
          <li>Dinner recommendation</li>
          <li>Evening activity</li>
        </ul>
        
        <h2>📅 Day 2: [Theme of the Day]</h2>
        <p>Repeat the same structure for additional days...</p>
        
        <h2>💡 Insider Tips</h2>
        <ul>
          <li>Local tip 1</li>
          <li>Local tip 2</li>
          <li>Local tip 3</li>
        </ul>
        
        <h2>💰 Estimated Costs</h2>
        <p>Breakdown of expected expenses...</p>
      `
    },
    {
      id: 'personal-story',
      name: 'Personal Travel Story',
      preview: 'Share your authentic travel experiences',
      content: `
        <h1>My [Memorable/Challenging/Amazing] Journey to [Destination]</h1>
        <p><em>Sometimes the best travel stories come from unexpected moments...</em></p>
        
        <h2>🌍 Setting the Scene</h2>
        <p>Describe the context of your trip - why you went, when, who you were with...</p>
        
        <h2>✈️ The Journey Begins</h2>
        <p>Share the beginning of your adventure...</p>
        
        <h2>🎯 The Turning Point</h2>
        <p>Describe the key moment or experience that made this trip memorable...</p>
        
        <blockquote>
          "Include a memorable quote from your trip or a reflection on what you learned."
        </blockquote>
        
        <h2>📸 Unforgettable Moments</h2>
        <p>Share specific experiences, encounters, or discoveries...</p>
        
        <h2>🎓 What I Learned</h2>
        <p>Reflect on insights gained from this experience...</p>
        
        <h2>💭 Final Reflections</h2>
        <p>Wrap up with how this experience shapes your approach to travel planning for clients...</p>
      `
    },
    {
      id: 'comparison',
      name: 'Destination Comparison',
      preview: 'Compare multiple destinations or options',
      content: `
        <h1>[Destination A] vs [Destination B]: Which Should You Choose?</h1>
        <p><em>A detailed comparison to help you make the perfect choice for your next adventure.</em></p>
        
        <h2>🏖️ [Destination A]</h2>
        <h3>Best For:</h3>
        <ul>
          <li>Type of traveler 1</li>
          <li>Type of traveler 2</li>
        </ul>
        
        <h3>Highlights:</h3>
        <ul>
          <li>Key attraction 1</li>
          <li>Key attraction 2</li>
          <li>Key attraction 3</li>
        </ul>
        
        <h3>Budget Range:</h3>
        <p>Cost expectations and value for money...</p>
        
        <h2>🏔️ [Destination B]</h2>
        <h3>Best For:</h3>
        <ul>
          <li>Type of traveler 1</li>
          <li>Type of traveler 2</li>
        </ul>
        
        <h3>Highlights:</h3>
        <ul>
          <li>Key attraction 1</li>
          <li>Key attraction 2</li>
          <li>Key attraction 3</li>
        </ul>
        
        <h3>Budget Range:</h3>
        <p>Cost expectations and value for money...</p>
        
        <h2>⚖️ The Verdict</h2>
        <p>Choose [Destination A] if you want...</p>
        <p>Choose [Destination B] if you prefer...</p>
        
        <h2>🤝 Need Help Deciding?</h2>
        <p>Contact me for personalised recommendations based on your preferences...</p>
      `
    }
  ];

  const applyTemplate = (template: typeof blogTemplates[0]) => {
    if (contentTextareaRef) {
      contentTextareaRef.innerHTML = template.content.trim();
      form.setValue('content', template.content.trim());
      // Clear excerpt so it doesn't get auto-populated from template content
      form.setValue('excerpt', '');
      setShowTemplates(false);
      toast({
        title: "Template Applied",
        description: `${template.name} template has been applied. Customize it with your content!`,
      });
    }
  };

  // Auto-save functionality
  const autoSaveMutation = useMutation({
    mutationFn: async (data: BlogPostFormData) => {
      const currentContent = contentTextareaRef?.innerHTML || data.content || '';
      
      const formData = new FormData();
      formData.append('title', data.title || '');
      formData.append('excerpt', data.excerpt || '');
      formData.append('content', currentContent);
      formData.append('status', 'draft');
      formData.append('holidayTypes', JSON.stringify(selectedHolidayTypes));
      formData.append('destinations', JSON.stringify(selectedDestinations));
      
      if (data.heroImageFile) {
        formData.append('heroImage', data.heroImageFile);
      }

      return fetch(`/api/agents/blog${existingPost ? `/${existingPost.id}` : ''}`, {
        method: existingPost ? 'PUT' : 'POST',
        body: formData,
        headers: {
          'Authorization': `Bearer ${localStorage.getItem('agentToken')}`,
        },
      }).then(res => res.json());
    },
    onMutate: () => {
      setAutoSaveStatus('saving');
    },
    onSuccess: () => {
      setAutoSaveStatus('saved');
      setLastAutoSave(new Date());
      queryClient.invalidateQueries({ queryKey: ["/api/agents/blog"] });
      
      // Reset status after 2 seconds
      setTimeout(() => setAutoSaveStatus('idle'), 2000);
    },
    onError: () => {
      setAutoSaveStatus('error');
      setTimeout(() => setAutoSaveStatus('idle'), 3000);
    },
  });

  // Auto-save every 15 seconds
  useEffect(() => {
    const autoSaveInterval = setInterval(() => {
      const data = form.getValues();
      const currentContent = contentTextareaRef?.innerHTML || '';
      
      // Only auto-save if there's meaningful content
      if (data.title?.trim() && currentContent?.trim()) {
        autoSaveMutation.mutate({ ...data, content: currentContent });
      }
    }, 15000); // 15 seconds

    return () => clearInterval(autoSaveInterval);
  }, [form, selectedHolidayTypes, selectedDestinations, contentTextareaRef]);

  // Auto-generate excerpt from content (but not from template placeholders)
  useEffect(() => {
    const content = form.watch('content');
    if (content && !form.getValues('excerpt')) {
      // Remove HTML tags and template placeholders
      const plainText = content
        .replace(/<[^>]*>/g, '') // Remove HTML tags
        .replace(/\[.*?\]/g, '') // Remove template placeholders like [Destination Name]
        .replace(/!\[.*?\]\(.*?\)/g, '') // Remove markdown images
        .replace(/[#*_]/g, '') // Remove markdown formatting
        .replace(/\s+/g, ' ') // Normalize whitespace
        .trim();
      
      // Only generate excerpt if there's meaningful content (not just template text)
      if (plainText && plainText.length > 20 && !plainText.includes('Add your') && !plainText.includes('Describe') && !plainText.includes('...')) {
        const excerpt = plainText.substring(0, 150).trim() + (plainText.length > 150 ? '...' : '');
        form.setValue('excerpt', excerpt);
      }
    }
  }, [form.watch('content')]);

  const onSubmit = (data: BlogPostFormData) => {
    // Get the latest content from contentEditable
    const currentContent = contentTextareaRef?.innerHTML || '';
    form.setValue('content', currentContent);
    createBlogMutation.mutate({ ...data, content: currentContent });
  };

  // Handle save as draft
  const handleSaveDraft = () => {
    // Get the latest content from contentEditable
    const currentContent = contentTextareaRef?.innerHTML || '';
    form.setValue('content', currentContent);
    
    const data = form.getValues();
    if (!data.title?.trim()) {
      toast({
        title: "Title Required",
        description: "Please enter a title for your blog post.",
        variant: "destructive",
      });
      return;
    }
    
    if (!currentContent?.trim()) {
      toast({
        title: "Content Required",
        description: "Please add some content to your blog post.",
        variant: "destructive",
      });
      return;
    }
    
    form.setValue('status', 'draft');
    form.setValue('holidayTypes', selectedHolidayTypes);
    form.setValue('destinations', selectedDestinations);
    createBlogMutation.mutate({ ...data, content: currentContent, status: 'draft' });
  };

  // Handle publish
  const handlePublish = () => {
    // Get the latest content from contentEditable
    const currentContent = contentTextareaRef?.innerHTML || '';
    form.setValue('content', currentContent);
    
    const data = form.getValues();
    if (!data.title?.trim() || !currentContent?.trim()) {
      toast({
        title: "Required Fields Missing",
        description: "Please fill in title and content before publishing.",
        variant: "destructive",
      });
      return;
    }
    
    if (selectedHolidayTypes.length === 0 || selectedDestinations.length === 0) {
      toast({
        title: "Tags Required",
        description: "Please select at least one holiday type and destination before publishing.",
        variant: "destructive",
      });
      return;
    }
    
    form.setValue('status', 'published');
    form.setValue('holidayTypes', selectedHolidayTypes);
    form.setValue('destinations', selectedDestinations);
    createBlogMutation.mutate({ ...data, content: currentContent, status: 'published' });
  };

  // Preview component
  const BlogPreview = () => {
    const formData = form.getValues();
    return (
      <div className="space-y-6">
        {/* Hero Section */}
        {heroImagePreview && (
          <div className="relative h-64 rounded-lg overflow-hidden">
            <img
              src={heroImagePreview}
              alt={formData.title}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-black/40 flex items-end">
              <div className="p-6 text-white">
                <h1 className="text-3xl font-bold mb-2">{formData.title || "Blog Title"}</h1>
                <p className="text-gray-200">{formData.excerpt || "Blog excerpt will appear here..."}</p>
              </div>
            </div>
          </div>
        )}

        {/* Tags */}
        <div className="flex flex-wrap gap-2">
          {selectedHolidayTypes.map((type) => (
            <Badge key={type} className="bg-green-100 text-green-800">
              {type}
            </Badge>
          ))}
          {selectedDestinations.map((dest) => (
            <Badge key={dest} className="bg-blue-100 text-blue-800">
              {dest}
            </Badge>
          ))}
        </div>

        {/* Content */}
        <div className="prose max-w-none">
          <div 
            className="whitespace-pre-wrap"
            dangerouslySetInnerHTML={{ 
              __html: formData.content || "Your blog content will appear here..." 
            }}
          />
        </div>

        {/* Status */}
        <div className="border-t pt-4">
          <Badge variant={formData.status === 'published' ? 'default' : 'secondary'}>
            {formData.status === 'published' ? 'Published' : 'Draft'}
          </Badge>
        </div>
      </div>
    );
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="flex items-center gap-4">
            <CardTitle className="flex items-center">
              <FileText className="w-5 h-5 mr-2" />
              {existingPost ? 'Edit Blog Post' : 'Create New Blog Post'}
            </CardTitle>
            
            {/* Auto-save status indicator */}
            <div className="flex items-center text-sm">
              {autoSaveStatus === 'saving' && (
                <span className="text-blue-600 flex items-center">
                  <div className="animate-spin w-3 h-3 border border-blue-600 border-t-transparent rounded-full mr-2"></div>
                  Saving...
                </span>
              )}
              {autoSaveStatus === 'saved' && (
                <span className="text-green-600 flex items-center">
                  <div className="w-3 h-3 bg-green-600 rounded-full mr-2"></div>
                  Saved
                </span>
              )}
              {autoSaveStatus === 'error' && (
                <span className="text-red-600 flex items-center">
                  <div className="w-3 h-3 bg-red-600 rounded-full mr-2"></div>
                  Save failed
                </span>
              )}
              {lastAutoSave && autoSaveStatus === 'idle' && (
                <span className="text-gray-500">
                  Last saved: {lastAutoSave.toLocaleTimeString()}
                </span>
              )}
            </div>
          </div>
          
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </CardHeader>
        
        <CardContent>
          {showPreview ? (
            <div>
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-lg font-semibold">Blog Preview</h3>
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setShowPreview(false)}
                >
                  <FileText className="w-4 h-4 mr-2" />
                  Back to Editor
                </Button>
              </div>
              <BlogPreview />
            </div>
          ) : (
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              {/* Hero Image Upload */}
              <div className="space-y-2">
                <FormLabel>Hero Image</FormLabel>
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4">
                  {heroImagePreview ? (
                    <div className="relative">
                      <img
                        src={heroImagePreview}
                        alt="Hero preview"
                        className="w-full h-48 object-cover rounded-lg"
                      />
                      <Button
                        type="button"
                        variant="destructive"
                        size="sm"
                        className="absolute top-2 right-2"
                        onClick={() => {
                          setHeroImagePreview(null);
                          form.setValue('heroImageFile', undefined);
                        }}
                      >
                        <X className="w-4 h-4" />
                      </Button>
                    </div>
                  ) : (
                    <div className="text-center">
                      <ImageIcon className="w-12 h-12 mx-auto text-gray-400 mb-2" />
                      <p className="text-sm text-gray-600 mb-2">Choose a hero image for your blog post</p>
                      <Input
                        type="file"
                        accept="image/*"
                        onChange={handleHeroImageChange}
                        className="max-w-xs mx-auto"
                      />
                    </div>
                  )}
                </div>
              </div>

              {/* Title */}
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Title</FormLabel>
                    <FormControl>
                      <Input placeholder="Enter blog post title..." {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Excerpt */}
              <FormField
                control={form.control}
                name="excerpt"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Excerpt</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Brief description (auto-generated from content if left empty)..." 
                        rows={2}
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Content */}
              <FormField
                control={form.control}
                name="content"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Content</FormLabel>
                    
                    {/* Comprehensive Rich Text Formatting Toolbar */}
                    <div className="border rounded-lg p-3 bg-gray-50 space-y-3">
                      {/* Templates Row */}
                      <div className="flex items-center gap-2 pb-2 border-b">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => setShowTemplates(!showTemplates)}
                          className="bg-purple-50 hover:bg-purple-100 border-purple-200 h-8"
                        >
                          <Layout className="w-4 h-4 mr-1" />
                          Templates
                        </Button>
                        {showTemplates && (
                          <div className="flex gap-1 flex-wrap">
                            {blogTemplates.map((template) => (
                              <Button
                                key={template.id}
                                type="button"
                                variant="ghost"
                                size="sm"
                                onClick={() => applyTemplate(template)}
                                className="h-7 px-2 text-xs border"
                                title={template.preview}
                              >
                                {template.name}
                              </Button>
                            ))}
                          </div>
                        )}
                      </div>

                      {/* Row 1: Basic Formatting */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <div className="flex items-center border-r pr-2 mr-2">
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={applyBold}
                            className="h-8 w-8 p-0"
                            title="Bold"
                          >
                            <Bold className="w-4 h-4" />
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={applyItalic}
                            className="h-8 w-8 p-0 ml-1"
                            title="Italic"
                          >
                            <Italic className="w-4 h-4" />
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={applyUnderline}
                            className="h-8 w-8 p-0 ml-1"
                            title="Underline"
                          >
                            <Underline className="w-4 h-4" />
                          </Button>
                        </div>

                        {/* Text Alignment */}
                        <div className="flex items-center border-r pr-2 mr-2">
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => alignText('Left')}
                            className="h-8 w-8 p-0"
                            title="Align Left"
                          >
                            <AlignLeft className="w-4 h-4" />
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => alignText('Center')}
                            className="h-8 w-8 p-0 ml-1"
                            title="Align Center"
                          >
                            <AlignCenter className="w-4 h-4" />
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => alignText('Right')}
                            className="h-8 w-8 p-0 ml-1"
                            title="Align Right"
                          >
                            <AlignRight className="w-4 h-4" />
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => alignText('Full')}
                            className="h-8 w-8 p-0 ml-1"
                            title="Justify"
                          >
                            <AlignJustify className="w-4 h-4" />
                          </Button>
                        </div>

                        {/* Lists */}
                        <div className="flex items-center border-r pr-2 mr-2">
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => insertList(false)}
                            className="h-8 w-8 p-0"
                            title="Bullet List"
                          >
                            <List className="w-4 h-4" />
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={() => insertList(true)}
                            className="h-8 w-8 p-0 ml-1"
                            title="Numbered List"
                          >
                            <ListOrdered className="w-4 h-4" />
                          </Button>
                        </div>

                        {/* Special Elements */}
                        <div className="flex items-center gap-1">
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={insertQuote}
                            className="h-8 w-8 p-0"
                            title="Quote"
                          >
                            <Quote className="w-4 h-4" />
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={insertCode}
                            className="h-8 w-8 p-0"
                            title="Code"
                          >
                            <Code className="w-4 h-4" />
                          </Button>
                          <Button
                            type="button"
                            variant="outline"
                            size="sm"
                            onClick={insertLink}
                            className="h-8 w-8 p-0"
                            title="Insert Link"
                          >
                            <Link className="w-4 h-4" />
                          </Button>
                          <div className="relative">
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => setShowEmojiPicker(!showEmojiPicker)}
                              className="h-8 w-8 p-0"
                              title="Insert Emoji"
                            >
                              <Smile className="w-4 h-4" />
                            </Button>
                            {showEmojiPicker && (
                              <div className="absolute top-10 left-0 z-50 bg-white border rounded-lg shadow-lg p-2 w-72">
                                <div className="text-xs text-gray-600 mb-2 font-medium">Travel Emojis</div>
                                <div className="grid grid-cols-10 gap-1 max-h-32 overflow-y-auto">
                                  {commonEmojis.map((emoji, index) => (
                                    <button
                                      key={index}
                                      type="button"
                                      onClick={() => insertEmoji(emoji)}
                                      className="w-6 h-6 text-sm hover:bg-gray-100 rounded flex items-center justify-center"
                                      title={emoji}
                                    >
                                      {emoji}
                                    </button>
                                  ))}
                                </div>
                                <div className="mt-2 pt-2 border-t">
                                  <div className="text-xs text-gray-500">Click any emoji to insert it at your cursor position</div>
                                </div>
                              </div>
                            )}
                          </div>
                        </div>
                      </div>

                      {/* Row 2: Typography and Styling */}
                      <div className="flex items-center gap-2 flex-wrap">
                        {/* Font Size */}
                        <div className="flex items-center gap-1">
                          <Type className="w-4 h-4 text-gray-600" />
                          <Select value={selectedFontSize} onValueChange={applyFontSize}>
                            <SelectTrigger className="w-20 h-8">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="12">12px</SelectItem>
                              <SelectItem value="14">14px</SelectItem>
                              <SelectItem value="16">16px</SelectItem>
                              <SelectItem value="18">18px</SelectItem>
                              <SelectItem value="20">20px</SelectItem>
                              <SelectItem value="24">24px</SelectItem>
                              <SelectItem value="28">28px</SelectItem>
                              <SelectItem value="32">32px</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {/* Font Family */}
                        <div className="flex items-center gap-1">
                          <Select value={selectedFontFamily} onValueChange={applyFontFamily}>
                            <SelectTrigger className="w-32 h-8">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Arial">Arial</SelectItem>
                              <SelectItem value="Helvetica">Helvetica</SelectItem>
                              <SelectItem value="Times New Roman">Times</SelectItem>
                              <SelectItem value="Georgia">Georgia</SelectItem>
                              <SelectItem value="Verdana">Verdana</SelectItem>
                              <SelectItem value="Courier New">Courier</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        {/* Text Color */}
                        <div className="flex items-center gap-1">
                          <Palette className="w-4 h-4 text-gray-600" />
                          <input
                            type="color"
                            value={selectedTextColor}
                            onChange={(e) => applyTextColor(e.target.value)}
                            className="w-8 h-8 border rounded cursor-pointer"
                            title="Text Color"
                          />
                        </div>

                        {/* Headings */}
                        <div className="flex items-center border-l pl-2 ml-2">
                          <span className="text-xs text-gray-600 mr-2">Headings:</span>
                          {[1, 2, 3, 4].map((level) => (
                            <Button
                              key={level}
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => insertHeading(level)}
                              className="h-8 px-2 ml-1 text-xs"
                              title={`Heading ${level}`}
                            >
                              H{level}
                            </Button>
                          ))}
                        </div>
                      </div>

                      {/* Row 3: Media and Tools */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={insertImageAtCursor}
                          className="bg-blue-50 hover:bg-blue-100 border-blue-200 h-8"
                        >
                          <ImageIcon className="w-4 h-4 mr-1" />
                          Insert Image
                        </Button>

                        {/* Image Controls - Only show when image is selected */}
                        {selectedImage && (
                          <div className="flex items-center gap-1 border-l pl-2 ml-2">
                            <span className="text-xs text-gray-600 mr-2">Image:</span>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => rotateImage(-90)}
                              className="h-8 w-8 p-0"
                              title="Rotate Left"
                            >
                              <RotateCw className="w-4 h-4 transform rotate-180" />
                            </Button>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => rotateImage(90)}
                              className="h-8 w-8 p-0"
                              title="Rotate Right"
                            >
                              <RotateCw className="w-4 h-4" />
                            </Button>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => resizeImage(0.8)}
                              className="h-8 w-8 p-0"
                              title="Smaller"
                            >
                              <ZoomOut className="w-4 h-4" />
                            </Button>
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              onClick={() => resizeImage(1.2)}
                              className="h-8 w-8 p-0"
                              title="Larger"
                            >
                              <ZoomIn className="w-4 h-4" />
                            </Button>
                          </div>
                        )}
                      </div>
                    </div>
                    <FormControl>
                      <div
                        ref={(ref) => {
                          setContentTextareaRef(ref);
                          if (ref && field.value && ref.innerHTML !== field.value) {
                            ref.innerHTML = field.value;
                          }
                        }}
                        contentEditable
                        className="min-h-[400px] font-sans text-sm leading-relaxed border border-gray-300 rounded-md p-3 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        style={{ minHeight: '400px' }}
                        onInput={handleContentChange}
                        onKeyDown={(e) => {
                          // Handle Delete/Backspace for selected images
                          if ((e.key === 'Delete' || e.key === 'Backspace')) {
                            const selection = window.getSelection();
                            if (selection && selection.rangeCount > 0) {
                              const range = selection.getRangeAt(0);
                              const element = range.commonAncestorContainer;
                              
                              // Check if cursor is positioned on an image container
                              let imageContainer = null;
                              if (element.nodeType === Node.ELEMENT_NODE) {
                                imageContainer = (element as Element).closest('.image-container');
                              } else if (element.parentElement) {
                                imageContainer = element.parentElement.closest('.image-container');
                              }
                              
                              if (imageContainer) {
                                e.preventDefault();
                                imageContainer.remove();
                                form.setValue('content', contentTextareaRef?.innerHTML || '');
                              }
                            }
                          }
                        }}
                        onKeyUp={updateCursorPosition}
                        onMouseUp={updateCursorPosition}
                        onClick={(e) => {
                          updateCursorPosition();
                          const target = e.target as HTMLElement;
                          
                          console.log('Content area clicked, target:', target.tagName); // Debug log
                          
                          // Handle image selection directly here
                          if (target.tagName === 'IMG') {
                            console.log('Image clicked - handling selection');
                            e.preventDefault();
                            e.stopPropagation();
                            
                            const imageElement = target as HTMLImageElement;
                            let container = imageElement.closest('.image-container') as HTMLElement;
                            
                            // If image is not in a container, wrap it
                            if (!container) {
                              console.log('Image not in container, wrapping...');
                              container = document.createElement('div');
                              container.className = 'image-container';
                              
                              // Wrap the image
                              imageElement.parentNode?.insertBefore(container, imageElement);
                              container.appendChild(imageElement);
                            }
                            
                            // Remove selection from other images
                            document.querySelectorAll('.image-container').forEach(otherContainer => {
                              if (otherContainer !== container) {
                                otherContainer.classList.remove('selected');
                              }
                            });
                            
                            // Add selected class - CSS will handle the visual controls
                            container.classList.add('selected');
                            setSelectedImage(imageElement);
                            console.log('Image selected - CSS controls should now be visible');
                            return;
                          } else if (!target.closest('.image-container')) {
                            // Clicking elsewhere deselects all images
                            console.log('Deselecting all images');
                            setSelectedImage(null);
                            document.querySelectorAll('.image-container').forEach(container => {
                              container.classList.remove('selected');
                            });
                          }
                          // Close emoji picker when clicking in content area
                          setShowEmojiPicker(false);
                        }}
                        suppressContentEditableWarning={true}
                        data-placeholder="Write your blog content here... 

Use the formatting toolbar above to style your text with different fonts, sizes, colors, and headings.

For example:
- Click 'B' then select text to make it bold
- Select text and click color picker to change colors
- Click 'H1' to create large headings
- Click 'Insert Image' to add photos anywhere

Start writing your amazing travel content!"
                      />
                    </FormControl>
                    <div className="text-xs text-gray-500 space-y-1">
                      <div>💡 <strong>Pro tip:</strong> Select text and use the formatting buttons above, or position your cursor and click to insert formatted text</div>
                      <div>🎨 Use the toolbar to style your content with different fonts, sizes, colors, and headings</div>
                      <div>💾 <strong>Auto-save:</strong> Your work is automatically saved every 15 seconds as a draft</div>
                    </div>
                    <FormMessage />
                  </FormItem>
                )}
              />

              {/* Tags Section */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Holiday Types */}
                <div className="space-y-2">
                  <FormLabel>Holiday Types</FormLabel>
                  <Select onValueChange={(value) => {
                    if (!selectedHolidayTypes.includes(value)) {
                      setSelectedHolidayTypes([...selectedHolidayTypes, value]);
                    }
                  }}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select holiday types..." />
                    </SelectTrigger>
                    <SelectContent>
                      {holidayTypes?.sort((a, b) => a.name.localeCompare(b.name)).map((type) => (
                        <SelectItem key={type.id} value={type.name}>
                          {type.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <div className="flex flex-wrap gap-2">
                    {selectedHolidayTypes.map((type) => (
                      <Badge key={type} variant="secondary" className="bg-green-100 text-green-800">
                        {type}
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="ml-1 h-auto p-0"
                          onClick={() => setSelectedHolidayTypes(prev => prev.filter(t => t !== type))}
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </Badge>
                    ))}
                  </div>
                </div>

                {/* Destinations */}
                <div className="space-y-2">
                  <FormLabel>Destinations</FormLabel>
                  <Select onValueChange={(value) => {
                    if (!selectedDestinations.includes(value)) {
                      setSelectedDestinations([...selectedDestinations, value]);
                    }
                  }}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select destinations..." />
                    </SelectTrigger>
                    <SelectContent>
                      {destinations?.sort((a, b) => a.name.localeCompare(b.name)).map((dest) => (
                        <SelectItem key={dest.id} value={dest.name}>
                          {dest.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <div className="flex flex-wrap gap-2">
                    {selectedDestinations.map((dest) => (
                      <Badge key={dest} variant="secondary" className="bg-blue-100 text-blue-800">
                        {dest}
                        <Button
                          type="button"
                          variant="ghost"
                          size="sm"
                          className="ml-1 h-auto p-0"
                          onClick={() => setSelectedDestinations(prev => prev.filter(d => d !== dest))}
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>

              {/* Status and Actions */}
              <div className="flex items-center justify-between pt-4 border-t">
                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <SelectTrigger className="w-32">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="draft">Draft</SelectItem>
                          <SelectItem value="published">Published</SelectItem>
                        </SelectContent>
                      </Select>
                    </FormItem>
                  )}
                />
                
                <div className="flex space-x-2">
                  <Button type="button" variant="outline" onClick={onClose}>
                    Cancel
                  </Button>
                  <Button 
                    type="button" 
                    variant="outline"
                    onClick={() => setShowPreview(true)}
                  >
                    <Eye className="w-4 h-4 mr-2" />
                    Preview
                  </Button>
                  <Button 
                    type="button"
                    variant="outline"
                    onClick={handleSaveDraft}
                    disabled={createBlogMutation.isPending}
                  >
                    {createBlogMutation.isPending ? (
                      <>Saving...</>
                    ) : (
                      <>
                        <Save className="w-4 h-4 mr-2" />
                        Save Draft
                      </>
                    )}
                  </Button>
                  <Button 
                    type="button"
                    onClick={handlePublish}
                    disabled={createBlogMutation.isPending}
                    className="bg-roamah-orange hover:bg-roamah-orange/90"
                  >
                    {createBlogMutation.isPending ? (
                      <>Publishing...</>
                    ) : (
                      <>
                        <Upload className="w-4 h-4 mr-2" />
                        Publish
                      </>
                    )}
                  </Button>
                </div>
              </div>
              </form>
            </Form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}