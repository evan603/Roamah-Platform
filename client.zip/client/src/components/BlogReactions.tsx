import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { apiRequest } from "@/lib/queryClient";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

// Travel-themed emoji reactions for blog posts
const AVAILABLE_EMOJIS = [
  { emoji: "❤️", label: "Love" },
  { emoji: "👍", label: "Like" },
  { emoji: "🤩", label: "Amazing" },
  { emoji: "🔥", label: "Fire" },
  { emoji: "✈️", label: "Wanderlust" },
  { emoji: "🎉", label: "Celebrate" },
];

interface BlogReactionsProps {
  blogPostId: number;
  userId?: string;
}

interface ReactionData {
  emoji: string;
  count: number;
  userReacted: boolean;
}

export function BlogReactions({ blogPostId, userId }: BlogReactionsProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Generate a session-based userId for anonymous users
  const [sessionUserId] = useState(() => {
    if (userId) return userId;
    
    // Try to get existing session ID from localStorage
    let sessionId = localStorage.getItem('roamah-session-id');
    if (!sessionId) {
      // Generate a new session ID
      sessionId = `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem('roamah-session-id', sessionId);
    }
    return sessionId;
  });

  // Fetch reactions for this blog post
  const { data: reactions = [], isLoading } = useQuery<ReactionData[]>({
    queryKey: [`/api/blog/${blogPostId}/reactions`, sessionUserId],
    queryFn: () => apiRequest(`/api/blog/${blogPostId}/reactions?userId=${sessionUserId}`),
  });

  // Add reaction mutation
  const addReactionMutation = useMutation({
    mutationFn: async (emoji: string) => {
      return apiRequest(`/api/blog/${blogPostId}/reactions`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emoji, userId: sessionUserId }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/blog/${blogPostId}/reactions`] });
      toast({
        title: "Reaction added!",
        description: "Your reaction has been recorded.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to add reaction. Please try again.",
        variant: "destructive",
      });
    },
  });

  // Remove reaction mutation
  const removeReactionMutation = useMutation({
    mutationFn: async (emoji: string) => {
      return apiRequest(`/api/blog/${blogPostId}/reactions`, {
        method: 'DELETE',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ emoji, userId: sessionUserId }),
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: [`/api/blog/${blogPostId}/reactions`] });
      toast({
        title: "Reaction removed",
        description: "Your reaction has been removed.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to remove reaction. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleReactionClick = (emoji: string) => {
    const existingReaction = reactions.find(r => r.emoji === emoji);
    
    if (existingReaction?.userReacted) {
      // User already reacted with this emoji, remove it
      removeReactionMutation.mutate(emoji);
    } else {
      // Add new reaction
      addReactionMutation.mutate(emoji);
    }
  };

  if (isLoading) {
    return (
      <Card className="p-4">
        <div className="text-sm text-gray-600 mb-3">Loading reactions...</div>
      </Card>
    );
  }

  // Get reaction counts for display
  const reactionCounts = new Map(reactions.map(r => [r.emoji, r]));

  return (
    <Card className="p-6 bg-gradient-to-r from-blue-50 to-orange-50 border-orange-200">
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-roamah-dark mb-1">What did you think?</h3>
        <p className="text-sm text-gray-600">Share your reaction to this travel story</p>
      </div>
      
      <div className="flex flex-wrap gap-3">
        {AVAILABLE_EMOJIS.map(({ emoji, label }) => {
          const reactionData = reactionCounts.get(emoji);
          const count = reactionData?.count || 0;
          const userReacted = reactionData?.userReacted || false;
          
          return (
            <Button
              key={emoji}
              variant={userReacted ? "default" : "outline"}
              size="sm"
              onClick={() => handleReactionClick(emoji)}
              disabled={addReactionMutation.isPending || removeReactionMutation.isPending}
              className={`flex items-center gap-2 px-3 py-2 text-sm transition-all duration-200 hover:scale-105 ${
                userReacted 
                  ? "bg-roamah-orange hover:bg-roamah-orange/90 text-white shadow-lg border-roamah-orange" 
                  : "hover:bg-white hover:shadow-md border-gray-200 hover:border-roamah-orange/50"
              }`}
              title={label}
            >
              <span className="text-lg">{emoji}</span>
              <span className={`text-xs font-medium ${userReacted ? 'text-white' : 'text-gray-600'}`}>
                {label}
              </span>
              {count > 0 && (
                <span className={`text-xs px-1.5 py-0.5 rounded-full ${
                  userReacted 
                    ? 'bg-white/20 text-white' 
                    : 'bg-gray-100 text-gray-700'
                }`}>
                  {count}
                </span>
              )}
            </Button>
          );
        })}
      </div>

      {/* Summary of total reactions */}
      {reactions.length > 0 && (
        <div className="mt-4 pt-4 border-t border-orange-200">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="flex -space-x-1">
                {reactions.slice(0, 4).map((reaction) => (
                  <span 
                    key={reaction.emoji}
                    className="inline-flex items-center justify-center w-6 h-6 bg-white border-2 border-orange-200 rounded-full text-xs shadow-sm"
                  >
                    {reaction.emoji}
                  </span>
                ))}
              </div>
              <span className="text-sm text-gray-600">
                {reactions.reduce((total, r) => total + r.count, 0)} 
                {reactions.reduce((total, r) => total + r.count, 0) === 1 ? ' reaction' : ' reactions'}
              </span>
            </div>
            
            {/* Most popular reaction */}
            {reactions.length > 0 && (
              <div className="text-xs text-gray-500">
                Most popular: {reactions.sort((a, b) => b.count - a.count)[0].emoji}
              </div>
            )}
          </div>
        </div>
      )}
    </Card>
  );
}