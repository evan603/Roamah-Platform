import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { useState, useEffect, useMemo } from "react";
import type { Destination } from "@shared/schema";

export function TrendingDestinations() {
  const [, setLocation] = useLocation();
  const [currentIndex, setCurrentIndex] = useState(0);

  const { data: allDestinations, isLoading } = useQuery<Destination[]>({
    queryKey: ["/api/destinations"],
  });

  // Randomly select 8 destinations on component mount
  const featuredDestinations = useMemo(() => {
    if (!allDestinations || allDestinations.length === 0) return [];
    
    const shuffled = [...allDestinations].sort(() => Math.random() - 0.5);
    return shuffled.slice(0, 8);
  }, [allDestinations]);

  // Auto-scroll every 5 seconds
  useEffect(() => {
    if (featuredDestinations.length === 0) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prev) => {
        // Show 4 destinations at a time, so max index is length - 4
        const maxIndex = Math.max(0, featuredDestinations.length - 4);
        return prev >= maxIndex ? 0 : prev + 1;
      });
    }, 5000);

    return () => clearInterval(interval);
  }, [featuredDestinations.length]);

  const handlePrevious = () => {
    setCurrentIndex((prev) => {
      const maxIndex = Math.max(0, featuredDestinations.length - 4);
      return prev === 0 ? maxIndex : prev - 1;
    });
  };

  const handleNext = () => {
    setCurrentIndex((prev) => {
      const maxIndex = Math.max(0, featuredDestinations.length - 4);
      return prev >= maxIndex ? 0 : prev + 1;
    });
  };

  if (isLoading || featuredDestinations.length === 0) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl font-bold text-roamah-dark mb-8">Trending Destinations</h3>
          <div className="overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              {[1, 2, 3, 4].map((i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gray-200 rounded-2xl h-64"></div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h3 className="text-3xl font-bold text-roamah-dark">Trending Destinations</h3>
          <div className="flex space-x-2">
            <Button variant="outline" size="sm" onClick={handlePrevious}>
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button variant="outline" size="sm" onClick={handleNext}>
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>

        <div className="overflow-hidden">
          <div 
            className="flex transition-transform duration-500 ease-in-out gap-6"
            style={{ 
              transform: `translateX(-${currentIndex * (23 + 1.5)}%)`,
            }}
          >
            {featuredDestinations.map((destination) => (
              <div
                key={destination.id}
                className="flex-shrink-0 w-full md:w-1/2 lg:w-[23%]"
              >
                <div
                  className="relative rounded-2xl overflow-hidden shadow-lg group cursor-pointer transform hover:scale-105 transition-transform"
                  onClick={() => setLocation(`/destination/${destination.slug}`)}
                >
                  <img
                    src={destination.image}
                    alt={destination.name}
                    className="w-full h-[24rem] object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
                  <div className="absolute bottom-4 left-4 text-white">
                    <h4 className="text-xl font-semibold">{destination.name}</h4>
                    <p className="text-sm opacity-90">Over {destination.agentCount} agents</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}