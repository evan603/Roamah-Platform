import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { MultiSelect } from "@/components/ui/multi-select";
import { BUDGET_RANGES } from "@/lib/constants";

export function Newsletter() {
  const { toast } = useToast();
  const [email, setEmail] = useState("");
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  
  // Fetch holiday types and destinations from API
  const { data: holidayTypes } = useQuery<any[]>({
    queryKey: ["/api/holiday-types"],
  });

  const { data: destinations } = useQuery<any[]>({
    queryKey: ["/api/destinations"],
  });
  
  const [detailsData, setDetailsData] = useState({
    firstName: "",
    lastName: "",
    budgetRange: "",
    destinations: [] as string[],
    holidayTypes: [] as string[],
  });

  const subscribeMutation = useMutation({
    mutationFn: async (data: { email: string } & typeof detailsData) => {
      return apiRequest("/api/newsletter/subscribe", {
        method: "POST",
        body: JSON.stringify(data),
        headers: {
          "Content-Type": "application/json",
        },
      });
    },
    onSuccess: () => {
      toast({
        title: "Subscribed!",
        description: "Thank you for subscribing! We'll send you personalised travel inspiration based on your preferences.",
      });
      setEmail("");
      setDetailsData({
        firstName: "",
        lastName: "",
        budgetRange: "",
        destinations: [],
        holidayTypes: [],
      });
      setShowDetailsModal(false);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to subscribe. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleEmailSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!email.trim()) {
      toast({
        title: "Error",
        description: "Email address is required.",
        variant: "destructive",
      });
      return;
    }
    
    // Show details modal
    setShowDetailsModal(true);
  };

  const handleDetailsSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate required fields
    if (!detailsData.firstName.trim()) {
      toast({
        title: "Error",
        description: "First name is required.",
        variant: "destructive",
      });
      return;
    }
    
    if (!detailsData.lastName.trim()) {
      toast({
        title: "Error",
        description: "Surname is required.",
        variant: "destructive",
      });
      return;
    }
    
    if (detailsData.holidayTypes.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one holiday type.",
        variant: "destructive",
      });
      return;
    }
    
    if (detailsData.destinations.length === 0) {
      toast({
        title: "Error",
        description: "Please select at least one destination.",
        variant: "destructive",
      });
      return;
    }
    
    // Submit complete data
    subscribeMutation.mutate({
      email,
      ...detailsData,
    });
  };

  return (
    <>
      <section className="text-white py-16 bg-[#fff3f0]">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold mb-4 text-[#000000]">
            Stay Updated with Our Travel Newsletter
          </h2>
          <p className="text-xl mb-8 text-[#94a3b8]">
            Get the latest travel inspiration and exclusive offers delivered to your inbox
          </p>
          
          <form onSubmit={handleEmailSubmit} className="flex flex-col sm:flex-row gap-4 max-w-lg mx-auto">
            <Input
              type="email"
              placeholder="Enter your email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="flex-1 px-6 py-4 rounded-lg border-0 focus:outline-none focus:ring-2 focus:ring-white/20 text-black placeholder:text-gray-500"
            />
            <Button
              type="submit"
              className="bg-roamah-orange text-white px-8 py-4 rounded-lg font-bold hover:bg-roamah-orange/90 transition-colors"
            >
              Subscribe
            </Button>
          </form>
          
          <p className="text-sm mt-4 text-[#90a1bd]">No spam, unsubscribe anytime</p>
        </div>
      </section>
      {/* Details Collection Modal */}
      <Dialog open={showDetailsModal} onOpenChange={setShowDetailsModal}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Help Us Personalise Your Experience</DialogTitle>
            <DialogDescription>
              We'd love to tailor our special offers and marketing to your interests. 
              This information helps us send you the most relevant travel inspiration.
            </DialogDescription>
          </DialogHeader>
          
          <form onSubmit={handleDetailsSubmit} className="space-y-6 mt-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* First Name */}
              <div>
                <Label htmlFor="firstName" className="text-sm font-semibold mb-2 block">
                  First Name *
                </Label>
                <Input
                  id="firstName"
                  placeholder="Enter your first name"
                  value={detailsData.firstName}
                  onChange={(e) => setDetailsData({ ...detailsData, firstName: e.target.value })}
                  required
                  className="text-black"
                />
              </div>

              {/* Last Name */}
              <div>
                <Label htmlFor="lastName" className="text-sm font-semibold mb-2 block">
                  Surname *
                </Label>
                <Input
                  id="lastName"
                  placeholder="Enter your surname"
                  value={detailsData.lastName}
                  onChange={(e) => setDetailsData({ ...detailsData, lastName: e.target.value })}
                  required
                  className="text-black"
                />
              </div>
            </div>

            {/* Budget Range */}
            <div>
              <Label htmlFor="budgetRange" className="text-sm font-semibold mb-2 block">
                How much do you usually spend per person on a holiday?
              </Label>
              <Select value={detailsData.budgetRange} onValueChange={(value) => setDetailsData({ ...detailsData, budgetRange: value })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select your typical budget range" />
                </SelectTrigger>
                <SelectContent>
                  {BUDGET_RANGES.map((range) => (
                    <SelectItem key={range} value={range}>
                      {range}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            {/* Holiday Types */}
            <div>
              <Label className="text-sm font-semibold mb-2 block">
                What holiday types do you currently enjoy or would like to try? *
              </Label>
              <MultiSelect
                options={holidayTypes?.map(type => type.name) || []}
                selected={detailsData.holidayTypes}
                onChange={(selectedHolidayTypes) => setDetailsData({ ...detailsData, holidayTypes: selectedHolidayTypes })}
                placeholder="Select holiday types that interest you"
              />
            </div>

            {/* Destinations */}
            <div>
              <Label className="text-sm font-semibold mb-2 block">
                Which destinations interest you? *
              </Label>
              <MultiSelect
                options={destinations?.map(dest => dest.name) || []}
                selected={detailsData.destinations}
                onChange={(selectedDestinations) => setDetailsData({ ...detailsData, destinations: selectedDestinations })}
                placeholder="Select destinations you'd like to visit"
              />
            </div>

            <div className="flex gap-3 pt-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => {
                  // Allow skipping - just submit with email only
                  subscribeMutation.mutate({
                    email,
                    firstName: detailsData.firstName || "Newsletter",
                    lastName: detailsData.lastName || "Subscriber",
                    budgetRange: detailsData.budgetRange || "",
                    destinations: [],
                    holidayTypes: [],
                  });
                }}
                className="flex-1"
              >
                Skip for now
              </Button>
              <Button
                type="submit"
                disabled={subscribeMutation.isPending}
                className="flex-1 bg-roamah-orange hover:bg-roamah-orange/90"
              >
                {subscribeMutation.isPending ? "Subscribing..." : "Complete Subscription"}
              </Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </>
  );
}
