import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Search, Crown, Heart, Ship, Umbrella, Camera } from "lucide-react";
import { useLocation } from "wouter";
import { DESTINATIONS } from "@/lib/constants";

const holidayTypes = [
  { name: "Luxury Holidays", icon: Crown, color: "text-purple-500" },
  { name: "Honeymoons", icon: Heart, color: "text-red-500" },
  { name: "Cruises", icon: Ship, color: "text-teal-500" },
  { name: "Beach Holidays", icon: Umbrella, color: "text-yellow-500" },
  { name: "Safari Holidays", icon: Camera, color: "text-orange-500" },
];

export function HeroSection() {
  const [searchQuery, setSearchQuery] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [filteredDestinations, setFilteredDestinations] = useState<string[]>([]);
  const [, setLocation] = useLocation();
  const searchContainerRef = useRef<HTMLDivElement>(null);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      // Check if the search query matches a destination
      const matchingDestination = DESTINATIONS.find(dest => 
        dest.toLowerCase() === searchQuery.trim().toLowerCase()
      );
      
      if (matchingDestination) {
        // Navigate to the specific destination page
        setLocation(`/destination/${matchingDestination.toLowerCase().replace(/\s+/g, '-')}`);
      } else {
        // Fall back to agent search
        setLocation(`/browse-agents?search=${encodeURIComponent(searchQuery.trim())}`);
      }
    }
    setShowSuggestions(false);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setSearchQuery(value);
    
    if (value.length >= 2) {
      const filtered = DESTINATIONS.filter(dest =>
        dest.toLowerCase().includes(value.toLowerCase())
      );
      setFilteredDestinations(filtered);
      setShowSuggestions(filtered.length > 0);
    } else {
      setShowSuggestions(false);
      setFilteredDestinations([]);
    }
  };

  const handleSuggestionClick = (destination: string) => {
    setSearchQuery(destination);
    setShowSuggestions(false);
    setLocation(`/destination/${destination.toLowerCase().replace(/\s+/g, '-')}`);
  };

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchContainerRef.current && !searchContainerRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  const handleHolidayTypeClick = (typeName: string) => {
    // Convert holiday type name to slug format for navigation
    const slug = typeName.toLowerCase().replace(/\s+/g, '-');
    setLocation(`/holiday-type/${slug}`);
  };

  return (
    <section className="bg-roamah-peach py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 className="text-4xl md:text-5xl font-bold text-roamah-dark mb-6">
          The perfect holiday from the travel experts
        </h2>
        <p className="text-xl text-roamah-gray mb-12 max-w-3xl mx-auto">The best holidays in the world from travel agents that have travelled there. Find your travel expert by typing where you want to go or by choosing your holiday type from the options below</p>
        
        {/* Search Bar */}
        <div className="max-w-2xl mx-auto mb-8 relative" ref={searchContainerRef}>
          <form onSubmit={handleSearch}>
            <div className="flex rounded-lg shadow-lg overflow-hidden">
              <Input
                type="text"
                placeholder="Try 'Dubai'"
                value={searchQuery}
                onChange={handleInputChange}
                onFocus={() => {
                  if (filteredDestinations.length > 0 && searchQuery.length >= 2) {
                    setShowSuggestions(true);
                  }
                }}
                className="flex-1 px-6 py-4 text-lg border-0 focus:outline-none rounded-none"
              />
              <Button
                type="submit"
                className="bg-roamah-orange hover:bg-roamah-orange/90 px-8 py-4 rounded-none font-bold"
              >
                <Search className="h-4 w-4 mr-2" />
                Search
              </Button>
            </div>
          </form>
          
          {/* Autocomplete Suggestions */}
          {showSuggestions && filteredDestinations.length > 0 && (
            <div className="absolute top-full left-0 right-0 bg-white border border-gray-200 rounded-b-lg shadow-lg z-50 max-h-60 overflow-y-auto">
              {filteredDestinations.map((destination, index) => (
                <button
                  key={destination}
                  onClick={() => handleSuggestionClick(destination)}
                  className="w-full px-6 py-3 text-left hover:bg-gray-50 focus:bg-gray-50 focus:outline-none border-b border-gray-100 last:border-b-0"
                >
                  <div className="flex items-center">
                    <Search className="h-4 w-4 mr-3 text-gray-400" />
                    <span className="text-gray-900">{destination}</span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Holiday Type Filters */}
        <div className="flex flex-wrap justify-center gap-4 mb-8">
          {holidayTypes.map((type) => {
            const IconComponent = type.icon;
            return (
              <Button
                key={type.name}
                variant="secondary"
                className="bg-white text-roamah-dark px-6 py-3 rounded-full shadow-sm hover:shadow-md transition-all font-bold"
                onClick={() => handleHolidayTypeClick(type.name)}
              >
                <IconComponent className={`h-4 w-4 mr-2 ${type.color}`} />
                {type.name}
              </Button>
            );
          })}
        </div>

        <Button
          variant="outline" 
          className="border-roamah-orange text-roamah-orange hover:bg-roamah-orange hover:text-white font-bold px-8 py-3 pl-[12px] pr-[12px]"
          onClick={() => setLocation("/browse-holiday-types")}
        >View All Holiday Types</Button>
      </div>
    </section>
  );
}
