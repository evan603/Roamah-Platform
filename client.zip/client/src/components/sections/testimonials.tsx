import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { StarRating } from "@/components/ui/star-rating";
import { useState, useEffect, useMemo } from "react";
import { Link } from "wouter";
import type { Review } from "@shared/schema";

export function Testimonials() {
  const [currentIndex, setCurrentIndex] = useState(0);
  
  const { data: reviews, isLoading } = useQuery<Review[]>({
    queryKey: ["/api/reviews"],
  });

  // Memoize the selection to prevent re-shuffling on every render
  const selectedReviews = useMemo(() => {
    if (!reviews) return [];
    
    // Filter for 5-star reviews only, then randomly select up to 15
    const fiveStarReviews = reviews.filter(review => review.rating === 5);
    const shuffled = [...fiveStarReviews].sort(() => Math.random() - 0.5);
    const selected = shuffled.slice(0, 15);
    
    console.log(`Testimonials: ${fiveStarReviews.length} five-star reviews available, showing ${selected.length}`);
    return selected;
  }, [reviews]);

  // Auto-rotate carousel every 5 seconds
  useEffect(() => {
    if (!selectedReviews || selectedReviews.length <= 3) return;

    const interval = setInterval(() => {
      setCurrentIndex((prev) => {
        const maxIndex = Math.max(0, selectedReviews.length - 3);
        return prev >= maxIndex ? 0 : prev + 1;
      });
    }, 5000);

    return () => clearInterval(interval);
  }, [selectedReviews]);

  const nextSlide = () => {
    if (!selectedReviews) return;
    const maxIndex = Math.max(0, selectedReviews.length - 3);
    setCurrentIndex(prev => prev >= maxIndex ? 0 : prev + 1);
  };

  const prevSlide = () => {
    if (!selectedReviews) return;
    const maxIndex = Math.max(0, selectedReviews.length - 3);
    setCurrentIndex(prev => prev <= 0 ? maxIndex : prev - 1);
  };

  // Get 3 reviews to display based on current index
  const visibleReviews = selectedReviews?.slice(currentIndex, currentIndex + 3) || [];

  if (isLoading) {
    return (
      <section className="py-16 bg-roamah-peach">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl font-bold text-roamah-dark mb-8">What Our Customers Say</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-white rounded-2xl p-6 shadow-lg">
                  <div className="h-6 bg-gray-200 rounded mb-4"></div>
                  <div className="h-20 bg-gray-200 rounded mb-6"></div>
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-gray-200 rounded-full mr-3"></div>
                    <div>
                      <div className="h-4 bg-gray-200 rounded mb-1 w-20"></div>
                      <div className="h-3 bg-gray-200 rounded w-24"></div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="py-16 bg-roamah-peach">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h3 className="text-3xl font-bold text-roamah-dark">What Our Customers Say</h3>
          {selectedReviews && selectedReviews.length > 3 && (
            <div className="flex space-x-2">
              <Button variant="outline" size="sm" onClick={prevSlide}>
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button variant="outline" size="sm" onClick={nextSlide}>
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>

        <div className="relative overflow-hidden">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {visibleReviews.map((review) => {
              // Smart text truncation for consistent card sizing
              let truncatedText = review.reviewText;
              
              // Truncate to ~200 characters for better fit in cards
              if (review.reviewText.length > 200) {
                const words = review.reviewText.split(' ');
                let result = '';
                
                for (let i = 0; i < words.length; i++) {
                  const testText = result + (result ? ' ' : '') + words[i];
                  if (testText.length > 200) break;
                  result = testText;
                }
                
                truncatedText = result.trim() + '...';
              }

              return (
                <div key={review.id} className="bg-white rounded-2xl p-6 shadow-lg h-80 flex flex-col">
                  <div className="mb-4">
                    <StarRating rating={review.rating} showCount={false} />
                  </div>
                  <div className="flex-grow flex flex-col min-h-0">
                    <p className="text-roamah-gray mb-1 leading-relaxed text-sm flex-grow overflow-hidden">
                      "{truncatedText}"
                    </p>
                    <div className="mt-auto">
                      <h5 className="font-semibold text-roamah-dark">{review.customerName}</h5>
                      <p className="text-sm text-roamah-gray mb-1">{review.tripType}</p>
                      <Link href={`/agent/${review.agentId}`}>
                        <span className="text-xs text-roamah-orange font-medium hover:text-roamah-dark cursor-pointer transition-colors duration-200">
                          Travel Expert: {review.agentName || `Agent #${review.agentId}`}
                        </span>
                      </Link>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
          
          {/* Carousel indicators */}
          {selectedReviews && selectedReviews.length > 3 && (
            <div className="flex justify-center mt-8 space-x-2">
              {Array.from({ length: Math.max(1, selectedReviews.length - 2) }, (_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-3 h-3 rounded-full transition-all duration-300 ${
                    currentIndex === index 
                      ? 'bg-roamah-orange shadow-lg scale-110' 
                      : 'bg-gray-300 hover:bg-gray-400'
                  }`}
                />
              ))}
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
