import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { AgentCard } from "@/components/ui/agent-card";
import { EnquiryModal } from "@/components/ui/enquiry-modal";
import { useLocation } from "wouter";
import type { Agent } from "@shared/schema";

export function FeaturedAgents() {
  const [, setLocation] = useLocation();
  const [selectedAgent, setSelectedAgent] = useState<Agent | null>(null);
  const [enquiryModalOpen, setEnquiryModalOpen] = useState(false);
  const [currentIndex, setCurrentIndex] = useState(0);

  const { data: agents, isLoading } = useQuery<Agent[]>({
    queryKey: ["/api/agents/featured"],
  });

  const handleEnquire = (agent: Agent) => {
    setSelectedAgent(agent);
    setEnquiryModalOpen(true);
  };

  // Auto-scroll every 10 seconds, move by 6 agents at a time
  useEffect(() => {
    if (!agents || agents.length === 0) return;
    
    const interval = setInterval(() => {
      setCurrentIndex((prevIndex) => {
        const nextIndex = prevIndex + 6;
        return nextIndex >= agents.length ? 0 : nextIndex;
      });
    }, 10000);

    return () => clearInterval(interval);
  }, [agents]);

  const handlePrevious = () => {
    if (!agents) return;
    setCurrentIndex((prevIndex) => {
      const newIndex = prevIndex - 6;
      return newIndex < 0 ? Math.max(0, agents.length - 6) : newIndex;
    });
  };

  const handleNext = () => {
    if (!agents) return;
    setCurrentIndex((prevIndex) => {
      const nextIndex = prevIndex + 6;
      return nextIndex >= agents.length ? 0 : nextIndex;
    });
  };

  const getVisibleAgents = () => {
    if (!agents || agents.length === 0) return [];
    
    const visibleAgents = [];
    for (let i = 0; i < 6; i++) {
      const index = (currentIndex + i) % agents.length;
      visibleAgents.push(agents[index]);
    }
    return visibleAgents;
  };

  if (isLoading) {
    return (
      <section className="py-16 bg-roamah-peach">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl font-bold text-roamah-dark mb-8">Featured Travel Experts</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-white rounded-2xl p-6">
                  <div className="bg-gray-200 rounded-xl h-48 mb-4"></div>
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                  <div className="h-20 bg-gray-200 rounded mb-4"></div>
                  <div className="h-8 bg-gray-200 rounded"></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  return (
    <>
      <section className="py-16 bg-roamah-peach">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <div>
              <h3 className="text-3xl font-bold text-roamah-dark">Featured Travel Experts</h3>
              {agents && agents.length > 0 && (
                <p className="text-sm text-roamah-dark/70 mt-1">
                  Showing {currentIndex + 1} - {Math.min(currentIndex + 6, agents.length)} of {agents.length}
                </p>
              )}
            </div>
            <div className="flex items-center space-x-2">
              {agents && agents.length > 6 && (
                <div className="flex space-x-1 mr-3">
                  {Array.from({ length: Math.ceil(agents.length / 6) }, (_, i) => (
                    <div
                      key={i}
                      className={`h-2 w-2 rounded-full transition-colors ${
                        Math.floor(currentIndex / 6) === i 
                          ? 'bg-roamah-orange' 
                          : 'bg-gray-300'
                      }`}
                    />
                  ))}
                </div>
              )}
              <Button 
                variant="outline" 
                size="sm"
                onClick={handlePrevious}
                disabled={!agents || agents.length === 0}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button 
                variant="outline" 
                size="sm"
                onClick={handleNext}
                disabled={!agents || agents.length === 0}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {/* Display agents in 2 rows of 3 columns each (6 agents total) */}
          <div className="space-y-8">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {getVisibleAgents().slice(0, 3).map((agent, index) => (
                <AgentCard
                  key={`agent-${agent.id}-${currentIndex}-${index}`}
                  agent={agent}
                  onEnquire={handleEnquire}
                />
              ))}
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {getVisibleAgents().slice(3, 6).map((agent, index) => (
                <AgentCard
                  key={`agent-${agent.id}-${currentIndex}-${index + 3}`}
                  agent={agent}
                  onEnquire={handleEnquire}
                />
              ))}
            </div>
          </div>


          <div className="text-center mt-8">
            <Button
              className="hover:bg-roamah-orange/90 text-[#ff7e57] bg-[#ffffff] font-bold"
              onClick={() => setLocation("/browse-agents")}
            >
              Browse all Travel Experts
            </Button>
          </div>
        </div>
      </section>

      <EnquiryModal
        isOpen={enquiryModalOpen}
        onClose={() => setEnquiryModalOpen(false)}
        agent={selectedAgent}
      />
    </>
  );
}
