import { useQuery } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Star, ChevronLeft, ChevronRight } from "lucide-react";
import { Agent, Offer } from "@shared/schema";
import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { OfferImageCarousel } from "@/components/OfferImageCarousel";

type OfferWithAgent = Offer & { agent: Agent };


export function HolidayOffers() {
  const [, setLocation] = useLocation();
  const { data: offers, isLoading } = useQuery<OfferWithAgent[]>({
    queryKey: ["/api/offers"],
  });
  
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Auto-rotation effect
  useEffect(() => {
    if (!offers || offers.length <= 3 || !isAutoPlaying) return;

    intervalRef.current = setInterval(() => {
      setCurrentIndex((prev) => {
        const maxIndex = Math.max(0, offers.length - 3);
        return prev >= maxIndex ? 0 : prev + 1;
      });
    }, 4000); // 4 seconds

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
      }
    };
  }, [offers, isAutoPlaying]);

  const nextOffers = () => {
    if (!offers || offers.length <= 3) return;
    const maxIndex = Math.max(0, offers.length - 3);
    setCurrentIndex((prev) => prev >= maxIndex ? 0 : prev + 1);
    setIsAutoPlaying(false); // Stop auto-play when user manually navigates
  };

  const prevOffers = () => {
    if (!offers || offers.length <= 3) return;
    const maxIndex = Math.max(0, offers.length - 3);
    setCurrentIndex((prev) => prev <= 0 ? maxIndex : prev - 1);
    setIsAutoPlaying(false); // Stop auto-play when user manually navigates
  };

  const goToIndex = (index: number) => {
    setCurrentIndex(index);
    setIsAutoPlaying(false); // Stop auto-play when user manually navigates
  };

  if (isLoading) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl font-bold text-roamah-dark mb-8">Top Holiday Offers</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-white rounded-2xl overflow-hidden shadow-lg">
                  <div className="bg-gray-200 h-64"></div>
                  <div className="p-6">
                    <div className="h-4 bg-gray-200 rounded mb-2"></div>
                    <div className="h-4 bg-gray-200 rounded w-3/4 mb-4"></div>
                    <div className="h-6 bg-gray-200 rounded w-1/2"></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  if (!offers || offers.length === 0) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-3xl font-bold text-roamah-dark mb-8">Top Holiday Offers</h3>
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">No offers available at the moment</p>
            <p className="text-gray-400 text-sm mt-2">Check back soon for amazing travel deals!</p>
          </div>
        </div>
      </section>
    );
  }

  // Calculate how many slides we need (showing 3 cards at a time)
  const totalSlides = Math.max(1, Math.ceil(offers.length / 3));
  const maxIndex = Math.max(0, offers.length - 3);
  
  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h3 className="text-3xl font-bold text-roamah-dark">Top Holiday Offers</h3>
          
          {/* Manual navigation buttons */}
          {offers.length > 3 && (
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={prevOffers}
                className="h-10 w-10 p-0 rounded-full border-roamah-orange text-roamah-orange hover:bg-roamah-orange hover:text-white"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={nextOffers}
                className="h-10 w-10 p-0 rounded-full border-roamah-orange text-roamah-orange hover:bg-roamah-orange hover:text-white"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
        
        {/* Carousel container */}
        <div className="relative overflow-hidden">
          <div
            className="flex transition-transform duration-500 ease-in-out"
            style={{ transform: `translateX(-${currentIndex * (100 / Math.ceil(offers.length / 3))}%)` }}
          >
            {offers.map((offer) => (
              <div
                key={offer.id}
                className="w-full md:w-1/2 lg:w-1/3 flex-shrink-0 px-3"
              >
                <div className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all group h-full flex flex-col">
                  {/* Hero image carousel */}
                  <OfferImageCarousel offer={offer} />
                  
                  <div className="p-6 flex flex-col flex-grow">
                    {/* Badges */}
                    <div className="flex flex-wrap gap-2 mb-3">
                      {offer.destinations?.map((dest, index) => (
                        <Badge key={`dest-${index}`} className="bg-blue-100 text-blue-800 border-0">
                          <MapPin className="w-3 h-3 mr-1" />
                          {dest}
                        </Badge>
                      ))}
                      {offer.holidayTypes?.map((type, index) => (
                        <Badge key={`type-${index}`} className="bg-green-100 text-green-800 border-0">
                          {type}
                        </Badge>
                      ))}
                    </div>
                    
                    <h4 className="font-bold text-xl text-roamah-dark mb-2 line-clamp-2">
                      {offer.title}
                    </h4>
                    
                    <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                      {offer.briefDescription}
                    </p>
                    
                    {/* Offer messages as bullet points */}
                    <div className="mb-4 space-y-1 flex-grow">
                      {offer.offerMessage1 && (
                        <div className="flex items-start text-sm text-gray-700">
                          <span className="w-1.5 h-1.5 bg-roamah-orange rounded-full mr-2 mt-1.5 flex-shrink-0"></span>
                          <span className="line-clamp-1">{offer.offerMessage1}</span>
                        </div>
                      )}
                      {offer.offerMessage2 && (
                        <div className="flex items-start text-sm text-gray-700">
                          <span className="w-1.5 h-1.5 bg-roamah-orange rounded-full mr-2 mt-1.5 flex-shrink-0"></span>
                          <span className="line-clamp-1">{offer.offerMessage2}</span>
                        </div>
                      )}
                      {offer.offerMessage3 && (
                        <div className="flex items-start text-sm text-gray-700">
                          <span className="w-1.5 h-1.5 bg-roamah-orange rounded-full mr-2 mt-1.5 flex-shrink-0"></span>
                          <span className="line-clamp-1">{offer.offerMessage3}</span>
                        </div>
                      )}
                    </div>
                    
                    {/* Agent info */}
                    <div className="flex items-center gap-3 mb-4 pt-3 border-t border-gray-100 mt-auto">
                      <img
                        src={offer.agent?.profileImage || "/api/placeholder/40/40"}
                        alt={`${offer.agent?.firstName} ${offer.agent?.lastName}`}
                        className="w-10 h-10 rounded-full object-cover"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-semibold text-roamah-dark text-sm truncate">
                          {offer.agent?.firstName} {offer.agent?.lastName}
                        </p>
                        <div className="flex items-center gap-1 text-xs text-gray-500">
                          <MapPin className="w-3 h-3" />
                          <span className="truncate">{offer.agent?.location}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 text-xs text-yellow-600">
                        <Star className="w-3 h-3 fill-current" />
                        <span>{offer.agent?.rating || '5.0'}</span>
                      </div>
                    </div>
                    
                    <Button 
                      className="w-full bg-roamah-orange hover:bg-roamah-orange/90 text-white font-semibold"
                      onClick={() => setLocation(`/offer/${offer.id}`)}
                    >
                      View Offer Details
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        {/* Dots indicator */}
        {offers.length > 3 && (
          <div className="flex justify-center gap-2 mt-6">
            {Array.from({ length: Math.ceil(maxIndex + 1) }, (_, index) => (
              <button
                key={index}
                onClick={() => goToIndex(index)}
                className={`w-3 h-3 rounded-full transition-all ${
                  currentIndex === index
                    ? 'bg-roamah-orange scale-110'
                    : 'bg-gray-300 hover:bg-gray-400'
                }`}
              />
            ))}
          </div>
        )}
        
        {/* View all offers button */}
        <div className="text-center mt-8">
          <Button 
            variant="outline" 
            size="lg" 
            className="border-roamah-orange text-roamah-orange hover:bg-roamah-orange hover:text-white font-bold px-8"
            onClick={() => setLocation("/browse-offers")}
          >
            View All Offers
          </Button>
        </div>
      </div>
    </section>
  );
}