import { useQuery } from "@tanstack/react-query";
import { ArrowRight } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import type { BlogPost, Agent } from "@shared/schema";

type BlogPostWithAgent = BlogPost & { agent: Agent };

export function BlogSection() {
  const { data: blogPosts, isLoading } = useQuery<BlogPostWithAgent[]>({
    queryKey: ["/api/blog"],
  });

  if (isLoading) {
    return (
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center mb-8">
            <h3 className="text-3xl font-bold text-roamah-dark">Get Inspired</h3>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[1, 2, 3].map((i) => (
              <div key={i} className="animate-pulse">
                <div className="bg-white rounded-2xl overflow-hidden shadow-lg">
                  <div className="bg-gray-200 h-48"></div>
                  <div className="p-6">
                    <div className="h-4 bg-gray-200 rounded mb-3"></div>
                    <div className="h-6 bg-gray-200 rounded mb-4"></div>
                    <div className="h-16 bg-gray-200 rounded mb-4"></div>
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-gray-200 rounded-full mr-3"></div>
                      <div>
                        <div className="h-4 bg-gray-200 rounded mb-1 w-20"></div>
                        <div className="h-3 bg-gray-200 rounded w-16"></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    );
  }

  const formatDate = (date: string | Date) => {
    const d = new Date(date);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - d.getTime());
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays === 1) return "1 day ago";
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 14) return "1 week ago";
    return `${Math.ceil(diffDays / 7)} weeks ago`;
  };

  return (
    <section className="py-16 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center mb-8">
          <h3 className="text-3xl font-bold text-roamah-dark">Get Inspired</h3>
          <Link href="/blogs">
            <Button variant="ghost" className="text-roamah-orange font-bold flex items-center hover:text-roamah-orange/80">
              View more blogs <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {blogPosts?.slice(0, 3).map((post) => (
            <article key={post.id} className="bg-white rounded-2xl overflow-hidden shadow-lg hover:shadow-xl transition-all group h-full flex flex-col">
              <Link href={`/blog/${post.slug}`} className="flex-grow">
                <div className="cursor-pointer flex flex-col h-full">
                  <img
                    src={post.heroImage ?? 'https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=600&h=400&fit=crop'}
                    alt={post.title}
                    className="w-full h-48 object-cover group-hover:scale-105 transition-transform"
                  />
                  <div className="p-6 flex-grow">
                    {/* Display holiday types and destinations as tags */}
                    <div className="flex flex-wrap gap-2 mb-3">
                      {post.holidayTypes && post.holidayTypes.slice(0, 2).map((type) => (
                        <Badge key={type} variant="secondary" className="bg-green-100 text-green-800 text-xs">
                          {type}
                        </Badge>
                      ))}
                      {post.destinations && post.destinations.slice(0, 1).map((dest) => (
                        <Badge key={dest} variant="secondary" className="bg-blue-100 text-blue-800 text-xs">
                          {dest}
                        </Badge>
                      ))}
                      {(!post.holidayTypes || post.holidayTypes.length === 0) && 
                       (!post.destinations || post.destinations.length === 0) && (
                        <Badge variant="secondary" className="bg-green-100 text-green-800">
                          Travel Tips
                        </Badge>
                      )}
                    </div>
                    <h4 className="text-xl font-semibold text-roamah-dark mb-3 group-hover:text-roamah-orange transition-colors">
                      {post.title}
                    </h4>
                    <p className="text-roamah-gray mb-4">{post.excerpt}</p>
                  </div>
                </div>
              </Link>
              <div className="px-6 pb-6 mt-auto">
                <Link href={`/agent/${post.agent.id}`}>
                  <div className="flex items-center cursor-pointer hover:opacity-80 transition-opacity">
                    <img
                      src={post.agent.profileImage ?? 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face'}
                      alt={post.agent.name ?? 'Agent'}
                      className="w-10 h-10 rounded-full mr-3 aspect-square object-cover"
                    />
                    <div>
                      <p className="text-sm font-semibold text-roamah-dark hover:text-roamah-orange transition-colors">{post.agent.name ?? 'Travel Expert'}</p>
                      <p className="text-xs text-roamah-gray">
                        {post.publishedAt ? formatDate(post.publishedAt) : formatDate(post.createdAt)}
                      </p>
                    </div>
                  </div>
                </Link>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
