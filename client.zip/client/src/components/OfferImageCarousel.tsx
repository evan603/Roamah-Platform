import { ChevronLeft, ChevronRight } from "lucide-react";
import { useState } from "react";
import type { Offer } from "@shared/schema";

interface OfferImageCarouselProps {
  offer: Offer & { agent?: any };
}

export function OfferImageCarousel({ offer }: OfferImageCarouselProps) {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  
  // Get all available images (prioritize images array, fallback to heroImage)
  const images = offer.images && offer.images.length > 0 
    ? offer.images 
    : offer.heroImage 
    ? [offer.heroImage] 
    : [];
    
  const hasMultipleImages = images.length > 1;

  const nextImage = () => {
    setCurrentImageIndex((prev) => (prev + 1) % images.length);
  };

  const prevImage = () => {
    setCurrentImageIndex((prev) => (prev - 1 + images.length) % images.length);
  };

  return (
    <div className="relative h-64 overflow-hidden">
      {images.length > 0 ? (
        <>
          <img
            src={images[currentImageIndex]}
            alt={offer.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
          />
          
          {/* Image navigation */}
          {hasMultipleImages && (
            <>
              <button
                onClick={prevImage}
                className="absolute left-2 top-1/2 -translate-y-1/2 bg-black/50 text-white rounded-full w-8 h-8 flex items-center justify-center hover:bg-black/70 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" />
              </button>
              <button
                onClick={nextImage}
                className="absolute right-2 top-1/2 -translate-y-1/2 bg-black/50 text-white rounded-full w-8 h-8 flex items-center justify-center hover:bg-black/70 transition-colors"
              >
                <ChevronRight className="w-4 h-4" />
              </button>
              
              {/* Image dots indicator */}
              <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1">
                {images.map((_, index) => (
                  <button
                    key={index}
                    onClick={() => setCurrentImageIndex(index)}
                    className={`w-2 h-2 rounded-full transition-colors ${
                      index === currentImageIndex ? 'bg-white' : 'bg-white/50'
                    }`}
                  />
                ))}
              </div>
            </>
          )}
        </>
      ) : (
        <div className="w-full h-full bg-gradient-to-r from-roamah-dark to-roamah-orange flex items-center justify-center">
          <div className="text-white text-center">
            <h4 className="text-xl font-bold">{offer.title}</h4>
          </div>
        </div>
      )}
      
      {/* Price overlay */}
      <div className="absolute top-4 left-4">
        <div className="bg-roamah-orange text-white px-3 py-1 rounded-full font-bold text-sm">
          {offer.fromPrice}
        </div>
      </div>
    </div>
  );
}