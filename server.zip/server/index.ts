import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";
import { storage } from "./storage";
import { initializeEmailTemplates } from "./email-templates-data";
import { processSurveyResponses } from './mailchimp-survey-integration';

const app = express();
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: false, limit: '50mb' }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  console.log("🚀 Starting Roamah application...");
  console.log("📝 Environment:", process.env.NODE_ENV || 'development');
  console.log("🔌 Port:", process.env.PORT || '5000');
  console.log("🔑 Environment variables loaded:", Object.keys(process.env).filter(k => !k.includes('SECRET') && !k.includes('PASSWORD')).length);
  
  try {
    const server = await registerRoutes(app);
    console.log("✅ Routes registered successfully");

  // Initialize email templates on startup
  try {
    await initializeEmailTemplates();
  } catch (error) {
    console.error("Error initializing email templates:", error);
  }

  // Start automation processor for persistent tag cleanup and review requests
  try {
    const { startAutomationProcessor } = await import("./mailchimp-automation");
    startAutomationProcessor();
  } catch (error) {
    console.error("Error starting automation processor:", error);
  }

  // Set up periodic check for expired offers (every hour)
  setInterval(async () => {
    try {
      await storage.checkAndUpdateExpiredOffers();
      console.log("Checked for expired offers");
    } catch (error) {
      console.error("Error checking expired offers:", error);
    }
  }, 60 * 60 * 1000); // 1 hour

  // Set up periodic survey response processing (every 15 minutes)
  setInterval(async () => {
    try {
      await processSurveyResponses();
    } catch (error) {
      console.error("Error processing survey responses:", error);
    }
  }, 15 * 60 * 1000); // 15 minutes

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on the port specified in the environment variable PORT
  // Other ports are firewalled. Default to 5000 if not specified.
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = parseInt(process.env.PORT || '5000', 10);
    
    // Ensure server starts and binds properly
    await new Promise<void>((resolve, reject) => {
      const serverInstance = server.listen(port, "0.0.0.0", () => {
        console.log(`🌟 Roamah server running on port ${port}`);
        console.log(`🔗 Access at: http://localhost:${port}`);
        if (process.env.NODE_ENV === 'production') {
          console.log(`🌐 Production URL: https://roamah.replit.app`);
        }
        log(`serving on port ${port}`);
        resolve();
      });
      
      serverInstance.on('error', (err) => {
        console.error(`❌ Server failed to start on port ${port}:`, err);
        reject(err);
      });
      
      // Set a timeout to ensure the server starts within a reasonable time
      setTimeout(() => {
        console.log(`✅ Server startup completed on port ${port}`);
      }, 1000);
    });
  } catch (error: any) {
    console.error("❌ Failed to start Roamah application:", error);
    console.error("Stack trace:", error.stack);
    console.error("Environment check:");
    console.error("- NODE_ENV:", process.env.NODE_ENV || 'undefined');
    console.error("- PORT:", process.env.PORT || 'undefined');
    console.error("- DATABASE_URL:", process.env.DATABASE_URL ? 'configured' : 'missing');
    process.exit(1);
  }
})();
