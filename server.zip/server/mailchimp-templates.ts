import { storage } from "./storage";

interface MailchimpTemplate {
  id: number;
  name: string;
  type: string;
  thumbnail: string;
  date_created: string;
  date_edited: string;
  folder_id?: string;
  content_type: string;
}

interface MailchimpTemplateContent {
  html: string;
  text?: string;
  error?: string;
}

export class MailchimpTemplateManager {
  private apiKey: string;
  private serverPrefix: string;

  constructor() {
    this.apiKey = process.env.MAILCHIMP_MARKETING_API_KEY || '';
    this.serverPrefix = process.env.MAILCHIMP_SERVER_PREFIX || '';
  }

  /**
   * Get all templates from Mailchimp
   */
  async getTemplates(): Promise<MailchimpTemplate[]> {
    try {
      const response = await fetch(`https://${this.serverPrefix}.api.mailchimp.com/3.0/templates`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        throw new Error(`Mailchimp API error: ${response.status}`);
      }

      const data = await response.json();
      
      // Log all templates for debugging
      console.log('All Mailchimp templates:', JSON.stringify(data.templates, null, 2));
      
      // Filter to only show user-created saved templates (not defaults or system templates)
      const savedTemplates = (data.templates || []).filter((template: any) => {
        // Only include templates that are:
        // 1. User-created (type: 'user' only - excludes Mailchimp's base templates)
        // 2. Have been explicitly saved with a meaningful name
        const isUserCreated = template.type === 'user';
        const hasValidName = template.name && 
                            template.name.trim().length > 0 &&
                            !template.name.toLowerCase().includes('untitled') &&
                            !template.name.toLowerCase().includes('draft') &&
                            template.name !== 'New Template';
        
        console.log(`Template "${template.name}" - Type: ${template.type}, User Created: ${isUserCreated}, Valid Name: ${hasValidName}, Final: ${isUserCreated && hasValidName}`);
        
        return isUserCreated && hasValidName;
      });
      
      return savedTemplates;
    } catch (error) {
      console.error('Error fetching Mailchimp templates:', error);
      return [];
    }
  }

  /**
   * Get specific template content from Mailchimp
   */
  async getTemplateContent(templateId: number): Promise<MailchimpTemplateContent | null> {
    try {
      const response = await fetch(`https://${this.serverPrefix}.api.mailchimp.com/3.0/templates/${templateId}/default-content`, {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${this.apiKey}`,
          'Content-Type': 'application/json'
        }
      });

      if (!response.ok) {
        console.error(`Template ${templateId} content fetch failed with status: ${response.status}`);
        // Some template types (multichannel) don't support content retrieval via API
        if (response.status === 500) {
          return {
            html: '',
            text: '',
            error: 'Template content not accessible via API'
          } as MailchimpTemplateContent;
        }
        throw new Error(`Mailchimp API error: ${response.status}`);
      }

      const data = await response.json();
      return {
        html: data.html || '',
        text: data.text || ''
      };
    } catch (error) {
      console.error('Error fetching Mailchimp template content:', error);
      return null;
    }
  }

  /**
   * Sync Mailchimp templates to our database
   */
  async syncTemplates(): Promise<{ synced: number; errors: string[] }> {
    const results = { synced: 0, errors: [] as string[] };

    try {
      const mailchimpTemplates = await this.getTemplates();
      
      for (const template of mailchimpTemplates) {
        try {
          // Get template content
          const content = await this.getTemplateContent(template.id);
          
          if (content) {
            // Create or update in our database
            await storage.upsertEmailTemplate({
              id: `mailchimp-${template.id}`,
              type: 'transactional',
              name: template.name,
              subject: `Template: ${template.name}`,
              htmlContent: content.html,
              textContent: content.text || this.extractTextFromHtml(content.html),
              description: `Synced from Mailchimp template (ID: ${template.id})`,
              isActive: true
            });
            
            results.synced++;
          }
        } catch (error) {
          results.errors.push(`Failed to sync template ${template.name}: ${error.message}`);
        }
      }
    } catch (error) {
      results.errors.push(`Failed to fetch templates: ${error.message}`);
    }

    return results;
  }

  /**
   * Send email using Mailchimp template
   */
  async sendTemplateEmail(templateId: number, to: string, variables: Record<string, any>): Promise<boolean> {
    try {
      const response = await fetch(`https://mandrillapp.com/api/1.0/messages/send-template.json`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          key: process.env.MAILCHIMP_API_KEY,
          template_name: `template-${templateId}`,
          template_content: [],
          message: {
            to: [{ email: to }],
            global_merge_vars: Object.entries(variables).map(([name, content]) => ({
              name: name.toUpperCase(),
              content
            }))
          }
        })
      });

      if (!response.ok) {
        throw new Error(`Mandrill API error: ${response.status}`);
      }

      const result = await response.json();
      return result && result[0] && result[0].status === 'sent';
    } catch (error) {
      console.error('Error sending template email:', error);
      return false;
    }
  }

  /**
   * Extract plain text from HTML content
   */
  private extractTextFromHtml(html: string): string {
    return html
      .replace(/<[^>]*>/g, '') // Remove HTML tags
      .replace(/\s+/g, ' ')    // Replace multiple spaces with single space
      .trim();
  }
}

// Get template content with variable replacement
export async function getTemplateWithVariables(templateId: string, variables: Record<string, string>): Promise<{ html: string; subject: string }> {
  try {
    console.log(`📧 Getting Mailchimp template ${templateId} with variables:`, variables);
    
    const manager = new MailchimpTemplateManager();
    
    // Get the template's default content
    const response = await fetch(`https://${process.env.MAILCHIMP_SERVER_PREFIX}.api.mailchimp.com/3.0/templates/${templateId}/default-content`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${process.env.MAILCHIMP_MARKETING_API_KEY}`,
        'Content-Type': 'application/json'
      }
    });

    if (!response.ok) {
      throw new Error(`Failed to get template content: ${response.status}`);
    }

    const templateContent = await response.json();
    console.log('Template content response:', JSON.stringify(templateContent, null, 2));
    
    let htmlContent = '';
    let subject = 'Your Roamah Travel Experience - Please Share Your Feedback';
    
    // Extract HTML content based on template structure
    if (templateContent.html) {
      htmlContent = templateContent.html;
    } else if (templateContent.sections) {
      // For multichannel templates, content is in sections
      Object.values(templateContent.sections).forEach((section: any) => {
        if (section.html) {
          htmlContent += section.html;
        }
      });
    }
    
    // Replace variables in the HTML content
    Object.entries(variables).forEach(([key, value]) => {
      const placeholder = `{{${key}}}`;
      htmlContent = htmlContent.replace(new RegExp(placeholder, 'g'), value);
      subject = subject.replace(new RegExp(placeholder, 'g'), value);
    });
    
    console.log(`✅ Template content processed for template ${templateId}`);
    return { html: htmlContent, subject };
    
  } catch (error) {
    console.error(`❌ Error getting template ${templateId}:`, error);
    throw error;
  }
}

export const mailchimpTemplateManager = new MailchimpTemplateManager();