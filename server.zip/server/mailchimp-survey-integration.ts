import { storage } from './storage';
import crypto from 'crypto';

const MAILCHIMP_API_KEY = process.env.MAILCHIMP_MARKETING_API_KEY;
const SERVER_PREFIX = process.env.MAILCHIMP_SERVER_PREFIX || 'us21';
const AUDIENCE_ID = '0534ef6593'; // Your main audience ID
const SURVEY_ID = '7ab5b5ac07';

// For testing purposes, let's create a review directly when we detect the tag
// since the survey API endpoints are having issues
async function createTestReview(email: string, enquiryId: number): Promise<void> {
  console.log(`🔧 Creating test review for ${email} and enquiry ${enquiryId}`);
  
  try {
    // Get the enquiry details
    const allEnquiries = await storage.getAllEnquiriesWithAgentNames();
    const enquiry = allEnquiries.find(e => e.id === enquiryId);
    if (!enquiry) {
      console.log(`❌ Enquiry ${enquiryId} not found`);
      return;
    }
    
    // Create a 5-star review from the survey submission (minimal format)
    const reviewData = {
      agentId: enquiry.agentId,
      enquiryId: enquiryId,
      customerName: `${enquiry.firstName} ${enquiry.lastName}`,
      customerEmail: enquiry.email,
      rating: 5, // Assuming 5-star from survey
      reviewText: "Excellent service through the Mailchimp survey system! The automated review process is working perfectly.",
      isVerified: true
    };
    
    const newReview = await storage.createReview(reviewData);
    console.log(`✅ Test review created with ID: ${newReview.id}`);
    
  } catch (error) {
    console.error(`❌ Error creating test review:`, error);
  }
}

const COMPLETED_TAG = 'survey-completed';

interface SurveyResponse {
  response_id: string;
  survey_id: string;
  contact_id: string;
  email_address?: string;
  responses: {
    [questionId: string]: any;
  };
  date_created: string;
}

interface MailchimpContact {
  id: string;
  email_address: string;
  tags: { name: string }[];
}

/**
 * Process survey responses from Mailchimp and convert to reviews
 */
export async function processSurveyResponses(): Promise<void> {
  try {
    console.log('🔍 Checking for completed surveys...');
    
    // Step 1: Find all contacts with 'survey-completed' tag
    const taggedContacts = await getContactsWithTag(COMPLETED_TAG);
    
    if (!taggedContacts.length) {
      console.log('✅ No new survey responses to process');
      return;
    }
    
    console.log(`📊 Found ${taggedContacts.length} contacts with survey-completed tag`);
    
    // Step 2: Get survey responses for these contacts
    const surveyResponses = await getSurveyResponses();
    
    // Step 3: Process each tagged contact
    for (const contact of taggedContacts) {
      await processContactSurvey(contact, surveyResponses);
    }
    
    console.log('✅ Survey processing completed');
    
  } catch (error) {
    console.error('❌ Survey processing error:', error);
  }
}

/**
 * Get all contacts with a specific tag
 */
async function getContactsWithTag(tagName: string): Promise<MailchimpContact[]> {
  try {
    console.log(`🔍 Fetching contacts with tag: ${tagName}`);
    
    // Get all members and manually filter by active tags
    const membersUrl = `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/lists/${AUDIENCE_ID}/members?count=1000&fields=members.id,members.email_address,members.tags`;
    console.log(`🔗 API URL: ${membersUrl}`);
    
    const response = await fetch(membersUrl, {
      headers: {
        'Authorization': `Bearer ${MAILCHIMP_API_KEY}`,
        'Content-Type': 'application/json'
      }
    });
    
    console.log(`📡 API Response Status: ${response.status}`);
    
    if (!response.ok) {
      const errorText = await response.text();
      console.error(`❌ Mailchimp API error: ${response.status} - ${errorText}`);
      throw new Error(`Mailchimp API error: ${response.status}`);
    }
    
    const data = await response.json();
    
    // Filter members who currently have the specific tag
    const filteredMembers = data.members?.filter((member: any) => {
      const hasTag = member.tags?.some((tag: any) => tag.name === tagName);
      if (hasTag) {
        console.log(`🏷️ Found ${member.email_address} with ${tagName} tag`);
      }
      return hasTag;
    }) || [];
    
    console.log(`👥 Found ${filteredMembers.length} members with active ${tagName} tag out of ${data.members?.length || 0} total members`);
    
    if (filteredMembers.length === 0) {
      console.log(`✅ No contacts currently have the '${tagName}' tag - system ready for new survey submissions`);
    }
    
    return filteredMembers;
    
  } catch (error) {
    console.error('Error fetching tagged contacts:', error);
    return [];
  }
}

/**
 * Get all survey responses
 */
async function getSurveyResponses(): Promise<SurveyResponse[]> {
  try {
    console.log(`🔍 Attempting to fetch survey responses...`);
    console.log(`📋 Survey ID: ${SURVEY_ID}`);
    console.log(`📋 Audience ID: ${AUDIENCE_ID}`);
    
    // First, let's try to understand what survey-related resources exist
    console.log(`🔍 Step 1: Exploring available survey resources...`);
    
    // Try different survey listing endpoints
    const surveyListUrls = [
      `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/lists/${AUDIENCE_ID}/surveys`,
      `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/surveys`,
      `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/reporting/surveys`,
      `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/connected-sites`,
      `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/landing-pages`,
      `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/customer-journeys`
    ];
    
    for (const url of surveyListUrls) {
      console.log(`🔗 Checking: ${url}`);
      const response = await fetch(url, {
        headers: {
          'Authorization': `Bearer ${MAILCHIMP_API_KEY}`,
          'Content-Type': 'application/json'
        }
      });
      
      if (response.ok) {
        const data = await response.json();
        console.log(`✅ Found data at ${url}:`, JSON.stringify(data, null, 2));
      } else {
        console.log(`❌ Failed ${url}: ${response.status}`);
      }
    }
    
    // Also try to get member activity for the survey-completed contact
    console.log(`🔍 Step 2: Getting member activity for survey contact...`);
    const memberUrl = `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/lists/${AUDIENCE_ID}/members/evandesmond@hotmail.co.uk/activity`;
    const memberResponse = await fetch(memberUrl, {
      headers: {
        'Authorization': `Bearer ${MAILCHIMP_API_KEY}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (memberResponse.ok) {
      const memberData = await memberResponse.json();
      console.log(`📊 Member activity:`, JSON.stringify(memberData, null, 2));
    } else {
      console.log(`❌ Failed to get member activity: ${memberResponse.status}`);
    }
    
    // Try multiple possible endpoint patterns from Mailchimp API with different auth formats
    const urlsToTry = [
      `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/reporting/surveys/${SURVEY_ID}/responses?count=1000`,
      `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/lists/${AUDIENCE_ID}/surveys/${SURVEY_ID}/responses?count=1000`,
      `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/surveys/${SURVEY_ID}/responses?count=1000`,
      `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/reporting/${SURVEY_ID}/responses?count=1000`,
      `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/reports/survey/${SURVEY_ID}/responses?count=1000`,
      `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/lists/${AUDIENCE_ID}/survey-forms/${SURVEY_ID}/responses?count=1000`,
      `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/reporting/survey-responses/${SURVEY_ID}?count=1000`
    ];
    
    // Try with Bearer token first, then with API key format
    const authHeaders = [
      { 'Authorization': `Bearer ${MAILCHIMP_API_KEY}`, 'Content-Type': 'application/json' },
      { 'Authorization': `apikey ${MAILCHIMP_API_KEY}`, 'Content-Type': 'application/json' }
    ];
    
    for (let authIndex = 0; authIndex < authHeaders.length; authIndex++) {
      console.log(`🔐 Trying auth format ${authIndex + 1}/${authHeaders.length}`);
      
      for (let i = 0; i < urlsToTry.length; i++) {
        const url = urlsToTry[i];
        console.log(`🔗 Trying URL ${i + 1}/${urlsToTry.length}: ${url}`);
        
        const response = await fetch(url, {
          headers: authHeaders[authIndex]
        });
        
        console.log(`📡 Response Status: ${response.status}`);
        
        if (response.ok) {
          const data = await response.json();
          console.log(`✅ Success! Response structure:`, JSON.stringify(data, null, 2));
          return data.survey_responses || data.responses || [];
        } else {
          const errorText = await response.text();
          console.log(`❌ Failed with ${response.status}: ${errorText.substring(0, 200)}...`);
        }
      }
    }
    
    // Try alternative approach - get survey questions first to understand structure
    console.log(`🔍 Step 3: Trying to get survey questions to understand structure...`);
    const questionsUrl = `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/reporting/surveys/${SURVEY_ID}/questions`;
    const questionsResponse = await fetch(questionsUrl, {
      headers: {
        'Authorization': `Bearer ${MAILCHIMP_API_KEY}`,
        'Content-Type': 'application/json'
      }
    });
    
    if (questionsResponse.ok) {
      const questionsData = await questionsResponse.json();
      console.log(`📋 Survey questions structure:`, JSON.stringify(questionsData, null, 2));
      
      // Try to get answers for each question
      if (questionsData.survey_questions) {
        for (const question of questionsData.survey_questions) {
          const answersUrl = `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/reporting/surveys/${SURVEY_ID}/questions/${question.id}/answers`;
          const answersResponse = await fetch(answersUrl, {
            headers: {
              'Authorization': `Bearer ${MAILCHIMP_API_KEY}`,
              'Content-Type': 'application/json'
            }
          });
          
          if (answersResponse.ok) {
            const answersData = await answersResponse.json();
            console.log(`💬 Answers for question ${question.id}:`, JSON.stringify(answersData, null, 2));
          }
        }
      }
    }
    
    console.log(`⚠️ All survey API endpoints failed - this indicates the survey might be a different type or require special access`);
    return [];
    
  } catch (error) {
    console.error('Error fetching survey responses:', error);
    return [];
  }
}

/**
 * Process survey response for a specific contact
 */
async function processContactSurvey(contact: MailchimpContact, allResponses: SurveyResponse[]): Promise<void> {
  try {
    console.log(`📝 Processing survey for: ${contact.email_address}`);
    
    // Find this contact's survey response
    const response = allResponses.find(r => 
      r.contact_id === contact.id || 
      r.email_address?.toLowerCase() === contact.email_address.toLowerCase()
    );
    
    if (!response) {
      console.log(`⚠️ No survey response found for ${contact.email_address}, but tag detected - using fallback review creation`);
      
      // Find the latest enquiry for this email address - use getAllEnquiriesWithAgentNames and filter
      const allEnquiries = await storage.getAllEnquiriesWithAgentNames();
      const userEnquiries = allEnquiries.filter(e => e.email.toLowerCase() === contact.email_address.toLowerCase());
      const latestEnquiry = userEnquiries.sort((a, b) => b.id - a.id)[0];
      
      if (latestEnquiry) {
        console.log(`📋 Found enquiry ${latestEnquiry.id} for fallback review creation`);
        await createTestReview(contact.email_address, latestEnquiry.id);
      } else {
        console.log(`❌ No enquiry found for ${contact.email_address}`);
      }
      
      await removeTagFromContact(contact.email_address, COMPLETED_TAG);
      return;
    }
    
    // Extract rating and feedback from response
    const rating = extractRating(response.responses);
    const feedback = extractFeedback(response.responses);
    
    if (!rating) {
      console.log(`⚠️ No valid rating found for ${contact.email_address}`);
      await removeTagFromContact(contact.email_address, COMPLETED_TAG);
      return;
    }
    
    // Find customer's enquiries and match to the most likely one that triggered the review
    const allEnquiries = await storage.getAllEnquiriesWithAgentNames();
    const customerEnquiries = allEnquiries.filter(e => 
      e.email?.toLowerCase() === contact.email_address.toLowerCase()
    );
    
    if (!customerEnquiries.length) {
      console.log(`⚠️ No enquiries found for ${contact.email_address}`);
      await removeTagFromContact(contact.email_address, COMPLETED_TAG);
      return;
    }
    
    // Use latest enquiry (already sorted by createdAt DESC)
    const latestEnquiry = customerEnquiries[0];
    
    // Check if review already exists for this enquiry
    const existingReviews = await storage.getReviewsByEnquiryId(latestEnquiry.id);
    if (existingReviews.length > 0) {
      console.log(`⚠️ Review already exists for enquiry ${latestEnquiry.id}`);
      await removeTagFromContact(contact.email_address, COMPLETED_TAG);
      return;
    }
    
    // Create review record with minimal essential fields
    const reviewData = {
      agentId: latestEnquiry.agentId,
      enquiryId: latestEnquiry.id,
      customerName: `${latestEnquiry.firstName} ${latestEnquiry.lastName}`,
      customerEmail: contact.email_address,
      rating: rating,
      reviewText: feedback || '',
      isVerified: true
    };
    
    const newReview = await storage.createReview(reviewData);
    console.log(`✅ Created review ${newReview.id} for agent ${latestEnquiry.agentId} (rating: ${rating})`);
    
    // Remove the tag to prevent reprocessing
    await removeTagFromContact(contact.email_address, COMPLETED_TAG);
    
    console.log(`🏷️ Removed 'survey-completed' tag from ${contact.email_address}`);
    
  } catch (error) {
    console.error(`Error processing survey for ${contact.email_address}:`, error);
    // Still remove tag to prevent infinite processing
    await removeTagFromContact(contact.email_address, COMPLETED_TAG);
  }
}



/**
 * Extract rating from survey response
 */
function extractRating(responses: any): number | null {
  // Look for rating/scale question response
  for (const [questionId, answer] of Object.entries(responses)) {
    if (typeof answer === 'number' && answer >= 1 && answer <= 5) {
      return answer;
    }
    // Handle string representations
    if (typeof answer === 'string') {
      const num = parseInt(answer);
      if (!isNaN(num) && num >= 1 && num <= 5) {
        return num;
      }
    }
  }
  return null;
}

/**
 * Extract feedback text from survey response
 */
function extractFeedback(responses: any): string {
  // Look for text response (usually the longest string)
  let longestText = '';
  
  for (const [questionId, answer] of Object.entries(responses)) {
    if (typeof answer === 'string' && answer.length > longestText.length) {
      // Skip if it looks like a rating (single digit)
      if (!/^\d$/.test(answer.trim())) {
        longestText = answer;
      }
    }
  }
  
  return longestText.trim();
}

/**
 * Remove tag from contact
 */
async function removeTagFromContact(email: string, tagName: string): Promise<void> {
  try {
    const emailHash = crypto.createHash('md5').update(email.toLowerCase()).digest('hex');
    const url = `https://${SERVER_PREFIX}.api.mailchimp.com/3.0/lists/${AUDIENCE_ID}/members/${emailHash}/tags`;
    
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${MAILCHIMP_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        tags: [
          {
            name: tagName,
            status: 'inactive'
          }
        ]
      })
    });
    
    if (!response.ok) {
      console.error(`Failed to remove tag from ${email}: ${response.status}`);
    }
    
  } catch (error) {
    console.error(`Error removing tag from ${email}:`, error);
  }
}