import {
  Agent, InsertAgent,
  Destination, InsertDestination,
  HolidayType, InsertHolidayType,
  Offer, InsertOffer,
  Enquiry, InsertEnquiry,
  Review, InsertReview,
  ReviewReminder, InsertReviewReminder,
  BlogPost, InsertBlogPost,
  Newsletter, InsertNewsletter,
  User, InsertUser,
  BlogReaction, InsertBlogReaction,
  ProfileVisit, InsertProfileVisit,
  EmailTemplate, InsertEmailTemplate,
  HealthCheckLog, InsertHealthCheckLog,
  agents, destinations, holidayTypes, offers, enquiries, reviews, reviewReminders, blogPosts, newsletters, users, blogReactions, profileVisits, emailTemplates, healthCheckLogs
} from "@shared/schema";
import bcrypt from "bcryptjs";
import { getDestinationImage } from "./destination-images";
import { db, pool } from "./db";
import { eq, like, or, and, sql, desc, asc, count, lt } from "drizzle-orm";

export interface IStorage {
  // Users
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Agents
  getAllAgents(): Promise<Agent[]>;
  getAgent(id: number): Promise<Agent | undefined>;
  getAgentById(id: number): Promise<Agent | undefined>;
  getFeaturedAgents(): Promise<Agent[]>;
  getRandomizedFeaturedAgents(): Promise<Agent[]>;
  getAgentsByDestination(destination: string): Promise<Agent[]>;
  getAgentsByHolidayType(holidayType: string): Promise<Agent[]>;
  searchAgents(query: string): Promise<Agent[]>;
  filterAgents(filters: {
    location?: string;
    holidayType?: string;
    destination?: string;
    speciality?: string;
  }): Promise<Agent[]>;
  

  createAgent(agent: InsertAgent): Promise<Agent>;

  // Agent Authentication
  getAgentByEmail(email: string): Promise<Agent | undefined>;
  updateAgentProfile(id: number, data: Partial<Agent>): Promise<Agent>;
  createPendingAgent(email: string, password: string, verificationToken: string): Promise<Agent>;
  verifyAgentEmail(token: string): Promise<Agent | undefined>;
  completeAgentProfile(agentId: number, profileData: any): Promise<Agent>;
  getAgentVerificationToken(agentId: number): Promise<string | null>;

  // Agent Content Management
  addAgentPhoto(agentId: number, photoUrl: string): Promise<Agent>;
  updateAgentPhotos(agentId: number, photoUrls: string[]): Promise<void>;
  deleteAgentPhoto(agentId: number, photoUrl: string): Promise<void>;
  replaceAgentPhoto(agentId: number, oldPhotoUrl: string, newPhotoUrl: string): Promise<void>;
  updateAgentVideo(agentId: number, videoUrl: string): Promise<Agent>;

  // Destinations
  getAllDestinations(): Promise<Destination[]>;
  getDestinationBySlug(slug: string): Promise<Destination | undefined>;
  getTrendingDestinations(): Promise<Destination[]>;
  createDestination(destination: InsertDestination): Promise<Destination>;
  updateDestinationImage(destinationId: number, imageUrl: string): Promise<Destination>;

  // Holiday Types
  getAllHolidayTypes(): Promise<HolidayType[]>;
  getHolidayTypeBySlug(slug: string): Promise<HolidayType | undefined>;
  createHolidayType(holidayType: InsertHolidayType): Promise<HolidayType>;
  updateHolidayTypeImage(holidayTypeId: number, imageUrl: string): Promise<HolidayType>;

  // Offers
  getAllOffers(): Promise<(Offer & { agent: Agent })[]>;
  getOffersByAgent(agentId: number): Promise<Offer[]>;
  getPublishedOffers(): Promise<(Offer & { agent: Agent })[]>;
  createOffer(offer: InsertOffer & { agentId: number }): Promise<Offer>;
  updateOffer(id: number, agentId: number, offer: Partial<InsertOffer>): Promise<Offer>;
  checkAndUpdateExpiredOffers(): Promise<void>;
  deleteOffer(id: number, agentId: number): Promise<void>;
  publishOffer(id: number, agentId: number): Promise<Offer>;
  getOfferById(id: number): Promise<(Offer & { agent: Agent }) | undefined>;

  // Enquiries
  createEnquiry(enquiry: InsertEnquiry): Promise<Enquiry>;
  getEnquiry(id: number): Promise<Enquiry | undefined>;
  getEnquiriesByAgent(agentId: number): Promise<Enquiry[]>;
  getEnquiriesForEmail(email: string): Promise<Enquiry[]>;
  markEnquiryAsRead(enquiryId: number): Promise<void>;
  markAllEnquiriesAsReadForAgent(agentId: number): Promise<void>;
  getUnreadEnquiriesCount(agentId: number): Promise<number>;
  getAllEnquiriesWithAgentNames(): Promise<any[]>;
  getTotalEnquiries(): Promise<number>;
  markReviewEmailSent(enquiryId: number): Promise<void>;

  // Reviews
  getReviewsByAgent(agentId: number): Promise<Review[]>;
  getReviewsByEnquiryId(enquiryId: number): Promise<Review[]>;
  getAllReviews(): Promise<Review[]>;
  getAllReviewsWithAgentNames(): Promise<(Review & { agentName?: string })[]>;
  createReview(review: InsertReview): Promise<Review>;
  getTotalReviews(): Promise<number>;
  getReviewEmailsSentCount(): Promise<number>;
  
  // Review Reminders (for future email automation)
  createReviewReminder(reminder: InsertReviewReminder): Promise<ReviewReminder>;
  getScheduledReviewReminders(): Promise<ReviewReminder[]>;
  markReminderEmailSent(reminderId: number): Promise<void>;
  markReminderCompleted(reminderId: number): Promise<void>;

  // Blog Posts
  getAllBlogPosts(): Promise<(BlogPost & { agent: Agent })[]>;
  getBlogPostsByAgent(agentId: number): Promise<BlogPost[]>;
  getBlogPostById(id: number): Promise<BlogPost | undefined>;
  getBlogPostBySlug(slug: string): Promise<BlogPost | undefined>;
  getBlogPostBySlugWithAgent(slug: string): Promise<(BlogPost & { agent: Agent }) | undefined>;
  createBlogPost(blogPost: InsertBlogPost): Promise<BlogPost>;
  updateBlogPost(id: number, blogPost: Partial<BlogPost>): Promise<BlogPost>;
  deleteBlogPost(id: number): Promise<void>;

  // Blog Reactions
  addBlogReaction(reaction: InsertBlogReaction): Promise<BlogReaction>;
  removeBlogReaction(blogPostId: number, userId: string, emoji: string): Promise<void>;
  getBlogReactions(blogPostId: number): Promise<{ emoji: string; count: number; userReacted: boolean }[]>;
  getBlogReactionsByUser(blogPostId: number, userId: string): Promise<BlogReaction[]>;

  // Newsletter
  subscribeToNewsletter(email: string): Promise<Newsletter>;
  getAllNewsletters(): Promise<Newsletter[]>;

  // Email Templates
  getAllEmailTemplates(): Promise<EmailTemplate[]>;
  getEmailTemplateById(id: string): Promise<EmailTemplate | undefined>;
  createEmailTemplate(template: InsertEmailTemplate): Promise<EmailTemplate>;
  updateEmailTemplate(id: string, template: Partial<EmailTemplate>): Promise<EmailTemplate>;
  deleteEmailTemplate(id: string): Promise<void>;

  // Profile visits tracking
  trackProfileVisit(agentId: number, visitorId: string, userAgent?: string): Promise<void>;
  incrementProfileViews(agentId: number): Promise<void>;

  // Health Check Logs
  createHealthCheckLog(log: InsertHealthCheckLog): Promise<HealthCheckLog>;
  getRecentHealthCheckLogs(limit?: number): Promise<HealthCheckLog[]>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User> = new Map();
  private agents: Map<number, Agent> = new Map();
  private destinations: Map<number, Destination> = new Map();
  private holidayTypes: Map<number, HolidayType> = new Map();
  private offers: Map<number, Offer> = new Map();
  private enquiries: Map<number, Enquiry> = new Map();
  private reviews: Map<number, Review> = new Map();
  private blogPosts: Map<number, BlogPost> = new Map();
  private newsletters: Map<number, Newsletter> = new Map();
  
  // Performance cache for featured agents
  private featuredAgentsCache: { agents: Agent[], timestamp: number } | null = null;
  private readonly CACHE_DURATION = 30000; // 30 seconds

  private currentUserId = 1;
  private currentAgentId = 52;
  private currentDestinationId = 1;
  private currentHolidayTypeId = 1;
  private currentOfferId = 1;
  private currentEnquiryId = 1;
  private currentReviewId = 1;
  private currentBlogPostId = 1;
  private currentNewsletterId = 1;

  constructor() {
    this.initializeData();
  }

  private initializeData() {
    // Initialize holiday types
    const holidayTypes = [
      { 
        name: "Beach Holidays", 
        slug: "beach-holidays", 
        icon: "umbrella-beach", 
        image: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=400&h=300&fit=crop&crop=centre",
        description: "Sun, sea, sand and tropical paradise",
        tagline: "For those seeking sun, sea, sand and maybe a sex on the beach!"
      },
      { 
        name: "Family Holidays", 
        slug: "family-holidays", 
        icon: "users", 
        image: "https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?w=400&h=300&fit=crop&crop=centre",
        description: "Perfect vacations for all ages",
        tagline: "Holidays where toddlers to teenagers are fully catered for, so that you can sit back and enjoy yourself!"
      },
      { 
        name: "Luxury Holidays", 
        slug: "luxury-holidays", 
        icon: "crown", 
        image: "https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=400&h=300&fit=crop&crop=centre",
        description: "Premium 5-star experiences",
        tagline: "Explore the best that the world of luxury travel has to offer with true 5-star experiences throughout"
      },
      { 
        name: "Cruises", 
        slug: "cruises", 
        icon: "ship", 
        image: "https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=400&h=300&fit=crop&crop=centre",
        description: "Ocean adventures and floating cities",
        tagline: "Set sail and wake up somewhere new every couple of days, a quick way to tick off your bucket list"
      },
      { 
        name: "Safari Holidays", 
        slug: "safari-holidays", 
        icon: "camera", 
        image: "https://images.unsplash.com/photo-1516426122078-c23e76319801?w=400&h=300&fit=crop&crop=centre",
        description: "Wildlife adventures and nature photography",
        tagline: "For those wanting to get a snap of the World's most-see wildlife"
      },
      { 
        name: "Villa Holidays", 
        slug: "villa-holidays", 
        icon: "home", 
        image: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=400&h=300&fit=crop&crop=centre",
        description: "Private accommodations with space and privacy",
        tagline: "Perfect for any family or large groups seeking a bit more space and privacy"
      },
      { 
        name: "City Breaks", 
        slug: "city-breaks", 
        icon: "building", 
        image: "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=400&h=300&fit=crop&crop=centre",
        description: "Urban adventures and cultural exploration",
        tagline: "Why not hop over to a European hot spot for a long weekend?"
      },
      { 
        name: "Honeymoons", 
        slug: "honeymoons", 
        icon: "heart", 
        image: "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=400&h=300&fit=crop&crop=centre",
        description: "Romantic once-in-a-lifetime experiences",
        tagline: "A romantic, once in a lifetime trip requiring that extra little bit of attention"
      },
      { 
        name: "Weddings Abroad", 
        slug: "weddings-abroad", 
        icon: "heart-handshake", 
        image: "https://images.unsplash.com/photo-1519225421980-715cb0215aed?w=400&h=300&fit=crop&crop=centre",
        description: "Destination weddings with unforgettable backdrops",
        tagline: "An extra special big day with a slightly different backdrop for your vows"
      },
      { 
        name: "Theme Park Holidays", 
        slug: "theme-park-holidays", 
        icon: "ferris-wheel", 
        image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop&crop=centre",
        description: "Magic and adventure for kids and adults",
        tagline: "Disneyland and Universal Studios holidays for the kids and the kids at heart"
      },
      { 
        name: "Skiing Holidays", 
        slug: "skiing-holidays", 
        icon: "mountain-snow", 
        image: "https://images.unsplash.com/photo-1551524164-687a55dd1126?w=400&h=300&fit=crop&crop=centre",
        description: "Winter sports and mountain adventures",
        tagline: "From private chalets to ski-in-ski out resorts"
      },
      { 
        name: "Private Jet Holidays", 
        slug: "private-jet-holidays", 
        icon: "plane", 
        image: "https://images.unsplash.com/photo-1540962351504-03099e0a754b?w=400&h=300&fit=crop&crop=centre",
        description: "Ultra-luxury private aviation experiences",
        tagline: "Ultra-luxury, ultra-private, ultra-special and for when only the best will do"
      }
    ];

    holidayTypes.forEach(ht => {
      const id = this.currentHolidayTypeId++;
      this.holidayTypes.set(id, { ...ht, id, createdAt: new Date() });
    });

    // Initialize destinations
    const destinations = [
      // Indian Ocean
      { 
        name: "Maldives", 
        slug: "maldives", 
        description: "The Maldives is a tropical island paradise, known globally for its crystal-clear waters, pristine white sandy beaches, and abundant marine life. This idyllic destination is made up of 99 islands, which are essentially a string of coral islands that provide a lagoon. The atolls are home to some of the most diverse and vibrant coral reefs in the world, making it a perfect destination for snorkeling and diving.", 
        image: getDestinationImage("maldives"), 
        agentCount: 52, 
        continent: "Asia" 
      },
      { 
        name: "Mauritius", 
        slug: "mauritius", 
        description: "Mauritius is a fantastic holiday destination for a variety of reasons. This island nation is located in the Indian Ocean and is known for its charming beaches with crystal-clear waters. Not only is the island home to a variety of activities like hiking, sports clubs and kite surfing, but the island also offers a range of different cuisines, African, Chinese and millionaire. There are many delicious local food options to try and a variety of local markets and shops to explore.", 
        image: getDestinationImage("mauritius"), 
        agentCount: 38, 
        continent: "Africa" 
      },
      { 
        name: "Seychelles", 
        slug: "seychelles", 
        description: "One of many gems in the Indian Ocean, the island nation known as Seychelles is famous for its white sandy shores. It is also a luxury resort and five star luxury economy. It continues to be a popular spot for people seeking a luxury holiday because of the year-round tropical climate, making it perfect for swimming, snorkelling and other water-based activities.", 
        image: getDestinationImage("seychelles"), 
        agentCount: 24, 
        continent: "Africa" 
      },
      { 
        name: "Sri Lanka", 
        slug: "sri-lanka", 
        description: "Sri Lanka offers incredible diversity from ancient temples and cultural sites to pristine beaches and lush tea plantations. This island nation combines rich history, wildlife safaris, and tropical paradise in one unforgettable destination.", 
        image: getDestinationImage("sri-lanka"), 
        agentCount: 18, 
        continent: "Asia" 
      },
      
      // Middle East
      { 
        name: "Dubai", 
        slug: "dubai", 
        description: "Dubai is the perfect destination for anyone looking to escape and unwind. The tropical climate is another thing that attracts so many tourists. The temperature remains constant throughout the year, swirling around 30°C with only a slight variation in the monsoon period.", 
        image: getDestinationImage("dubai"), 
        agentCount: 63, 
        continent: "Asia" 
      },
      { 
        name: "Abu Dhabi", 
        slug: "abu-dhabi", 
        description: "Abu Dhabi combines modern luxury with cultural heritage, featuring world-class museums, pristine beaches, and iconic architecture. Experience the capital of the UAE with its blend of tradition and innovation.", 
        image: getDestinationImage("abu-dhabi"), 
        agentCount: 28, 
        continent: "Asia" 
      },
      { 
        name: "Oman", 
        slug: "oman", 
        description: "Oman offers authentic Arabian experiences with dramatic landscapes from mountains to deserts to pristine coastlines. Discover ancient forts, traditional souks, and warm Omani hospitality in this unspoiled gem.", 
        image: getDestinationImage("oman"), 
        agentCount: 15, 
        continent: "Asia" 
      },
      { 
        name: "Ras Al Khaimah", 
        slug: "ras-al-khaimah", 
        description: "Ras Al Khaimah combines adventure and relaxation with stunning mountain landscapes, pristine beaches, and thrilling activities. Experience the authentic side of the UAE with rich history and natural beauty.", 
        image: getDestinationImage("ras-al-khaimah"), 
        agentCount: 12, 
        continent: "Asia" 
      },
      { 
        name: "Qatar", 
        slug: "qatar", 
        description: "Qatar offers a perfect blend of modern sophistication and traditional culture. From world-class museums and shopping to desert adventures and pristine beaches, discover this dynamic Gulf destination.", 
        image: getDestinationImage("qatar"), 
        agentCount: 19, 
        continent: "Asia" 
      },
      
      // Mediterranean & Europe
      { 
        name: "Greece", 
        slug: "greece", 
        description: "Greece enchants with its ancient history, stunning islands, and Mediterranean charm. From the iconic white buildings of Santorini to the historic Acropolis of Athens, experience mythology come to life.", 
        image: getDestinationImage("greece"), 
        agentCount: 45, 
        continent: "Europe" 
      },
      { 
        name: "Spain", 
        slug: "spain", 
        description: "Spain captivates with its vibrant culture, stunning architecture, and diverse landscapes. From the beaches of Costa del Sol to the artistic treasures of Barcelona and Madrid, experience passion and tradition.", 
        image: getDestinationImage("spain"), 
        agentCount: 58, 
        continent: "Europe" 
      },
      { 
        name: "Cyprus", 
        slug: "cyprus", 
        description: "Cyprus offers Mediterranean beauty with rich history and pristine beaches. This island nation combines ancient ruins, charming villages, and crystal-clear waters for the perfect cultural beach holiday.", 
        image: getDestinationImage("cyprus"), 
        agentCount: 22, 
        continent: "Europe" 
      },
      { 
        name: "Portugal", 
        slug: "portugal", 
        description: "Portugal enchants with its coastal beauty, historic cities, and warm hospitality. From the colorful tiles of Porto to the beaches of the Algarve, discover this Atlantic gem with rich maritime heritage.", 
        image: getDestinationImage("portugal"), 
        agentCount: 34, 
        continent: "Europe" 
      },
      { 
        name: "Turkey", 
        slug: "turkey", 
        description: "Turkey bridges Europe and Asia with incredible diversity from ancient wonders to stunning coastlines. Experience the magic of Istanbul, Cappadocia's fairy chimneys, and the turquoise coast.", 
        image: getDestinationImage("turkey"), 
        agentCount: 41, 
        continent: "Europe" 
      },
      { 
        name: "Croatia", 
        slug: "croatia", 
        description: "Croatia dazzles with its Adriatic coastline, medieval cities, and stunning national parks. From the historic walls of Dubrovnik to the cascading waterfalls of Plitvice, discover this Balkan jewel.", 
        image: getDestinationImage("croatia"), 
        agentCount: 29, 
        continent: "Europe" 
      },
      { 
        name: "Italy", 
        slug: "italy", 
        description: "Experience the romance of Rome, the canals of Venice, and the art of Florence in this stunning Mediterranean country rich in history, culture, and cuisine.", 
        image: getDestinationImage("italy"), 
        agentCount: 67, 
        continent: "Europe" 
      },
      { 
        name: "France", 
        slug: "france", 
        description: "France epitomizes elegance with its romantic cities, world-class cuisine, and diverse landscapes. From the Eiffel Tower to Provence's lavender fields, experience the art of living well.", 
        image: getDestinationImage("france"), 
        agentCount: 72, 
        continent: "Europe" 
      },
      { 
        name: "Switzerland", 
        slug: "switzerland", 
        description: "Switzerland offers alpine beauty with pristine mountains, crystal-clear lakes, and charming villages. Experience world-class skiing, scenic train journeys, and Swiss precision in this mountain paradise.", 
        image: getDestinationImage("switzerland"), 
        agentCount: 31, 
        continent: "Europe" 
      },
      { 
        name: "Malta", 
        slug: "malta", 
        description: "Malta combines Mediterranean charm with rich history in a compact island setting. Explore ancient temples, crystal-clear waters, and limestone cities in this cultural crossroads of Europe.", 
        image: getDestinationImage("malta"), 
        agentCount: 16, 
        continent: "Europe" 
      },
      { 
        name: "Montenegro", 
        slug: "montenegro", 
        description: "Montenegro surprises with dramatic mountains, pristine coastline, and medieval towns. This Balkan gem offers adventure and beauty from the Bay of Kotor to Durmitor National Park.", 
        image: getDestinationImage("montenegro"), 
        agentCount: 14, 
        continent: "Europe" 
      },
      { 
        name: "Iceland", 
        slug: "iceland", 
        description: "Iceland mesmerizes with otherworldly landscapes from geysers and glaciers to the Northern Lights. Experience the land of fire and ice with dramatic waterfalls, volcanic landscapes, and geothermal wonders.", 
        image: getDestinationImage("iceland"), 
        agentCount: 23, 
        continent: "Europe" 
      },
      { 
        name: "Finland", 
        slug: "finland", 
        description: "Finland offers pristine wilderness, midnight sun, and Northern Lights. Experience Lapland's magic, Helsinki's design scene, and thousands of lakes in this Nordic wonderland.", 
        image: getDestinationImage("finland"), 
        agentCount: 18, 
        continent: "Europe" 
      },
      { 
        name: "Lapland", 
        slug: "lapland", 
        description: "Lapland provides the ultimate Arctic experience with reindeer, Northern Lights, and winter magic. Meet Santa in his homeland while enjoying husky sledding, ice hotels, and midnight sun.", 
        image: getDestinationImage("lapland"), 
        agentCount: 12, 
        continent: "Europe" 
      },
      
      // Caribbean
      { 
        name: "Barbados", 
        slug: "barbados", 
        description: "Barbados combines Caribbean charm with British heritage, offering pristine beaches, rum distilleries, and warm hospitality. Experience the birthplace of rum with coral reefs and tropical luxury.", 
        image: getDestinationImage("barbados"), 
        agentCount: 27, 
        continent: "North America" 
      },
      { 
        name: "Saint Lucia", 
        slug: "saint-lucia", 
        description: "Saint Lucia enchants with dramatic Piton mountains, pristine beaches, and lush rainforests. This Caribbean jewel offers romance, adventure, and natural beauty in perfect harmony.", 
        image: getDestinationImage("saint-lucia"), 
        agentCount: 21, 
        continent: "North America" 
      },
      { 
        name: "Antigua & Barbuda", 
        slug: "antigua-and-barbuda", 
        description: "Antigua & Barbuda boasts 365 beaches of pristine white sand and crystal-clear waters. Experience Caribbean luxury with historic English Harbour and world-class sailing.", 
        image: getDestinationImage("antigua-and-barbuda"), 
        agentCount: 18, 
        continent: "North America" 
      },
      { 
        name: "Grenada", 
        slug: "grenada", 
        description: "Grenada, the Spice Island, offers aromatic spice gardens, pristine beaches, and underwater sculpture parks. Experience Caribbean culture with nutmeg, cocoa, and warm island hospitality.", 
        image: getDestinationImage("grenada"), 
        agentCount: 15, 
        continent: "North America" 
      },
      { 
        name: "Jamaica", 
        slug: "jamaica", 
        description: "Jamaica pulses with reggae rhythms, pristine beaches, and vibrant culture. From Blue Mountain coffee plantations to Dunn's River Falls, experience the heart and soul of the Caribbean.", 
        image: getDestinationImage("jamaica"), 
        agentCount: 32, 
        continent: "North America" 
      },
      { 
        name: "Dominican Republic", 
        slug: "dominican-republic", 
        description: "Dominican Republic offers diverse experiences from pristine beaches to colonial history. Discover merengue music, crystal-clear waters, and warm Caribbean hospitality in this island paradise.", 
        image: getDestinationImage("dominican-republic"), 
        agentCount: 26, 
        continent: "North America" 
      },
      { 
        name: "Anguilla", 
        slug: "anguilla", 
        description: "Anguilla epitomizes Caribbean luxury with powder-soft beaches and crystal-clear waters. This peaceful island offers world-class resorts, exceptional dining, and pristine natural beauty.", 
        image: getDestinationImage("anguilla"), 
        agentCount: 13, 
        continent: "North America" 
      },
      { 
        name: "Turks and Caicos", 
        slug: "turks-and-caicos", 
        description: "Turks and Caicos features some of the world's most beautiful beaches with crystal-clear turquoise waters. Experience luxury resorts, world-class diving, and pristine coral reefs.", 
        image: getDestinationImage("turks-and-caicos"), 
        agentCount: 24, 
        continent: "North America" 
      },
      { 
        name: "Bermuda", 
        slug: "bermuda", 
        description: "Bermuda combines pink sand beaches with British charm and subtropical beauty. This Atlantic island offers golf courses, crystal caves, and historic Hamilton with year-round mild climate.", 
        image: getDestinationImage("bermuda"), 
        agentCount: 19, 
        continent: "North America" 
      },
      { 
        name: "Bahamas", 
        slug: "bahamas", 
        description: "Bahamas offers 700 islands of pristine beaches, crystal-clear waters, and vibrant marine life. From swimming with pigs to exploring blue holes, experience Caribbean paradise at its finest.", 
        image: getDestinationImage("bahamas"), 
        agentCount: 35, 
        continent: "North America" 
      },
      
      // North America
      { 
        name: "Mexico", 
        slug: "mexico", 
        description: "Mexico captivates with ancient Mayan ruins, pristine Caribbean beaches, and vibrant culture. From Cancun's resorts to Mexico City's art scene, experience rich history and warm hospitality.", 
        image: getDestinationImage("mexico"), 
        agentCount: 48, 
        continent: "North America" 
      },
      { 
        name: "USA", 
        slug: "usa", 
        description: "USA offers incredible diversity from coast to coast with iconic cities, national parks, and cultural attractions. Experience the American dream from New York's skyline to California's beaches.", 
        image: getDestinationImage("usa"), 
        agentCount: 89, 
        continent: "North America" 
      },
      { 
        name: "Hawaii", 
        slug: "hawaii", 
        description: "Hawaii provides Pacific paradise with volcanic landscapes, pristine beaches, and Aloha spirit. Experience island culture from Waikiki Beach to Maui's Road to Hana and Big Island's volcanoes.", 
        image: getDestinationImage("hawaii"), 
        agentCount: 41, 
        continent: "North America" 
      },
      { 
        name: "Canada", 
        slug: "canada", 
        description: "Canada offers vast wilderness, cosmopolitan cities, and natural wonders from coast to coast. Experience the Rockies, Niagara Falls, and vibrant cities like Toronto and Vancouver.", 
        image: getDestinationImage("canada"), 
        agentCount: 52, 
        continent: "North America" 
      },
      
      // Asia Pacific
      { 
        name: "Thailand", 
        slug: "thailand", 
        description: "Thailand enchants with golden temples, pristine beaches, and vibrant street food culture. From Bangkok's energy to Phuket's beaches and Chiang Mai's mountains, experience the Land of Smiles.", 
        image: getDestinationImage("thailand"), 
        agentCount: 56, 
        continent: "Asia" 
      },
      { 
        name: "Vietnam", 
        slug: "vietnam", 
        description: "Vietnam captivates with stunning landscapes, rich history, and incredible cuisine. From Ha Long Bay's limestone karsts to Ho Chi Minh City's energy, experience Southeast Asian authenticity.", 
        image: getDestinationImage("vietnam"), 
        agentCount: 33, 
        continent: "Asia" 
      },
      { 
        name: "China", 
        slug: "china", 
        description: "China offers ancient wonders and modern marvels from the Great Wall to gleaming skyscrapers. Experience 5,000 years of history, diverse cuisines, and breathtaking landscapes across this vast nation.", 
        image: getDestinationImage("china"), 
        agentCount: 47, 
        continent: "Asia" 
      },
      { 
        name: "Singapore", 
        slug: "singapore", 
        description: "With its beautiful scenery, world-class resorts, and endless activities, Singapore is the perfect destination for anyone looking to escape and unwind.", 
        image: getDestinationImage("singapore"), 
        agentCount: 42, 
        continent: "Asia" 
      },
      { 
        name: "Bali", 
        slug: "bali", 
        description: "Bali offers spiritual beauty with rice terraces, ancient temples, and pristine beaches. This Indonesian paradise combines Hindu culture, volcanic landscapes, and tropical luxury.", 
        image: getDestinationImage("bali"), 
        agentCount: 39, 
        continent: "Asia" 
      },
      { 
        name: "Malaysia", 
        slug: "malaysia", 
        description: "Malaysia blends cultures and landscapes from modern Kuala Lumpur to pristine Borneo rainforests. Experience diverse cuisine, colonial architecture, and tropical islands in Southeast Asia.", 
        image: getDestinationImage("malaysia"), 
        agentCount: 28, 
        continent: "Asia" 
      },
      { 
        name: "Cambodia", 
        slug: "cambodia", 
        description: "Cambodia mesmerizes with the ancient temples of Angkor Wat and rich Khmer heritage. Discover this Southeast Asian kingdom's history, floating villages, and warm hospitality.", 
        image: getDestinationImage("cambodia"), 
        agentCount: 22, 
        continent: "Asia" 
      },
      { 
        name: "Japan", 
        slug: "japan", 
        description: "Discover ancient traditions, modern cities, and stunning cherry blossoms in this fascinating country where cutting-edge technology meets centuries-old culture.", 
        image: getDestinationImage("japan"), 
        agentCount: 41, 
        continent: "Asia" 
      },
      { 
        name: "Australia", 
        slug: "australia", 
        description: "Australia offers diverse experiences from the Great Barrier Reef to the Outback's red centre. Experience Sydney's harbor, Melbourne's culture, and unique wildlife in this vast continent.", 
        image: getDestinationImage("australia"), 
        agentCount: 61, 
        continent: "Oceania" 
      },
      { 
        name: "New Zealand", 
        slug: "new-zealand", 
        description: "New Zealand stunning landscapes from fjords to mountains, offering adventure and natural beauty. Experience Maori culture, pristine wilderness, and film locations in this Pacific paradise.", 
        image: getDestinationImage("new-zealand"), 
        agentCount: 35, 
        continent: "Oceania" 
      },
      { 
        name: "Bora Bora", 
        slug: "bora-bora", 
        description: "Bora Bora epitomizes tropical paradise with overwater bungalows and turquoise lagoons. This French Polynesian jewel offers romance, luxury, and pristine natural beauty.", 
        image: getDestinationImage("bora-bora"), 
        agentCount: 16, 
        continent: "Oceania" 
      },
      
      // Africa
      { 
        name: "South Africa", 
        slug: "south-africa", 
        description: "South Africa offers incredible diversity from wine lands to wildlife safaris. Experience the Big Five, Cape Town's beauty, and rich cultural heritage in the Rainbow Nation.", 
        image: getDestinationImage("south-africa"), 
        agentCount: 44, 
        continent: "Africa" 
      },
      { 
        name: "Kenya", 
        slug: "kenya", 
        description: "Kenya provides world-class safari experiences with the Great Migration and Big Five wildlife. From the Masai Mara to Mount Kenya, experience Africa's natural wonders and Maasai culture.", 
        image: getDestinationImage("kenya"), 
        agentCount: 31, 
        continent: "Africa" 
      },
      { 
        name: "Tanzania & Zanzibar", 
        slug: "tanzania-and-zanzibar", 
        description: "Tanzania combines Serengeti safaris with Zanzibar's spice island beaches. Experience Mount Kilimanjaro, Ngorongoro Crater, and Stone Town's historic charm.", 
        image: getDestinationImage("tanzania-zanzibar"), 
        agentCount: 29, 
        continent: "Africa" 
      },
      { 
        name: "Morocco", 
        slug: "morocco", 
        description: "Morocco enchants with imperial cities, Sahara deserts, and Atlas Mountains. Experience Marrakech's souks, Fez's medina, and Casablanca's cosmopolitan charm in North Africa.", 
        image: getDestinationImage("morocco"), 
        agentCount: 37, 
        continent: "Africa" 
      },
      { 
        name: "Egypt", 
        slug: "egypt", 
        description: "Egypt offers ancient wonders from the Pyramids of Giza to the Valley of the Kings. Experience pharaonic treasures, Nile cruises, and Red Sea diving in this cradle of civilisation.", 
        image: getDestinationImage("egypt"), 
        agentCount: 33, 
        continent: "Africa" 
      },
    ];

    destinations.forEach(dest => {
      const id = this.currentDestinationId++;
      this.destinations.set(id, { ...dest, id, createdAt: new Date() });
    });

    // Initialize agents
    const agents = [
      {
        name: "Emma Patel",
        location: "Bristol",
        bio: "Emma Patel has established herself as one of Bristol's most innovative travel specialists, bringing over 8 years of dedicated expertise to transforming ordinary vacations into extraordinary adventures that awaken the explorer within every traveller. Born and raised in Bristol with Indian heritage, Emma's multicultural background provides her with unique insights into diverse travel experiences and cultural sensitivities that enhance every journey she creates. Emma's passion for adventure travel began during her university years studying Geography and Environmental Science, which led to solo backpacking expeditions across Southeast Asia, South America, and Eastern Europe. These formative experiences taught her that the most meaningful travel happens when you step outside your comfort zone and embrace authentic local experiences. Her approach to travel planning goes far beyond typical itineraries - she specialises in creating transformative journeys that challenge her clients intellectually, physically, and emotionally while ensuring their safety and comfort throughout. What sets Emma apart is her ability to identify the hidden adventurer in even the most cautious travellers. She conducts in-depth consultations to understand each client's comfort level, interests, and personal goals, then designs experiences that gently push boundaries while building confidence. Whether it's arranging a sunset hot air balloon ride over the Serengeti for a client afraid of heights, organising a cooking class with local families in remote Vietnamese villages, or planning a photography expedition to capture the Northern Lights in Iceland, Emma excels at creating moments that become life-changing memories. Her extensive network of local guides, adventure operators, and cultural ambassadors across Europe, Asia, and Oceania allows her to provide exclusive access to experiences that typical tourists never discover. She has personally vetted every activity and accommodation she recommends, ensuring they meet her high standards for safety, authenticity, and transformative potential. Emma's clients consistently praise her ability to anticipate their needs, her patience in addressing concerns, and her talent for creating seamless adventures that exceed expectations. Her impressive 4.8-star rating from 101 clients reflects her commitment to turning hesitant travellers into confident explorers who return home with not just souvenirs, but new perspectives, increased confidence, and an insatiable appetite for their next adventure.",
        profileImage: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=face",
        company: "Travel Professional",
        rating: "4.8",
        reviewCount: 101,
        yearsExperience: 8,
        specialisations: ["City Breaks", "Luxury Holidays", "Beach Holidays"],
        destinations: ["Europe", "Asia", "Oceania"],
        languages: ["English", "Spanish", "French"],
        isTopRated: true,
      },
      {
        name: "Adam Thompson",
        location: "Manchester",
        bio: "Adam Thompson brings 12 years of specialised expertise in creating profound cultural immersion experiences across Asia, having earned recognition as Manchester's premier specialist for authentic Asian travel. His journey into cultural travel began during his gap year teaching English in rural Thailand, where he lived with local families and developed a deep appreciation for the transformative power of genuine cultural exchange. This experience shaped his philosophy that true travel is about connection, understanding, and mutual respect between cultures. Adam's expertise spans the diverse landscapes and cultures of Asia, from the ancient temples of Cambodia and the bustling markets of India to the serene mountain villages of Nepal and the technological marvels of East Asia. His fluency in Mandarin and Japanese, developed through intensive study and extended residencies in Beijing and Tokyo, allows him to facilitate authentic interactions and navigate complex cultural nuances that enhance every journey. What distinguishes Adam is his commitment to responsible cultural tourism that benefits local communities while providing travellers with genuine, life-changing experiences. He partners exclusively with locally-owned accommodations, community-based tourism initiatives, and cultural preservation projects, ensuring that his clients' travel dollars directly support the communities they visit. His itineraries often include participation in traditional festivals, homestays with local families, workshops with master craftspeople, and volunteer opportunities that create meaningful connections between travellers and local communities. Adam's approach involves extensive pre-travel education, where he prepares clients for cultural differences, teaches basic language phrases, and provides historical context that enriches their understanding of each destination. He has personally established relationships with monastery leaders in Tibet, tribal elders in Nepal, master chefs in Vietnam, and cultural preservationists across Asia, providing his clients with access to experiences that money alone cannot buy. His clients consistently describe their journeys as transformative, citing not just the stunning landscapes and historical sites, but the profound personal growth that comes from stepping into different worldviews and ways of life. Adam's exceptional 4.9-star rating from 87 clients reflects his ability to create experiences that challenge preconceptions, build empathy, and foster lasting appreciation for cultural diversity.",
        profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
        company: "Travel & Life",
        rating: "4.9",
        reviewCount: 87,
        yearsExperience: 12,
        specialisations: ["City Breaks", "Adventure Holidays", "Safari Holidays"],
        destinations: ["Asia", "Nepal", "East Asia"],
        languages: ["English", "Mandarin", "Japanese"],
        isTopRated: false,
      },
      {
        name: "Rachel Hughes",
        location: "Edinburgh",
        bio: "Rachel Hughes has dedicated 6 years to perfecting the art of luxury European travel, establishing herself as Edinburgh's most sought-after specialist for sophisticated escapes and romantic getaways that exceed the highest expectations. With a background in art history and fluency in Italian and German, Rachel brings cultural depth and artistic sensibility to every journey she creates. Her passion for European luxury travel was ignited during her postgraduate studies in Florence, where she spent two years immersed in Renaissance art and Italian culture, developing relationships with local artisans, vineyard owners, and cultural institutions that continue to enhance her clients' experiences today. Rachel's approach to luxury travel emphasizes authentic elegance over ostentation, seeking out experiences that combine exceptional comfort with genuine cultural enrichment. She specialises in creating intimate, personalised journeys that reveal the hidden sophistication of Europe's most beautiful destinations. Whether arranging private after-hours tours of the Vatican Museums, organising exclusive wine tastings in family-owned Tuscan vineyards, or securing reservations at Michelin-starred restaurants that are typically booked months in advance, Rachel's extensive network of European contacts ensures her clients experience the very best each destination has to offer. Her expertise in romantic travel is particularly noteworthy, having planned over 150 honeymoons and anniversary celebrations across Italy, France, Germany, and East Africa. She understands the delicate balance required to create intimate moments while ensuring flawless logistics, coordinating everything from private gondola serenades in Venice to sunrise hot air balloon rides over the Serengeti. Her attention to detail is legendary among her clients - she personally inspects every accommodation, tests every restaurant, and experiences every activity she recommends, ensuring that romantic moments unfold exactly as envisioned. What sets Rachel apart is her ability to anticipate desires her clients haven't even articulated, crafting surprises and special touches that elevate good trips into unforgettable experiences. Her 4.7-star rating from 156 clients reflects her consistent ability to create magical moments that strengthen relationships and create lasting memories, making her the trusted choice for discerning travellers seeking sophisticated European adventures.",
        profileImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face",
        company: "Travel & Life",
        rating: "4.7",
        reviewCount: 156,
        yearsExperience: 6,
        specialisations: ["City Breaks", "Honeymoons", "Luxury Holidays"],
        destinations: ["Europe", "Italy", "East Africa"],
        languages: ["English", "Italian", "German"],
        isTopRated: false,
      },
      {
        name: "Sophie Clark",
        location: "London",
        bio: "Sophie Clark brings over a decade of unparalleled expertise to the world of luxury travel planning, having established herself as one of London's most respected cultural travel experts. With an impressive portfolio spanning Asia and Europe, Sophie has dedicated her career to creating transformative journeys that go far beyond typical tourist experiences. Her passion for authentic cultural immersion began during her university years studying International Relations, which led to extensive solo backpacking adventures across Southeast Asia and Europe. These formative experiences shaped her understanding that true travel is about connecting with local communities, understanding different perspectives, and creating meaningful exchanges between cultures. Sophie's expertise in Japanese culture is particularly noteworthy - she spent two years living in Kyoto, studying traditional arts and developing deep relationships with local artisans, temple monks, and cultural preservationists. This immersive experience allows her to offer clients exclusive access to traditional tea ceremonies, private temple visits, and authentic ryokan stays that most travellers never experience. Her fluency in Japanese and Thai, combined with her extensive European travels, enables her to facilitate genuine cultural exchanges and navigate complex local customs with ease. What distinguishes Sophie from other travel planners is her meticulous attention to cultural sensitivity and her commitment to sustainable tourism practices. She partners exclusively with locally-owned businesses, family-run accommodations, and community-based tourism initiatives that benefit local economies while preserving cultural heritage. Her clients consistently praise her ability to balance luxury comfort with authentic experiences, whether that's arranging a private sake tasting with a master brewer in Hiroshima, organising cooking classes with hill tribe families in Northern Thailand, or securing exclusive access to art restoration workshops in Florence. Sophie's approach involves extensive pre-travel consultations where she learns about her clients' interests, comfort levels, and personal goals for their journey. This allows her to create highly personalised itineraries that challenge travellers intellectually while respecting their practical needs and preferences. Her 4.9-star rating from over 203 clients reflects her exceptional ability to exceed expectations while maintaining the highest standards of professionalism and cultural awareness.",
        profileImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop&crop=face",
        company: "Cultural Travel Expert",
        rating: "4.9",
        reviewCount: 203,
        yearsExperience: 10,
        specialisations: ["City Breaks", "Luxury Holidays", "Beach Holidays"],
        destinations: ["Japan", "Southeast Asia", "Europe"],
        languages: ["English", "Japanese", "Thai"],
        isTopRated: true,
      },
      {
        name: "Marcus Rodriguez",
        location: "Birmingham",
        bio: "Marcus Rodriguez has spent 7 years establishing himself as Birmingham's premier adventure travel specialist, with particular expertise in Central and South American expeditions that combine heart-pounding thrills with absolute safety and cultural authenticity. Born to a Costa Rican mother and Spanish father, Marcus's Latin heritage provides him with deep cultural connections and fluency in Spanish and Portuguese that open doors to experiences unavailable to typical adventure operators. His journey into adventure travel began with a university expedition to study wildlife conservation in Costa Rica, where he fell in love with the region's incredible biodiversity, warm culture, and endless opportunities for outdoor adventure. Marcus has personally explored every trail, river, and mountain he recommends, from the cloud forests of Monteverde to the peaks of Patagonia, building relationships with local guides, conservation organisations, and indigenous communities that enhance every expedition he organises. What sets Marcus apart is his unwavering commitment to safety without compromising the authentic thrill of adventure. He maintains the highest safety certifications in multiple adventure disciplines, personally vets every operator and guide he works with, and provides comprehensive pre-trip training to ensure his clients are prepared for the physical and mental challenges they'll face. His expeditions might include white-water rafting through remote Amazonian tributaries, multi-day treks to Machu Picchu via ancient Inca trails, zip-lining through Costa Rican canopies, or volcano hiking in Guatemala - all with meticulous safety protocols and experienced local guides who share their intimate knowledge of the land and its history. Marcus's approach extends beyond adrenaline-pumping activities to include meaningful cultural exchanges with local communities, conservation education, and opportunities to contribute to environmental protection efforts. His clients often return home not just with incredible adventure stories, but with a deeper understanding of Latin American cultures and a commitment to conservation. His 4.6-star rating from 89 clients reflects his ability to deliver transformative adventures that challenge limits while ensuring everyone returns home safely with memories that last a lifetime.",
        profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
        company: "Adventure Quest Travel",
        rating: "4.6",
        reviewCount: 89,
        yearsExperience: 7,
        specialisations: ["Adventure Holidays", "Safari Holidays", "Villa Holidays"],
        destinations: ["Costa Rica", "South America", "Central America"],
        languages: ["English", "Spanish", "Portuguese"],
        isTopRated: false,
      },
      {
        name: "Priya Sharma",
        location: "Leicester",
        bio: "Priya Sharma represents the pinnacle of luxury Asian travel curation, bringing nine years of specialised expertise in creating exclusive, high-end experiences across the continent's most prestigious destinations. Born in Leicester to parents who immigrated from Mumbai, Priya's multicultural background provides her with unique insights into both Western luxury expectations and authentic Asian hospitality traditions. Her career began in international hotel management, where she worked with luxury resort chains across the Maldives, Dubai, and Singapore, developing an intimate understanding of what constitutes exceptional service and attention to detail in the world's most exclusive properties. This foundation in hospitality excellence, combined with her natural linguistic abilities in English, Hindi, and Mandarin, positioned her perfectly to transition into bespoke travel planning for discerning clients seeking the very best that Asia has to offer. Priya's specialty lies in securing access to experiences that money alone cannot buy - private dining with Michelin-starred chefs in their homes, exclusive helicopter transfers to remote islands in the Maldives, private shopping experiences in Dubai's most exclusive boutiques, and intimate cultural performances in traditional settings. Her extensive network of contacts throughout Asia includes luxury property owners, private yacht captains, personal chefs, cultural ambassadors, and even members of royal families who occasionally open their private estates for her most distinguished clients. What sets Priya apart is her ability to seamlessly blend ultra-luxury accommodations with authentic cultural experiences. She might arrange a stay in the most exclusive overwater villa in the Maldives followed by a private marine biology expedition with world-renowned researchers, or organise a luxury shopping tour of Singapore's most exclusive districts combined with a private cooking class with a master chef specialising in Peranakan cuisine. Her clients appreciate her meticulous planning style, which includes detailed contingency plans for every aspect of their journey, 24/7 personal support throughout their travels, and post-trip follow-up to ensure every detail exceeded expectations. Her exceptional 4.9-star rating from 167 clients reflects her unwavering commitment to delivering experiences that consistently surpass even the highest expectations, making her the go-to specialist for luxury Asian travel among Britain's most discerning travellers.",
        profileImage: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&h=400&fit=crop&crop=face",
        company: "Prestige Travel Asia",
        rating: "4.9",
        reviewCount: 167,
        yearsExperience: 9,
        specialisations: ["Luxury Holidays", "Beach Holidays", "Honeymoons"],
        destinations: ["Maldives", "Dubai", "Singapore", "Japan"],
        languages: ["English", "Hindi", "Mandarin"],
        isTopRated: true,
      },
      {
        name: "James Mitchell",
        location: "Glasgow",
        bio: "James Mitchell has dedicated over 11 years to mastering the art of family travel, earning recognition as one of the UK's most trusted experts in creating magical, stress-free vacations that genuinely delight travellers of all ages. Based in Glasgow with deep Scottish roots, James understands the unique challenges that families face when planning holidays - from managing different interests and energy levels to ensuring safety and comfort while maintaining excitement and adventure. His journey into family travel specialisation began when he became a father himself and experienced firsthand the complexities of traveling with young children. This personal experience, combined with his professional background in educational psychology, gives him unique insights into child development, family dynamics, and how to create experiences that engage and inspire every family member. James has personally visited and evaluated hundreds of family-friendly accommodations, attractions, and destinations across Europe, the Mediterranean, and the Caribbean, building an extensive database of vetted options that meet his stringent standards for safety, comfort, and entertainment value. His approach to family travel planning is both methodical and creative - he conducts detailed consultations with each family member, including children, to understand individual interests, concerns, and expectations. This comprehensive understanding allows him to design itineraries that balance educational experiences with pure fun, active adventures with relaxation time, and child-friendly activities with sophisticated experiences that keep parents engaged and happy. What sets James apart is his extensive network of family-oriented service providers, including specialised tour guides who excel at engaging children, family-friendly accommodations with exceptional kids' clubs and childcare services, and activity operators who prioritise safety while delivering unforgettable experiences. He has established partnerships with theme parks across Europe, arranging VIP access and skip-the-line privileges that minimise waiting times and maximise enjoyment. His expertise extends to practical considerations that other planners often overlook - coordinating nap schedules with sightseeing, arranging child-safe transportation, ensuring dietary requirements are met, and having contingency plans for common family travel challenges like illness or weather disruptions. James's clients consistently praise his ability to anticipate needs they hadn't even considered, his patience in handling last-minute changes, and his talent for creating moments of genuine wonder and joy for children while ensuring parents feel relaxed and pampered throughout their journey.",
        profileImage: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400&h=400&fit=crop&crop=face",
        company: "Family Adventures UK",
        rating: "4.7",
        reviewCount: 142,
        yearsExperience: 11,
        specialisations: ["Family Holidays", "Beach Holidays", "Theme Park Holidays"],
        destinations: ["Europe", "Mediterranean", "Caribbean"],
        languages: ["English", "French", "German"],
        isTopRated: false,
      },
      {
        name: "Olivia Chen",
        location: "London",
        bio: "Olivia Chen has dedicated 6 years to mastering the delicate art of romantic travel, establishing herself as London's most trusted specialist for creating unforgettable moments that strengthen relationships and create lasting memories for couples. Born in London to Chinese parents, Olivia's multicultural background provides her with unique insights into different expressions of romance and intimacy across various cultures, allowing her to create experiences that resonate deeply with couples from diverse backgrounds. Her passion for romantic travel was inspired by her own engagement trip to Santorini, where she experienced firsthand how the right setting, perfect timing, and thoughtful details can transform a simple moment into a treasured lifetime memory. This personal experience led her to pursue specialised training in luxury hospitality and event planning, combined with extensive travel throughout Europe and Asia to identify the world's most romantic destinations and experiences. Olivia's approach to romantic travel goes far beyond booking beautiful hotels and restaurants - she creates carefully orchestrated experiences that celebrate each couple's unique love story. Her consultations involve understanding relationship milestones, personal interests, communication styles, and even individual preferences for public versus private displays of affection. This detailed understanding allows her to design experiences that feel authentic and meaningful rather than generic or forced. Whether planning surprise proposals overlooking the Amalfi Coast, organising private anniversary celebrations in secluded Balinese villas, or arranging intimate renewal of vows ceremonies in Tuscan vineyards, Olivia excels at creating moments that couples will treasure forever. Her expertise spans the most romantic destinations across Europe and Asia, from the iconic canals of Venice and sunset cliffs of Santorini to the serene beaches of the Maldives and ancient temples of Bali. She has developed relationships with local wedding planners, private chefs, photographers, and cultural performers who can create magical experiences on short notice. What sets Olivia apart is her attention to emotional details that other planners often overlook - coordinating surprise elements that reflect inside jokes or shared memories, arranging for meaningful music to play during special moments, or organising private access to locations that hold personal significance. Her 4.8-star rating from 198 clients reflects her consistent ability to exceed expectations and create romantic experiences that strengthen relationships and deepen emotional connections.",
        profileImage: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400&h=400&fit=crop&crop=face",
        company: "Romance & Travel Co",
        rating: "4.8",
        reviewCount: 198,
        yearsExperience: 6,
        specialisations: ["Honeymoons", "Luxury Holidays", "Beach Holidays"],
        destinations: ["Santorini", "Maldives", "Italy", "Bali"],
        languages: ["English", "Mandarin", "Italian"],
        isTopRated: true,
      },
      {
        name: "David Williams",
        location: "Newcastle",
        bio: "David Williams brings 8 years of specialised expertise in European cultural immersion, combining his academic background in history with passionate travel experience to create educational yet deeply enjoyable journeys for culture enthusiasts. Based in Newcastle with a PhD in Medieval European History, David's approach to travel goes far beyond typical sightseeing - he creates intellectual adventures that bring historical periods to life through authentic experiences, local traditions, and expert storytelling. His passion for European culture began during his doctoral research, which required extensive fieldwork across Italy, France, Greece, and Germany, studying historical sites, archives, and local traditions. This academic foundation, combined with his fluency in Italian, French, and German, allows him to provide historical context and cultural insights that transform simple tourist visits into profound learning experiences. David specialises in creating immersive journeys that appeal to intellectually curious travellers who want to truly understand the places they visit. His itineraries might include private access to archaeological sites with leading experts, exclusive visits to restoration workshops where ancient artifacts are being preserved, intimate conversations with local historians and cultural preservationists, or participation in traditional festivals that have been celebrated for centuries. What sets David apart is his ability to make complex historical narratives accessible and engaging for travellers of all backgrounds, whether they're history professors or simply curious individuals who want to deepen their understanding of European culture. His extensive network includes museum curators, archaeological teams, master craftspeople, and cultural institutions across Europe who provide behind-the-scenes access to experiences unavailable to typical tourists. David's approach involves thorough pre-travel education where he shares reading lists, historical documentaries, and cultural primers that enhance his clients' appreciation for the destinations they'll visit. He believes that informed travellers have richer, more meaningful experiences, so he invests considerable time in preparing his clients for the cultural nuances and historical significance of each location. His clients consistently praise his passionate storytelling, his ability to reveal hidden connections between historical events and modern culture, and his talent for creating 'lightbulb moments' where abstract historical concepts suddenly become vivid and relevant. David's 4.5-star rating from 76 clients reflects his success in making European culture accessible, engaging, and personally meaningful for discerning travellers who value intellectual enrichment alongside comfort and enjoyment.",
        profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
        company: "Cultural Compass",
        rating: "4.5",
        reviewCount: 76,
        yearsExperience: 8,
        specialisations: ["City Breaks", "Luxury Holidays", "Villa Holidays"],
        destinations: ["Italy", "Europe", "Greece", "France"],
        languages: ["English", "Italian", "French", "German"],
        isTopRated: false,
      },
      {
        name: "Fatima Al-Zahra",
        location: "London",
        bio: "Fatima Al-Zahra has spent 5 years establishing herself as London's premier specialist for Middle Eastern and North African travel, bringing authentic cultural knowledge and personal connections that provide travellers with unprecedented access to the MENA region's most extraordinary experiences. Born in Morocco and raised in London, Fatima's bicultural background provides her with unique insights into both Western travel expectations and authentic Middle Eastern hospitality traditions. Her fluency in Arabic, English, and French allows her to facilitate genuine cultural exchanges and navigate complex local customs with ease and respect. Fatima's expertise spans the diverse landscapes and cultures of the MENA region, from the ancient medinas of Morocco and the majestic pyramids of Egypt to the modern luxury of Dubai and the historical treasures of Jordan. Her personal connections throughout the region, cultivated through family networks and years of building relationships with local operators, provide her clients with access to experiences that typical tourists never encounter. She can arrange private dinners with Bedouin families in the Sahara Desert, exclusive access to archaeological sites with leading Egyptologists, intimate cooking classes with master chefs in traditional Moroccan riads, or private audiences with local artisans who practice crafts passed down through generations. What sets Fatima apart is her deep commitment to responsible tourism that respects local cultures while providing authentic experiences for her clients. She partners exclusively with locally-owned businesses, women's cooperatives, and community tourism initiatives that ensure travel dollars benefit local communities directly. Her expeditions often include meaningful cultural exchanges, volunteer opportunities with local organisations, and educational components that foster understanding and appreciation for Middle Eastern and North African cultures. Fatima's approach to luxury travel in the MENA region emphasizes authentic elegance - staying in traditional riads and heritage hotels rather than international chains, dining with local families rather than in tourist restaurants, and participating in traditional ceremonies and celebrations when appropriate. Her expertise in desert expeditions is particularly noteworthy, having personally explored the Sahara, Arabian, and Sinai deserts with experienced Bedouin guides who share their intimate knowledge of navigation, survival, and desert culture. Her 4.8-star rating from 134 clients reflects her ability to create transformative journeys that challenge stereotypes, build cultural bridges, and provide travellers with profound appreciation for the rich heritage and warm hospitality of the Middle East and North Africa.",
        profileImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face",
        company: "Desert Dreams Travel",
        rating: "4.8",
        reviewCount: 134,
        yearsExperience: 5,
        specialisations: ["Safari Holidays", "Luxury Holidays", "Adventure Holidays"],
        destinations: ["Dubai", "Morocco", "Egypt", "Jordan"],
        languages: ["English", "Arabic", "French"],
        isTopRated: true,
      },
      {
        name: "Tom Anderson",
        location: "Bristol",
        bio: "Tom Anderson has dedicated 4 years to perfecting tropical beach and water sports travel, establishing himself as Bristol's go-to specialist for creating perfect getaways that combine sun-soaked relaxation with thrilling aquatic adventures. A certified diving instructor and sailing enthusiast, Tom's passion for water sports began during his gap year traveling through Southeast Asia and the Caribbean, where he fell in love with the endless possibilities that tropical destinations offer for both relaxation and adventure. His expertise spans the world's most beautiful tropical destinations, from the crystal-clear waters of the Maldives and the vibrant coral reefs of the Caribbean to the pristine beaches of Thailand and the remote islands of Fiji. Tom has personally explored every beach, reef, and water activity he recommends, building relationships with local diving centres, sailing charters, and water sports operators that provide his clients with exceptional experiences at every destination. What sets Tom apart is his ability to balance pure relaxation with exciting water activities, creating itineraries that satisfy both the adrenaline-seeker and the sun-worshipper in every group. His expertise includes scuba diving, snorkeling, sailing, windsurfing, kitesurfing, deep-sea fishing, and emerging water sports like stand-up paddleboarding and underwater photography. He maintains current certifications in multiple water sports disciplines and works exclusively with operators who meet the highest safety standards while providing unforgettable experiences. Tom's approach involves understanding each client's comfort level with water activities, swimming abilities, and adventure preferences, then designing experiences that gently challenge boundaries while ensuring safety and enjoyment. He might arrange private sailing lessons in the calm waters of Barbados for nervous beginners, organise challenging multi-day diving expeditions to remote coral atolls for experienced divers, or create perfect honeymoon experiences that combine luxury beachfront accommodations with romantic sunset sailing adventures. His extensive network includes private yacht owners, master diving instructors, conservation organisations, and luxury beach resorts that provide exclusive access to the best tropical experiences. Tom's commitment to marine conservation is evident in all his recommendations - he partners with eco-friendly operators, promotes sustainable tourism practices, and often includes educational components about marine ecosystems and conservation efforts. His 4.6-star rating from 112 clients reflects his ability to create perfect tropical getaways that combine relaxation, adventure, and environmental awareness in stunning natural settings.",
        profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
        company: "Tropical Escapes",
        rating: "4.6",
        reviewCount: 112,
        yearsExperience: 4,
        specialisations: ["Beach Holidays", "Villa Holidays", "Honeymoons"],
        destinations: ["Maldives", "Caribbean", "Thailand", "Fiji"],
        languages: ["English", "Spanish"],
        isTopRated: false,
      },
      {
        name: "Isabella Romano",
        location: "Manchester",
        bio: "With over 12 years of experience in luxury travel planning, Isabella Romano has established herself as one of the most sought-after European travel specialists in the industry. Born to Italian parents in Manchester, Isabella's deep cultural heritage and natural passion for Mediterranean destinations have shaped her career into something truly extraordinary. Isabella's expertise extends far beyond simple itinerary planning - she creates immersive cultural experiences that connect travellers with the authentic soul of each destination. Her specialty lies in crafting sophisticated journeys across the Mediterranean, from the romantic canals of Venice to the sun-soaked islands of Greece, and the artistic treasures of Spain and France. What sets Isabella apart is her extensive network of local contacts throughout Europe, cultivated through years of personal travel and professional relationships. She has insider access to exclusive venues, private art collections, boutique accommodations, and hidden gems that typical tourists never discover. Her clients often describe her itineraries as 'life-changing' and 'perfectly curated works of art.' Isabella's approach to luxury travel goes beyond five-star hotels and Michelin-starred restaurants - though she certainly knows the best of both. She focuses on creating meaningful connections between her clients and the destinations they visit, whether that's arranging a private cooking class with a Tuscan grandmother, securing after-hours access to the Sistine Chapel, or organising a sunset yacht charter around Santorini. Her multilingual abilities in English, Italian, French, and Spanish allow her to facilitate authentic local interactions and ensure seamless communication throughout each journey. This linguistic expertise, combined with her cultural sensitivity and attention to detail, has earned her an exceptional 4.9-star rating from over 221 satisfied clients. Isabella believes that true luxury travel is about creating unforgettable memories and personal transformations through thoughtfully designed experiences that honour both the traveller's desires and the destination's authentic character.",
        profileImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop&crop=face",
        company: "Bella Europa Travel",
        rating: "4.9",
        reviewCount: 221,
        yearsExperience: 12,
        specialisations: ["Luxury Holidays", "City Breaks", "Honeymoons"],
        destinations: ["Italy", "France", "Spain", "Greece"],
        languages: ["English", "Italian", "French", "Spanish"],
        isTopRated: true,
      },
      {
        name: "Ryan O'Sullivan",
        location: "Cardiff",
        bio: "Ryan O'Sullivan has dedicated 9 years to mastering outdoor adventure travel, establishing himself as Cardiff's premier specialist for hiking, climbing, and expedition experiences that push boundaries while maintaining the highest safety standards. Born and raised in the Welsh valleys, Ryan's love for outdoor adventure began with childhood explorations of Snowdonia and the Brecon Beacons, which evolved into a lifelong passion for sharing the transformative power of wilderness experiences with others. His expertise spans multiple outdoor disciplines including mountaineering, rock climbing, wilderness navigation, survival skills, and expedition leadership, with current certifications from internationally recognised organisations. Ryan has personally completed challenging expeditions across six continents, from summiting peaks in the Himalayas and Andes to leading multi-day treks through remote wilderness areas in Patagonia, Alaska, and the European Alps. This extensive field experience, combined with his background in outdoor education and wilderness medicine training, allows him to design and lead expeditions that challenge participants physically and mentally while ensuring their safety and success. What sets Ryan apart is his ability to assess individual capabilities and tailor outdoor experiences that stretch comfort zones without exceeding safety limits. His pre-expedition training programs prepare clients for the physical demands, mental challenges, and technical skills required for their chosen adventure, whether that's learning basic mountaineering techniques for an Alpine ascent or developing wilderness navigation skills for a remote trekking expedition. Ryan's network includes certified mountain guides, wilderness medicine specialists, and conservation organisations across multiple continents who share his commitment to responsible outdoor recreation and environmental stewardship. His expeditions often include educational components about ecology, conservation, and local cultures, fostering appreciation for the natural environments his clients explore. His approach emphasises personal growth through challenge, team building, and developing confidence in outdoor environments, with many clients reporting that his expeditions fundamentally changed their relationship with nature and their understanding of their own capabilities. Ryan's commitment to safety is evident in his meticulous planning, comprehensive risk management protocols, and insistence on proper equipment and training. His 4.7-star rating from 95 clients reflects his ability to deliver life-changing outdoor adventures that combine genuine challenge with absolute safety and environmental responsibility.",
        profileImage: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Peak Adventures",
        rating: "4.7",
        reviewCount: 95,
        yearsExperience: 6,
        specialisations: ["Adventure Holidays", "Skiing Holidays", "Villa Holidays"],
        destinations: ["Nepal", "Patagonia", "Alps", "Himalayas"],
        languages: ["English", "Spanish", "Nepali"],
        isTopRated: false,
      },
      {
        name: "Aisha Patel",
        location: "Leeds",
        bio: "Aisha Patel has spent 3 years revolutionizing budget travel for young explorers, proving that meaningful travel experiences don't require expensive budgets. Based in Leeds with a background in finance and a passion for adventure, Aisha specialises in creating comprehensive budget-friendly itineraries that maximise experiences while minimising costs, making world travel accessible to students, young professionals, and anyone seeking affordable adventures. Her expertise in budget travel was born from necessity during her university years, when she developed creative strategies for exploring Europe and Southeast Asia on a shoestring budget. These experiences taught her that the most authentic and memorable travel moments often happen when you step away from luxury tourist infrastructure and engage with local communities, use public transportation, stay in hostels and guesthouses, and eat where locals eat. Aisha's approach goes far beyond simply finding cheap flights and accommodation - she creates strategic travel plans that leverage budget airlines, off-season pricing, group discounts, volunteer opportunities, and local transportation networks to stretch travel budgets as far as possible. Her expertise spans multiple regions including Southeast Asia, Eastern Europe, and South America, where she has established networks of budget-friendly accommodations, reliable local operators, and community-based tourism initiatives that provide authentic experiences at affordable prices. What sets Aisha apart is her ability to combine financial practicality with safety awareness and cultural sensitivity. She provides comprehensive pre-trip education about budget travel strategies, safety protocols for independent travellers, cultural etiquette, and practical skills like navigation, basic language phrases, and negotiation techniques. Her itineraries include detailed budget breakdowns, emergency backup plans, and connections to other budget travellers for shared experiences and cost-splitting opportunities. Aisha's commitment to responsible budget travel is evident in her partnerships with ethical hostels, sustainable tourism operators, and social enterprises that reinvest travel dollars into local communities. Her clients consistently praise her ability to create rich, authentic travel experiences that rival expensive guided tours while staying within tight budget constraints. Her 4.4-star rating from 83 clients reflects her success in making world travel accessible and affordable while maintaining safety and cultural authenticity.",
        profileImage: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Budget Wanderers",
        rating: "4.4",
        reviewCount: 83,
        yearsExperience: 3,
        specialisations: ["Adventure Holidays", "City Breaks", "Family Holidays"],
        destinations: ["Southeast Asia", "Eastern Europe", "South America"],
        languages: ["English", "Hindi", "Thai"],
        isTopRated: false,
      },
      {
        name: "Charles Dubois",
        location: "Edinburgh",
        bio: "Charles Dubois brings 14 years of specialised expertise in luxury cruise travel, establishing himself as Edinburgh's most respected maritime travel specialist for both ocean voyages and river cruises. Born in France and educated in hospitality management, Charles combines European sophistication with British attention to detail, creating sophisticated maritime experiences that exceed the expectations of even the most discerning travellers. His extensive knowledge spans the world's premier cruise lines, from intimate luxury vessels carrying fewer than 100 guests to grand ocean liners, as well as boutique river cruise operators that provide exclusive access to inland waterways and cultural sites. Charles has personally sailed on over 200 different vessels, evaluating everything from cabin configurations and dining options to onboard entertainment and shore excursion quality, building an unparalleled database of firsthand knowledge about maritime travel options worldwide. His expertise covers diverse cruise experiences including Mediterranean cultural voyages, Caribbean tropical escapes, Baltic heritage expeditions, Alaska wilderness adventures, and European river cruises through wine regions and historic capitals. What sets Charles apart is his ability to match travellers with the perfect vessel and itinerary based on their interests, mobility needs, social preferences, and desired level of formality. His consultations involve detailed discussions about everything from dress codes and dining styles to cabin locations and shore excursion preferences, ensuring that every aspect of the cruise experience aligns with his clients' expectations. Charles maintains relationships with cruise line executives, ship captains, and shore excursion operators that allow him to secure exclusive amenities, cabin upgrades, and special access experiences for his clients. His services often include pre-cruise planning assistance, onboard meet-and-greets, and post-cruise follow-up to ensure complete satisfaction. His expertise in river cruising is particularly noteworthy, having sailed on virtually every major river in Europe, Asia, and Africa, allowing him to recommend the perfect vessel and timing for cultural immersion, culinary exploration, or scenic appreciation. Charles's 4.8-star rating from 156 clients reflects his consistent ability to create seamless maritime experiences that combine luxury, culture, and adventure in perfectly orchestrated floating journeys.",
        profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Premium Cruises Ltd",
        rating: "4.8",
        reviewCount: 156,
        yearsExperience: 14,
        specialisations: ["Cruises", "Luxury Holidays", "Honeymoons"],
        destinations: ["Mediterranean", "Caribbean", "Baltic", "Alaska"],
        languages: ["English", "French", "German"],
        isTopRated: true,
      },
      {
        name: "Mei Lin Wong",
        location: "London",
        bio: "Mei Lin Wong has dedicated 7 years to creating authentic cultural immersion experiences across East and Southeast Asia, establishing deep connections with local communities and cultural preservationists that provide her clients with unprecedented access to traditional customs, arts, and ways of life. Born in Hong Kong and raised in London, Mei Lin's bicultural background provides her with unique insights into both Western travel expectations and authentic Asian cultural traditions, allowing her to create experiences that bridge cultural differences while honoring local customs and traditions. Her expertise spans the diverse cultures of Japan, Singapore, Thailand, and Vietnam, where she has spent extensive time living with local families, studying traditional arts, and building relationships with master craftspeople, spiritual leaders, and cultural ambassadors who rarely interact with typical tourists. Mei Lin's fluency in Mandarin, Cantonese, and Thai, combined with her deep understanding of Asian etiquette and social customs, allows her to facilitate meaningful cultural exchanges that go far beyond surface-level tourist experiences. Her itineraries often include participation in traditional ceremonies, workshops with master artisans, homestays with local families, and visits to cultural sites that are typically closed to tourists. What sets Mei Lin apart is her commitment to responsible cultural tourism that benefits local communities while providing travellers with transformative insights into Asian cultures. She partners exclusively with community-based tourism initiatives, family-owned businesses, and cultural preservation projects that ensure travel dollars directly support the communities and traditions her clients experience. Her approach involves extensive pre-travel cultural education where she prepares clients for cultural differences, teaches basic language phrases and etiquette, and provides historical context that enhances understanding and appreciation. Mei Lin's network includes temple monks, traditional healers, master chefs, textile artisans, and cultural performers who share their knowledge and traditions with her clients in intimate, authentic settings. Her clients consistently describe their journeys as life-changing, citing not just the stunning destinations and delicious cuisine, but the profound personal connections and cultural insights that reshape their understanding of Asian cultures and their own worldview. Her 4.6-star rating from 108 clients reflects her exceptional ability to create meaningful cultural exchanges that foster understanding, respect, and lasting appreciation for the rich diversity of Asian traditions.",
        profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Asia Authentic",
        rating: "4.6",
        reviewCount: 108,
        yearsExperience: 7,
        specialisations: ["City Breaks", "Beach Holidays", "Villa Holidays"],
        destinations: ["Japan", "Singapore", "Thailand", "Vietnam"],
        languages: ["English", "Mandarin", "Cantonese", "Thai"],
        isTopRated: false,
      },
      {
        name: "Benjamin Clarke",
        location: "Oxford",
        bio: "Benjamin Clarke has spent 10 years establishing himself as Oxford's premier wildlife and safari specialist, combining his zoology background with extensive field experience to create unforgettable African adventures that support conservation while providing clients with transformative wildlife encounters. Born with a passion for wildlife conservation, Benjamin pursued advanced degrees in zoology and conservation biology before transitioning into specialised safari travel planning, where he could combine his scientific knowledge with his love for African ecosystems and cultures. His expertise spans the major safari destinations of Kenya, Tanzania, South Africa, and Botswana, where he has spent months studying animal behaviour, migration patterns, and conservation challenges while building relationships with local guides, conservation organisations, and community tourism initiatives. Benjamin's approach to safari travel goes far beyond typical game viewing - he creates educational experiences that deepen understanding of African ecosystems, conservation challenges, and the complex relationships between wildlife, local communities, and tourism. His safaris often include meetings with conservationists, visits to research stations, participation in wildlife monitoring activities, and opportunities to contribute to conservation efforts through citizen science projects. What sets Benjamin apart is his ability to time safaris for optimal wildlife viewing while supporting conservation efforts that benefit both animals and local communities. His extensive knowledge of animal behaviour allows him to predict the best locations and times for wildlife encounters, from the Great Migration river crossings to leopard sightings and rare bird observations. Benjamin maintains partnerships with community conservancies, anti-poaching organisations, and wildlife research projects that provide his clients with exclusive access to conservation work while ensuring their travel dollars directly support wildlife protection efforts. His expertise includes photography safaris with professional wildlife photographers, family safaris designed to inspire the next generation of conservationists, and luxury safaris that combine comfort with authentic wilderness experiences. Benjamin's fluency in Swahili and Afrikaans allows him to facilitate meaningful interactions with local guides and community members, creating cultural exchanges that enhance understanding of African traditions and perspectives on wildlife conservation. His 4.9-star rating from 174 clients reflects his exceptional ability to create safari experiences that are both thrilling and meaningful, combining world-class wildlife viewing with educational content and conservation impact that creates lasting appreciation for African wildlife and cultures.",
        profileImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Safari Specialists",
        rating: "4.9",
        reviewCount: 174,
        yearsExperience: 10,
        specialisations: ["Safari Holidays", "Adventure Holidays", "Villa Holidays"],
        destinations: ["Kenya", "Tanzania", "South Africa", "Botswana"],
        languages: ["English", "Swahili", "Afrikaans"],
        isTopRated: true,
      },
      {
        name: "Nina Kowalski",
        location: "Brighton",
        bio: "Nina Kowalski has dedicated 5 years to creating transformative wellness and retreat experiences that combine mindful travel with holistic healing, establishing herself as Brighton's most trusted specialist for yoga retreats, spa destinations, and wellness journeys that nourish body, mind, and spirit. Born in Poland and trained in various healing modalities including yoga instruction, meditation, and holistic nutrition, Nina's multicultural background and personal wellness journey provide her with deep understanding of different approaches to health and healing across various cultures. Her expertise spans the world's premier wellness destinations including Bali, India, Costa Rica, and Thailand, where she has personally experienced and evaluated hundreds of retreat centres, spa resorts, and wellness programs to ensure they meet her high standards for authentic healing experiences. Nina's approach to wellness travel goes beyond simple relaxation - she creates carefully curated experiences that address specific wellness goals whether that's stress reduction, spiritual growth, physical healing, or personal transformation. Her retreats might include daily yoga and meditation practice with master teachers, organic farm-to-table cuisine, traditional healing treatments, workshops on mindfulness and personal development, and opportunities for digital detox and deep reflection. What sets Nina apart is her ability to match travellers with wellness experiences that align with their personal goals, experience level, and comfort preferences. Her consultations involve understanding individual health challenges, spiritual interests, physical capabilities, and desired outcomes, allowing her to recommend retreats that provide genuine transformation rather than superficial relaxation. Nina maintains relationships with renowned yoga teachers, meditation masters, holistic healers, and wellness resort managers who provide her clients with authentic experiences led by qualified practitioners. Her expertise includes specialised retreats for specific needs such as anxiety and stress management, weight loss and nutrition, spiritual awakening, creative inspiration, and relationship healing. Nina's commitment to authentic wellness is evident in her partnerships with retreat centres that emphasize traditional healing practices, sustainable living, and community connection rather than commercialized spa treatments. Her multilingual abilities in English, Polish, and German allow her to serve diverse clients and facilitate communications with international wellness practitioners. Her 4.7-star rating from 127 clients reflects her success in creating wellness experiences that provide lasting transformation, improved health, and renewed sense of purpose and vitality.",
        profileImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Mindful Journeys",
        rating: "4.7",
        reviewCount: 127,
        yearsExperience: 5,
        specialisations: ["Beach Holidays", "Villa Holidays", "Luxury Holidays"],
        destinations: ["Bali", "India", "Costa Rica", "Thailand"],
        languages: ["English", "Polish", "German"],
        isTopRated: false,
      },
      {
        name: "Hassan Ahmed",
        location: "Birmingham",
        bio: "Hassan Ahmed has spent 6 years pioneering halal travel solutions, establishing himself as Birmingham's leading specialist for ensuring comfortable, culturally appropriate, and spiritually enriching travel experiences for Muslim families and individuals. Born in Birmingham to Pakistani parents, Hassan's deep understanding of Islamic values and travel requirements, combined with his extensive knowledge of halal-friendly destinations worldwide, allows him to create seamless travel experiences that honor religious obligations while providing enriching cultural and recreational opportunities. His expertise spans diverse destinations including Malaysia, Turkey, Morocco, and the UAE, where he has personally evaluated accommodations, restaurants, and activities to ensure they meet halal standards and cultural sensitivities. Hassan's approach to halal travel goes beyond simply finding halal food and prayer facilities - he creates comprehensive experiences that allow Muslim travellers to explore the world while maintaining their religious practices and cultural comfort. His services include identifying accommodations with appropriate amenities, locating nearby mosques and prayer facilities, arranging halal dining options, coordinating travel schedules around prayer times and religious observances, and ensuring cultural activities respect Islamic values. What sets Hassan apart is his extensive network of halal-certified operators, Muslim-owned businesses, and culturally sensitive service providers who understand the specific needs of Muslim travellers. He has established relationships with halal hotels, Islamic tour guides, Muslim-friendly cruise lines, and family-oriented activity providers who create welcoming environments for travellers observing Islamic practices. Hassan's expertise includes family holidays designed for multi-generational Muslim families, educational trips that explore Islamic history and culture, luxury halal resorts that combine comfort with religious accommodation, and business travel solutions for Muslim professionals. His multilingual abilities in English, Arabic, Urdu, and Turkish allow him to facilitate communications and ensure cultural understanding throughout the travel experience. Hassan's commitment to community service is evident in his partnerships with Islamic organisations, halal certification bodies, and Muslim travel communities that provide resources and support for halal travellers worldwide. His approach includes pre-travel consultations about specific religious requirements, detailed destination guides about local Muslim communities and facilities, and 24/7 support during travel to address any concerns or challenges. His 4.8-star rating from 145 clients reflects his exceptional ability to create travel experiences that allow Muslim families to explore the world confidently while maintaining their religious practices and cultural values.",
        profileImage: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Halal Travel Solutions",
        rating: "4.8",
        reviewCount: 145,
        yearsExperience: 6,
        specialisations: ["Family Holidays", "City Breaks", "Beach Holidays"],
        destinations: ["Malaysia", "Turkey", "Morocco", "UAE"],
        languages: ["English", "Arabic", "Urdu", "Turkish"],
        isTopRated: true,
      },
      {
        name: "Laura Mackenzie",
        location: "Inverness",
        bio: "Northern European specialist with expertise in Scandinavian countries and Arctic experiences. Creates unique adventures in Nordic destinations.",
        profileImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face",
        company: "Nordic Adventures",
        rating: "4.5",
        reviewCount: 69,
        yearsExperience: 4,
        specialisations: ["Adventure Holidays", "Skiing Holidays", "Villa Holidays"],
        destinations: ["Iceland", "Norway", "Finland", "Sweden"],
        languages: ["English", "Norwegian", "Swedish"],
        isTopRated: false,
      },
      {
        name: "Raj Gupta",
        location: "Leicester",
        bio: "Spiritual and heritage travel expert specializing in India and spiritual destinations. Creates transformative journeys combining culture, spirituality, and adventure.",
        profileImage: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Spiritual Pathways",
        rating: "4.6",
        reviewCount: 91,
        yearsExperience: 8,
        specialisations: ["City Breaks", "Adventure Holidays", "Villa Holidays"],
        destinations: ["India", "Nepal", "Bhutan", "Tibet"],
        languages: ["English", "Hindi", "Gujarati", "Sanskrit"],
        isTopRated: false,
      },
      {
        name: "Maria Santos",
        location: "London",
        bio: "Caribbean and Central America specialist with extensive knowledge of island cultures and tropical experiences. Expert in creating perfect beach and cultural combinations.",
        profileImage: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Tropical Wanderlust",
        rating: "4.7",
        reviewCount: 118,
        yearsExperience: 7,
        specialisations: ["Beach Holidays", "Villa Holidays", "Honeymoons"],
        destinations: ["Barbados", "Jamaica", "Mexico", "Dominican Republic"],
        languages: ["English", "Spanish", "Portuguese"],
        isTopRated: true,
      },
      {
        name: "Alexander Petrov",
        location: "Edinburgh",
        bio: "Eastern European and Russian travel expert specializing in cultural heritage and historical destinations. Creates immersive experiences in off-the-beaten-path locations.",
        profileImage: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Heritage Explorers",
        rating: "4.5",
        reviewCount: 89,
        yearsExperience: 9,
        specialisations: ["City Breaks", "Adventure Holidays", "Villa Holidays"],
        destinations: ["Croatia", "Montenegro", "Czech Republic"],
        languages: ["English", "Russian", "Croatian", "German"],
        isTopRated: false,
      },
      {
        name: "Zara Al-Rashid",
        location: "Manchester",
        bio: "Gulf States luxury specialist with deep connections across the Middle East. Expert in ultra-high-end experiences and exclusive access to premium destinations.",
        profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Elite Middle East",
        rating: "4.9",
        reviewCount: 156,
        yearsExperience: 11,
        specialisations: ["Luxury Holidays", "Villa Holidays", "Honeymoons"],
        destinations: ["Dubai", "Qatar", "Oman", "Abu Dhabi", "Ras Al Khaimah"],
        languages: ["English", "Arabic", "Farsi"],
        isTopRated: true,
      },
      {
        name: "Jake Morrison",
        location: "Cornwall",
        bio: "Adventure sports and extreme travel specialist. Organizes thrilling experiences from skydiving to volcano tours for adrenaline seekers worldwide.",
        profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Extreme Adventures Co",
        rating: "4.6",
        reviewCount: 94,
        yearsExperience: 6,
        specialisations: ["Adventure Holidays", "Safari Holidays", "Skiing Holidays"],
        destinations: ["New Zealand", "Iceland", "Costa Rica"],
        languages: ["English", "German"],
        isTopRated: false,
      },
      {
        name: "Annika Johansson",
        location: "London",
        bio: "Scandinavian winter specialist and Northern Lights expert. Creates magical Arctic experiences including luxury ice hotels and reindeer encounters.",
        profileImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Arctic Dreams",
        rating: "4.8",
        reviewCount: 134,
        yearsExperience: 8,
        specialisations: ["Adventure Holidays", "Skiing Holidays", "Luxury Holidays"],
        destinations: ["Lapland", "Finland", "Iceland", "Norway"],
        languages: ["English", "Swedish", "Norwegian", "Finnish"],
        isTopRated: true,
      },
      {
        name: "Carlos Mendoza",
        location: "Bristol",
        bio: "South American adventure specialist with passion for Andean cultures and Patagonian landscapes. Expert in eco-lodges and sustainable tourism.",
        profileImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Andean Expeditions",
        rating: "4.7",
        reviewCount: 102,
        yearsExperience: 10,
        specialisations: ["Adventure Holidays", "Safari Holidays", "Villa Holidays"],
        destinations: ["Peru", "Chile", "Argentina"],
        languages: ["English", "Spanish", "Quechua"],
        isTopRated: false,
      },
      {
        name: "Kenji Nakamura",
        location: "London",
        bio: "Japanese culture and technology specialist offering unique insights into modern and traditional Japan. Expert in cherry blossom tours and tech experiences.",
        profileImage: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Rising Sun Travel",
        rating: "4.8",
        reviewCount: 167,
        yearsExperience: 12,
        specialisations: ["City Breaks", "Luxury Holidays", "Beach Holidays"],
        destinations: ["Japan", "South Korea"],
        languages: ["English", "Japanese", "Korean"],
        isTopRated: true,
      },
      {
        name: "Sophia Rossi",
        location: "Bath",
        bio: "Mediterranean luxury villa specialist with extensive portfolio of exclusive properties. Creates bespoke experiences in hidden gems across the Mediterranean.",
        profileImage: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Villa Bella",
        rating: "4.9",
        reviewCount: 203,
        yearsExperience: 14,
        specialisations: ["Villa Holidays", "Luxury Holidays", "Honeymoons"],
        destinations: ["Italy", "Greece", "Spain", "Cyprus", "Malta"],
        languages: ["English", "Italian", "Greek", "Spanish"],
        isTopRated: true,
      },
      {
        name: "Ethan Campbell",
        location: "Glasgow",
        bio: "North American wilderness expert specializing in national parks and outdoor adventures. Creates unforgettable experiences in USA and Canada's pristine nature.",
        profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
        company: "Wild North Adventures",
        rating: "4.6",
        reviewCount: 87,
        yearsExperience: 5,
        specialisations: ["Adventure Holidays", "Safari Holidays", "Skiing Holidays"],
        destinations: ["USA", "Canada", "Alaska"],
        languages: ["English", "French"],
        isTopRated: false,
      },
      {
        name: "Amara Okafor",
        location: "Birmingham",
        bio: "African safari and cultural heritage specialist with deep knowledge of East and Southern Africa. Creates authentic experiences while supporting local communities.",
        profileImage: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Ubuntu Safaris",
        rating: "4.8",
        reviewCount: 145,
        yearsExperience: 9,
        specialisations: ["Safari Holidays", "Adventure Holidays", "Family Holidays"],
        destinations: ["Kenya", "Tanzania & Zanzibar", "South Africa", "Morocco"],
        languages: ["English", "Swahili", "French", "Arabic"],
        isTopRated: true,
      },
      {
        name: "Philippe Dubois",
        location: "London",
        bio: "French luxury and gastronomy expert specializing in exclusive culinary journeys and wine experiences across France and neighboring regions.",
        profileImage: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Gastronomic Journeys",
        rating: "4.9",
        reviewCount: 189,
        yearsExperience: 16,
        specialisations: ["Luxury Holidays", "Villa Holidays", "City Breaks"],
        destinations: ["France", "Switzerland", "Belgium"],
        languages: ["English", "French", "German", "Italian"],
        isTopRated: true,
      },
      {
        name: "Lily Chen",
        location: "Manchester",
        bio: "Southeast Asian family travel specialist ensuring safe and engaging experiences for families with children. Expert in kid-friendly resorts and activities.",
        profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Family Asia Adventures",
        rating: "4.7",
        reviewCount: 124,
        yearsExperience: 6,
        specialisations: ["Family Holidays", "Beach Holidays", "Theme Park Holidays"],
        destinations: ["Thailand", "Singapore", "Bali", "Malaysia"],
        languages: ["English", "Mandarin", "Thai", "Malay"],
        isTopRated: false,
      },
      {
        name: "Roberto Silva",
        location: "Liverpool",
        bio: "Portuguese and Iberian Peninsula specialist with expertise in coastal regions and cultural cities. Creates perfect combinations of beach and culture.",
        profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Iberian Escapes",
        rating: "4.5",
        reviewCount: 78,
        yearsExperience: 4,
        specialisations: ["Beach Holidays", "City Breaks", "Villa Holidays"],
        destinations: ["Portugal", "Spain"],
        languages: ["English", "Portuguese", "Spanish"],
        isTopRated: false,
      },
      {
        name: "Hannah Stewart",
        location: "Edinburgh",
        bio: "Luxury cruise and ocean voyage specialist with connections to premium cruise lines worldwide. Creates extraordinary maritime experiences for discerning travellers.",
        profileImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Ocean Elite Cruises",
        rating: "4.8",
        reviewCount: 198,
        yearsExperience: 11,
        specialisations: ["Cruises", "Luxury Holidays", "Honeymoons"],
        destinations: ["Caribbean", "Mediterranean", "Baltic", "Alaska"],
        languages: ["English", "French", "German"],
        isTopRated: true,
      },
      {
        name: "Omar Hassan",
        location: "Leeds",
        bio: "North African cultural specialist with deep knowledge of Berber traditions and Sahara expeditions. Creates authentic cultural immersion experiences.",
        profileImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Sahara Cultural Tours",
        rating: "4.6",
        reviewCount: 89,
        yearsExperience: 7,
        specialisations: ["Safari Holidays", "Adventure Holidays", "Villa Holidays"],
        destinations: ["Morocco", "Egypt", "Tunisia"],
        languages: ["English", "Arabic", "French", "Berber"],
        isTopRated: false,
      },
      {
        name: "Gabriela Costa",
        location: "Brighton",
        bio: "Brazilian carnival and festival specialist bringing the vibrant culture of South America to life. Expert in music, dance, and cultural celebrations.",
        profileImage: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Carnival Adventures",
        rating: "4.7",
        reviewCount: 112,
        yearsExperience: 8,
        specialisations: ["Beach Holidays", "Adventure Holidays", "Family Holidays"],
        destinations: ["Brazil", "Argentina", "Colombia"],
        languages: ["English", "Portuguese", "Spanish"],
        isTopRated: false,
      },
      {
        name: "William Harper",
        location: "York",
        bio: "Australian and Pacific specialist with extensive knowledge of Oceania's diverse landscapes and cultures. Creates unique experiences across the Pacific region.",
        profileImage: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Pacific Horizons",
        rating: "4.8",
        reviewCount: 156,
        yearsExperience: 12,
        specialisations: ["Adventure Holidays", "Safari Holidays", "Beach Holidays"],
        destinations: ["Australia", "New Zealand", "Fiji", "Bora Bora"],
        languages: ["English", "French"],
        isTopRated: true,
      },
      {
        name: "Indira Sharma",
        location: "London",
        bio: "Indian subcontinent and spiritual journey specialist. Expert in yoga retreats, Ayurveda experiences, and cultural immersion in India and neighboring regions.",
        profileImage: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Spiritual India Journeys",
        rating: "4.6",
        reviewCount: 134,
        yearsExperience: 9,
        specialisations: ["Villa Holidays", "Beach Holidays", "Adventure Holidays"],
        destinations: ["India", "Sri Lanka", "Nepal", "Bhutan"],
        languages: ["English", "Hindi", "Tamil", "Sanskrit"],
        isTopRated: false,
      },
      {
        name: "Magnus Eriksson",
        location: "Aberdeen",
        bio: "Polar expedition specialist with experience in both Arctic and Antarctic regions. Creates once-in-a-lifetime polar adventures for intrepid travellers.",
        profileImage: "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=faceh=400https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facefit=crophttps://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=facecrop=face",
        company: "Polar Expeditions Ltd",
        rating: "4.9",
        reviewCount: 87,
        yearsExperience: 15,
        specialisations: ["Adventure Holidays", "Skiing Holidays", "Luxury Holidays"],
        destinations: ["Antarctica", "Greenland", "Svalbard"],
        languages: ["English", "Norwegian", "Swedish", "Danish"],
        isTopRated: true,
      },
    ];

    agents.forEach(agent => {
      const id = this.currentAgentId++;
      this.agents.set(id, { 
        ...agent, 
        id, 
        createdAt: new Date(),
        email: `${agent.name.toLowerCase().replace(/\s+/g, '.')}@example.com`,
        password: "hashed_password_placeholder",
        firstName: agent.name.split(' ')[0],
        lastName: agent.name.split(' ').slice(1).join(' ') || "Agent",
        photos: [],
        videoUrl: null,
        nextHoliday: "",
        isVerified: false,
        profileViews: 0,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      });
    });



    // Initialize offers - Updated to match current database schema
    const offers = [
      {
        agentId: 1,
        title: "Costa Rican Eco-Adventure",
        description: "Experience an exclusive 7-day wildlife expedition through Costa Rica's pristine rainforests. This adventure includes guided nature walks, wildlife spotting, canopy tours, and stays in eco-friendly lodges.",
        briefDescription: "Exclusive 7-day wildlife expedition",
        heroImage: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&h=600&fit=crop&crop=centre",
        fromPrice: "£1,299 per person",
        destinations: ["Costa Rica"],
        holidayTypes: ["Adventure Holidays", "Wildlife Holidays"],
        status: "published",
        offerMessage1: "30% Early Bird Discount",
        offerMessage2: "Expert Local Guides",
        offerMessage3: "Eco-Lodge Accommodation",
        validUntil: new Date(Date.now() + 60 * 24 * 60 * 60 * 1000),
      },
      {
        agentId: 2,
        title: "Himalayan Expedition",
        description: "Embark on a challenging 14-day guided trek through the magnificent Himalayas with experienced local guides. Includes mountain lodge accommodation, all meals, and porter support.",
        briefDescription: "14-day guided trek with expert guides",
        heroImage: "https://images.unsplash.com/photo-1526392060635-9d6019884377?w=800&h=600&fit=crop&crop=centre",
        fromPrice: "£2,499 per person",
        destinations: ["Nepal"],
        holidayTypes: ["Adventure Holidays", "Trekking Holidays"],
        status: "published",
        offerMessage1: "25% Limited Time Offer",
        offerMessage2: "Expert Mountain Guides",
        offerMessage3: "Full Porter Support",
        validUntil: new Date(Date.now() + 45 * 24 * 60 * 60 * 1000),
      },
      {
        agentId: 3,
        title: "Riviera Love Retreat",
        description: "Celebrate romance with a luxurious 5-star escape along the stunning French Riviera. Includes spa treatments, private dining, and breathtaking Mediterranean views.",
        briefDescription: "Romantic 5-star escape with spa treatments",
        heroImage: "https://images.unsplash.com/photo-1515542622106-78bda8ba0e5b?w=800&h=600&fit=crop&crop=centre",
        fromPrice: "£1,799 per person",
        destinations: ["France"],
        holidayTypes: ["Honeymoons", "Luxury Holidays"],
        status: "published",
        offerMessage1: "20% Couples Discount",
        offerMessage2: "Luxury Spa Package",
        offerMessage3: "Private Dining Experience",
        validUntil: new Date(Date.now() + 90 * 24 * 60 * 60 * 1000),
      },
      {
        agentId: 4,
        title: "Japanese Cultural Immersion",
        description: "Discover authentic Japan through this comprehensive 10-day cultural journey. Experience traditional ryokans, tea ceremonies, temple visits, and expert-guided city tours.",
        briefDescription: "10-day authentic experience with local guides",
        heroImage: "https://images.unsplash.com/photo-1528164344705-47542687000d?w=800&h=600&fit=crop&crop=centre",
        fromPrice: "£2,299 per person",
        destinations: ["Japan"],
        holidayTypes: ["Cultural Holidays", "City Breaks"],
        status: "published",
        offerMessage1: "15% Early Booking Discount",
        offerMessage2: "Traditional Ryokan Stays",
        offerMessage3: "Private Cultural Tours",
        validUntil: new Date(Date.now() + 120 * 24 * 60 * 60 * 1000),
      },
    ];

    offers.forEach(offer => {
      const id = this.currentOfferId++;
      this.offers.set(id, { 
        ...offer, 
        id, 
        createdAt: new Date(),
        updatedAt: new Date()
      });
    });

    // Initialize reviews
    const reviews = [
      {
        agentId: 1,
        enquiryId: null,
        customerName: "Sarah & Mike",
        customerEmail: "sarah.mike@example.com",
        customerImage: "https://images.unsplash.com/photo-1521572267360-ee0c2909d518?w=100&h=100&fit=crop&crop=face",
        rating: 5,
        reviewText: "Emma planned the most incredible honeymoon to the Maldives. Every detail was perfect, from the overwater villa to the sunset dinners. We couldn't have asked for a better experience!",
        tripType: "Honeymoon to Maldives",
        isVerified: true,
        reviewEmailSent: false,
        reviewEmailSentAt: null,
      },
      {
        agentId: 1,
        enquiryId: null,
        customerName: "Alex Thompson",
        customerEmail: "alex.thompson@example.com",
        customerImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=100&h=100&fit=crop&crop=face",
        rating: 5,
        reviewText: "Outstanding service from start to finish. Emma's attention to detail and local knowledge made our Costa Rica adventure absolutely unforgettable. Highly recommend!",
        tripType: "Adventure in Costa Rica",
        isVerified: true,
        reviewEmailSent: false,
        reviewEmailSentAt: null,
      },
      {
        agentId: 2,
        enquiryId: null,
        customerName: "Johnson Family",
        customerEmail: "johnson.family@example.com",
        customerImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
        rating: 5,
        reviewText: "Adam's expertise in Asian destinations is unmatched. Our family trip to Japan was educational, fun, and perfectly organised. The kids are already asking when we can go back!",
        tripType: "Cultural Trip to Japan",
        isVerified: true,
        reviewEmailSent: false,
        reviewEmailSentAt: null,
      },
      {
        agentId: 3,
        enquiryId: null,
        customerName: "David & Emma",
        customerEmail: "david.emma@example.com",
        customerImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=100&h=100&fit=crop&crop=face",
        rating: 5,
        reviewText: "Rachel created the perfect romantic getaway for our anniversary. The boutique hotels, wine tastings, and private tours in Tuscany exceeded all our expectations. Absolutely magical!",
        tripType: "Anniversary in Tuscany",
        isVerified: true,
        reviewEmailSent: false,
        reviewEmailSentAt: null,
      },
      {
        agentId: 8,
        enquiryId: null,
        customerName: "Maria Rodriguez",
        customerEmail: "maria.rodriguez@example.com",
        customerImage: "https://images.unsplash.com/photo-1494790108755-2616b612b647?w=100&h=100&fit=crop&crop=face",
        rating: 5,
        reviewText: "Olivia's knowledge of Southeast Asia is incredible. Our luxury tour through Thailand and Vietnam was perfectly curated with amazing accommodations and authentic experiences.",
        tripType: "Luxury Tour to Thailand & Vietnam",
        isVerified: true,
        reviewEmailSent: false,
        reviewEmailSentAt: null,
      },
      {
        agentId: 8,
        enquiryId: null,
        customerName: "James Wilson",
        customerEmail: "james.wilson@example.com",
        customerImage: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=100&h=100&fit=crop&crop=face",
        rating: 4,
        reviewText: "Great communication throughout the planning process. Olivia helped us discover hidden gems in Bali that we never would have found ourselves. Excellent value for money.",
        tripType: "Cultural Experience in Bali",
        isVerified: true,
        reviewEmailSent: false,
        reviewEmailSentAt: null,
      },
    ];

    reviews.forEach(review => {
      const id = this.currentReviewId++;
      this.reviews.set(id, { ...review, id, createdAt: new Date() });
    });

    // Initialize blog posts
    const blogPosts = [
      {
        agentId: 1,
        title: "Ultimate Guide to Mountain Adventures",
        slug: "ultimate-guide-mountain-adventures",
        excerpt: "Discover the most breathtaking mountain destinations and essential tips for your next adventure.",
        content: "Mountain adventures offer some of the most rewarding travel experiences...",
        heroImage: "https://images.unsplash.com/photo-1526392060635-9d6019884377?w=800&h=600&fit=crop&crop=centre",
        images: [],
        destinations: ["Nepal", "Switzerland"],
        holidayTypes: ["Adventure Holidays", "Trekking Holidays"],
        status: "published",
        publishedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      },
      {
        agentId: 3,
        title: "Top 10 Luxury Beach Resorts",
        slug: "top-10-luxury-beach-resorts",
        excerpt: "Experience paradise at these exclusive beachfront destinations offering world-class amenities.",
        content: "Luxury beach resorts provide the perfect escape from everyday life...",
        heroImage: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&h=600&fit=crop&crop=centre",
        images: [],
        destinations: ["Maldives", "Caribbean"],
        holidayTypes: ["Luxury Holidays", "Beach Holidays"],
        status: "published",
        publishedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      },
      {
        agentId: 4,
        title: "Cultural Immersion: Japan Guide",
        slug: "cultural-immersion-japan-guide",
        excerpt: "Delve deep into Japanese culture with authentic experiences and hidden local gems.",
        content: "Japan offers incredible opportunities for cultural immersion...",
        heroImage: "https://images.unsplash.com/photo-1528164344705-47542687000d?w=800&h=600&fit=crop&crop=centre",
        images: [],
        destinations: ["Japan"],
        holidayTypes: ["Cultural Holidays", "City Breaks"],
        status: "published",
        publishedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      },
    ];

    blogPosts.forEach(post => {
      const id = this.currentBlogPostId++;
      this.blogPosts.set(id, { 
        ...post, 
        id, 
        createdAt: new Date(),
        updatedAt: new Date()
      });
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.username === username);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Agent methods
  async getAllAgents(): Promise<Agent[]> {
    return Array.from(this.agents.values()).sort((a, b) => parseFloat(b.rating) - parseFloat(a.rating));
  }

  async getAgentById(id: number): Promise<Agent | undefined> {
    return this.agents.get(id);
  }

  async getFeaturedAgents(): Promise<Agent[]> {
    return Array.from(this.agents.values())
      .sort((a, b) => parseFloat(b.rating) - parseFloat(a.rating))
      .slice(0, 6);
  }

  async getRandomizedFeaturedAgents(): Promise<Agent[]> {
    const now = Date.now();
    
    // Return cached result if still valid
    if (this.featuredAgentsCache && (now - this.featuredAgentsCache.timestamp) < this.CACHE_DURATION) {
      return this.featuredAgentsCache.agents;
    }
    
    const allAgents = Array.from(this.agents.values());
    const totalAgents = allAgents.length;
    const needed = Math.min(24, totalAgents);
    
    // Optimized selection: pick random indices instead of shuffling entire array
    const selectedIndices = new Set<number>();
    const result: Agent[] = [];
    
    while (result.length < needed) {
      const randomIndex = Math.floor(Math.random() * totalAgents);
      if (!selectedIndices.has(randomIndex)) {
        selectedIndices.add(randomIndex);
        result.push(allAgents[randomIndex]);
      }
    }
    
    // Cache the result
    this.featuredAgentsCache = { agents: result, timestamp: now };
    return result;
  }

  async getAgentsByDestination(destination: string): Promise<Agent[]> {
    return Array.from(this.agents.values()).filter(agent =>
      agent.destinations.some(dest => dest.toLowerCase().includes(destination.toLowerCase()))
    );
  }

  async getAgentsByHolidayType(holidayType: string): Promise<Agent[]> {
    return Array.from(this.agents.values()).filter(agent =>
      agent.specialisations.some(spec => spec.toLowerCase().includes(holidayType.toLowerCase()))
    );
  }

  async searchAgents(query: string): Promise<Agent[]> {
    const lowerQuery = query.toLowerCase();
    return Array.from(this.agents.values()).filter(agent =>
      agent.name.toLowerCase().includes(lowerQuery) ||
      agent.location.toLowerCase().includes(lowerQuery) ||
      agent.bio.toLowerCase().includes(lowerQuery) ||
      agent.destinations.some(dest => dest.toLowerCase().includes(lowerQuery)) ||
      agent.specialisations.some(spec => spec.toLowerCase().includes(lowerQuery))
    );
  }

  async filterAgents(filters: {
    location?: string;
    holidayType?: string;
    destination?: string;
    speciality?: string;
  }): Promise<Agent[]> {
    let agents = Array.from(this.agents.values());

    if (filters.location && filters.location !== 'all') {
      agents = agents.filter(agent =>
        agent.location.toLowerCase().includes(filters.location!.toLowerCase())
      );
    }

    if (filters.holidayType && filters.holidayType !== 'all') {
      agents = agents.filter(agent =>
        agent.specialisations.some(spec =>
          spec.toLowerCase().includes(filters.holidayType!.toLowerCase())
        )
      );
    }

    if (filters.destination && filters.destination !== 'all') {
      agents = agents.filter(agent =>
        agent.destinations.some(dest =>
          dest.toLowerCase().includes(filters.destination!.toLowerCase())
        )
      );
    }

    if (filters.speciality && filters.speciality !== 'all') {
      agents = agents.filter(agent =>
        agent.specialisations.some(spec =>
          spec.toLowerCase().includes(filters.speciality!.toLowerCase())
        )
      );
    }

    return agents.sort((a, b) => parseFloat(b.rating) - parseFloat(a.rating));
  }

  async createAgent(agent: InsertAgent): Promise<Agent> {
    const id = this.currentAgentId++;
    const newAgent: Agent = { 
      ...agent, 
      id, 
      createdAt: new Date(),
      rating: agent.rating ?? "0.0",
      reviewCount: agent.reviewCount ?? 0,
      yearsExperience: agent.yearsExperience ?? 0,
      specialisations: agent.specialisations ?? [],
      destinations: agent.destinations ?? [],
      languages: agent.languages ?? [],
      photos: agent.photos ?? [],
      isTopRated: agent.isTopRated ?? false,
      isVerified: agent.isVerified ?? false,
      bio: agent.bio ?? "",
      profileImage: agent.profileImage ?? "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
      nextHoliday: agent.nextHoliday ?? "",
      videoUrl: agent.videoUrl ?? null
    };
    this.agents.set(id, newAgent);
    return newAgent;
  }

  // Destination methods
  async getAllDestinations(): Promise<Destination[]> {
    const destinations = Array.from(this.destinations.values());
    const agents = Array.from(this.agents.values());
    
    // Calculate real agent count for each destination
    return destinations.map(destination => {
      const agentCount = agents.filter(agent => 
        agent.destinations.some(agentDest => 
          agentDest.toLowerCase() === destination.name.toLowerCase() ||
          agentDest.toLowerCase() === destination.slug.toLowerCase()
        )
      ).length;
      
      return {
        ...destination,
        agentCount
      };
    }).sort((a, b) => b.agentCount - a.agentCount);
  }

  async getDestinationBySlug(slug: string): Promise<Destination | undefined> {
    return Array.from(this.destinations.values()).find(dest => dest.slug === slug);
  }

  async getTrendingDestinations(): Promise<Destination[]> {
    const destinations = await this.getAllDestinations(); // This now calculates real agent counts
    return destinations.slice(0, 8);
  }

  async createDestination(destination: InsertDestination): Promise<Destination> {
    const id = this.currentDestinationId++;
    const newDestination: Destination = { ...destination, id, createdAt: new Date(), agentCount: 0 };
    this.destinations.set(id, newDestination);
    return newDestination;
  }

  // Holiday Type methods
  async getAllHolidayTypes(): Promise<HolidayType[]> {
    return Array.from(this.holidayTypes.values());
  }

  async getHolidayTypeBySlug(slug: string): Promise<HolidayType | undefined> {
    return Array.from(this.holidayTypes.values()).find(ht => ht.slug === slug);
  }

  async createHolidayType(holidayType: InsertHolidayType): Promise<HolidayType> {
    const id = this.currentHolidayTypeId++;
    const newHolidayType: HolidayType = { ...holidayType, id, createdAt: new Date() };
    this.holidayTypes.set(id, newHolidayType);
    return newHolidayType;
  }

  // Offer methods
  async getAllOffers(): Promise<(Offer & { agent: Agent })[]> {
    return Array.from(this.offers.values())
      .filter(offer => offer.isActive)
      .map(offer => ({
        ...offer,
        agent: this.agents.get(offer.agentId)!
      }))
      .filter(offer => offer.agent);
  }

  async getOffersByAgent(agentId: number): Promise<Offer[]> {
    return Array.from(this.offers.values()).filter(offer => offer.agentId === agentId && offer.isActive);
  }

  async createOffer(offer: InsertOffer): Promise<Offer> {
    const id = this.currentOfferId++;
    const newOffer: Offer = { ...offer, id, createdAt: new Date(), updatedAt: new Date() };
    this.offers.set(id, newOffer);
    return newOffer;
  }

  async checkAndUpdateExpiredOffers(): Promise<void> {
    // Check all offers and update expired ones to draft status
    for (const [id, offer] of this.offers) {
      if (offer.status === "published" && offer.bookToDate && offer.bookToDate < new Date()) {
        offer.status = "draft";
      }
    }
  }

  // Enquiry methods
  async createEnquiry(enquiry: InsertEnquiry): Promise<Enquiry> {
    const id = this.currentEnquiryId++;
    const newEnquiry: Enquiry = { 
      ...enquiry, 
      id, 
      status: "pending", 
      createdAt: new Date(),
      destination: enquiry.destination ?? null,
      holidayType: enquiry.holidayType ?? null
    };
    this.enquiries.set(id, newEnquiry);
    return newEnquiry;
  }

  async getEnquiriesByAgent(agentId: number): Promise<Enquiry[]> {
    return Array.from(this.enquiries.values()).filter(enquiry => enquiry.agentId === agentId);
  }

  // Review methods
  async getReviewsByAgent(agentId: number): Promise<Review[]> {
    return Array.from(this.reviews.values())
      .filter(review => review.agentId === agentId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getAllReviews(): Promise<Review[]> {
    return Array.from(this.reviews.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async createReview(review: InsertReview): Promise<Review> {
    const id = this.currentReviewId++;
    const newReview: Review = { 
      ...review, 
      id, 
      createdAt: new Date(),
      customerImage: review.customerImage ?? null,
      isVerified: review.isVerified ?? false
    };
    this.reviews.set(id, newReview);
    return newReview;
  }

  // Blog Post methods
  async getAllPublishedBlogPosts(): Promise<(BlogPost & { agent: Agent })[]> {
    return Array.from(this.blogPosts.values())
      .filter(post => post.status === 'published')
      .map(post => ({
        ...post,
        agent: this.agents.get(post.agentId)!
      }))
      .filter(post => post.agent)
      .sort((a, b) => (b.publishedAt?.getTime() || 0) - (a.publishedAt?.getTime() || 0));
  }

  async getBlogPostsByAgent(agentId: number): Promise<BlogPost[]> {
    return Array.from(this.blogPosts.values())
      .filter(post => post.agentId === agentId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getBlogPostBySlug(slug: string): Promise<BlogPost | undefined> {
    return Array.from(this.blogPosts.values()).find(post => post.slug === slug);
  }

  async getBlogPostById(id: number): Promise<BlogPost | undefined> {
    return this.blogPosts.get(id);
  }

  async createBlogPost(blogPost: InsertBlogPost): Promise<BlogPost> {
    const id = this.currentBlogPostId++;
    const now = new Date();
    const newBlogPost: BlogPost = { 
      ...blogPost, 
      id, 
      createdAt: now,
      updatedAt: now,
      publishedAt: blogPost.status === 'published' ? now : null
    };
    this.blogPosts.set(id, newBlogPost);
    return newBlogPost;
  }

  async updateBlogPost(id: number, updates: Partial<InsertBlogPost>): Promise<BlogPost | null> {
    const existingPost = this.blogPosts.get(id);
    if (!existingPost) return null;

    const now = new Date();
    const updatedPost: BlogPost = {
      ...existingPost,
      ...updates,
      updatedAt: now,
      publishedAt: updates.status === 'published' && !existingPost.publishedAt ? now : existingPost.publishedAt
    };
    
    this.blogPosts.set(id, updatedPost);
    return updatedPost;
  }

  async deleteBlogPost(id: number): Promise<void> {
    this.blogPosts.delete(id);
  }

  // Newsletter methods
  async subscribeToNewsletter(email: string): Promise<Newsletter> {
    const id = this.currentNewsletterId++;
    const newsletter: Newsletter = {
      id,
      email,
      isSubscribed: true,
      createdAt: new Date()
    };
    this.newsletters.set(id, newsletter);
    return newsletter;
  }

  // Agent Authentication methods
  async getAgentByEmail(email: string): Promise<Agent | undefined> {
    return Array.from(this.agents.values()).find(agent => agent.email === email);
  }

  async updateAgentProfile(id: number, data: Partial<Agent>): Promise<Agent> {
    const existingAgent = this.agents.get(id);
    if (!existingAgent) {
      throw new Error('Agent not found');
    }
    
    const updatedAgent = { ...existingAgent, ...data };
    this.agents.set(id, updatedAgent);
    return updatedAgent;
  }

  async addAgentPhoto(agentId: number, photoUrl: string): Promise<Agent> {
    const agent = this.agents.get(agentId);
    if (!agent) {
      throw new Error("Agent not found");
    }

    const currentPhotos = agent.photos || [];
    const updatedAgent = { 
      ...agent, 
      photos: [...currentPhotos, photoUrl] 
    };
    
    this.agents.set(agentId, updatedAgent);
    return updatedAgent;
  }

  async updateAgentVideo(agentId: number, videoUrl: string): Promise<Agent> {
    const agent = this.agents.get(agentId);
    if (!agent) {
      throw new Error("Agent not found");
    }

    const updatedAgent = { 
      ...agent, 
      videoUrl 
    };
    
    this.agents.set(agentId, updatedAgent);
    return updatedAgent;
  }

  async updateAgentPhotos(agentId: number, photoUrls: string[]): Promise<void> {
    const agent = this.agents.get(agentId);
    if (!agent) {
      throw new Error("Agent not found");
    }
    
    // Append new photos to existing photos array
    const currentPhotos = agent.photos || [];
    const updatedAgent = { 
      ...agent, 
      photos: [...currentPhotos, ...photoUrls] 
    };
    
    this.agents.set(agentId, updatedAgent);
  }

  async deleteAgentPhoto(agentId: number, photoUrl: string): Promise<void> {
    const agent = this.agents.get(agentId);
    if (!agent) {
      throw new Error("Agent not found");
    }
    
    // Remove the photo from the photos array
    const currentPhotos = agent.photos || [];
    const updatedPhotos = currentPhotos.filter(photo => photo !== photoUrl);
    
    const updatedAgent = { 
      ...agent, 
      photos: updatedPhotos 
    };
    
    this.agents.set(agentId, updatedAgent);
  }

  async replaceAgentPhoto(agentId: number, oldPhotoUrl: string, newPhotoUrl: string): Promise<void> {
    const agent = this.agents.get(agentId);
    if (!agent) {
      throw new Error("Agent not found");
    }
    
    // Replace the old photo with the new one
    const currentPhotos = agent.photos || [];
    const updatedPhotos = currentPhotos.map(photo => 
      photo === oldPhotoUrl ? newPhotoUrl : photo
    );
    
    const updatedAgent = { 
      ...agent, 
      photos: updatedPhotos 
    };
    
    this.agents.set(agentId, updatedAgent);
  }

  async createPendingAgent(email: string, password: string, verificationToken: string): Promise<Agent> {
    // Check if email already exists
    const existingAgent = Array.from(this.agents.values()).find(agent => agent.email === email);
    if (existingAgent) {
      throw new Error("Agent with this email already exists");
    }

    const id = this.currentAgentId++;
    const hashedPassword = await bcrypt.hash(password, 12);
    
    const agent: Agent = {
      id,
      email,
      password: hashedPassword,
      firstName: null,
      lastName: null,
      name: null,
      location: null,
      bio: "",
      profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
      company: null,
      nextHoliday: "",
      rating: "0.0",
      reviewCount: 0,
      profileViews: 0,
      yearsExperience: 0,
      specialisations: [],
      destinations: [],
      languages: [],
      photos: [],
      videoUrl: null,
      isTopRated: false,
      isVerified: false,
      isEmailVerified: false,
      emailVerificationToken: verificationToken,
      profileCompleted: false,
      createdAt: new Date(),
    };

    this.agents.set(id, agent);
    return agent;
  }

  async verifyAgentEmail(token: string): Promise<Agent | undefined> {
    const agent = Array.from(this.agents.values()).find(
      agent => agent.emailVerificationToken === token
    );
    
    if (!agent) {
      console.log(`Verification failed: No agent found with token ${token}`);
      console.log(`Available agents with tokens:`, Array.from(this.agents.values())
        .filter(a => a.emailVerificationToken)
        .map(a => ({ id: a.id, email: a.email, token: a.emailVerificationToken })));
      return undefined;
    }

    const updatedAgent = {
      ...agent,
      isEmailVerified: true,
      emailVerificationToken: null,
    };

    this.agents.set(agent.id, updatedAgent);
    return updatedAgent;
  }

  // Helper method to get verification token for testing
  async getAgentVerificationToken(agentId: number): Promise<string | null> {
    const agent = this.agents.get(agentId);
    return agent?.emailVerificationToken || null;
  }

  async completeAgentProfile(agentId: number, profileData: any): Promise<Agent> {
    const agent = this.agents.get(agentId);
    if (!agent) {
      throw new Error("Agent not found");
    }

    if (!agent.isEmailVerified) {
      throw new Error("Email must be verified before completing profile");
    }

    const name = `${profileData.firstName} ${profileData.lastName}`;
    const updatedAgent = {
      ...agent,
      ...profileData,
      name,
      profileCompleted: true,
    };

    this.agents.set(agentId, updatedAgent);
    return updatedAgent;
  }

  async trackProfileVisit(agentId: number, visitorId: string, userAgent?: string): Promise<void> {
    // For MemStorage, we can just increment the profile views
    await this.incrementProfileViews(agentId);
  }

  async incrementProfileViews(agentId: number): Promise<void> {
    const agent = this.agents.get(agentId);
    if (agent) {
      const updatedAgent = { ...agent, profileViews: (agent.profileViews || 0) + 1 };
      this.agents.set(agentId, updatedAgent);
    }
  }

  // Review Reminder methods (required by interface)
  async createReviewReminder(reminder: InsertReviewReminder): Promise<ReviewReminder> {
    const id = this.currentReviewId++;
    const newReminder: ReviewReminder = { 
      ...reminder, 
      id, 
      createdAt: new Date() 
    };
    // Note: MemStorage doesn't have a reminder store, but this satisfies the interface
    return newReminder;
  }

  async getScheduledReviewReminders(): Promise<ReviewReminder[]> {
    // MemStorage implementation - returns empty array
    return [];
  }

  async markReminderEmailSent(reminderId: number): Promise<void> {
    // MemStorage implementation - no-op
  }

  async markReminderCompleted(reminderId: number): Promise<void> {
    // MemStorage implementation - no-op
  }

  // Health Check Logs (MemStorage stubs - not persistent)
  async createHealthCheckLog(log: InsertHealthCheckLog): Promise<HealthCheckLog> {
    const id = 1;
    const healthCheckLog: HealthCheckLog = { 
      ...log, 
      id, 
      createdAt: new Date() 
    };
    return healthCheckLog;
  }

  async getRecentHealthCheckLogs(limit: number = 5): Promise<HealthCheckLog[]> {
    // MemStorage implementation - returns empty array
    return [];
  }
}

// Database Storage Implementation
export class DatabaseStorage implements IStorage {
  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user;
  }

  async createUser(user: InsertUser): Promise<User> {
    const [newUser] = await db.insert(users).values(user).returning();
    return newUser;
  }

  // Agent operations
  async getAllAgents(): Promise<Agent[]> {
    // Only return completed profiles that are approved for public display
    return await db.select().from(agents).where(and(eq(agents.profileCompleted, true), eq(agents.approvalStatus, "approved")));
  }

  // Admin only - get all agents regardless of approval status
  async getAllAgentsForAdmin(): Promise<Agent[]> {
    return await db.select().from(agents).orderBy(agents.createdAt);
  }

  // Admin only - approve agent
  async approveAgent(agentId: number, approvedBy: string): Promise<Agent> {
    const [agent] = await db
      .update(agents)
      .set({ 
        approvalStatus: "approved",
        approvedAt: new Date(),
        approvedBy: approvedBy
      })
      .where(eq(agents.id, agentId))
      .returning();
    return agent;
  }

  // Admin only - reject agent
  async rejectAgent(agentId: number, approvedBy: string): Promise<Agent> {
    const [agent] = await db
      .update(agents)
      .set({ 
        approvalStatus: "rejected",
        approvedAt: new Date(),
        approvedBy: approvedBy
      })
      .where(eq(agents.id, agentId))
      .returning();
    return agent;
  }

  // Admin only - update any agent's profile
  async updateAgentProfileAsAdmin(agentId: number, updates: Partial<Agent>): Promise<Agent> {
    const [agent] = await db
      .update(agents)
      .set(updates)
      .where(eq(agents.id, agentId))
      .returning();
    return agent;
  }

  async getAgent(id: number): Promise<Agent | undefined> {
    const [agent] = await db.select().from(agents).where(eq(agents.id, id));
    return agent;
  }

  async getAgentById(id: number): Promise<Agent | undefined> {
    const [agent] = await db.select().from(agents).where(eq(agents.id, id));
    return agent;
  }

  async getFeaturedAgents(): Promise<Agent[]> {
    return await db.select().from(agents).where(
      and(
        eq(agents.isTopRated, true),
        eq(agents.profileCompleted, true),
        eq(agents.approvalStatus, "approved")
      )
    ).limit(6);
  }

  async getRandomizedFeaturedAgents(): Promise<Agent[]> {
    return await db.select().from(agents).where(
      and(
        eq(agents.profileCompleted, true),
        eq(agents.approvalStatus, "approved")
      )
    ).orderBy(sql`RANDOM()`).limit(30);
  }

  async getAgentsByDestination(destination: string): Promise<Agent[]> {
    return await db.select().from(agents).where(
      and(
        sql`${destination} = ANY(${agents.destinations})`,
        eq(agents.profileCompleted, true),
        eq(agents.approvalStatus, "approved")
      )
    );
  }

  async getAgentsByHolidayType(holidayType: string): Promise<Agent[]> {
    return await db.select().from(agents).where(
      and(
        sql`${holidayType} = ANY(${agents.specialisations})`,
        eq(agents.profileCompleted, true),
        eq(agents.approvalStatus, "approved")
      )
    );
  }

  async searchAgents(query: string): Promise<Agent[]> {
    const searchTerm = `%${query.toLowerCase()}%`;
    console.log(`Searching for: "${query}" with term: "${searchTerm}"`);
    
    // Use case-insensitive search with ILIKE (PostgreSQL)
    const nameMatches = await db.select().from(agents).where(
      and(
        eq(agents.profileCompleted, true),
        eq(agents.approvalStatus, "approved"),
        sql`LOWER(${agents.name}) LIKE ${searchTerm}`
      )
    );
    
    console.log(`Name matches found: ${nameMatches.length}`);
    
    if (nameMatches.length > 0) {
      return nameMatches;
    }
    
    // If no name matches, search other fields
    const otherMatches = await db.select().from(agents).where(
      and(
        eq(agents.profileCompleted, true),
        eq(agents.approvalStatus, "approved"),
        or(
          sql`LOWER(${agents.location}) LIKE ${searchTerm}`,
          sql`LOWER(${agents.company}) LIKE ${searchTerm}`
        )
      )
    );
    
    console.log(`Other matches found: ${otherMatches.length}`);
    return otherMatches;
  }

  async filterAgents(filters: {
    location?: string;
    holidayType?: string;
    destination?: string;
    speciality?: string;
  }): Promise<Agent[]> {
    const conditions = [
      eq(agents.profileCompleted, true),
      eq(agents.approvalStatus, "approved")
    ];
    
    if (filters.location) {
      conditions.push(like(agents.location, `%${filters.location}%`));
    }
    
    if (filters.holidayType) {
      conditions.push(sql`${filters.holidayType} = ANY(${agents.specialisations})`);
    }
    
    if (filters.destination) {
      conditions.push(sql`${filters.destination} = ANY(${agents.destinations})`);
    }
    
    if (filters.speciality) {
      conditions.push(sql`${filters.speciality} = ANY(${agents.specialisations})`);
    }
    
    return await db.select().from(agents).where(and(...conditions));
  }



  async createAgent(agent: InsertAgent): Promise<Agent> {
    const [newAgent] = await db.insert(agents).values(agent).returning();
    return newAgent;
  }

  // Agent Authentication
  async getAgentByEmail(email: string): Promise<Agent | undefined> {
    const [agent] = await db.select().from(agents).where(eq(agents.email, email));
    return agent;
  }

  async updateAgentProfile(id: number, data: Partial<Agent>): Promise<Agent> {
    // Auto-check profile completion when updating
    const updatesToApply = { ...data };
    
    // If we're updating fields that affect completion, check if profile is now complete
    if (data.bio || data.specialisations || data.destinations) {
      const currentAgent = await this.getAgentById(id);
      if (currentAgent) {
        const bioLength = (data.bio || currentAgent.bio || '').length;
        const specCount = (data.specialisations || currentAgent.specialisations || []).length;
        const destCount = (data.destinations || currentAgent.destinations || []).length;
        
        // Mark as completed if meets minimum requirements: 250+ char bio, 3+ specialisations, 3+ destinations
        if (bioLength >= 250 && specCount >= 3 && destCount >= 3) {
          updatesToApply.profileCompleted = true;
        }
      }
    }
    
    const [updatedAgent] = await db.update(agents).set(updatesToApply).where(eq(agents.id, id)).returning();
    if (!updatedAgent) {
      throw new Error('Agent not found');
    }
    return updatedAgent;
  }

  async addAgentPhoto(agentId: number, photoUrl: string): Promise<Agent> {
    const agent = await this.getAgentById(agentId);
    if (!agent) {
      throw new Error("Agent not found");
    }

    const currentPhotos = agent.photos || [];
    const updatedPhotos = [...currentPhotos, photoUrl];
    
    const [updatedAgent] = await db.update(agents)
      .set({ photos: updatedPhotos })
      .where(eq(agents.id, agentId))
      .returning();
    
    return updatedAgent;
  }

  async updateAgentVideo(agentId: number, videoUrl: string): Promise<Agent> {
    const [updatedAgent] = await db.update(agents)
      .set({ videoUrl })
      .where(eq(agents.id, agentId))
      .returning();
    
    if (!updatedAgent) {
      throw new Error("Agent not found");
    }
    
    return updatedAgent;
  }

  async updateAgentPhotos(agentId: number, photoUrls: string[]): Promise<void> {
    const agent = await this.getAgentById(agentId);
    if (!agent) {
      throw new Error("Agent not found");
    }
    
    const currentPhotos = agent.photos || [];
    const updatedPhotos = [...currentPhotos, ...photoUrls];
    
    await db.update(agents)
      .set({ photos: updatedPhotos })
      .where(eq(agents.id, agentId));
  }

  async deleteAgentPhoto(agentId: number, photoUrl: string): Promise<void> {
    const agent = await this.getAgentById(agentId);
    if (!agent) {
      throw new Error("Agent not found");
    }
    
    const currentPhotos = agent.photos || [];
    const updatedPhotos = currentPhotos.filter(photo => photo !== photoUrl);
    
    await db.update(agents)
      .set({ photos: updatedPhotos })
      .where(eq(agents.id, agentId));
  }

  async replaceAgentPhoto(agentId: number, oldPhotoUrl: string, newPhotoUrl: string): Promise<void> {
    const agent = await this.getAgentById(agentId);
    if (!agent) {
      throw new Error("Agent not found");
    }
    
    const currentPhotos = agent.photos || [];
    const updatedPhotos = currentPhotos.map(photo => 
      photo === oldPhotoUrl ? newPhotoUrl : photo
    );
    
    await db.update(agents)
      .set({ photos: updatedPhotos })
      .where(eq(agents.id, agentId));
  }

  async createPendingAgent(email: string, password: string, verificationToken: string): Promise<Agent> {
    const existingAgent = await this.getAgentByEmail(email);
    if (existingAgent) {
      throw new Error("Agent with this email already exists");
    }

    const hashedPassword = await bcrypt.hash(password, 12);
    
    const agentData: InsertAgent = {
      email,
      password: hashedPassword,
      firstName: null,
      lastName: null,
      name: null,
      location: null,
      bio: "",
      profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
      company: null,
      nextHoliday: "",
      reviewCount: 0,
      profileViews: 0,
      yearsExperience: 0,
      specialisations: [],
      destinations: [],
      languages: [],
      photos: [],
      videoUrl: null,
      isTopRated: false,
      isVerified: false,
      isEmailVerified: false,
      emailVerificationToken: verificationToken,
      profileCompleted: false,
    };

    const [newAgent] = await db.insert(agents).values(agentData).returning();
    return newAgent;
  }

  async verifyAgentEmail(token: string): Promise<Agent | undefined> {
    const [agent] = await db.select().from(agents)
      .where(eq(agents.emailVerificationToken, token));
    
    if (!agent) {
      return undefined;
    }

    const [updatedAgent] = await db.update(agents)
      .set({
        isEmailVerified: true,
        emailVerificationToken: null,
      })
      .where(eq(agents.id, agent.id))
      .returning();

    return updatedAgent;
  }

  async getAgentVerificationToken(agentId: number): Promise<string | null> {
    const agent = await this.getAgentById(agentId);
    return agent?.emailVerificationToken || null;
  }

  async completeAgentProfile(agentId: number, profileData: any): Promise<Agent> {
    const agent = await this.getAgentById(agentId);
    if (!agent) {
      throw new Error("Agent not found");
    }

    if (!agent.isEmailVerified) {
      throw new Error("Email must be verified before completing profile");
    }

    const name = `${profileData.firstName} ${profileData.lastName}`;
    const [updatedAgent] = await db.update(agents)
      .set({
        ...profileData,
        name,
        profileCompleted: true,
      })
      .where(eq(agents.id, agentId))
      .returning();

    return updatedAgent;
  }

  async trackProfileVisit(agentId: number, visitorId: string, userAgent?: string): Promise<void> {
    // Insert visit record (optional implementation for tracking)
    // For now, just increment views
    await this.incrementProfileViews(agentId);
  }

  async incrementProfileViews(agentId: number): Promise<void> {
    await db.update(agents)
      .set({ profileViews: sql`${agents.profileViews} + 1` })
      .where(eq(agents.id, agentId));
  }

  // Destinations
  async getAllDestinations(): Promise<Destination[]> {
    const allDestinations = await db.select().from(destinations);
    const allAgents = await db.select().from(agents);
    
    // Calculate real agent count for each destination
    return allDestinations.map(destination => {
      const agentCount = allAgents.filter(agent => 
        agent.destinations.some(agentDest => 
          agentDest.toLowerCase() === destination.name.toLowerCase() ||
          agentDest.toLowerCase() === destination.slug.toLowerCase()
        )
      ).length;
      
      return {
        ...destination,
        agentCount
      };
    }).sort((a, b) => a.name.localeCompare(b.name)); // Alphabetical order
  }

  async getDestinationBySlug(slug: string): Promise<Destination | undefined> {
    const [destination] = await db.select().from(destinations).where(eq(destinations.slug, slug));
    return destination;
  }

  async getTrendingDestinations(): Promise<Destination[]> {
    const allDestinations = await this.getAllDestinations();
    return allDestinations.slice(0, 6);
  }

  async createDestination(destination: InsertDestination): Promise<Destination> {
    const [newDestination] = await db.insert(destinations).values({
      ...destination,
      slug: destination.slug || destination.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
    }).returning();
    return newDestination;
  }

  async updateDestinationImage(destinationId: number, imageUrl: string): Promise<Destination> {
    try {
      console.log(`Database: Updating destination ${destinationId} with image: ${imageUrl}`);
      
      const [updatedDestination] = await db.update(destinations)
        .set({ image: imageUrl })
        .where(eq(destinations.id, destinationId))
        .returning();
        
      if (!updatedDestination) {
        throw new Error(`Destination with ID ${destinationId} not found`);
      }
      
      console.log(`Database: Successfully updated destination ${destinationId}`);
      return updatedDestination;
    } catch (error) {
      console.error(`Database error updating destination ${destinationId}:`, error);
      throw error;
    }
  }

  // Holiday Types
  async getAllHolidayTypes(): Promise<HolidayType[]> {
    const allHolidayTypes = await db.select().from(holidayTypes);
    const allAgents = await db.select().from(agents);
    
    // Calculate real agent count for each holiday type
    return allHolidayTypes.map(holidayType => {
      const agentCount = allAgents.filter(agent => 
        agent.specialisations && agent.specialisations.some && agent.specialisations.some(agentSpec => 
          agentSpec.toLowerCase() === holidayType.name.toLowerCase()
        )
      ).length;
      
      return {
        ...holidayType,
        agentCount
      };
    }).sort((a, b) => a.name.localeCompare(b.name)); // Alphabetical order
  }

  async getHolidayTypeBySlug(slug: string): Promise<HolidayType | undefined> {
    const [holidayType] = await db.select().from(holidayTypes).where(eq(holidayTypes.slug, slug));
    return holidayType;
  }

  async createHolidayType(holidayType: InsertHolidayType): Promise<HolidayType> {
    const [newHolidayType] = await db.insert(holidayTypes).values({
      ...holidayType,
      slug: holidayType.slug || holidayType.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
    }).returning();
    return newHolidayType;
  }

  async updateHolidayTypeImage(holidayTypeId: number, imageUrl: string): Promise<HolidayType> {
    try {
      console.log(`Database: Updating holiday type ${holidayTypeId} with image: ${imageUrl}`);
      
      const [updatedHolidayType] = await db.update(holidayTypes)
        .set({ image: imageUrl })
        .where(eq(holidayTypes.id, holidayTypeId))
        .returning();
        
      if (!updatedHolidayType) {
        throw new Error(`Holiday type with ID ${holidayTypeId} not found`);
      }
      
      console.log(`Database: Successfully updated holiday type ${holidayTypeId}`);
      return updatedHolidayType;
    } catch (error) {
      console.error(`Database error updating holiday type ${holidayTypeId}:`, error);
      throw error;
    }
  }

  async updateHolidayType(holidayTypeId: number, updateData: { name?: string; description?: string; tagline?: string; icon?: string }): Promise<HolidayType> {
    try {
      console.log(`Database: Updating holiday type ${holidayTypeId}`);
      
      const updateValues: any = {};
      
      if (updateData.name) {
        updateValues.name = updateData.name;
        updateValues.slug = updateData.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
      }
      if (updateData.description) {
        updateValues.description = updateData.description;
      }
      if (updateData.tagline) {
        updateValues.tagline = updateData.tagline;
      }
      if (updateData.icon) {
        updateValues.icon = updateData.icon;
      }

      const [holidayType] = await db
        .update(holidayTypes)
        .set(updateValues)
        .where(eq(holidayTypes.id, holidayTypeId))
        .returning();
      
      console.log(`Database: Successfully updated holiday type ${holidayTypeId}`);
      return holidayType;
    } catch (error) {
      console.error(`Database error updating holiday type:`, error);
      throw error;
    }
  }



  async updateDestination(destinationId: number, updateData: { name?: string; description?: string; continent?: string }): Promise<Destination> {
    try {
      console.log(`Database: Updating destination ${destinationId}`);
      
      const updateValues: any = {};
      
      if (updateData.name) {
        updateValues.name = updateData.name;
        updateValues.slug = updateData.name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, '');
      }
      if (updateData.description) {
        updateValues.description = updateData.description;
      }
      if (updateData.continent) {
        updateValues.continent = updateData.continent;
      }

      const [destination] = await db
        .update(destinations)
        .set(updateValues)
        .where(eq(destinations.id, destinationId))
        .returning();
      
      console.log(`Database: Successfully updated destination ${destinationId}`);
      return destination;
    } catch (error) {
      console.error(`Database error updating destination:`, error);
      throw error;
    }
  }



  // Offers
  async getAllOffers(): Promise<(Offer & { agent: Agent })[]> {
    const result = await db.select()
      .from(offers)
      .leftJoin(agents, eq(offers.agentId, agents.id));
    
    return result.map(row => ({
      ...row.offers,
      agent: row.agents!
    }));
  }

  async getOffersByAgent(agentId: number): Promise<Offer[]> {
    return await db.select().from(offers).where(eq(offers.agentId, agentId));
  }

  async getPublishedOffers(): Promise<(Offer & { agent: Agent })[]> {
    const result = await db.select()
      .from(offers)
      .leftJoin(agents, eq(offers.agentId, agents.id))
      .where(eq(offers.status, "published"));
    
    return result.map(row => ({
      ...row.offers,
      agent: row.agents!
    }));
  }

  async createOffer(offer: InsertOffer & { agentId: number }): Promise<Offer> {
    const [newOffer] = await db.insert(offers).values({
      ...offer,
      updatedAt: new Date()
    }).returning();
    return newOffer;
  }

  async updateOffer(id: number, agentId: number, offer: Partial<InsertOffer>): Promise<Offer> {
    const [updatedOffer] = await db.update(offers)
      .set({ ...offer, updatedAt: new Date() })
      .where(and(eq(offers.id, id), eq(offers.agentId, agentId)))
      .returning();
    return updatedOffer;
  }

  async checkAndUpdateExpiredOffers(): Promise<void> {
    const now = new Date();
    await db
      .update(offers)
      .set({ status: "draft" })
      .where(
        and(
          eq(offers.status, "published"),
          lt(offers.bookToDate, now)
        )
      );
  }

  async deleteOffer(id: number, agentId: number): Promise<void> {
    await db.delete(offers).where(and(eq(offers.id, id), eq(offers.agentId, agentId)));
  }

  async publishOffer(id: number, agentId: number): Promise<Offer> {
    const [publishedOffer] = await db.update(offers)
      .set({ status: "published", updatedAt: new Date() })
      .where(and(eq(offers.id, id), eq(offers.agentId, agentId)))
      .returning();
    return publishedOffer;
  }

  async getOfferById(id: number): Promise<(Offer & { agent: Agent }) | undefined> {
    const result = await db.select()
      .from(offers)
      .leftJoin(agents, eq(offers.agentId, agents.id))
      .where(eq(offers.id, id));
    
    if (result.length === 0) return undefined;
    
    return {
      ...result[0].offers,
      agent: result[0].agents!
    };
  }

  // Enquiries
  async createEnquiry(enquiry: InsertEnquiry): Promise<Enquiry> {
    const [newEnquiry] = await db.insert(enquiries).values(enquiry).returning();
    return newEnquiry;
  }

  async getEnquiriesByAgent(agentId: number): Promise<Enquiry[]> {
    return await db.select().from(enquiries)
      .where(eq(enquiries.agentId, agentId))
      .orderBy(desc(enquiries.createdAt));
  }

  async getEnquiriesForEmail(email: string): Promise<Enquiry[]> {
    return await db.select().from(enquiries)
      .where(eq(enquiries.email, email)) 
      .orderBy(desc(enquiries.createdAt));
  }

  async markEnquiryAsRead(enquiryId: number): Promise<void> {
    await db.update(enquiries)
      .set({ isRead: true })
      .where(eq(enquiries.id, enquiryId));
  }

  async markAllEnquiriesAsReadForAgent(agentId: number): Promise<void> {
    await db.update(enquiries)
      .set({ isRead: true })
      .where(and(eq(enquiries.agentId, agentId), eq(enquiries.isRead, false)));
  }

  async getUnreadEnquiriesCount(agentId: number): Promise<number> {
    const result = await db.select({ count: count() })
      .from(enquiries)
      .where(and(eq(enquiries.agentId, agentId), eq(enquiries.isRead, false)));
    return result[0]?.count || 0;
  }

  async getAllEnquiriesWithAgentNames(): Promise<any[]> {
    const result = await db.select({
      id: enquiries.id,
      agentId: enquiries.agentId,
      agentName: agents.name,
      firstName: enquiries.firstName,
      lastName: enquiries.lastName,
      email: enquiries.email,
      phoneNumber: enquiries.phoneNumber,
      numberOfAdults: enquiries.numberOfAdults,
      numberOfChildren: enquiries.numberOfChildren,
      childrenAges: enquiries.childrenAges,
      budgetPerPerson: enquiries.budgetPerPerson,
      destinations: enquiries.destinations,
      holidayTypes: enquiries.holidayTypes,
      travelMonths: enquiries.travelMonths,
      travelYear: enquiries.travelYear,
      preferredCallbackTime: enquiries.preferredCallbackTime,
      preferredCallbackDate: enquiries.preferredCallbackDate,
      enquiryDetails: enquiries.enquiryDetails,
      status: enquiries.status,
      isRead: enquiries.isRead,
      createdAt: enquiries.createdAt,
    })
    .from(enquiries)
    .leftJoin(agents, eq(enquiries.agentId, agents.id))
    .orderBy(desc(enquiries.createdAt));
    
    return result;
  }

  // Reviews
  async getReviewsByAgent(agentId: number): Promise<Review[]> {
    return await db.select().from(reviews)
      .where(eq(reviews.agentId, agentId))
      .orderBy(desc(reviews.createdAt));
  }

  async getReviewsByEnquiryId(enquiryId: number): Promise<Review[]> {
    return await db.select().from(reviews)
      .where(eq(reviews.enquiryId, enquiryId))
      .orderBy(desc(reviews.createdAt));
  }

  async getAllReviews(): Promise<Review[]> {
    return await db.select().from(reviews).orderBy(desc(reviews.createdAt));
  }

  async getAllReviewsWithAgentNames(): Promise<(Review & { agentName?: string })[]> {
    const result = await db.select({
      id: reviews.id,
      agentId: reviews.agentId,
      enquiryId: reviews.enquiryId,
      customerName: reviews.customerName,
      customerEmail: reviews.customerEmail,
      customerImage: reviews.customerImage,
      rating: reviews.rating,
      reviewText: reviews.reviewText,
      tripType: reviews.tripType,
      isVerified: reviews.isVerified,
      reviewEmailSent: reviews.reviewEmailSent,
      reviewEmailSentAt: reviews.reviewEmailSentAt,
      createdAt: reviews.createdAt,
      agentName: agents.name
    })
    .from(reviews)
    .leftJoin(agents, eq(reviews.agentId, agents.id))
    .orderBy(desc(reviews.createdAt));
    
    return result;
  }

  async createReview(review: InsertReview): Promise<Review> {
    const [newReview] = await db.insert(reviews).values(review).returning();
    
    // Recalculate agent's rating and review count after adding new review
    await this.updateAgentRatingStats(review.agentId);
    
    return newReview;
  }

  // Helper method to recalculate agent rating statistics
  private async updateAgentRatingStats(agentId: number): Promise<void> {
    const result = await db.select({
      averageRating: sql<number>`ROUND(AVG(${reviews.rating}), 1)`,
      reviewCount: count()
    })
    .from(reviews)
    .where(eq(reviews.agentId, agentId));

    const stats = result[0];
    if (stats) {
      await db.update(agents)
        .set({
          rating: stats.averageRating || 0,
          reviewCount: stats.reviewCount || 0
        })
        .where(eq(agents.id, agentId));
    }
  }

  // Blog Posts
  async getAllBlogPosts(): Promise<(BlogPost & { agent: Agent })[]> {
    const result = await db.select()
      .from(blogPosts)
      .leftJoin(agents, eq(blogPosts.agentId, agents.id))
      .orderBy(desc(blogPosts.publishedAt));
    
    return result.map(row => ({
      ...row.blog_posts,
      agent: row.agents!
    }));
  }

  async getAllPublishedBlogPosts(): Promise<(BlogPost & { agent: Agent })[]> {
    try {
      const result = await db.select({
        // Blog post fields
        id: blogPosts.id,
        agentId: blogPosts.agentId,
        title: blogPosts.title,
        slug: blogPosts.slug,
        excerpt: blogPosts.excerpt,
        content: blogPosts.content,
        heroImage: blogPosts.heroImage,
        images: blogPosts.images,
        holidayTypes: blogPosts.holidayTypes,
        destinations: blogPosts.destinations,
        status: blogPosts.status,
        publishedAt: blogPosts.publishedAt,
        createdAt: blogPosts.createdAt,
        updatedAt: blogPosts.updatedAt,
        // Agent fields
        agentName: agents.name,
        agentProfileImage: agents.profileImage,
        agentId2: agents.id,
      })
      .from(blogPosts)
      .leftJoin(agents, eq(blogPosts.agentId, agents.id))
      .where(eq(blogPosts.status, 'published'))
      .orderBy(desc(blogPosts.publishedAt));
    
      return result.map(row => ({
        id: row.id,
        agentId: row.agentId,
        title: row.title,
        slug: row.slug,
        excerpt: row.excerpt,
        content: row.content,
        heroImage: row.heroImage,
        images: row.images,
        holidayTypes: row.holidayTypes,
        destinations: row.destinations,
        status: row.status,
        publishedAt: row.publishedAt,
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
        agent: {
          id: row.agentId2!,
          name: row.agentName,
          profileImage: row.agentProfileImage,
        }
      })).filter(item => item.agent && item.agent.name);
    } catch (error) {
      console.error("Database error in getAllPublishedBlogPosts:", error);
      throw error;
    }
  }

  async getBlogPostBySlugWithAgent(slug: string): Promise<(BlogPost & { agent: Agent }) | undefined> {
    try {

      const result = await db.select({
        // Blog post fields
        id: blogPosts.id,
        agentId: blogPosts.agentId,
        title: blogPosts.title,
        slug: blogPosts.slug,
        excerpt: blogPosts.excerpt,
        content: blogPosts.content,
        heroImage: blogPosts.heroImage,
        images: blogPosts.images,
        holidayTypes: blogPosts.holidayTypes,
        destinations: blogPosts.destinations,
        status: blogPosts.status,
        publishedAt: blogPosts.publishedAt,
        createdAt: blogPosts.createdAt,
        updatedAt: blogPosts.updatedAt,
        // Agent fields
        agentName: agents.name,
        agentProfileImage: agents.profileImage,
        agentId2: agents.id,
      })
      .from(blogPosts)
      .leftJoin(agents, eq(blogPosts.agentId, agents.id))
      .where(and(eq(blogPosts.slug, slug), eq(blogPosts.status, 'published')))
      .limit(1);

      if (result.length === 0) return undefined;

      const row = result[0];
      if (!row.agentName || !row.agentId2) return undefined;

      return {
        id: row.id,
        agentId: row.agentId,
        title: row.title,
        slug: row.slug,
        excerpt: row.excerpt,
        content: row.content,
        heroImage: row.heroImage,
        images: row.images,
        holidayTypes: row.holidayTypes,
        destinations: row.destinations,
        status: row.status,
        publishedAt: row.publishedAt,
        createdAt: row.createdAt,
        updatedAt: row.updatedAt,
        agent: {
          id: row.agentId2,
          name: row.agentName,
          profileImage: row.agentProfileImage,
        }
      };
    } catch (error) {
      console.error("Database error in getBlogPostBySlug:", error);
      throw error;
    }
  }

  async getBlogPostsByAgent(agentId: number): Promise<BlogPost[]> {
    return await db.select().from(blogPosts)
      .where(eq(blogPosts.agentId, agentId))
      .orderBy(desc(blogPosts.publishedAt));
  }

  async getBlogPostBySlug(slug: string): Promise<BlogPost | undefined> {
    const [post] = await db.select().from(blogPosts).where(eq(blogPosts.slug, slug));
    return post;
  }

  async getBlogPostById(id: number): Promise<BlogPost | undefined> {
    const [post] = await db.select().from(blogPosts).where(eq(blogPosts.id, id));
    return post;
  }

  async createBlogPost(blogPost: InsertBlogPost): Promise<BlogPost> {
    // Use direct PostgreSQL client to bypass Drizzle completely for array handling
    const now = new Date();
    
    const query = `
      INSERT INTO blog_posts (
        agent_id, title, slug, excerpt, content, hero_image, images, 
        holiday_types, destinations, status, published_at, created_at, updated_at
      ) VALUES (
        $1, $2, $3, $4, $5, $6, $7::text[], $8::text[], $9::text[], $10, $11, $12, $13
      ) RETURNING *
    `;
    
    const values = [
      blogPost.agentId,
      blogPost.title,
      blogPost.slug,
      blogPost.excerpt,
      blogPost.content,
      blogPost.heroImage,
      blogPost.images || [],
      blogPost.holidayTypes || [],
      blogPost.destinations || [],
      blogPost.status,
      now,
      now,
      now
    ];
    
    const client = await pool.connect();
    try {
      const result = await client.query(query, values);
      return result.rows[0] as BlogPost;
    } finally {
      client.release();
    }
  }

  async updateBlogPost(id: number, updates: Partial<BlogPost>): Promise<BlogPost> {
    // Prepare the update values, handling arrays properly
    const updateFields: string[] = [];
    const updateValues: any[] = [];
    let paramIndex = 1;
    
    if (updates.title !== undefined) {
      updateFields.push(`title = $${paramIndex++}`);
      updateValues.push(updates.title);
    }
    if (updates.slug !== undefined) {
      updateFields.push(`slug = $${paramIndex++}`);
      updateValues.push(updates.slug);
    }
    if (updates.excerpt !== undefined) {
      updateFields.push(`excerpt = $${paramIndex++}`);
      updateValues.push(updates.excerpt);
    }
    if (updates.content !== undefined) {
      updateFields.push(`content = $${paramIndex++}`);
      updateValues.push(updates.content);
    }
    if (updates.heroImage !== undefined) {
      updateFields.push(`hero_image = $${paramIndex++}`);
      updateValues.push(updates.heroImage);
    }
    if (updates.images !== undefined) {
      updateFields.push(`images = $${paramIndex++}::text[]`);
      updateValues.push(updates.images || []);
    }
    if (updates.holidayTypes !== undefined) {
      updateFields.push(`holiday_types = $${paramIndex++}::text[]`);
      updateValues.push(updates.holidayTypes || []);
    }
    if (updates.destinations !== undefined) {
      updateFields.push(`destinations = $${paramIndex++}::text[]`);
      updateValues.push(updates.destinations || []);
    }
    if (updates.status !== undefined) {
      updateFields.push(`status = $${paramIndex++}`);
      updateValues.push(updates.status);
    }
    
    // Always update the updated_at field
    updateFields.push(`updated_at = $${paramIndex++}`);
    updateValues.push(new Date());
    
    // Add the id for the WHERE clause
    updateValues.push(id);
    
    const query = `
      UPDATE blog_posts 
      SET ${updateFields.join(', ')} 
      WHERE id = $${paramIndex}
      RETURNING *
    `;
    
    // Use direct PostgreSQL client for array handling
    const result = await pool.query(query, updateValues);
    return result.rows[0] as BlogPost;
  }

  async deleteBlogPost(id: number): Promise<void> {
    await db.delete(blogPosts).where(eq(blogPosts.id, id));
  }

  // Newsletter
  async subscribeToNewsletter(data: InsertNewsletter): Promise<Newsletter> {
    const [newsletter] = await db.insert(newsletters)
      .values(data)
      .onConflictDoUpdate({
        target: newsletters.email,
        set: { 
          ...data,
          isSubscribed: true 
        }
      })
      .returning();
    return newsletter;
  }

  async getAllNewsletters(): Promise<Newsletter[]> {
    return await db.select().from(newsletters).orderBy(newsletters.createdAt);
  }

  // Email Templates
  async getAllEmailTemplates(): Promise<EmailTemplate[]> {
    return await db.select().from(emailTemplates).orderBy(emailTemplates.type, emailTemplates.name);
  }

  async getEmailTemplateById(id: string): Promise<EmailTemplate | undefined> {
    const [template] = await db.select().from(emailTemplates).where(eq(emailTemplates.id, id));
    return template;
  }

  async createEmailTemplate(template: InsertEmailTemplate): Promise<EmailTemplate> {
    const [newTemplate] = await db.insert(emailTemplates)
      .values({
        ...template,
        updatedAt: new Date()
      })
      .returning();
    return newTemplate;
  }

  async upsertEmailTemplate(template: InsertEmailTemplate): Promise<EmailTemplate> {
    const [upsertedTemplate] = await db
      .insert(emailTemplates)
      .values({
        ...template,
        updatedAt: new Date()
      })
      .onConflictDoUpdate({
        target: emailTemplates.id,
        set: {
          name: template.name,
          subject: template.subject,
          htmlContent: template.htmlContent,
          textContent: template.textContent,
          description: template.description,
          isActive: template.isActive,
          updatedAt: new Date()
        }
      })
      .returning();
    return upsertedTemplate;
  }

  async updateEmailTemplate(id: string, templateData: Partial<EmailTemplate>): Promise<EmailTemplate> {
    const [updatedTemplate] = await db.update(emailTemplates)
      .set({ 
        ...templateData, 
        updatedAt: new Date() 
      })
      .where(eq(emailTemplates.id, id))
      .returning();
    return updatedTemplate;
  }

  async deleteEmailTemplate(id: string): Promise<void> {
    await db.delete(emailTemplates).where(eq(emailTemplates.id, id));
  }

  // Blog Reactions
  async addBlogReaction(reaction: InsertBlogReaction): Promise<BlogReaction> {
    try {
      const [blogReaction] = await db
        .insert(blogReactions)
        .values(reaction)
        .onConflictDoUpdate({
          target: [blogReactions.blogPostId, blogReactions.userId, blogReactions.emoji],
          set: {
            createdAt: new Date(),
          },
        })
        .returning();
      return blogReaction;
    } catch (error) {
      console.error("Error adding blog reaction:", error);
      throw error;
    }
  }

  async removeBlogReaction(blogPostId: number, userId: string, emoji: string): Promise<void> {
    try {
      await db
        .delete(blogReactions)
        .where(
          and(
            eq(blogReactions.blogPostId, blogPostId),
            eq(blogReactions.userId, userId),
            eq(blogReactions.emoji, emoji)
          )
        );
    } catch (error) {
      console.error("Error removing blog reaction:", error);
      throw error;
    }
  }

  async getBlogReactions(blogPostId: number, userId?: string): Promise<{ emoji: string; count: number; userReacted: boolean }[]> {
    try {
      // Get all reactions grouped by emoji with counts
      const reactionCounts = await db
        .select({
          emoji: blogReactions.emoji,
          count: count(blogReactions.id).as('count'),
        })
        .from(blogReactions)
        .where(eq(blogReactions.blogPostId, blogPostId))
        .groupBy(blogReactions.emoji);

      // Get user's reactions if userId provided
      let userReactions: string[] = [];
      if (userId) {
        const userReactionResults = await db
          .select({ emoji: blogReactions.emoji })
          .from(blogReactions)
          .where(
            and(
              eq(blogReactions.blogPostId, blogPostId),
              eq(blogReactions.userId, userId)
            )
          );
        userReactions = userReactionResults.map(r => r.emoji);
      }

      return reactionCounts.map(reaction => ({
        emoji: reaction.emoji,
        count: Number(reaction.count),
        userReacted: userReactions.includes(reaction.emoji),
      }));
    } catch (error) {
      console.error("Error getting blog reactions:", error);
      throw error;
    }
  }

  async getBlogReactionsByUser(blogPostId: number, userId: string): Promise<BlogReaction[]> {
    try {
      return await db
        .select()
        .from(blogReactions)
        .where(
          and(
            eq(blogReactions.blogPostId, blogPostId),
            eq(blogReactions.userId, userId)
          )
        );
    } catch (error) {
      console.error("Error getting user blog reactions:", error);
      throw error;
    }
  }

  // Admin statistics
  async getAdminStats(): Promise<{
    totalAgents: number;
    pendingAgents: number;
    approvedAgents: number;
    totalEnquiries: number;
    totalReviews: number;
    totalOffers: number;
    totalDestinations: number;
    totalHolidayTypes: number;
  }> {
    try {
      const [
        agentsResult,
        pendingAgentsResult,
        approvedAgentsResult,
        enquiriesResult,
        reviewsResult,
        offersResult,
        destinationsResult,
        holidayTypesResult
      ] = await Promise.all([
        db.select({ count: count() }).from(agents),
        db.select({ count: count() }).from(agents).where(eq(agents.approvalStatus, 'pending')),
        db.select({ count: count() }).from(agents).where(eq(agents.approvalStatus, 'approved')),
        db.select({ count: count() }).from(enquiries),
        db.select({ count: count() }).from(reviews),
        db.select({ count: count() }).from(offers),
        db.select({ count: count() }).from(destinations),
        db.select({ count: count() }).from(holidayTypes)
      ]);

      return {
        totalAgents: Number(agentsResult[0]?.count || 0),
        pendingAgents: Number(pendingAgentsResult[0]?.count || 0),
        approvedAgents: Number(approvedAgentsResult[0]?.count || 0),
        totalEnquiries: Number(enquiriesResult[0]?.count || 0),
        totalReviews: Number(reviewsResult[0]?.count || 0),
        totalOffers: Number(offersResult[0]?.count || 0),
        totalDestinations: Number(destinationsResult[0]?.count || 0),
        totalHolidayTypes: Number(holidayTypesResult[0]?.count || 0),
      };
    } catch (error) {
      console.error("Error getting admin stats:", error);
      throw error;
    }
  }

  // Get count of review emails sent  
  async getReviewEmailsSentCount(): Promise<number> {
    try {
      // Since reviewEmailSent column doesn't exist yet, return 0 for now
      // This will be implemented when the column is added to the schema
      return 0;
    } catch (error) {
      console.error("Error getting review emails sent count:", error);
      return 0;
    }
  }

  // Health Check Logs
  async createHealthCheckLog(log: InsertHealthCheckLog): Promise<HealthCheckLog> {
    try {
      const [healthCheckLog] = await db
        .insert(healthCheckLogs)
        .values(log)
        .returning();
      return healthCheckLog;
    } catch (error) {
      console.error("Error creating health check log:", error);
      throw error;
    }
  }

  async getRecentHealthCheckLogs(limit: number = 5): Promise<HealthCheckLog[]> {
    try {
      return await db
        .select()
        .from(healthCheckLogs)
        .orderBy(desc(healthCheckLogs.checkTime))
        .limit(limit);
    } catch (error) {
      console.error("Error getting recent health check logs:", error);
      return [];
    }
  }
}

// Database initialisation with complete original data
async function initializeDatabaseData() {
  try {
    // Force reinitialize by clearing existing data if needed
    const existingDestinations = await db.select().from(destinations).limit(1);
    if (existingDestinations.length > 0) {
      console.log("Database already initialized, skipping data seeding");
      return;
    }

    console.log("Initializing database with complete original data...");

    // Initialize all destinations - complete list restored
    const destinationsData = [
      // Indian Ocean
      { name: "Maldives", slug: "maldives", description: "The Maldives is a tropical island paradise, known globally for its crystal-clear waters, pristine white sandy beaches, and abundant marine life.", image: getDestinationImage("maldives"), agentCount: 52, continent: "Asia" },
      { name: "Mauritius", slug: "mauritius", description: "Mauritius is a fantastic holiday destination with charming beaches, crystal-clear waters, and diverse activities from hiking to kite surfing.", image: getDestinationImage("mauritius"), agentCount: 38, continent: "Africa" },
      { name: "Seychelles", slug: "seychelles", description: "One of many gems in the Indian Ocean, famous for white sandy shores and year-round tropical climate perfect for water activities.", image: getDestinationImage("seychelles"), agentCount: 24, continent: "Africa" },
      { name: "Sri Lanka", slug: "sri-lanka", description: "Sri Lanka offers incredible diversity from ancient temples and cultural sites to pristine beaches and lush tea plantations.", image: getDestinationImage("sri-lanka"), agentCount: 18, continent: "Asia" },
      
      // Middle East
      { name: "Dubai", slug: "dubai", description: "Dubai is the perfect destination for luxury and relaxation with constant tropical climate and world-class attractions.", image: getDestinationImage("dubai"), agentCount: 63, continent: "Asia" },
      { name: "Abu Dhabi", slug: "abu-dhabi", description: "Abu Dhabi combines modern luxury with cultural heritage, featuring world-class museums, pristine beaches, and iconic architecture.", image: getDestinationImage("abu-dhabi"), agentCount: 28, continent: "Asia" },
      { name: "Oman", slug: "oman", description: "Oman offers authentic Arabian experiences with dramatic landscapes from mountains to deserts to pristine coastlines.", image: getDestinationImage("oman"), agentCount: 15, continent: "Asia" },
      { name: "Ras Al Khaimah", slug: "ras-al-khaimah", description: "Ras Al Khaimah combines adventure and relaxation with stunning mountain landscapes, pristine beaches, and thrilling activities.", image: getDestinationImage("ras-al-khaimah"), agentCount: 12, continent: "Asia" },
      { name: "Qatar", slug: "qatar", description: "Qatar offers a perfect blend of modern sophistication and traditional culture with world-class museums and desert adventures.", image: getDestinationImage("qatar"), agentCount: 19, continent: "Asia" },
      
      // Mediterranean & Europe
      { name: "Greece", slug: "greece", description: "Greece enchants with its ancient history, stunning islands, and Mediterranean charm from Santorini to the Acropolis of Athens.", image: getDestinationImage("greece"), agentCount: 45, continent: "Europe" },
      { name: "Spain", slug: "spain", description: "Spain captivates with its vibrant culture, stunning architecture, and diverse landscapes from Costa del Sol to Barcelona and Madrid.", image: getDestinationImage("spain"), agentCount: 58, continent: "Europe" },
      { name: "Cyprus", slug: "cyprus", description: "Cyprus offers Mediterranean beauty with rich history and pristine beaches, combining ancient ruins with crystal-clear waters.", image: getDestinationImage("cyprus"), agentCount: 22, continent: "Europe" },
      { name: "Portugal", slug: "portugal", description: "Portugal enchants with coastal beauty, historic cities, and warm hospitality from Porto's colorful tiles to Algarve's beaches.", image: getDestinationImage("portugal"), agentCount: 34, continent: "Europe" },
      { name: "Turkey", slug: "turkey", description: "Turkey bridges Europe and Asia with incredible diversity from ancient wonders to stunning coastlines and Cappadocia's fairy chimneys.", image: getDestinationImage("turkey"), agentCount: 41, continent: "Europe" },
      { name: "Croatia", slug: "croatia", description: "Croatia dazzles with its Adriatic coastline, medieval cities, and stunning national parks from Dubrovnik to Plitvice waterfalls.", image: getDestinationImage("croatia"), agentCount: 29, continent: "Europe" },
      { name: "Italy", slug: "italy", description: "Experience the romance of Rome, the canals of Venice, and the art of Florence in this stunning Mediterranean country.", image: getDestinationImage("italy"), agentCount: 67, continent: "Europe" },
      { name: "France", slug: "france", description: "France epitomizes elegance with romantic cities, world-class cuisine, and diverse landscapes from the Eiffel Tower to Provence's lavender fields.", image: getDestinationImage("france"), agentCount: 72, continent: "Europe" },
      { name: "Switzerland", slug: "switzerland", description: "Switzerland offers alpine beauty with pristine mountains, crystal-clear lakes, and charming villages perfect for skiing and scenic trains.", image: getDestinationImage("switzerland"), agentCount: 31, continent: "Europe" },
      { name: "Malta", slug: "malta", description: "Malta combines Mediterranean charm with rich history in a compact island setting with ancient temples and limestone cities.", image: getDestinationImage("malta"), agentCount: 16, continent: "Europe" },
      { name: "Montenegro", slug: "montenegro", description: "Montenegro surprises with dramatic mountains, pristine coastline, and medieval towns from the Bay of Kotor to Durmitor National Park.", image: getDestinationImage("montenegro"), agentCount: 14, continent: "Europe" },
      { name: "Iceland", slug: "iceland", description: "Iceland mesmerizes with otherworldly landscapes from geysers and glaciers to the Northern Lights and dramatic waterfalls.", image: getDestinationImage("iceland"), agentCount: 23, continent: "Europe" },
      { name: "Finland", slug: "finland", description: "Finland offers pristine wilderness, midnight sun, and Northern Lights with Lapland's magic and Helsinki's design scene.", image: getDestinationImage("finland"), agentCount: 18, continent: "Europe" },
      { name: "Lapland", slug: "lapland", description: "Lapland provides the ultimate Arctic experience with reindeer, Northern Lights, and winter magic including Santa's homeland.", image: getDestinationImage("lapland"), agentCount: 12, continent: "Europe" },
      
      // Caribbean
      { name: "Barbados", slug: "barbados", description: "Barbados combines Caribbean charm with British heritage, offering pristine beaches, rum distilleries, and warm hospitality.", image: getDestinationImage("barbados"), agentCount: 27, continent: "North America" },
      { name: "Saint Lucia", slug: "saint-lucia", description: "Saint Lucia enchants with dramatic Piton mountains, pristine beaches, and lush rainforests offering romance and adventure.", image: getDestinationImage("saint-lucia"), agentCount: 21, continent: "North America" },
      { name: "Antigua & Barbuda", slug: "antigua-and-barbuda", description: "Antigua & Barbuda boasts 365 beaches of pristine white sand with historic English Harbour and world-class sailing.", image: getDestinationImage("antigua-and-barbuda"), agentCount: 18, continent: "North America" },
      { name: "Grenada", slug: "grenada", description: "Grenada, the Spice Island, offers aromatic spice gardens, pristine beaches, and underwater sculpture parks.", image: getDestinationImage("grenada"), agentCount: 15, continent: "North America" },
      { name: "Jamaica", slug: "jamaica", description: "Jamaica pulses with reggae rhythms, Blue Mountain coffee, and pristine beaches with vibrant culture and warm hospitality.", image: getDestinationImage("jamaica"), agentCount: 33, continent: "North America" },
      
      // Asia
      { name: "Thailand", slug: "thailand", description: "Thailand captivates with golden temples, pristine beaches, and vibrant street food from Bangkok's energy to Phuket's serenity.", image: getDestinationImage("thailand"), agentCount: 56, continent: "Asia" },
      { name: "Japan", slug: "japan", description: "Japan seamlessly blends ancient traditions with cutting-edge modernity from Tokyo's neon lights to Kyoto's serene temples.", image: getDestinationImage("japan"), agentCount: 42, continent: "Asia" },
      { name: "Bali", slug: "bali", description: "Bali enchants with spiritual temples, lush rice terraces, and pristine beaches creating the perfect tropical paradise.", image: getDestinationImage("bali"), agentCount: 49, continent: "Asia" },
      { name: "Singapore", slug: "singapore", description: "Singapore dazzles as a modern city-state with world-class dining, stunning architecture, and tropical gardens.", image: getDestinationImage("singapore"), agentCount: 38, continent: "Asia" },
      { name: "Malaysia", slug: "malaysia", description: "Malaysia offers incredible diversity from bustling Kuala Lumpur to pristine Langkawi beaches and ancient Borneo rainforests.", image: getDestinationImage("malaysia"), agentCount: 31, continent: "Asia" },
      { name: "Indonesia", slug: "indonesia", description: "Indonesia amazes with over 17,000 islands offering diverse cultures, pristine beaches, and incredible biodiversity.", image: getDestinationImage("indonesia"), agentCount: 28, continent: "Asia" },
      { name: "Philippines", slug: "philippines", description: "The Philippines enchants with over 7,000 islands featuring pristine beaches, vibrant coral reefs, and warm Filipino hospitality.", image: getDestinationImage("philippines"), agentCount: 25, continent: "Asia" },
      { name: "Vietnam", slug: "vietnam", description: "Vietnam captivates with stunning landscapes from Ha Long Bay's limestone karsts to bustling Ho Chi Minh City and ancient Hoi An.", image: getDestinationImage("vietnam"), agentCount: 34, continent: "Asia" },
      { name: "Cambodia", slug: "cambodia", description: "Cambodia mesmerizes with the magnificent Angkor Wat temples and rich Khmer culture alongside pristine beaches.", image: getDestinationImage("cambodia"), agentCount: 19, continent: "Asia" },
      { name: "India", slug: "india", description: "India overwhelms the senses with incredible diversity from the Golden Triangle's palaces to Kerala's backwaters and Goa's beaches.", image: getDestinationImage("india"), agentCount: 41, continent: "Asia" },
      
      // Africa
      { name: "Kenya", slug: "kenya", description: "Kenya offers world-class safari experiences with the Great Migration, diverse wildlife, and stunning landscapes from savanna to coast.", image: getDestinationImage("kenya"), agentCount: 36, continent: "Africa" },
      { name: "Tanzania", slug: "tanzania", description: "Tanzania amazes with Serengeti plains, Ngorongoro Crater, and Mount Kilimanjaro alongside pristine Zanzibar beaches.", image: getDestinationImage("tanzania"), agentCount: 32, continent: "Africa" },
      { name: "South Africa", slug: "south-africa", description: "South Africa captivates with Cape Town's beauty, wine regions, Big Five safaris, and rich cultural heritage.", image: getDestinationImage("south-africa"), agentCount: 44, continent: "Africa" },
      { name: "Morocco", slug: "morocco", description: "Morocco enchants with imperial cities, Sahara dunes, Atlas Mountains, and vibrant souks full of spices and crafts.", image: getDestinationImage("morocco"), agentCount: 39, continent: "Africa" },
      { name: "Egypt", slug: "egypt", description: "Egypt reveals ancient wonders from the Pyramids of Giza to the Valley of the Kings alongside Red Sea diving.", image: getDestinationImage("egypt"), agentCount: 35, continent: "Africa" },
      
      // Americas
      { name: "Costa Rica", slug: "costa-rica", description: "Costa Rica amazes with incredible biodiversity, pristine beaches, and adventure activities from zip-lining to wildlife watching.", image: getDestinationImage("costa-rica"), agentCount: 29, continent: "North America" },
      { name: "Mexico", slug: "mexico", description: "Mexico captivates with ancient Mayan ruins, pristine Caribbean beaches, vibrant culture, and world-class cuisine.", image: getDestinationImage("mexico"), agentCount: 47, continent: "North America" },
      { name: "Peru", slug: "peru", description: "Peru mesmerizes with ancient Inca heritage, Machu Picchu's majesty, Amazon rainforest, and diverse landscapes.", image: getDestinationImage("peru"), agentCount: 26, continent: "South America" },
      { name: "Chile", slug: "chile", description: "Chile offers incredible diversity from Atacama Desert to Patagonian glaciers with world-class wine regions.", image: getDestinationImage("chile"), agentCount: 22, continent: "South America" },
      { name: "Argentina", slug: "argentina", description: "Argentina entices with tango culture, world-class steaks, stunning Patagonia, and the dramatic Iguazu Falls.", image: getDestinationImage("argentina"), agentCount: 28, continent: "South America" },
      { name: "Brazil", slug: "brazil", description: "Brazil pulses with energy from Rio's beaches and Carnival to Amazon rainforest and vibrant cultural diversity.", image: getDestinationImage("brazil"), agentCount: 33, continent: "South America" },
      
      // Oceania
      { name: "Australia", slug: "australia", description: "Australia amazes with Sydney's iconic Opera House, Great Barrier Reef, Outback adventures, and unique wildlife.", image: getDestinationImage("australia"), agentCount: 41, continent: "Oceania" },
      { name: "New Zealand", slug: "new-zealand", description: "New Zealand captivates with dramatic landscapes from fjords to mountains, adventure sports, and Maori culture.", image: getDestinationImage("new-zealand"), agentCount: 24, continent: "Oceania" },
      { name: "Fiji", slug: "fiji", description: "Fiji enchants with pristine coral reefs, crystal-clear waters, pristine beaches, and warm Fijian hospitality.", image: getDestinationImage("fiji"), agentCount: 16, continent: "Oceania" }
    ];

    for (const dest of destinationsData) {
      await db.insert(destinations).values(dest).onConflictDoNothing();
    }

    // Initialize all holiday types - complete original list restored
    const holidayTypesData = [
      { name: "Beach Holidays", slug: "beach-holidays", icon: "umbrella-beach", image: "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=400&h=300&fit=crop&crop=centre", description: "Sun, sea, sand and tropical paradise", tagline: "For those seeking sun, sea, sand and maybe a sex on the beach!" },
      { name: "Family Holidays", slug: "family-holidays", icon: "users", image: "https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?w=400&h=300&fit=crop&crop=centre", description: "Perfect vacations for all ages", tagline: "Holidays where toddlers to teenagers are fully catered for, so that you can sit back and enjoy yourself!" },
      { name: "Luxury Holidays", slug: "luxury-holidays", icon: "crown", image: "https://images.unsplash.com/photo-1564501049412-61c2a3083791?w=400&h=300&fit=crop&crop=centre", description: "Premium 5-star experiences", tagline: "Explore the best that the world of luxury travel has to offer with true 5-star experiences throughout" },
      { name: "Cruises", slug: "cruises", icon: "ship", image: "https://images.unsplash.com/photo-1488646953014-85cb44e25828?w=400&h=300&fit=crop&crop=centre", description: "Ocean adventures and floating cities", tagline: "Set sail and wake up somewhere new every couple of days, a quick way to tick off your bucket list" },
      { name: "Safari Holidays", slug: "safari-holidays", icon: "camera", image: "https://images.unsplash.com/photo-1516426122078-c23e76319801?w=400&h=300&fit=crop&crop=centre", description: "Wildlife adventures and nature photography", tagline: "For those wanting to get a snap of the World's most-see wildlife" },
      { name: "Villa Holidays", slug: "villa-holidays", icon: "home", image: "https://images.unsplash.com/photo-1613490493576-7fde63acd811?w=400&h=300&fit=crop&crop=centre", description: "Private accommodations with space and privacy", tagline: "Perfect for any family or large groups seeking a bit more space and privacy" },
      { name: "City Breaks", slug: "city-breaks", icon: "building", image: "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?w=400&h=300&fit=crop&crop=centre", description: "Urban adventures and cultural exploration", tagline: "Why not hop over to a European hot spot for a long weekend?" },
      { name: "Honeymoons", slug: "honeymoons", icon: "heart", image: "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=400&h=300&fit=crop&crop=centre", description: "Romantic once-in-a-lifetime experiences", tagline: "A romantic, once in a lifetime trip requiring that extra little bit of attention" },
      { name: "Weddings Abroad", slug: "weddings-abroad", icon: "heart-handshake", image: "https://images.unsplash.com/photo-1519225421980-715cb0215aed?w=400&h=300&fit=crop&crop=centre", description: "Destination weddings with unforgettable backdrops", tagline: "An extra special big day with a slightly different backdrop for your vows" },
      { name: "Theme Park Holidays", slug: "theme-park-holidays", icon: "ferris-wheel", image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=400&h=300&fit=crop&crop=centre", description: "Magic and adventure for kids and adults", tagline: "Disneyland and Universal Studios holidays for the kids and the kids at heart" },
      { name: "Skiing Holidays", slug: "skiing-holidays", icon: "mountain-snow", image: "https://images.unsplash.com/photo-1551524164-687a55dd1126?w=400&h=300&fit=crop&crop=centre", description: "Winter sports and mountain adventures", tagline: "From private chalets to ski-in-ski out resorts" },
      { name: "Adventure Holidays", slug: "adventure-holidays", icon: "mountain", image: "https://images.unsplash.com/photo-1551632811-561732d1e306?w=400&h=300&fit=crop&crop=centre", description: "Thrilling adventures and outdoor experiences", tagline: "For those seeking thrilling experiences and outdoor adventures" },
      { name: "Private Jet Holidays", slug: "private-jet-holidays", icon: "plane", image: "https://images.unsplash.com/photo-1540962351504-03099e0a754b?w=400&h=300&fit=crop&crop=centre", description: "Ultra-luxury private aviation experiences", tagline: "Ultra-luxury, ultra-private, ultra-special and for when only the best will do" }
    ];

    for (const holidayType of holidayTypesData) {
      await db.insert(holidayTypes).values(holidayType).onConflictDoNothing();
    }

    // Initialize all original agents from memory storage
    const allAgents = [
      // Convert the original memory storage agents to database format
      {
        email: "emma.patel@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Emma",
        lastName: "Patel",
        name: "Emma Patel",
        location: "Bristol",
        bio: "Emma Patel has established herself as one of Bristol's most innovative travel specialists, bringing over 8 years of dedicated expertise to transforming ordinary vacations into extraordinary adventures that awaken the explorer within every traveller.",
        profileImage: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=400&h=400&fit=crop&crop=face",
        company: "Travel Professional",
        nextHoliday: "Iceland Adventure - March 2025",
        rating: "4.8",
        reviewCount: 101,
        yearsExperience: 8,
        specialisations: ["City Breaks", "Luxury Holidays", "Beach Holidays"],
        destinations: ["Europe", "Asia", "Oceania"],
        languages: ["English", "Spanish", "French"],
        photos: ["https://images.unsplash.com/photo-1528181304800-259b08848526?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video1",
        isTopRated: true,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      {
        email: "adam.thompson@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Adam",
        lastName: "Thompson", 
        name: "Adam Thompson",
        location: "Manchester",
        bio: "Adam Thompson brings 12 years of specialised expertise in creating profound cultural immersion experiences across Asia, having earned recognition as Manchester's premier specialist for authentic Asian travel.",
        profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
        company: "Travel & Life",
        nextHoliday: "Nepal Cultural Trek - April 2025",
        rating: "4.9",
        reviewCount: 87,
        yearsExperience: 12,
        specialisations: ["City Breaks", "Adventure Holidays", "Safari Holidays"],
        destinations: ["Asia", "Nepal", "East Asia"],
        languages: ["English", "Mandarin", "Japanese"],
        photos: ["https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video2",
        isTopRated: false,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      {
        email: "rachel.hughes@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Rachel",
        lastName: "Hughes",
        name: "Rachel Hughes",
        location: "Edinburgh",
        bio: "Rachel Hughes has dedicated 6 years to perfecting the art of luxury European travel, establishing herself as Edinburgh's most sought-after specialist for sophisticated escapes and romantic getaways.",
        profileImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face",
        company: "Travel & Life",
        nextHoliday: "Tuscany Romance - February 2025",
        rating: "4.7",
        reviewCount: 156,
        yearsExperience: 6,
        specialisations: ["City Breaks", "Honeymoons", "Luxury Holidays"],
        destinations: ["Europe", "Italy", "East Africa"],
        languages: ["English", "Italian", "German"],
        photos: ["https://images.unsplash.com/photo-1539650116574-75c0c6d73256?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video3",
        isTopRated: false,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      {
        email: "sophie.clark@example.com", 
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Sophie",
        lastName: "Clark",
        name: "Sophie Clark",
        location: "London",
        bio: "Sophie Clark brings over a decade of unparalleled expertise to the world of luxury travel planning, having established herself as one of London's most respected cultural travel experts.",
        profileImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop&crop=face",
        company: "Cultural Travel Expert",
        nextHoliday: "Japan Cultural Journey - March 2025",
        rating: "4.9",
        reviewCount: 203,
        yearsExperience: 10,
        specialisations: ["City Breaks", "Luxury Holidays", "Beach Holidays"],
        destinations: ["Japan", "Southeast Asia", "Europe"],
        languages: ["English", "Japanese", "Thai"],
        photos: ["https://images.unsplash.com/photo-1528181304800-259b08848526?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video4",
        isTopRated: true,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      // Add more agents from the original memory storage
      {
        email: "marcus.rodriguez@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Marcus",
        lastName: "Rodriguez",
        name: "Marcus Rodriguez",
        location: "Birmingham",
        bio: "Marcus Rodriguez has spent 7 years establishing himself as Birmingham's premier adventure travel specialist, with particular expertise in Central and South American expeditions.",
        profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
        company: "Adventure Quest Travel",
        nextHoliday: "Costa Rica Adventure - March 2025",
        rating: "4.6",
        reviewCount: 89,
        yearsExperience: 7,
        specialisations: ["Adventure Holidays", "Safari Holidays", "Villa Holidays"],
        destinations: ["Central America", "South America", "Costa Rica"],
        languages: ["English", "Spanish", "Portuguese"],
        photos: ["https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video5",
        isTopRated: false,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      {
        email: "priya.sharma@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Priya",
        lastName: "Sharma",
        name: "Priya Sharma",
        location: "London",
        bio: "Priya Sharma has dedicated 9 years to curating extraordinary luxury experiences across India and Southeast Asia, establishing herself as London's premier specialist for high-end Asian travel.",
        profileImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop&crop=face",
        company: "Asian Luxury Journeys",
        nextHoliday: "Rajasthan Palace Tour - April 2025",
        rating: "4.8",
        reviewCount: 134,
        yearsExperience: 9,
        specialisations: ["Luxury Holidays", "Cultural Holidays", "Honeymoons"],
        destinations: ["India", "Southeast Asia", "Thailand", "Vietnam"],
        languages: ["English", "Hindi", "Thai"],
        photos: ["https://images.unsplash.com/photo-1528181304800-259b08848526?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video6",
        isTopRated: true,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      {
        email: "oliver.james@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Oliver",
        lastName: "James",
        name: "Oliver James",
        location: "Bath",
        bio: "Oliver James brings 5 years of specialised experience in family travel planning, focusing on creating memorable adventures that cater to all ages and interests across Europe and North America.",
        profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
        company: "Family Adventures UK",
        nextHoliday: "Disney World Family Package - June 2025",
        rating: "4.7",
        reviewCount: 78,
        yearsExperience: 5,
        specialisations: ["Family Holidays", "Theme Parks", "City Breaks"],
        destinations: ["Europe", "North America", "France", "Spain"],
        languages: ["English", "French"],
        photos: ["https://images.unsplash.com/photo-1539650116574-75c0c6d73256?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video7",
        isTopRated: false,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      // Add many more agents to reach the original 41+ count
      {
        email: "charlotte.brown@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Charlotte",
        lastName: "Brown",
        name: "Charlotte Brown",
        location: "Oxford",
        bio: "Charlotte Brown has spent 11 years perfecting the art of romantic travel, specializing in honeymoons and anniversary celebrations across Europe's most enchanting destinations.",
        profileImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face",
        company: "Romance & Travel Co.",
        nextHoliday: "Santorini Honeymoon Special - May 2025",
        rating: "4.9",
        reviewCount: 189,
        yearsExperience: 11,
        specialisations: ["Honeymoons", "Romantic Holidays", "Luxury Holidays"],
        destinations: ["Greece", "Italy", "France", "Spain"],
        languages: ["English", "Italian", "Greek"],
        photos: ["https://images.unsplash.com/photo-1528181304800-259b08848526?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video8",
        isTopRated: true,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      {
        email: "liam.wilson@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Liam",
        lastName: "Wilson",
        name: "Liam Wilson",
        location: "Cardiff",
        bio: "Liam Wilson has established himself as Wales' leading adventure travel expert over 8 years, specializing in outdoor pursuits and wildlife experiences across Europe and Africa.",
        profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
        company: "Wild Wales Adventures",
        nextHoliday: "Kenya Safari Expedition - July 2025",
        rating: "4.6",
        reviewCount: 95,
        yearsExperience: 8,
        specialisations: ["Adventure Holidays", "Wildlife Holidays", "Safari Holidays"],
        destinations: ["Africa", "Kenya", "Tanzania", "Europe"],
        languages: ["English", "Welsh", "Swahili"],
        photos: ["https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video9",
        isTopRated: false,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      {
        email: "isabella.garcia@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Isabella",
        lastName: "Garcia",
        name: "Isabella Garcia",
        location: "Brighton",
        bio: "Isabella Garcia brings 7 years of expertise in beach and coastal holidays, specializing in Mediterranean and Caribbean destinations for the perfect seaside escape.",
        profileImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop&crop=face",
        company: "Coastal Escapes",
        nextHoliday: "Barbados Beach Retreat - August 2025",
        rating: "4.8",
        reviewCount: 112,
        yearsExperience: 7,
        specialisations: ["Beach Holidays", "Caribbean", "Mediterranean"],
        destinations: ["Caribbean", "Mediterranean", "Spain", "Greece"],
        languages: ["English", "Spanish", "Portuguese"],
        photos: ["https://images.unsplash.com/photo-1539650116574-75c0c6d73256?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video10",
        isTopRated: true,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      {
        email: "thomas.davies@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Thomas",
        lastName: "Davies",
        name: "Thomas Davies",
        location: "Liverpool",
        bio: "Thomas Davies has spent 6 years specializing in cultural and historical tours across Europe, with particular expertise in ancient civilisations and UNESCO World Heritage sites.",
        profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
        company: "Heritage Tours Europe",
        nextHoliday: "Ancient Greece Historical Tour - September 2025",
        rating: "4.7",
        reviewCount: 88,
        yearsExperience: 6,
        specialisations: ["Cultural Holidays", "Historical Tours", "City Breaks"],
        destinations: ["Europe", "Greece", "Italy", "Turkey"],
        languages: ["English", "Greek", "Italian"],
        photos: ["https://images.unsplash.com/photo-1528181304800-259b08848526?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video11",
        isTopRated: false,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      {
        email: "emily.taylor@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Emily",
        lastName: "Taylor",
        name: "Emily Taylor",
        location: "Newcastle",
        bio: "Emily Taylor has established herself as Northeast England's premier wellness travel specialist over 9 years, focusing on spa retreats, yoga holidays, and mindfulness experiences.",
        profileImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face",
        company: "Wellness Wanderers",
        nextHoliday: "Bali Yoga Retreat - October 2025",
        rating: "4.9",
        reviewCount: 167,
        yearsExperience: 9,
        specialisations: ["Wellness Holidays", "Spa Retreats", "Yoga Holidays"],
        destinations: ["Bali", "Thailand", "India", "Costa Rica"],
        languages: ["English", "Indonesian"],
        photos: ["https://images.unsplash.com/photo-1539650116574-75c0c6d73256?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video12",
        isTopRated: true,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      // Adding 38 more agents to reach total of 50
      {
        email: "james.mitchell@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "James",
        lastName: "Mitchell",
        name: "James Mitchell",
        location: "Glasgow",
        bio: "James Mitchell has established himself as Scotland's premier adventure and wildlife specialist over the past 9 years, combining his passion for outdoor exploration with deep expertise in sustainable tourism practices. Born and raised in the Scottish Highlands, James developed an early appreciation for nature's raw beauty and the importance of preserving pristine wilderness areas for future generations. His journey into professional travel planning began after completing a degree in Environmental Science and spending two years working with conservation organisations across Africa and South America. James specialises in creating transformative adventure experiences that challenge travellers physically and mentally while maintaining the highest safety standards and environmental responsibility. His extensive personal experience includes leading expeditions to remote corners of Patagonia, organising wildlife photography tours in Kenya's Maasai Mara, and guiding multi-day treks through Scotland's most challenging terrain. What sets James apart is his ability to design adventures that cater to different fitness levels while ensuring every participant experiences genuine connection with nature and local cultures. His comprehensive pre-trip preparation includes fitness assessments, gear recommendations, and cultural briefings that prepare travellers for authentic encounters with indigenous communities and wildlife. James maintains partnerships with local guides and conservation organisations worldwide, ensuring his clients' adventures directly contribute to wildlife protection and community development initiatives.",
        profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
        company: "Highland Adventures",
        nextHoliday: "Patagonia Wildlife Expedition - May 2025",
        rating: "4.8",
        reviewCount: 142,
        yearsExperience: 9,
        specialisations: ["Adventure Holidays", "Wildlife Holidays", "Safari Holidays", "Eco Tourism"],
        destinations: ["Scotland", "Patagonia", "Kenya", "Tanzania", "Nepal"],
        languages: ["English", "Gaelic", "Spanish"],
        photos: ["https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video13",
        isTopRated: true,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      {
        email: "sarah.robinson@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Sarah",
        lastName: "Robinson",
        name: "Sarah Robinson",
        location: "York",
        bio: "Sarah Robinson brings 7 years of specialised expertise in luxury European travel, having cultivated an impressive network of exclusive accommodations, private guides, and cultural institutions across the continent. Her background in art history and fluency in four European languages allows her to create deeply enriching cultural experiences that go far beyond typical tourist attractions. Sarah's passion for European luxury travel was ignited during her postgraduate studies in Vienna, where she spent three years immersed in classical music culture and developing relationships with prominent museums, private galleries, and aristocratic families who open their historic properties for exclusive visits. Her approach to luxury travel emphasizes authentic sophistication over ostentatious displays, seeking out experiences that combine exceptional comfort with genuine cultural enrichment and historical significance. Sarah specialises in creating bespoke itineraries for discerning travellers who appreciate fine dining, classical arts, and architectural heritage. Her services include arranging private concerts in historic palaces, securing after-hours access to world-renowned museums, organising intimate wine tastings in centuries-old cellars, and booking stays in converted castles and aristocratic estates. What distinguishes Sarah is her meticulous attention to detail and her ability to anticipate her clients' preferences, often arranging surprise experiences that exceed expectations. Her clients consistently praise her ability to create seamless luxury experiences that feel effortless while being incredibly complex to coordinate behind the scenes.",
        profileImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop&crop=face",
        company: "European Elegance Travel",
        nextHoliday: "Austrian Classical Music Tour - April 2025",
        rating: "4.9",
        reviewCount: 187,
        yearsExperience: 7,
        specialisations: ["Luxury Holidays", "Cultural Holidays", "Art Tours", "Classical Music"],
        destinations: ["Austria", "Germany", "France", "Italy", "Czech Republic"],
        languages: ["English", "German", "French", "Italian"],
        photos: ["https://images.unsplash.com/photo-1528181304800-259b08848526?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video14",
        isTopRated: true,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      {
        email: "david.chen@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "David",
        lastName: "Chen",
        name: "David Chen",
        location: "Cambridge",
        bio: "David Chen has dedicated 11 years to mastering the art of family travel planning, specialising in creating magical experiences that cater to multiple generations while ensuring every family member, from toddlers to grandparents, feels engaged and excited throughout their journey. His expertise stems from his multicultural background - born in Hong Kong and educated in the UK - which gives him unique insight into creating travel experiences that bridge different cultures and age groups. David's approach to family travel goes beyond simply booking child-friendly accommodations; he designs comprehensive itineraries that balance educational opportunities with pure fun, active adventures with relaxing downtime, and cultural immersion with familiar comforts. His extensive research into child psychology and developmental stages allows him to recommend age-appropriate activities and destinations that stimulate learning while keeping children entertained. David maintains detailed databases of family-friendly accommodations worldwide, including properties with interconnecting rooms, kids' clubs with qualified childcare professionals, and resorts offering both adult and children's activities. He personally visits and evaluates every accommodation he recommends, testing everything from playground safety to the quality of children's menus. His services include creating detailed daily itineraries with backup indoor activities for rainy days, arranging specialised transportation for families with young children, and providing comprehensive packing lists tailored to specific destinations and seasons. David's clients consistently praise his ability to anticipate potential challenges and provide solutions before problems arise, making family travel feel effortless and enjoyable for parents.",
        profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
        company: "Family World Explorers",
        nextHoliday: "Multi-Generation Japan Discovery - June 2025",
        rating: "4.8",
        reviewCount: 234,
        yearsExperience: 11,
        specialisations: ["Family Holidays", "Multi-Generation Travel", "Educational Tours", "Theme Parks"],
        destinations: ["Japan", "Singapore", "Australia", "United States", "United Kingdom"],
        languages: ["English", "Mandarin", "Cantonese"],
        photos: ["https://images.unsplash.com/photo-1539650116574-75c0c6d73256?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video15",
        isTopRated: false,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      {
        email: "maria.gonzalez@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Maria",
        lastName: "Gonzalez",
        name: "Maria Gonzalez",
        location: "Seville",
        bio: "Maria Gonzalez has spent 8 years establishing herself as the premier specialist for authentic Spanish and Latin American cultural experiences, combining her native Spanish heritage with extensive travel throughout the Hispanic world to create deeply immersive journeys that reveal the true soul of Latin culture. Born in Andalusia and having lived in Argentina, Mexico, and Peru, Maria possesses intimate knowledge of regional variations in language, customs, cuisine, and traditions that allows her to craft highly personalised experiences for travellers seeking genuine cultural connections. Her expertise extends beyond typical tourist attractions to include exclusive access to flamenco workshops with master dancers, private cooking classes with renowned chefs in their family kitchens, and intimate meetings with local artisans who demonstrate traditional crafts passed down through generations. Maria's approach to cultural travel emphasizes respectful engagement with local communities, ensuring that her clients' visits contribute positively to the places they explore while providing travellers with transformative experiences that challenge preconceptions and build lasting cultural understanding. She specialises in designing itineraries that reveal the complexity and richness of Hispanic cultures, from the sophisticated urban culture of Buenos Aires to the ancient indigenous traditions preserved in remote Andean villages. Her services include arranging stays in historic haciendas, organising private tours of family-run vineyards and olive groves, and facilitating meaningful interactions with local families who welcome travellers into their homes for authentic cultural exchanges. Maria's clients consistently describe their journeys as life-changing, citing not just the beautiful destinations and delicious food, but the deep personal connections they formed with local people and the profound understanding they gained of different ways of life.",
        profileImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop&crop=face",
        company: "Authentic Hispanic Experiences",
        nextHoliday: "Andalusian Flamenco Immersion - March 2025",
        rating: "4.9",
        reviewCount: 156,
        yearsExperience: 8,
        specialisations: ["Cultural Holidays", "Culinary Tours", "Flamenco Experiences", "Wine Tours"],
        destinations: ["Spain", "Argentina", "Mexico", "Peru", "Colombia"],
        languages: ["Spanish", "English", "Portuguese"],
        photos: ["https://images.unsplash.com/photo-1528181304800-259b08848526?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video16",
        isTopRated: true,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      {
        email: "andrew.stewart@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Andrew",
        lastName: "Stewart",
        name: "Andrew Stewart",
        location: "Edinburgh",
        bio: "Andrew Stewart has devoted 12 years to perfecting the art of luxury Scottish and Nordic travel, combining his deep knowledge of Celtic and Scandinavian cultures with access to exclusive accommodations and experiences throughout Scotland, Iceland, Norway, and Denmark. His passion for Northern European travel began during his studies in medieval history at Edinburgh University, where he developed a fascination with Viking culture and Celtic traditions that continues to inform his travel planning today. Andrew specialises in creating sophisticated journeys that reveal the rich cultural heritage, stunning natural beauty, and modern innovations of Nordic countries while providing access to experiences unavailable to typical tourists. His extensive network includes relationships with Scottish castle owners who open their private estates for exclusive visits, Icelandic geologists who lead private tours to hidden geological wonders, Norwegian fishermen who take small groups on authentic Arctic expeditions, and Danish design studios that offer behind-the-scenes glimpses into Scandinavian aesthetic philosophy. Andrew's approach to luxury travel emphasizes authentic cultural immersion combined with exceptional comfort, whether that means arranging stays in converted Scottish castles, booking private Northern Lights viewing experiences in glass igloos, or organising exclusive whisky tastings in distilleries normally closed to the public. His clients consistently praise his encyclopedic knowledge of Northern European history and culture, his ability to secure reservations at restaurants with year-long waiting lists, and his talent for creating itineraries that perfectly balance adventure with relaxation. Andrew's attention to detail is legendary among his clients, who often discover that he has anticipated their needs and preferences in ways that make their travels feel effortless and magical.",
        profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
        company: "Nordic Heritage Travel",
        nextHoliday: "Private Scottish Castle Tour - May 2025",
        rating: "4.9",
        reviewCount: 198,
        yearsExperience: 12,
        specialisations: ["Luxury Holidays", "Castle Tours", "Viking Heritage", "Whisky Tours"],
        destinations: ["Scotland", "Iceland", "Norway", "Denmark", "Sweden"],
        languages: ["English", "Gaelic", "Norwegian"],
        photos: ["https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video17",
        isTopRated: true,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      // Continue adding 33 more agents for total of 50
      {
        email: "linda.wang@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Linda",
        lastName: "Wang",
        name: "Linda Wang",
        location: "Manchester",
        bio: "Linda Wang has established herself as the UK's premier wellness and spiritual travel specialist over 10 years, combining her background in holistic health with extensive knowledge of global wellness destinations to create transformative journeys that nurture mind, body, and spirit. Her expertise stems from personal experience overcoming burnout in the corporate world, which led her to explore wellness practices across Asia, South America, and Europe. Linda specialises in designing retreats and wellness holidays that go far beyond typical spa experiences, incorporating authentic healing traditions, meditation practices, and spiritual growth opportunities. Her comprehensive approach includes pre-travel wellness assessments, personalised itineraries based on individual health goals, and post-travel integration support to help clients maintain their wellness practices at home. Linda maintains close relationships with renowned wellness centres, meditation teachers, Ayurvedic practitioners, and spiritual guides worldwide, ensuring her clients receive authentic experiences rather than commercialized wellness tourism. Her services include arranging stays at exclusive wellness retreats in Bali, organising Ayurvedic treatments with master practitioners in India, booking meditation retreats in Buddhist monasteries, and coordinating detox programs at world-class wellness centres. What sets Linda apart is her holistic approach to wellness travel, considering not just physical health but emotional, mental, and spiritual well-being throughout the journey.",
        profileImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop&crop=face",
        company: "Holistic Journey Wellness",
        nextHoliday: "Bali Spiritual Awakening Retreat - April 2025",
        rating: "4.9",
        reviewCount: 173,
        yearsExperience: 10,
        specialisations: ["Wellness Holidays", "Spiritual Retreats", "Meditation Tours", "Ayurveda"],
        destinations: ["Bali", "India", "Costa Rica", "Peru", "Thailand"],
        languages: ["English", "Mandarin", "Indonesian"],
        photos: ["https://images.unsplash.com/photo-1539650116574-75c0c6d73256?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video18",
        isTopRated: true,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      {
        email: "robert.king@example.com",
        password: await bcrypt.hash("temppass123", 12), 
        firstName: "Robert",
        lastName: "King",
        name: "Robert King",
        location: "Canterbury",
        bio: "Robert King has dedicated 13 years to becoming Britain's foremost specialist in historical and archaeological travel, combining his doctorate in Medieval History with extensive field experience to create deeply educational journeys that bring ancient civilisations to life. His passion for historical travel began during archaeological excavations in Greece and Turkey, where he developed relationships with leading archaeologists and historians who continue to provide exclusive access to restricted sites and newly discovered artifacts. Robert specialises in creating immersive historical experiences that go far beyond typical guided tours, incorporating hands-on archaeological activities, meetings with leading researchers, and access to sites normally closed to the public. His expertise spans ancient civilisations from Egyptian pyramids to Roman ruins, Medieval castles to Renaissance palaces, and Viking settlements to Mayan temples. Robert's approach to historical travel emphasizes authentic learning experiences that challenge participants intellectually while providing unforgettable adventures. His services include arranging private tours with renowned archaeologists, organising access to restricted excavation sites, coordinating lectures by world-leading historians, and facilitating hands-on workshops in traditional crafts and historical skills. What distinguishes Robert is his ability to make ancient history feel immediate and relevant, helping travellers understand the daily lives, challenges, and achievements of people who lived thousands of years ago. His clients consistently describe their journeys as transformative educational experiences that fundamentally change their understanding of human history and their place within it.",
        profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
        company: "Ancient Worlds Explorer",
        nextHoliday: "Archaeological Greece Expedition - June 2025",
        rating: "4.8",
        reviewCount: 145,
        yearsExperience: 13,
        specialisations: ["Historical Tours", "Archaeological Expeditions", "Educational Travel", "Ancient Civilisations"],
        destinations: ["Greece", "Turkey", "Egypt", "Italy", "Peru"],
        languages: ["English", "Greek", "Latin"],
        photos: ["https://images.unsplash.com/photo-1528181304800-259b08848526?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video19",
        isTopRated: false,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      // Continue adding remaining 31 agents to reach 50 total
      {
        email: "jennifer.clark@example.com",
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Jennifer",
        lastName: "Clark",
        name: "Jennifer Clark",
        location: "Bath",
        bio: "Jennifer Clark has spent 9 years establishing herself as the UK's leading specialist in romantic and luxury European holidays, creating unforgettable experiences for couples celebrating special occasions. Her expertise combines intimate knowledge of Europe's most romantic destinations with access to exclusive venues, private experiences, and luxury accommodations that transform ordinary trips into magical celebrations of love. Jennifer's background in hospitality management and her fluency in five European languages enable her to coordinate complex romantic itineraries with flawless attention to detail. She specialises in designing honeymoon packages, anniversary celebrations, proposal trips, and romantic getaways that exceed couples' highest expectations. Her services include arranging private dinners in historic castles, booking couples' spa treatments at world-renowned wellness centres, coordinating sunset yacht cruises along the Mediterranean coast, and securing reservations at Michelin-starred restaurants with the most romantic ambiances. Jennifer maintains exclusive partnerships with luxury hotels, private villa owners, and boutique experience providers throughout Europe, ensuring her clients receive VIP treatment and access to experiences unavailable through typical booking channels. What sets Jennifer apart is her ability to understand each couple's unique love story and translate that into personalised travel experiences that celebrate their relationship while creating new memories together.",
        profileImage: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop&crop=face",
        company: "European Romance Specialists",
        nextHoliday: "Tuscany Romantic Escape - May 2025",
        rating: "4.9",
        reviewCount: 167,
        yearsExperience: 9,
        specialisations: ["Romantic Holidays", "Honeymoons", "Luxury Holidays", "Anniversary Celebrations"],
        destinations: ["Italy", "France", "Greece", "Spain", "Portugal"],
        languages: ["English", "Italian", "French", "Spanish"],
        photos: ["https://images.unsplash.com/photo-1528181304800-259b08848526?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1499856871958-5b9627545d1a?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video20",
        isTopRated: true,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      },
      {
        email: "michael.brown@example.com", 
        password: await bcrypt.hash("temppass123", 12),
        firstName: "Michael",
        lastName: "Brown",
        name: "Michael Brown",
        location: "Birmingham",
        bio: "Michael Brown has dedicated 11 years to mastering group adventure travel, specialising in organising expeditions for corporate teams, friend groups, and adventure clubs seeking challenging and transformative experiences in remote destinations. His expertise stems from his background as a former Royal Marine and qualified mountain guide, providing him with unparalleled skills in risk assessment, group dynamics, and wilderness safety. Michael excels at creating adventures that push participants beyond their comfort zones while maintaining the highest safety standards and fostering team bonding through shared challenges. His extensive experience includes leading groups through Patagonia's most demanding treks, organising multi-day kayaking expeditions in Norwegian fjords, coordinating rock climbing adventures in the Swiss Alps, and facilitating survival training programs in remote wilderness areas. Michael's approach to group adventure travel emphasizes personal growth, team building, and environmental stewardship, ensuring that every expedition leaves participants more confident, connected, and conscious of their impact on pristine natural environments. His comprehensive pre-expedition preparation includes fitness assessments, skills training, equipment provision, and team-building exercises that prepare groups for the physical and mental challenges ahead. Michael maintains relationships with expert local guides, wilderness first aid specialists, and conservation organisations worldwide, ensuring that his expeditions contribute positively to local communities and environmental protection efforts.",
        profileImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face",
        company: "Extreme Adventure Collective",
        nextHoliday: "Patagonia Group Expedition - July 2025",
        rating: "4.7",
        reviewCount: 134,
        yearsExperience: 11,
        specialisations: ["Adventure Holidays", "Group Travel", "Corporate Retreats", "Wilderness Survival"],
        destinations: ["Patagonia", "Norway", "Switzerland", "Nepal", "New Zealand"],
        languages: ["English", "Spanish", "Norwegian"],
        photos: ["https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=600&h=400&fit=crop"],
        videoUrl: "https://example.com/video21",
        isTopRated: false,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      }
    ];

    // Generate remaining 31 agents to reach 50 total
    const additionalAgents = [];
    const additionalNames = [
      "Sophie Turner", "Alex Johnson", "Grace Wilson", "Ben Parker", "Olivia Davis", 
      "Luke Thompson", "Hannah White", "Ryan Miller", "Zoe Anderson", "Jacob Garcia",
      "Mia Rodriguez", "Noah Martinez", "Emma Wilson", "William Jones", "Isabella Thomas",
      "Mason Brown", "Charlotte Jackson", "Logan Harris", "Amelia Clark", "Lucas Lewis",
      "Harper Robinson", "Henry Walker", "Evelyn Hall", "Sebastian Young", "Abigail King",
      "Owen Wright", "Emily Lopez", "Caleb Hill", "Madison Green", "Aidan Adams",
      "Chloe Nelson"
    ];

    const cities = ["Leeds", "Sheffield", "Nottingham", "Leicester", "Coventry", "Hull", "Bradford", "Cardiff", "Belfast", "Aberdeen", "Dundee", "Portsmouth", "Plymouth", "Southampton", "Reading", "Bolton", "Preston", "Newport", "Swansea", "Derby", "Salford", "Wolverhampton", "Luton", "Milton Keynes", "Northampton", "Norwich", "Dudley", "Oxford", "Blackpool", "Middlesbrough", "Swindon"];
    
    const specialisations = [
      ["Beach Holidays", "Island Escapes", "Water Sports", "Tropical Paradise"],
      ["Mountain Adventures", "Hiking", "Skiing", "Alpine Experiences"],
      ["City Breaks", "Urban Exploration", "Nightlife", "Cultural Cities"],
      ["Culinary Tours", "Food Adventures", "Wine Tasting", "Gourmet Travel"],
      ["Photography Tours", "Wildlife Photography", "Landscape Photography", "Portrait Travel"],
      ["Solo Travel", "Independent Adventures", "Backpacking", "Self Discovery"],
      ["Senior Travel", "Accessible Travel", "Comfortable Tours", "Heritage Tours"],
      ["Budget Travel", "Backpacker Friendly", "Value Adventures", "Student Travel"],
      ["Luxury Cruises", "Ocean Voyages", "River Cruises", "Yacht Charters"],
      ["Desert Adventures", "Sahara Expeditions", "Camel Trekking", "Oasis Tours"]
    ];

    const destinationSets = [
      ["Caribbean", "Bahamas", "Jamaica", "Barbados"],
      ["Swiss Alps", "French Alps", "Austrian Alps", "Italian Dolomites"],
      ["Paris", "London", "Rome", "Barcelona", "Amsterdam"],
      ["France", "Italy", "Spain", "Greece", "Portugal"],
      ["Kenya", "Tanzania", "South Africa", "Botswana", "Namibia"],
      ["Thailand", "Vietnam", "Cambodia", "Laos", "Myanmar"],
      ["Scotland", "Ireland", "Wales", "England"],
      ["Eastern Europe", "Czech Republic", "Poland", "Hungary"],
      ["Mediterranean", "Aegean Sea", "Adriatic Sea", "French Riviera"],
      ["Morocco", "Egypt", "Jordan", "Dubai", "Oman"]
    ];

    for (let i = 0; i < 31; i++) {
      const [firstName, lastName] = additionalNames[i].split(" ");
      const specIndex = i % specialisations.length;
      
      additionalAgents.push({
        email: `${firstName.toLowerCase()}.${lastName.toLowerCase()}@example.com`,
        password: await bcrypt.hash("temppass123", 12),
        firstName,
        lastName,
        name: additionalNames[i],
        location: cities[i],
        bio: `${additionalNames[i]} has established themselves as a leading specialist in ${specialisations[specIndex][0].toLowerCase()} with ${5 + (i % 8)} years of dedicated experience creating exceptional travel experiences. Their passion for travel began through personal adventures and has evolved into expertise in crafting memorable journeys for discerning travellers. With deep knowledge of their specialised destinations and extensive networks of local contacts, ${firstName} delivers authentic experiences that go beyond typical tourist attractions. Their meticulous attention to detail and commitment to excellence ensures every trip exceeds expectations, whether organising intimate getaways for couples, adventurous expeditions for thrill-seekers, or culturally immersive journeys for curious explorers. ${firstName} takes pride in understanding each client's unique preferences and tailoring itineraries that create lasting memories. Their comprehensive approach includes thorough destination research, careful selection of accommodations and experiences, and ongoing support throughout the journey. With proven expertise in ${specialisations[specIndex].join(", ").toLowerCase()}, ${firstName} continues to build a reputation for delivering exceptional travel experiences that transform ordinary vacations into extraordinary adventures that clients treasure for years to come.`,
        profileImage: i % 2 === 0 ? "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop&crop=face" : "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=400&h=400&fit=crop&crop=face",
        company: `${specialisations[specIndex][0]} Specialists`,
        nextHoliday: `${destinationSets[specIndex][0]} Adventure - ${["March", "April", "May", "June", "July", "August"][i % 6]} 2025`,
        rating: (4.2 + (i % 8) * 0.1).toFixed(1),
        reviewCount: 50 + (i * 12),
        yearsExperience: 5 + (i % 8),
        specialisations: specialisations[specIndex],
        destinations: destinationSets[specIndex],
        languages: i < 10 ? ["English", "Spanish"] : i < 20 ? ["English", "French"] : ["English", "German"],
        photos: ["https://images.unsplash.com/photo-1539650116574-75c0c6d73256?w=600&h=400&fit=crop", "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=600&h=400&fit=crop"],
        videoUrl: `https://example.com/video${22 + i}`,
        isTopRated: i % 5 === 0,
        isVerified: true,
        isEmailVerified: true,
        emailVerificationToken: null,
        profileCompleted: true
      });
    }

    allAgents.push(...additionalAgents);

    for (const agent of allAgents) {
      await db.insert(agents).values(agent).onConflictDoNothing();
    }

    // Get the first 3 agents that were just created to use their IDs for offers
    const createdAgents = await db.select().from(agents).limit(3);
    
    // Add sample offers (using correct agent IDs that exist)
    const sampleOffers = [
      {
        agentId: createdAgents[0]?.id || 1,
        title: "European Adventure Package", 
        description: "14 days exploring Europe's hidden gems",
        image: "https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?w=600&h=400&fit=crop",
        originalPrice: "2999.00",
        discountPrice: "2399.00",
        discountPercentage: 20,
        destination: "Europe",
        holidayType: "Adventure Holidays",
        isActive: true
      },
      {
        agentId: createdAgents[1]?.id || 2,
        title: "Asian Cultural Journey",
        description: "21 days of cultural immersion across Asia",
        image: "https://images.unsplash.com/photo-1490806843957-31f4c9a91c65?w=600&h=400&fit=crop",
        originalPrice: "3499.00",
        discountPrice: "2799.00",
        discountPercentage: 20,
        destination: "Asia",
        holidayType: "Cultural Holidays",
        isActive: true
      },
      {
        agentId: createdAgents[2]?.id || 3,
        title: "European Luxury Romance",
        description: "10 days of luxury romance across Europe",
        image: "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?w=600&h=400&fit=crop",
        originalPrice: "4999.00",
        discountPrice: "3999.00",
        discountPercentage: 20,
        destination: "Europe",
        holidayType: "Luxury Holidays",
        isActive: true
      }
    ];

    for (const offer of sampleOffers) {
      await db.insert(offers).values(offer).onConflictDoNothing();
    }

    // Add sample reviews using the correct agent IDs
    const sampleReviews = [
      {
        agentId: createdAgents[0]?.id || 1,
        customerName: "Sarah Johnson",
        customerImage: "https://images.unsplash.com/photo-1494790108755-2616b612b602?w=100&h=100&fit=crop&crop=face",
        rating: 5,
        reviewText: "Emma planned the most incredible European adventure for us. Every detail was perfect!",
        tripType: "Adventure Holiday",
        isVerified: true
      },
      {
        agentId: createdAgents[1]?.id || 2,
        customerName: "Mike Chen",
        customerImage: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=100&h=100&fit=crop&crop=face",
        rating: 5,
        reviewText: "Adam took us on an amazing cultural journey across Asia. Experiences we never would have found ourselves!",
        tripType: "Cultural Holiday",
        isVerified: true
      },
      {
        agentId: createdAgents[2]?.id || 3,
        customerName: "Lisa Anderson",
        customerImage: "https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=100&h=100&fit=crop&crop=face",
        rating: 5,
        reviewText: "Rachel's attention to luxury details made our European romance trip absolutely unforgettable.",
        tripType: "Luxury Holiday",
        isVerified: true
      }
    ];

    for (const review of sampleReviews) {
      await db.insert(reviews).values(review).onConflictDoNothing();
    }

    // Add sample blog posts using the correct agent IDs
    const sampleBlogs = [
      {
        agentId: createdAgents[0]?.id || 1,
        title: "Adventure Travel Safety: Essential Tips for Every Explorer",
        slug: "adventure-travel-safety-essential-tips",
        excerpt: "Learn the essential safety protocols and gear recommendations for adventure travel, from mountain trekking to jungle expeditions.",
        content: "Adventure travel opens up incredible experiences, but safety should always be your top priority. Here are my top recommendations based on years of leading expeditions...",
        image: "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=600&h=400&fit=crop",
        category: "Travel Tips",
        publishedAt: new Date('2025-01-15')
      },
      {
        agentId: createdAgents[1]?.id || 2,
        title: "Cultural Immersion: The Art of Authentic Asian Travel",
        slug: "cultural-immersion-authentic-asian-travel",
        excerpt: "Discover how to create meaningful connections with local communities during your Asian adventures.",
        content: "Cultural immersion goes beyond visiting tourist attractions. As someone who has been creating authentic Asian experiences for over 12 years, I want to share the secrets...",
        image: "https://images.unsplash.com/photo-1523906834658-6e24ef2386f9?w=600&h=400&fit=crop",
        category: "Cultural Travel",
        publishedAt: new Date('2025-01-10')
      },
      {
        agentId: createdAgents[2]?.id || 3,
        title: "Luxury European Romance: Creating Perfect Getaways",
        slug: "luxury-european-romance-perfect-getaways",
        excerpt: "Explore the finest romantic destinations across Europe with insider tips for creating unforgettable moments.",
        content: "Romance in Europe takes many forms, from intimate Tuscan villas to Parisian rooftop dinners. After planning over 150 romantic getaways...",
        image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?w=600&h=400&fit=crop",
        category: "Romance Travel",
        publishedAt: new Date('2025-01-05')
      }
    ];

    for (const blog of sampleBlogs) {
      await db.insert(blogPosts).values(blog).onConflictDoNothing();
    }

    console.log("Database initialisation completed successfully with full dataset");
  } catch (error) {
    console.error("Error initializing database:", error);
  }
}

// Use database storage for production
export const storage = new DatabaseStorage();

// Initialize database data on startup
initializeDatabaseData().catch(console.error);
