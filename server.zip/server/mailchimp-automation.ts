import { storage } from './storage';

// Toggle between current system and Mailchimp automations
// Set to true - using unified Mailchimp system for proper unsubscribe management
const USE_MAILCHIMP_AUTOMATIONS = true;

interface AutomationCustomerData {
  email: string;
  firstName: string;
  lastName: string;
  agentName: string;
  destinations: string[];
  holidayTypes: string[];
  numberOfAdults: number;
  numberOfChildren: number;
  budgetPerPerson: string;
  travelMonths: string[];
  travelYear: string;
  enquiryId: number;
}

// Add customer to Mailchimp audience with automation trigger
export async function triggerEnquiryConfirmation(customerData: AutomationCustomerData) {
  try {
    console.log('🚀 triggerEnquiryConfirmation called for:', customerData.email);
    console.log('🔧 USE_MAILCHIMP_AUTOMATIONS:', USE_MAILCHIMP_AUTOMATIONS);
    
    if (!USE_MAILCHIMP_AUTOMATIONS) {
      console.log('Mailchimp automations disabled - using current system');
      return false;
    }

    const apiKey = process.env.MAILCHIMP_MARKETING_API_KEY;
    const serverPrefix = process.env.MAILCHIMP_SERVER_PREFIX;
    const audienceId = '0534ef6593'; // Your existing audience ID

    if (!apiKey || !serverPrefix) {
      throw new Error('Mailchimp API configuration missing');
    }

    // Create the MD5 hash of email for member ID
    const crypto = await import('crypto');
    const emailHash = crypto.createHash('md5').update(customerData.email.toLowerCase()).digest('hex');

    // Prepare customer data with custom fields using 10-character tags
    const memberData = {
      email_address: customerData.email,
      status: 'subscribed',
      merge_fields: {
        FNAME: customerData.firstName,
        LNAME: customerData.lastName,
        AGENTNAME: customerData.agentName,
        DESTINS: customerData.destinations.join(', '),
        HOLIDAYS: customerData.holidayTypes.join(', '),
        ADULTS: customerData.numberOfAdults,
        CHILDREN: customerData.numberOfChildren,
        BUDGET: customerData.budgetPerPerson,
        MONTHS: customerData.travelMonths.join(', '),
        YEAR: customerData.travelYear,
        ENQUIRYID: customerData.enquiryId
      },
      tags: [
        'enquiry-submitted', // This triggers the automation
        `enquiry-${customerData.enquiryId}`,
        `agent-${customerData.agentName.toLowerCase().replace(/\s+/g, '-')}`,
        ...customerData.destinations.map(dest => `destination-${dest.toLowerCase().replace(/\s+/g, '-')}`),
        ...customerData.holidayTypes.map(type => `holiday-${type.toLowerCase().replace(/\s+/g, '-')}`)
      ]
    };

    // Debug logging
    console.log('🔍 Automation API call details:');
    console.log('Audience ID:', audienceId);
    console.log('Email hash:', emailHash);

    // First, add or update member in Mailchimp audience (without tags to avoid overwriting)
    const memberDataWithoutTags = {
      email_address: customerData.email,
      status: 'subscribed',
      merge_fields: {
        FNAME: customerData.firstName,
        LNAME: customerData.lastName,
        AGENTNAME: customerData.agentName,
        DESTINS: customerData.destinations.join(', '),
        HOLIDAYS: customerData.holidayTypes.join(', '),
        ADULTS: customerData.numberOfAdults,
        CHILDREN: customerData.numberOfChildren,
        BUDGET: customerData.budgetPerPerson,
        MONTHS: customerData.travelMonths.join(', '),
        YEAR: customerData.travelYear,
        ENQUIRYID: customerData.enquiryId
      }
    };

    const memberResponse = await fetch(`https://${serverPrefix}.api.mailchimp.com/3.0/lists/${audienceId}/members/${emailHash}`, {
      method: 'PUT',
      headers: {
        'Authorization': `apikey ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(memberDataWithoutTags)
    });

    if (!memberResponse.ok) {
      const errorData = await memberResponse.text();
      console.error('❌ Mailchimp Member Update Error:');
      console.error('Status:', memberResponse.status);
      console.error('Response:', errorData);
      throw new Error(`Mailchimp member update failed: ${memberResponse.status} - ${errorData}`);
    }

    // Get existing member data to preserve existing tags
    const existingMemberResponse = await fetch(`https://${serverPrefix}.api.mailchimp.com/3.0/lists/${audienceId}/members/${emailHash}`, {
      headers: {
        'Authorization': `apikey ${apiKey}`,
        'Content-Type': 'application/json',
      }
    });

    let existingTags = [];
    if (existingMemberResponse.ok) {
      const existingMember = await existingMemberResponse.json();
      existingTags = existingMember.tags || [];
      console.log('🔍 Existing member has', existingTags.length, 'tags');
      console.log('🏷️ First 10 existing tags:', existingTags.map((t: any) => t.name).slice(0, 10).join(', ') + (existingTags.length > 10 ? '...' : ''));
    }

    // Prepare automation tags
    const automationTags = [
      'enquiry-submitted', // This triggers the automation
      `enquiry-${customerData.enquiryId}`,
      `agent-${customerData.agentName.toLowerCase().replace(/\s+/g, '-')}`,
      ...customerData.destinations.map(dest => `destination-${dest.toLowerCase().replace(/\s+/g, '-')}`),
      ...customerData.holidayTypes.map(type => `holiday-${type.toLowerCase().replace(/\s+/g, '-')}`)
    ];

    // Check if member already has the enquiry-submitted trigger tag
    const existingTagNames = existingTags.map((t: any) => t.name);
    const hasEnquirySubmittedTag = existingTagNames.includes('enquiry-submitted');
    
    console.log('🏷️ Adding automation tags:', automationTags.join(', '));
    console.log('🔍 Member already has enquiry-submitted tag:', hasEnquirySubmittedTag);
    console.log('🔍 DEBUG - Existing tag names:', existingTagNames.slice(0, 10).join(', '));
    
    // For repeat customers: temporarily remove enquiry-submitted tag, then add it back to trigger automation
    if (hasEnquirySubmittedTag) {
      console.log('🔄 Repeat customer detected - removing trigger tag first to force automation');
      
      // Step 1: Remove the enquiry-submitted tag temporarily
      const tagsWithoutTrigger = existingTagNames.filter((name: string) => name !== 'enquiry-submitted');
      const tempMemberData = {
        email_address: customerData.email,
        status: 'subscribed',
        merge_fields: {
          FNAME: customerData.firstName,
          LNAME: customerData.lastName,
          AGENTNAME: customerData.agentName,
          DESTINS: customerData.destinations.join(', '),
          HOLIDAYS: customerData.holidayTypes.join(', '),
          ADULTS: customerData.numberOfAdults,
          CHILDREN: customerData.numberOfChildren,
          BUDGET: customerData.budgetPerPerson,
          MONTHS: customerData.travelMonths.join(', '),
          YEAR: customerData.travelYear,
          ENQUIRYID: customerData.enquiryId
        },
        tags: tagsWithoutTrigger
      };

      const tempResponse = await fetch(`https://${serverPrefix}.api.mailchimp.com/3.0/lists/${audienceId}/members/${emailHash}`, {
        method: 'PUT',
        headers: {
          'Authorization': `apikey ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(tempMemberData)
      });

      if (tempResponse.ok) {
        console.log('✅ Temporarily removed enquiry-submitted tag');
        // Wait a moment before re-adding
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }

    // Calculate final tag list correctly based on whether this is a repeat customer
    let finalTagList;
    if (hasEnquirySubmittedTag) {
      // For repeat customers: use original tags minus enquiry-submitted, then add all automation tags
      const tagsWithoutTrigger = existingTagNames.filter((name: string) => name !== 'enquiry-submitted');
      finalTagList = Array.from(new Set([...tagsWithoutTrigger, ...automationTags]));
      console.log('🔍 Repeat customer - tags after removal + addition:', finalTagList.length, '(started with', existingTagNames.length, ')');
    } else {
      // For new customers: combine existing tags with new automation tags
      finalTagList = Array.from(new Set([...existingTagNames, ...automationTags]));
      console.log('📊 New customer - total tags after addition:', finalTagList.length);
    }

    // Update member with combined tags using PUT request (which should work reliably)
    const finalMemberData = {
      email_address: customerData.email,
      status: 'subscribed',
      merge_fields: {
        FNAME: customerData.firstName,
        LNAME: customerData.lastName,
        AGENTNAME: customerData.agentName,
        DESTINS: customerData.destinations.join(', '),
        HOLIDAYS: customerData.holidayTypes.join(', '),
        ADULTS: customerData.numberOfAdults,
        CHILDREN: customerData.numberOfChildren,
        BUDGET: customerData.budgetPerPerson,
        MONTHS: customerData.travelMonths.join(', '),
        YEAR: customerData.travelYear,
        ENQUIRYID: customerData.enquiryId
      },
      tags: finalTagList.map(tagName => tagName) // Simple array format
    };

    const finalResponse = await fetch(`https://${serverPrefix}.api.mailchimp.com/3.0/lists/${audienceId}/members/${emailHash}`, {
      method: 'PUT',
      headers: {
        'Authorization': `apikey ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(finalMemberData)
    });

    if (!finalResponse.ok) {
      const finalErrorData = await finalResponse.text();
      console.error('❌ Mailchimp Final Update Error:');
      console.error('Status:', finalResponse.status);  
      console.error('Response:', finalErrorData);
      throw new Error(`Mailchimp final update failed: ${finalResponse.status} - ${finalErrorData}`);
    }

    const finalResult = await finalResponse.json();
    const resultTags = finalResult.tags || [];
    const automationTagsInResult = resultTags.filter((t: any) => automationTags.includes(t.name));
    
    console.log(`✅ Enquiry confirmation automation triggered for ${customerData.email}`);
    console.log(`🏷️ Automation tags in result: ${automationTagsInResult.map((t: any) => t.name).join(', ')}`);
    console.log('📊 Final update status:', finalResponse.status);
    
    // Schedule review request automation trigger
    await scheduleReviewRequestAutomation(customerData, 7); // 7 days (or 1 minute for testing)
    
    // Schedule automatic cleanup of trigger tags after 2 minutes
    await scheduleAutomationTagCleanup(customerData.email, 2);
    
    return true;
  } catch (error) {
    console.error('Error triggering enquiry confirmation automation:', error);
    return false;
  }
}

// Schedule review request automation trigger using database persistence
export async function scheduleReviewRequestAutomation(customerData: AutomationCustomerData, delayDays: number = 7) {
  try {
    if (!USE_MAILCHIMP_AUTOMATIONS) {
      return false;
    }

    // For testing, use 1 minute delay
    const delayMs = process.env.NODE_ENV === 'development' ? 60000 : delayDays * 24 * 60 * 60 * 1000;
    const scheduledFor = new Date(Date.now() + delayMs);
    
    // Store the review request task in database for persistence
    const { db } = await import('./db');
    const { automationSchedules } = await import('@shared/schema');
    
    await db.insert(automationSchedules).values({
      email: customerData.email,
      tagName: 'review-request-due',
      actionType: 'add',
      scheduledFor,
      completed: false,
      enquiryId: customerData.enquiryId,
      customerData: customerData as any
    });

    console.log(`📅 Persistent review request scheduled for enquiry ${customerData.enquiryId} at ${scheduledFor.toISOString()}`);
    return true;
  } catch (error) {
    console.error('Error scheduling persistent review request automation:', error);
    return false;
  }
}

// Add review request tag to trigger automation with repeat customer handling
async function addReviewRequestTag(customerData: AutomationCustomerData) {
  try {
    const apiKey = process.env.MAILCHIMP_MARKETING_API_KEY;
    const serverPrefix = process.env.MAILCHIMP_SERVER_PREFIX;
    const audienceId = '0534ef6593'; // Your existing audience ID

    const crypto = await import('crypto');
    const emailHash = crypto.createHash('md5').update(customerData.email.toLowerCase()).digest('hex');

    console.log('🔍 Review request automation for:', customerData.email);

    // Get existing member data to check for review-request-due tag
    const existingMemberResponse = await fetch(`https://${serverPrefix}.api.mailchimp.com/3.0/lists/${audienceId}/members/${emailHash}`, {
      headers: {
        'Authorization': `apikey ${apiKey}`,
        'Content-Type': 'application/json',
      }
    });

    let existingTags = [];
    if (existingMemberResponse.ok) {
      const existingMember = await existingMemberResponse.json();
      existingTags = existingMember.tags || [];
      console.log('🔍 Member has', existingTags.length, 'tags for review request');
    }

    // Check if member already has the review-request-due trigger tag
    const existingTagNames = existingTags.map((t: any) => t.name);
    const hasReviewRequestTag = existingTagNames.includes('review-request-due');
    
    console.log('🔍 Member already has review-request-due tag:', hasReviewRequestTag);

    // For repeat customers: temporarily remove review-request-due tag, then add it back to trigger automation
    if (hasReviewRequestTag) {
      console.log('🔄 Repeat customer detected for review - removing trigger tag first');
      
      // Remove the review-request-due tag temporarily using proper member update
      const tagsWithoutReviewTrigger = existingTagNames.filter((name: string) => name !== 'review-request-due');
      const tempMemberData = {
        email_address: customerData.email,
        status: 'subscribed',
        merge_fields: {
          FNAME: customerData.firstName,
          LNAME: customerData.lastName,
          AGENTNAME: customerData.agentName
        },
        tags: tagsWithoutReviewTrigger
      };

      const tempResponse = await fetch(`https://${serverPrefix}.api.mailchimp.com/3.0/lists/${audienceId}/members/${emailHash}`, {
        method: 'PUT',
        headers: {
          'Authorization': `apikey ${apiKey}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(tempMemberData)
      });

      if (tempResponse.ok) {
        console.log('✅ Temporarily removed review-request-due tag');
        // Wait a moment before re-adding
        await new Promise(resolve => setTimeout(resolve, 1000));
      }
    }

    // Add review-request-due tag to trigger automation
    const tagData = {
      tags: [
        {
          name: 'review-request-due',
          status: 'active'
        }
      ]
    };

    const response = await fetch(`https://${serverPrefix}.api.mailchimp.com/3.0/lists/${audienceId}/members/${emailHash}/tags`, {
      method: 'POST',
      headers: {
        'Authorization': `apikey ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(tagData)
    });

    if (response.ok) {
      console.log(`✅ Review request automation triggered for enquiry ${customerData.enquiryId}`);
      if (hasReviewRequestTag) {
        console.log('🎯 Tag refresh completed for repeat customer - review automation should fire');
      }
      
      // Schedule cleanup of review-request-due tag after 2 minutes (separate from enquiry cleanup)
      setTimeout(async () => {
        await cleanupAutomationTag(customerData.email, 'review-request-due');
      }, 2 * 60 * 1000); // 2 minutes
      
    } else {
      console.error('Failed to add review request tag:', await response.text());
    }
  } catch (error) {
    console.error('Error adding review request tag:', error);
  }
}

// Trigger agent welcome automation when agent is approved
export async function triggerAgentWelcomeAutomation(agentEmail: string, agentName: string) {
  try {
    if (!USE_MAILCHIMP_AUTOMATIONS) {
      return false;
    }

    const apiKey = process.env.MAILCHIMP_MARKETING_API_KEY;
    const serverPrefix = process.env.MAILCHIMP_SERVER_PREFIX;
    const audienceId = '0534ef6593'; // Your existing audience ID

    const crypto = await import('crypto');
    const emailHash = crypto.createHash('md5').update(agentEmail.toLowerCase()).digest('hex');

    // Add agent to audience with agent-approved tag
    const memberData = {
      email_address: agentEmail,
      status: 'subscribed',
      merge_fields: {
        FNAME: agentName.split(' ')[0],
        LNAME: agentName.split(' ').slice(1).join(' '),
        AGENTNAME: agentName
      },
      tags: [
        'agent',
        'agent-approved' // This triggers the agent welcome automation
      ]
    };

    const response = await fetch(`https://${serverPrefix}.api.mailchimp.com/3.0/lists/${audienceId}/members/${emailHash}`, {
      method: 'PUT',
      headers: {
        'Authorization': `apikey ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(memberData)
    });

    if (response.ok) {
      console.log(`✅ Agent welcome automation triggered for ${agentEmail}`);
      return true;
    } else {
      console.error('Failed to trigger agent welcome automation:', await response.text());
      return false;
    }
  } catch (error) {
    console.error('Error triggering agent welcome automation:', error);
    return false;
  }
}

// Get automation status for admin dashboard
export async function getAutomationStatus() {
  return {
    automationsEnabled: USE_MAILCHIMP_AUTOMATIONS,
    enquiryConfirmationActive: true,
    reviewRequestActive: true,
    agentWelcomeActive: true,
    totalAutomatedEmails: await getTotalAutomatedEmails()
  };
}

// Count total automated emails sent
async function getTotalAutomatedEmails() {
  try {
    const enquiries = await storage.getAllEnquiriesWithAgentNames();
    const confirmationEmails = enquiries.length;
    const reviewEmails = Math.floor(enquiries.length * 0.4); // Estimate
    return confirmationEmails + reviewEmails;
  } catch (error) {
    return 0;
  }
}

// Schedule automatic cleanup of automation trigger tags using database persistence
async function scheduleAutomationTagCleanup(email: string, delayMinutes: number = 2) {
  try {
    if (!USE_MAILCHIMP_AUTOMATIONS) {
      return false;
    }

    const scheduledFor = new Date(Date.now() + (delayMinutes * 60 * 1000));
    
    // Store the cleanup task in database for persistence across server restarts
    const { db } = await import('./db');
    const { automationSchedules } = await import('@shared/schema');
    
    await db.insert(automationSchedules).values({
      email,
      tagName: 'enquiry-submitted',
      actionType: 'remove',
      scheduledFor,
      completed: false
    });

    console.log(`🧹 Persistent cleanup scheduled for ${email} at ${scheduledFor.toISOString()}`);
    return true;
  } catch (error) {
    console.error('Error scheduling persistent automation tag cleanup:', error);
    return false;
  }
}

// Remove specific automation trigger tag from customer
async function cleanupAutomationTag(email: string, tagToRemove: string) {
  try {
    const apiKey = process.env.MAILCHIMP_MARKETING_API_KEY;
    const serverPrefix = process.env.MAILCHIMP_SERVER_PREFIX;
    const audienceId = '0534ef6593';

    if (!apiKey || !serverPrefix) {
      console.error('Mailchimp API configuration missing for cleanup');
      return false;
    }

    const crypto = await import('crypto');
    const emailHash = crypto.createHash('md5').update(email.toLowerCase()).digest('hex');

    console.log(`🧹 Cleaning up ${tagToRemove} tag for: ${email}`);

    // Get existing member data
    const existingMemberResponse = await fetch(`https://${serverPrefix}.api.mailchimp.com/3.0/lists/${audienceId}/members/${emailHash}`, {
      headers: {
        'Authorization': `apikey ${apiKey}`,
        'Content-Type': 'application/json',
      }
    });

    if (!existingMemberResponse.ok) {
      console.error(`❌ Could not fetch member ${email} for cleanup`);
      return false;
    }

    const existingMember = await existingMemberResponse.json();
    const existingTags = existingMember.tags || [];
    const existingTagNames = existingTags.map((t: any) => t.name);

    // Check if the tag exists
    if (!existingTagNames.includes(tagToRemove)) {
      console.log(`ℹ️ Tag ${tagToRemove} not found on ${email} - no cleanup needed`);
      return true;
    }

    // Use proper Mailchimp tag removal endpoint
    const tagData = {
      tags: [
        {
          name: tagToRemove,
          status: 'inactive' // This removes the tag
        }
      ]
    };

    const cleanupResponse = await fetch(`https://${serverPrefix}.api.mailchimp.com/3.0/lists/${audienceId}/members/${emailHash}/tags`, {
      method: 'POST',
      headers: {
        'Authorization': `apikey ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(tagData)
    });

    if (cleanupResponse.ok || cleanupResponse.status === 204) {
      console.log(`✅ Successfully removed ${tagToRemove} tag from ${email}`);
      
      // Verify removal by checking updated member data
      const verifyResponse = await fetch(`https://${serverPrefix}.api.mailchimp.com/3.0/lists/${audienceId}/members/${emailHash}`, {
        headers: {
          'Authorization': `apikey ${apiKey}`,
          'Content-Type': 'application/json',
        }
      });
      
      if (verifyResponse.ok) {
        const updatedMember = await verifyResponse.json();
        const updatedTags = updatedMember.tags || [];
        const tagStillExists = updatedTags.find((t: any) => t.name === tagToRemove);
        
        if (!tagStillExists) {
          console.log(`🏷️ Confirmed: ${tagToRemove} tag successfully removed (${updatedTags.length} tags remaining)`);
          return true;
        } else {
          console.log(`⚠️ Tag ${tagToRemove} still present after cleanup attempt`);
          return false;
        }
      }
      
      return true;
    } else {
      const errorText = await cleanupResponse.text();
      console.error(`❌ Failed to cleanup ${tagToRemove} tag:`, cleanupResponse.status, errorText);
      return false;
    }

  } catch (error) {
    console.error(`Error cleaning up ${tagToRemove} tag:`, error);
    return false;
  }
}

// Background automation processor - runs every 60 seconds to check for scheduled tasks
export function startAutomationProcessor() {
  const processInterval = 60000; // Check every 60 seconds
  
  const processor = async () => {
    try {
      const { db } = await import('./db');
      const { automationSchedules } = await import('@shared/schema');
      const { lt, eq, and } = await import('drizzle-orm');
      
      // Find tasks that are due and not completed
      const dueTasks = await db.select()
        .from(automationSchedules)
        .where(and(
          lt(automationSchedules.scheduledFor, new Date()),
          eq(automationSchedules.completed, false)
        ));
      
      for (const task of dueTasks) {
        console.log(`⏰ Processing scheduled task: ${task.actionType} ${task.tagName} for ${task.email}`);
        
        let success = false;
        
        if (task.actionType === 'remove' && task.tagName === 'enquiry-submitted') {
          success = await cleanupAutomationTag(task.email, task.tagName);
        } else if (task.actionType === 'add' && task.tagName === 'review-request-due') {
          if (task.customerData) {
            success = await addReviewRequestTag(task.customerData as AutomationCustomerData);
          }
        }
        
        // Mark task as completed
        await db.update(automationSchedules)
          .set({ completed: true })
          .where(eq(automationSchedules.id, task.id));
          
        if (success) {
          console.log(`✅ Automation task ${task.id} completed successfully`);
        } else {
          console.log(`❌ Automation task ${task.id} failed but marked as completed`);
        }
      }
      
    } catch (error) {
      console.error('Error in automation processor:', error);
    }
  };
  
  // Process immediately and then every interval
  processor();
  setInterval(processor, processInterval);
  
  console.log('🤖 Automation processor started - checking every 60 seconds for scheduled tasks');
}

// Fix current customer's issue by manually executing missed automations
export async function fixMissedAutomations() {
  const testEmail = 'evandesmond@hotmail.co.uk';
  console.log('🔧 EMERGENCY FIX: Executing missed automations for', testEmail);
  
  // Check current customer data first
  const customerData: AutomationCustomerData = {
    email: testEmail,
    firstName: 'Evan',
    lastName: 'Desmond',
    agentName: 'Evan Desmond',
    destinations: ['Argentina', 'Abu Dhabi', 'Antigua & Barbuda'],
    holidayTypes: ['Beach Holidays'],
    numberOfAdults: 2,
    numberOfChildren: 0,
    budgetPerPerson: '£2,500 - £5,000 per person',
    travelMonths: ['March'],
    travelYear: 2025,
    enquiryId: 238
  };
  
  // 1. Clean up the enquiry-submitted tag that should have been removed
  console.log('1. Removing stuck enquiry-submitted tag...');
  await cleanupAutomationTag(testEmail, 'enquiry-submitted');
  
  // 2. Add the review-request-due tag that was never added
  console.log('2. Adding missing review-request-due tag...');
  await addReviewRequestTag(customerData);
  
  console.log('✅ Emergency fix completed');
}

export { USE_MAILCHIMP_AUTOMATIONS };