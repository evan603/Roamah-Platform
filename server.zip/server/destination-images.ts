// Comprehensive image database for destinations
// All images are optimized for 24rem height (384px) rectangular format
// Selected for iconic, recognizable landmarks and scenery

export const DESTINATION_IMAGES = {
  // Indian Ocean - Tropical paradise with overwater bungalows and crystal waters
  "maldives": "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?w=800&h=600&fit=crop&crop=center",
  "mauritius": "https://images.unsplash.com/photo-1551698618-1dfe5d97d256?w=800&h=600&fit=crop&crop=center", 
  "seychelles": "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&h=600&fit=crop&crop=center",
  "sri-lanka": "https://images.unsplash.com/photo-1566552881560-0be862a7c445?w=800&h=600&fit=crop&crop=center",

  // Middle East - Modern skylines and architectural marvels
  "dubai": "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=800&h=600&fit=crop&crop=center",
  "abu-dhabi": "https://images.unsplash.com/photo-1512632578888-169bbbc64f33?w=800&h=600&fit=crop&crop=center",
  "oman": "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=600&fit=crop&crop=center",
  "ras-al-khaimah": "https://images.unsplash.com/photo-1580674684081-7617fbf3d745?w=800&h=600&fit=crop&crop=center",
  "qatar": "https://images.unsplash.com/photo-1591608971362-f08b2a75731a?w=800&h=600&fit=crop&crop=center", // Qatar modern Doha skyline

  // Mediterranean & Europe - Historic architecture and coastal beauty
  "greece": "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?w=800&h=600&fit=crop&crop=center",
  "spain": "https://images.unsplash.com/photo-1543783207-ec64e4d95325?w=800&h=600&fit=crop&crop=center", 
  "cyprus": "https://images.unsplash.com/photo-1580837119756-563d608dd119?w=800&h=600&fit=crop&crop=center",
  "portugal": "https://images.unsplash.com/photo-1555881400-74d7acaacd8b?w=800&h=600&fit=crop&crop=center",
  "turkey": "https://images.unsplash.com/photo-1541432901042-2d8bd64b4a9b?w=800&h=600&fit=crop&crop=center",
  "italy": "https://images.unsplash.com/photo-1515542622106-78bda8ba0e5b?w=800&h=600&fit=crop&crop=center",
  "france": "https://images.unsplash.com/photo-1549144511-f099e773c147?w=800&h=600&fit=crop&crop=center", // France Eiffel Tower
  "croatia": "https://images.unsplash.com/photo-1467269204594-9661b134dd2b?w=800&h=600&fit=crop&crop=center",
  "malta": "https://images.unsplash.com/photo-1580837119756-563d608dd119?w=800&h=600&fit=crop&crop=center", // Malta coastal architecture
  "santorini": "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?w=800&h=600&fit=crop&crop=center",

  // Northern Europe - Fjords, aurora, and historic cities
  "iceland": "https://images.unsplash.com/photo-1531366936337-7c912a4589a7?w=800&h=600&fit=crop&crop=center",
  "norway": "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&h=600&fit=crop&crop=center",
  "sweden": "https://images.unsplash.com/photo-1509356843151-3e7d96241e11?w=800&h=600&fit=crop&crop=center",
  "finland": "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=600&fit=crop&crop=center", // Finland Northern Lights
  "lapland": "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=600&fit=crop&crop=center", // Lapland aurora

  // Asia Pacific - Temples, modern cities, and tropical islands
  "japan": "https://images.unsplash.com/photo-1528164344705-47542687000d?w=800&h=600&fit=crop&crop=center",
  "thailand": "https://images.unsplash.com/photo-1552465011-b4e21bf6e79a?w=800&h=600&fit=crop&crop=center",
  "singapore": "https://images.unsplash.com/photo-1525625293386-3f8f99389edd?w=800&h=600&fit=crop&crop=center",
  "bali": "https://images.unsplash.com/photo-1537953773345-d172ccf13cf1?w=800&h=600&fit=crop&crop=center",
  "vietnam": "https://images.unsplash.com/photo-1509023464722-18d996393ca8?w=800&h=600&fit=crop&crop=center",
  "china": "https://images.unsplash.com/photo-1508804185872-d7badad00f7d?w=800&h=600&fit=crop&crop=center",
  "malaysia": "https://images.unsplash.com/photo-1596422846543-75c6fc197f07?w=800&h=600&fit=crop&crop=center",
  "cambodia": "https://images.unsplash.com/photo-1596422846543-75c6fc197f07?w=800&h=600&fit=crop&crop=center", // Cambodia Angkor Wat
  "south-korea": "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=800&h=600&fit=crop&crop=center",

  // Oceania - Pristine beaches and natural wonders
  "australia": "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop&crop=center",
  "new-zealand": "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&h=600&fit=crop&crop=center",
  "fiji": "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&h=600&fit=crop&crop=center",
  "bora-bora": "https://images.unsplash.com/photo-1514282401047-d79a71a590e8?w=800&h=600&fit=crop&crop=center",

  // Africa - Safaris and diverse landscapes
  "south-africa": "https://images.unsplash.com/photo-1516426122078-c23e76319801?w=800&h=600&fit=crop&crop=center", // South Africa wildlife safari
  "kenya": "https://images.unsplash.com/photo-1516426122078-c23e76319801?w=800&h=600&fit=crop&crop=center",
  "tanzania-zanzibar": "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=800&h=600&fit=crop&crop=center",
  "morocco": "https://images.unsplash.com/photo-1539650116574-75c0c6d4d9b9?w=800&h=600&fit=crop&crop=center", // Morocco architecture
  "egypt": "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=600&fit=crop&crop=center", // Egypt pyramids
  "tunisia": "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=600&fit=crop&crop=center",
  "botswana": "https://images.unsplash.com/photo-1516426122078-c23e76319801?w=800&h=600&fit=crop&crop=center",

  // Americas - Diverse landscapes from ice to tropics
  "usa": "https://images.unsplash.com/photo-1485738422979-f5c462d49f74?w=800&h=600&fit=crop&crop=center",
  "canada": "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&h=600&fit=crop&crop=center",
  "hawaii": "https://images.unsplash.com/photo-1598135753163-6167c1a1ad65?w=800&h=600&fit=crop&crop=center",
  "alaska": "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=600&fit=crop&crop=center",
  "costa-rica": "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&h=600&fit=crop&crop=center",
  "brazil": "https://images.unsplash.com/photo-1483729558449-99ef09a8c325?w=800&h=600&fit=crop&crop=center",
  "argentina": "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&h=600&fit=crop&crop=center",
  "chile": "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&h=600&fit=crop&crop=center",
  "peru": "https://images.unsplash.com/photo-1526392060635-9d6019884377?w=800&h=600&fit=crop&crop=center",
  "colombia": "https://images.unsplash.com/photo-1483729558449-99ef09a8c325?w=800&h=600&fit=crop&crop=center",
  "patagonia": "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&h=600&fit=crop&crop=center",

  // Caribbean - Tropical paradises with specific iconic imagery
  "caribbean": "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop&crop=center",
  "barbados": "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&h=600&fit=crop&crop=center", // Barbados beaches
  "jamaica": "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&h=600&fit=crop&crop=center", // Jamaica coastline
  "mexico": "https://images.unsplash.com/photo-1518638150340-f706e86654de?w=800&h=600&fit=crop&crop=center", // Mexico ancient ruins
  "dominican-republic": "https://images.unsplash.com/photo-1580837119756-563d608dd119?w=800&h=600&fit=crop&crop=center", // DR beaches
  "bermuda": "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&h=600&fit=crop&crop=center", // Bermuda pink sand beaches
  "saint-lucia": "https://images.unsplash.com/photo-1590523277543-a94d2e4eb00b?w=800&h=600&fit=crop&crop=center", // Saint Lucia Pitons
  "grenada": "https://images.unsplash.com/photo-1588668214407-6ea9a6d8c272?w=800&h=600&fit=crop&crop=center", // Grenada spice island
  "antigua-and-barbuda": "https://images.unsplash.com/photo-1559827260-dc66d52bef19?w=800&h=600&fit=crop&crop=center", // Antigua beaches
  "anguilla": "https://images.unsplash.com/photo-1580837119756-563d608dd119?w=800&h=600&fit=crop&crop=center", // Anguilla pristine beaches
  "turks-and-caicos": "https://images.unsplash.com/photo-1571019613454-1cb2f99b2d8b?w=800&h=600&fit=crop&crop=center", // Turks crystal waters
  "bahamas": "https://images.unsplash.com/photo-1586500036706-41963de24d8b?w=800&h=600&fit=crop&crop=center", // Bahamas crystal waters

  // Mountain & Adventure regions
  "alps": "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&h=600&fit=crop&crop=center",
  "himalayas": "https://images.unsplash.com/photo-1526392060635-9d6019884377?w=800&h=600&fit=crop&crop=center",
  "nepal": "https://images.unsplash.com/photo-1526392060635-9d6019884377?w=800&h=600&fit=crop&crop=center",
  "bhutan": "https://images.unsplash.com/photo-1526392060635-9d6019884377?w=800&h=600&fit=crop&crop=center",
  "tibet": "https://images.unsplash.com/photo-1526392060635-9d6019884377?w=800&h=600&fit=crop&crop=center",

  // Indian Subcontinent
  "india": "https://images.unsplash.com/photo-1524492412937-b28074a5d7da?w=800&h=600&fit=crop&crop=center",

  // Eastern Europe
  "czech-republic": "https://images.unsplash.com/photo-1539650116574-75c0c6d4d9b9?w=800&h=600&fit=crop&crop=center",
  "montenegro": "https://images.unsplash.com/photo-1467269204594-9661b134dd2b?w=800&h=600&fit=crop&crop=center",

  // Special regions
  "antarctica": "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=600&fit=crop&crop=center",
  "greenland": "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=600&fit=crop&crop=center",
  "svalbard": "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=600&fit=crop&crop=center",

  // General regions
  "europe": "https://images.unsplash.com/photo-1515542622106-78bda8ba0e5b?w=800&h=600&fit=crop&crop=center",
  "asia": "https://images.unsplash.com/photo-1528164344705-47542687000d?w=800&h=600&fit=crop&crop=center",
  "southeast-asia": "https://images.unsplash.com/photo-1537953773345-d172ccf13cf1?w=800&h=600&fit=crop&crop=center",
  "east-asia": "https://images.unsplash.com/photo-1528164344705-47542687000d?w=800&h=600&fit=crop&crop=center",
  "central-america": "https://images.unsplash.com/photo-1544551763-46a013bb70d5?w=800&h=600&fit=crop&crop=center",
  "south-america": "https://images.unsplash.com/photo-1483729558449-99ef09a8c325?w=800&h=600&fit=crop&crop=center",
  "east-africa": "https://images.unsplash.com/photo-1516426122078-c23e76319801?w=800&h=600&fit=crop&crop=center",
  "mediterranean": "https://images.unsplash.com/photo-1613395877344-13d4a8e0d49e?w=800&h=600&fit=crop&crop=center",
  "baltic": "https://images.unsplash.com/photo-1509356843151-3e7d96241e11?w=800&h=600&fit=crop&crop=center",
  "oceania": "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop&crop=center",

  // Additional destinations
  "switzerland": "https://images.unsplash.com/photo-1469474968028-56623f02e42e?w=800&h=600&fit=crop&crop=center",
  "belgium": "https://images.unsplash.com/photo-1539650116574-75c0c6d4d9b9?w=800&h=600&fit=crop&crop=center",
  "jordan": "https://images.unsplash.com/photo-1578662996442-48f60103fc96?w=800&h=600&fit=crop&crop=center",
  "uae": "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=800&h=600&fit=crop&crop=center",
  "eastern-europe": "https://images.unsplash.com/photo-1539650116574-75c0c6d4d9b9?w=800&h=600&fit=crop&crop=center"
};

// Function to get optimized image for destination
export function getDestinationImage(slug: string): string {
  return DESTINATION_IMAGES[slug as keyof typeof DESTINATION_IMAGES] || 
         "https://images.unsplash.com/photo-1506905925346-21bda4d32df4?w=800&h=600&fit=crop&crop=center"; // Default fallback
}