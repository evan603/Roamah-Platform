import crypto from 'crypto';

if (!process.env.MAILCHIMP_API_KEY) {
  throw new Error("MAILCHIMP_API_KEY environment variable must be set for Mailchimp Transactional Email");
}

if (!process.env.MAILCHIMP_MARKETING_API_KEY) {
  console.warn("MAILCHIMP_MARKETING_API_KEY not set - audience integration disabled");
}

// Mailchimp Transactional Email (formerly Mandrill) API configuration
const TRANSACTIONAL_API_BASE = "https://mandrillapp.com/api/1.0";
const TRANSACTIONAL_API_KEY = process.env.MAILCHIMP_API_KEY;

// Mailchimp Marketing API configuration
const MARKETING_API_KEY = process.env.MAILCHIMP_MARKETING_API_KEY;
const MARKETING_API_BASE = `https://${process.env.MAILCHIMP_SERVER_PREFIX}.api.mailchimp.com/3.0`;
const AUDIENCE_ID = "0534ef6593";

// Helper function to make Transactional API requests
async function makeTransactionalRequest(endpoint: string, data: any): Promise<any> {
  try {
    const response = await fetch(`${TRANSACTIONAL_API_BASE}/${endpoint}`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        key: TRANSACTIONAL_API_KEY,
        ...data
      })
    });

    if (!response.ok) {
      throw new Error(`HTTP ${response.status}: ${response.statusText}`);
    }

    return await response.json();
  } catch (error) {
    console.error(`Transactional API error for ${endpoint}:`, error);
    throw error;
  }
}

interface CustomerData {
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber?: string;
  budgetPerPerson: string;
  destinations: string[];
  holidayTypes: string[];
  numberOfAdults: number;
  numberOfChildren: number;
  travelMonths?: string[];
  travelYear?: string;
  agentId: number;
  agentName?: string;
  enquiryId: number;
}

interface ReviewRequestData {
  customerName: string;
  customerEmail: string;
  agentName: string;
  agentId: number;
  enquiryId: number;
  tripType: string;
}

// Budget segmentation mapping
function getBudgetSegment(budgetPerPerson: string): string {
  // Extract all numbers from budget string
  const numbers = budgetPerPerson.match(/[\d,]+/g)?.map(num => parseInt(num.replace(/,/g, ''))) || [];
  const maxBudget = Math.max(...numbers);
  
  // Classify based on maximum budget amount
  if (maxBudget < 1500) return 'budget';
  if (maxBudget >= 1500 && maxBudget < 3000) return 'mid-range';
  if (maxBudget >= 3000 && maxBudget < 6000) return 'premium';
  if (maxBudget >= 6000) return 'luxury';
  
  // Fallback to text-based classification
  const budget = budgetPerPerson.toLowerCase();
  if (budget.includes('under') || budget.includes('budget')) return 'budget';
  if (budget.includes('luxury') || budget.includes('no limit')) return 'luxury';
  return 'unspecified';
}

// Test API connection
async function testConnection(): Promise<boolean> {
  try {
    const result = await makeTransactionalRequest('users/ping', {});
    return result === "PONG!";
  } catch (error) {
    console.error("Failed to connect to Mailchimp Transactional API:", error);
    return false;
  }
}

// Helper function to make Marketing API requests
async function makeMarketingRequest(endpoint: string, method: string = 'GET', data?: any): Promise<any> {
  try {
    // Mailchimp Marketing API uses Basic Auth with API key as username and 'anystring' as password
    const authString = Buffer.from(`anystring:${MARKETING_API_KEY}`).toString('base64');
    
    const response = await fetch(`${MARKETING_API_BASE}/${endpoint}`, {
      method,
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Basic ${authString}`,
      },
      body: data ? JSON.stringify(data) : undefined
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error(`Marketing API ${response.status} error:`, errorText);
      throw new Error(`HTTP ${response.status}: ${response.statusText} - ${errorText}`);
    }

    // Handle empty responses (like tag operations that return 204 No Content)
    const contentLength = response.headers.get('content-length');
    if (contentLength === '0' || response.status === 204) {
      return {}; // Return empty object for successful operations with no content
    }

    const responseText = await response.text();
    if (!responseText) {
      return {}; // Return empty object if response is empty
    }

    return JSON.parse(responseText);
  } catch (error) {
    console.error(`Marketing API error for ${endpoint}:`, error);
    throw error;
  }
}

// Add customer to audience using both Transactional Email AND Marketing API
export async function addCustomerToAudience(customerData: CustomerData): Promise<boolean> {
  try {
    // Test Transactional API connection first
    const isConnected = await testConnection();
    if (!isConnected) {
      console.error("Mailchimp Transactional API connection failed");
      return false;
    }

    console.log("✅ Mailchimp Transactional API connected successfully");
    
    // Confirmation email is now sent via the main enquiry system with custom template
    // await triggerEnquiryFollowUp(customerData); // REMOVED - duplicate email
    
    // Add to main Mailchimp audience with full customer data
    await addToMainAudience(customerData);
    
    return true;
  } catch (error) {
    console.error("Error in customer audience workflow:", error);
    return false;
  }
}

// Interface for agent data when adding to Mailchimp
interface AgentData {
  firstName: string;
  lastName: string;
  email: string;
  agentId: number;
}

// Add travel agent to Mailchimp audience with "agent" tag
export async function addAgentToAudience(agentData: AgentData): Promise<boolean> {
  try {
    if (!MARKETING_API_KEY) {
      console.log("Marketing API key not available - skipping agent addition to audience");
      return false;
    }

    // Test connection first
    const connectionOk = await testMarketingApiConnection();
    if (!connectionOk) {
      console.error("Marketing API connection failed - aborting agent addition");
      return false;
    }

    console.log(`Adding travel agent ${agentData.firstName} ${agentData.lastName} to Mailchimp audience...`);

    const memberData = {
      email_address: agentData.email,
      status: 'subscribed',
      merge_fields: {
        FNAME: agentData.firstName,
        LNAME: agentData.lastName,
        AGENT_ID: agentData.agentId.toString(),
      } as Record<string, string>
    };

    try {
      // Try to add as new member first  
      const result = await makeMarketingRequest(`lists/${AUDIENCE_ID}/members`, 'POST', memberData);
      console.log(`✅ Agent ${agentData.firstName} ${agentData.lastName} added to Mailchimp audience`);
      
      // Add "agent" tag after member is created - wait a moment for member to be fully created
      setTimeout(async () => {
        try {
          const emailHash = crypto.createHash('md5').update(agentData.email.toLowerCase()).digest('hex');
          const tagData = {
            tags: [{ name: 'agent', status: 'active' }]
          };
          
          await makeMarketingRequest(`lists/${AUDIENCE_ID}/members/${emailHash}/tags`, 'POST', tagData);
          console.log(`✅ "agent" tag added for ${agentData.firstName} ${agentData.lastName}`);
        } catch (tagError: any) {
          console.error(`❌ Failed to add agent tag to ${agentData.email}:`, tagError.message);
        }
      }, 1000); // Wait 1 second before adding tag
      
    } catch (addError: any) {
      if (addError.message.includes('Member Exists')) {
        // Agent already exists, update their profile instead
        console.log(`Agent ${agentData.email} already exists in audience, updating profile...`);
        const emailHash = crypto.createHash('md5').update(agentData.email.toLowerCase()).digest('hex');
        await makeMarketingRequest(`lists/${AUDIENCE_ID}/members/${emailHash}`, 'PUT', memberData);
        console.log(`✅ Agent ${agentData.firstName} ${agentData.lastName} profile updated in Mailchimp audience`);
        
        // Add the agent tag
        setTimeout(async () => {
          try {
            const tagData = {
              tags: [{ name: 'agent', status: 'active' }]
            };
            
            await makeMarketingRequest(`lists/${AUDIENCE_ID}/members/${emailHash}/tags`, 'POST', tagData);
            console.log(`✅ "agent" tag added for existing member ${agentData.firstName} ${agentData.lastName}`);
          } catch (tagError: any) {
            console.error(`❌ Failed to add agent tag to existing member ${agentData.email}:`, tagError.message);
          }
        }, 1000);
      } else {
        throw addError;
      }
    }

    return true;
  } catch (error) {
    console.error("Error adding agent to Mailchimp audience:", error);
    return false;
  }
}

// Test Marketing API connection
async function testMarketingApiConnection(): Promise<boolean> {
  try {
    if (!MARKETING_API_KEY) {
      console.log("Marketing API key not available for testing");
      return false;
    }
    
    console.log("Testing Marketing API connection...");
    console.log("API Key format check:", MARKETING_API_KEY.substring(0, 10) + "...");
    console.log("Server prefix:", process.env.MAILCHIMP_SERVER_PREFIX);
    console.log("Full API URL:", `${MARKETING_API_BASE}/ping`);
    
    const response = await makeMarketingRequest('ping');
    console.log("Marketing API ping successful:", response);
    return true;
  } catch (error) {
    console.error("Marketing API connection test failed:", error);
    return false;
  }
}

// Add customer to main Mailchimp audience with custom fields
async function addToMainAudience(customerData: CustomerData): Promise<void> {
  try {
    if (!MARKETING_API_KEY) {
      console.log("Marketing API key not available - skipping audience addition");
      return;
    }

    // Test connection first
    const connectionOk = await testMarketingApiConnection();
    if (!connectionOk) {
      console.error("Marketing API connection failed - aborting audience addition");
      return;
    }

    const memberData = {
      email_address: customerData.email,
      status: 'subscribed',
      merge_fields: {
        FNAME: customerData.firstName,
        LNAME: customerData.lastName,
        PHONE: customerData.phoneNumber || '',
        BUDGET: customerData.budgetPerPerson,
        ADULTS: customerData.numberOfAdults.toString(),
        CHILDREN: customerData.numberOfChildren.toString(),
        AGENT_ID: customerData.agentId.toString(),
        AGENT_NAME: customerData.agentName || '',
        ENQUIRY_ID: customerData.enquiryId.toString(),
        TRAVEL_YEAR: customerData.travelYear || '',
        TRAVEL_MONTHS: (customerData.travelMonths || []).join(', '),
      } as Record<string, string>
    };

    // Generate tags for customer segmentation - only for data we actually collected
    const memberTags = [];

    // Add destination tags only if destinations were provided
    if (customerData.destinations && customerData.destinations.length > 0) {
      memberTags.push(...customerData.destinations.map(dest => `destination-${dest.toLowerCase().replace(/\s+/g, '-')}`));
    }

    // Add holiday type tags only if holiday types were provided
    if (customerData.holidayTypes && customerData.holidayTypes.length > 0) {
      memberTags.push(...customerData.holidayTypes.map(type => `holiday-${type.toLowerCase().replace(/\s+/g, '-')}`));
    }

    // Add budget tag only if budget was provided and not empty
    if (customerData.budgetPerPerson && customerData.budgetPerPerson.trim()) {
      memberTags.push(`budget-${getBudgetSegment(customerData.budgetPerPerson).toLowerCase()}`);
    }

    // Add agent tag only if agent name was provided (for enquiries, not newsletter signups)
    if (customerData.agentName && customerData.agentName.trim()) {
      memberTags.push(`agent-${customerData.agentName.toLowerCase().replace(/\s+/g, '-')}`);
    }

    // Add travel timing tags only if travel months were provided
    if (customerData.travelMonths && customerData.travelMonths.length > 0) {
      memberTags.push(...customerData.travelMonths.map(month => `travel-${month.toLowerCase()}`));
    }

    // Add year tag ONLY for enquiries where we explicitly collect travel year (not newsletter signups)
    if (customerData.enquiryId > 0 && customerData.travelYear && customerData.travelYear.trim() && customerData.travelYear !== '') {
      memberTags.push(`year-${customerData.travelYear}`);
    }

    // Add family status tag only for enquiries where we have explicit information about number of children
    if (customerData.enquiryId > 0) {
      memberTags.push(customerData.numberOfChildren > 0 ? 'family' : 'couple-or-solo');
    }
    
    console.log(`🏷️ Generated tags for ${customerData.email}:`, memberTags);



    try {
      // Try to add as new member first
      const result = await makeMarketingRequest(`lists/${AUDIENCE_ID}/members`, 'POST', memberData);
      console.log(`✅ Customer ${customerData.email} added to main Mailchimp audience with custom fields`);
      
      // Add tags separately after member is created
      if (memberTags.length > 0) {
        try {
          const crypto = await import('crypto');
          const emailHash = crypto.createHash('md5').update(customerData.email.toLowerCase()).digest('hex');
          const tagPayload = {
            tags: memberTags.map(tag => ({ name: tag, status: 'active' }))
          };
          console.log(`🏷️ Adding tags to ${customerData.email} with payload:`, JSON.stringify(tagPayload, null, 2));
          
          await makeMarketingRequest(`lists/${AUDIENCE_ID}/members/${emailHash}/tags`, 'POST', tagPayload);
          console.log(`✅ Tags successfully added to customer ${customerData.email}: ${memberTags.join(', ')}`);
        } catch (tagError: any) {
          console.error(`❌ Failed to add tags to ${customerData.email}:`, tagError.message);
        }
      }
      
    } catch (addError: any) {
      if (addError.message.includes('Member Exists')) {
        // Customer already exists, update their profile instead
        console.log(`Customer ${customerData.email} already exists, updating profile with new data...`);
        const crypto = await import('crypto');
        const emailHash = crypto.createHash('md5').update(customerData.email.toLowerCase()).digest('hex');
        
        // Update member data
        await makeMarketingRequest(`lists/${AUDIENCE_ID}/members/${emailHash}`, 'PUT', memberData);
        console.log(`✅ Customer ${customerData.email} profile updated in Mailchimp audience with latest custom fields`);
        
        // Update tags for existing member
        if (memberTags.length > 0) {
          try {
            const tagPayload = {
              tags: memberTags.map(tag => ({ name: tag, status: 'active' }))
            };
            console.log(`🏷️ Updating tags for existing customer ${customerData.email} with payload:`, JSON.stringify(tagPayload, null, 2));
            
            await makeMarketingRequest(`lists/${AUDIENCE_ID}/members/${emailHash}/tags`, 'POST', tagPayload);
            console.log(`✅ Tags successfully updated for existing customer ${customerData.email}: ${memberTags.join(', ')}`);
          } catch (tagError: any) {
            console.error(`❌ Failed to update tags for ${customerData.email}:`, tagError.message);
          }
        }
      } else {
        throw addError; // Re-throw if it's a different error
      }
    }
    
  } catch (error) {
    console.error("Error adding customer to main audience:", error instanceof Error ? error.message : String(error));
    // Don't fail if Marketing API fails - Transactional still works
  }
}

// Send review request email using Transactional Email
export async function addCustomerForReview(reviewData: ReviewRequestData & { customTemplate?: { subject: string; html: string; text?: string } }): Promise<boolean> {
  try {
    // If custom template is provided, use it directly
    if (reviewData.customTemplate) {
      const result = await makeTransactionalRequest('messages/send', {
        message: {
          subject: reviewData.customTemplate.subject,
          from_email: "hello@roamah.com",
          from_name: "Roamah Travel",
          reply_to: "hello@roamah.com",
          to: [{
            email: reviewData.customerEmail,
            name: reviewData.customerName,
            type: "to"
          }],
          html: reviewData.customTemplate.html,
          text: reviewData.customTemplate.text || '',
          important: false,
          track_opens: true,
          track_clicks: true,
          auto_text: false,
          auto_html: false,
          inline_css: true,
          url_strip_qs: false,
          preserve_recipients: false,
          view_content_link: false,
          tracking_domain: null,
          signing_domain: null,
          return_path_domain: null,
          merge: true,
          merge_language: "mailchimp",
          tags: ["review-request", "transactional"],
          subaccount: null,
          google_analytics_domains: [],
          google_analytics_campaign: "review-request",
          metadata: {
            enquiry_id: reviewData.enquiryId.toString(),
            agent_id: reviewData.agentId.toString(),
            email_type: "review"
          },
          recipient_metadata: [{
            rcpt: reviewData.customerEmail,
            values: {
              customer_name: reviewData.customerName,
              agent_name: reviewData.agentName
            }
          }],
          headers: {
            "Reply-To": "hello@roamah.com",
            "X-MC-Important": "true",
            "X-MC-AutoText": "false",
            "List-Unsubscribe": `<mailto:unsubscribe@roamah.com?subject=unsubscribe>`,
            "X-Priority": "3",
            "X-MSMail-Priority": "Normal",
            "X-Mailer": "Roamah Travel Platform"
          }
        }
      });
      console.log(`📧 Custom template email sent to ${reviewData.customerEmail}`, result);
      return true;
    }
    
    // Otherwise use standard review request template
    await triggerReviewRequest(reviewData);
    return true;
  } catch (error) {
    console.error("Error sending review request:", error);
    return false;
  }
}

// Send enquiry confirmation email using Transactional Email
async function triggerEnquiryFollowUp(customerData: CustomerData): Promise<void> {
  try {
    const result = await makeTransactionalRequest('messages/send', {
      message: {
        subject: `Your travel enquiry confirmation - ${customerData.agentName} will contact you within 24 hours`,
        from_email: "hello@roamah.com",
        from_name: "Roamah Travel",
        reply_to: "hello@roamah.com",
        to: [{
          email: customerData.email,
          name: `${customerData.firstName} ${customerData.lastName}`,
          type: "to"
        }],
        important: false,
        track_opens: true,
        track_clicks: false,
        auto_text: true,
        auto_html: false,
        inline_css: true,
        url_strip_qs: false,
        preserve_recipients: false,
        view_content_link: false,
        tracking_domain: null,
        signing_domain: null,
        return_path_domain: null,
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #ff6b35;">Thank you for your travel enquiry!</h2>
            <p>Hey ${customerData.firstName},</p>
            <p>We've received your holiday enquiry for ${customerData.destinations.join(', ')}. Your travel expert <strong>${customerData.agentName}</strong> will be in touch within 24 hours.</p>
            
            <div style="background-color: #f8f9fa; padding: 20px; border-radius: 5px; margin: 20px 0;">
              <h3 style="color: #333; margin-top: 0;">Your Enquiry Details:</h3>
              <ul style="color: #666;">
                <li><strong>Destinations:</strong> ${customerData.destinations.join(', ')}</li>
                <li><strong>Holiday Types:</strong> ${customerData.holidayTypes.join(', ')}</li>
                <li><strong>Travel Party:</strong> ${customerData.numberOfAdults} adults${customerData.numberOfChildren > 0 ? `, ${customerData.numberOfChildren} children` : ''}</li>
                <li><strong>Travel Time:</strong> ${customerData.travelMonths?.join(', ') || 'Not specified'} ${customerData.travelYear || ''}</li>
                <li><strong>Budget:</strong> ${customerData.budgetPerPerson} per person</li>
              </ul>
            </div>
            
            <p>Best regards,<br><strong>Team Roamah</strong></p>
          </div>
        `,
        text: `Hey ${customerData.firstName},

We've received your holiday enquiry for ${customerData.destinations.join(', ')}. Your travel expert ${customerData.agentName} will be in touch within 24 hours.

Your Enquiry Details:
- Destinations: ${customerData.destinations.join(', ')}
- Holiday Types: ${customerData.holidayTypes.join(', ')}
- Travel Party: ${customerData.numberOfAdults} adults${customerData.numberOfChildren > 0 ? `, ${customerData.numberOfChildren} children` : ''}
- Travel Time: ${customerData.travelMonths?.join(', ') || 'Not specified'} ${customerData.travelYear || ''}
- Budget: ${customerData.budgetPerPerson} per person

Best regards,
Team Roamah`
      }
    });

    console.log(`📧 Enquiry confirmation email sent to ${customerData.email}`, result);
  } catch (error) {
    console.error("Error sending enquiry confirmation email:", error);
    throw error;
  }
}

// Send review request email using Transactional Email
async function triggerReviewRequest(reviewData: ReviewRequestData): Promise<void> {
  try {
    const firstName = reviewData.customerName.split(' ')[0];
    
    const result = await makeTransactionalRequest('messages/send', {
      message: {
        subject: `${reviewData.agentName} would love your feedback on your ${reviewData.tripType} experience`,
        from_email: "hello@roamah.com",
        from_name: "Roamah Travel",
        reply_to: "hello@roamah.com",
        to: [{
          email: reviewData.customerEmail,
          name: reviewData.customerName,
          type: "to"
        }],
        important: false,
        track_opens: false,
        track_clicks: false,
        auto_text: true,
        auto_html: false,
        inline_css: true,
        url_strip_qs: false,
        preserve_recipients: false,
        view_content_link: false,
        tracking_domain: null,
        signing_domain: null,
        return_path_domain: null,
        html: `
          <!DOCTYPE html>
          <html>
          <head>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Share Your Travel Experience</title>
          </head>
          <body style="margin: 0; padding: 0; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background-color: #f8f9fa;">
            <div style="max-width: 600px; margin: 0 auto; background-color: #ffffff; border-radius: 8px; overflow: hidden; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
              <!-- Header -->
              <div style="background: linear-gradient(135deg, #ff6b35 0%, #ff8a50 100%); padding: 30px 40px; text-align: center;">
                <h1 style="color: #ffffff; margin: 0; font-size: 28px; font-weight: 600;">Roamah Travel</h1>
                <p style="color: #ffffff; margin: 10px 0 0 0; opacity: 0.9; font-size: 16px;">Your trusted travel experts</p>
              </div>
              
              <!-- Content -->
              <div style="padding: 40px 40px 30px 40px;">
                <h2 style="color: #2c3e50; margin: 0 0 20px 0; font-size: 24px; font-weight: 600;">Hi ${firstName}!</h2>
                
                <p style="color: #4a5568; line-height: 1.6; margin: 0 0 20px 0; font-size: 16px;">
                  We hope you had an incredible <strong>${reviewData.tripType}</strong> experience with your travel expert <strong>${reviewData.agentName}</strong>.
                </p>
                
                <p style="color: #4a5568; line-height: 1.6; margin: 0 0 30px 0; font-size: 16px;">
                  Would you mind taking 2 minutes to share your experience? Your feedback helps other travelers discover amazing destinations and experiences.
                </p>
                
                <!-- CTA Button -->
                <div style="text-align: center; margin: 35px 0;">
                  <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="margin: 0 auto;">
                    <tr>
                      <td style="background: #ff6b35; border-radius: 25px; text-align: center;">
                        <a href="https://roamah.replit.app/review/${reviewData.enquiryId}" 
                           style="display: inline-block; color: #ffffff; padding: 16px 32px; text-decoration: none; font-weight: 600; font-size: 16px; font-family: Arial, sans-serif;">
                          Share Your Experience
                        </a>
                      </td>
                    </tr>
                  </table>
                </div>
                
                <div style="background-color: #f8f9fa; border-left: 4px solid #ff6b35; padding: 20px; margin: 30px 0; border-radius: 0 8px 8px 0;">
                  <p style="color: #4a5568; margin: 0; font-size: 14px; line-height: 1.5;">
                    <strong>Why your review matters:</strong><br>
                    • Helps other travelers make informed decisions<br>
                    • Supports ${reviewData.agentName} and our travel expert community<br>
                    • Takes just 2 minutes to complete
                  </p>
                </div>
                
                <p style="color: #4a5568; line-height: 1.6; margin: 20px 0 0 0; font-size: 16px;">
                  Thank you for choosing Roamah Travel. We're grateful for the opportunity to help create your travel memories.
                </p>
              </div>
              
              <!-- Footer -->
              <div style="background-color: #f8f9fa; padding: 25px 40px; border-top: 1px solid #e2e8f0;">
                <p style="margin: 0; color: #718096; font-size: 14px; text-align: center;">
                  Best regards,<br>
                  <strong style="color: #2d3748;">The Roamah Travel Team</strong>
                </p>
                <div style="text-align: center; margin-top: 15px;">
                  <p style="margin: 0; color: #a0aec0; font-size: 12px;">
                    This email was sent to ${reviewData.customerEmail} regarding your recent travel enquiry.
                  </p>
                </div>
              </div>
            </div>
            
            <!-- Spacer -->
            <div style="height: 40px;"></div>
          </body>
          </html>
        `,
        text: `Hi ${firstName},

We hope you had an amazing ${reviewData.tripType} experience with your travel expert ${reviewData.agentName}!

Would you mind sharing your experience to help other travelers? Please visit:
${process.env.REPLIT_DOMAINS ? `https://${process.env.REPLIT_DOMAINS.split(',')[0]}` : 'https://your-domain.replit.app'}/review/${reviewData.enquiryId}

Your feedback helps us maintain the highest quality service.

Best regards,
Roamah Travel Team`
      }
    });

    console.log(`📧 Review request email sent to ${reviewData.customerEmail}`, result);
  } catch (error) {
    console.error("Error sending review request email:", error);
    throw error;
  }
}

// Get API info for monitoring
export async function getApiInfo() {
  try {
    const result = await makeTransactionalRequest('users/info', {});
    return result;
  } catch (error) {
    console.error("Error getting API info:", error);
    return null;
  }
}

// Test email sending capability
export async function testEmailSending(): Promise<boolean> {
  try {
    const result = await makeTransactionalRequest('messages/send-template', {
      template_name: "test",
      template_content: [],
      message: {
        subject: "Test Email",
        from_email: "hello@roamah.com",
        from_name: "Roamah",
        to: [{
          email: "test@example.com",
          name: "Test User",
          type: "to"
        }]
      }
    });
    return true;
  } catch (error) {
    // This is expected to fail for testing, but confirms API connectivity
    return (error instanceof Error && error.message?.includes('template')) ? true : false;
  }
}

// Health check function for Mailchimp API
export async function pingMailchimp(): Promise<boolean> {
  try {
    // Test Marketing API
    const response = await fetch(`${MARKETING_API_BASE}/ping`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${MARKETING_API_KEY}`,
        'Content-Type': 'application/json',
      }
    });
    return response.ok;
  } catch (error) {
    console.error("Mailchimp ping failed:", error);
    return false;
  }
}

// Export utility functions
export { getBudgetSegment, testConnection };