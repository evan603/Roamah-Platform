import { storage } from "./storage";
import { InsertEmailTemplate } from "@shared/schema";

// Initialize email templates in the database
export async function initializeEmailTemplates() {
  console.log("Initializing email templates...");
  
  try {
    // Check if templates already exist
    const existingTemplates = await storage.getAllEmailTemplates();
    
    if (existingTemplates.length > 0) {
      console.log(`Found ${existingTemplates.length} existing templates, skipping initialization`);
      return;
    }

    const templates: InsertEmailTemplate[] = [
      {
        id: "enquiry-confirmation",
        type: "transactional",
        name: "Enquiry Confirmation Email",
        subject: "Thank you for your enquiry - Roamah Travel",
        htmlContent: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff;">
            <div style="background-color: #ff6b35; padding: 20px; text-align: center;">
              <h1 style="color: white; margin: 0; font-size: 28px;">Roamah Travel</h1>
              <p style="color: white; margin: 5px 0 0 0; font-size: 16px;">Your travel experts</p>
            </div>
            
            <div style="padding: 30px 20px;">
              <h2 style="color: #333; margin-bottom: 20px;">Thank you for your enquiry, {{customerName}}!</h2>
              
              <p style="color: #666; line-height: 1.6; margin-bottom: 20px;">
                We have received your enquiry for {{tripType}} and our travel expert {{agentName}} will be in touch with you soon.
              </p>
              
              <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <h3 style="color: #ff6b35; margin-top: 0;">Your Enquiry Details:</h3>
                <ul style="color: #666; line-height: 1.6;">
                  <li><strong>Trip Type:</strong> {{tripType}}</li>
                  <li><strong>Travel Expert:</strong> {{agentName}}</li>
                  <li><strong>Reference:</strong> ENQ-{{enquiryId}}</li>
                </ul>
              </div>
              
              <p style="color: #666; line-height: 1.6; margin-bottom: 20px;">
                {{agentName}} will contact you within 24 hours to discuss your travel requirements and provide you with a personalised quote.
              </p>
              
              <div style="text-align: center; margin: 30px 0;">
                <table style="margin: 0 auto;">
                  <tr>
                    <td style="background-color: #ff6b35; padding: 15px 30px; text-align: center; border-radius: 5px;">
                      <a href="https://{{domain}}/agent/{{agentId}}" style="color: white; text-decoration: none; font-weight: bold; font-size: 16px;">View {{agentName}}'s Profile</a>
                    </td>
                  </tr>
                </table>
              </div>
              
              <p style="color: #666; line-height: 1.6; font-size: 14px; margin-top: 30px;">
                Best regards,<br>
                The Roamah Travel Team
              </p>
            </div>
            
            <div style="background-color: #f8f9fa; padding: 20px; text-align: center; border-top: 1px solid #e9ecef;">
              <p style="color: #999; font-size: 12px; margin: 0;">
                This email was sent by Roamah Travel. If you have any questions, please contact us.
              </p>
            </div>
          </div>
        `,
        textContent: "Thank you for your enquiry! We have received your travel requirements and our expert will be in touch within 24 hours. Best regards, The Roamah Team",
        description: "Sent to customers when they submit an enquiry through the website",
        isActive: true
      },
      {
        id: "review-request",
        type: "transactional", 
        name: "Review Request Email",
        subject: "Share your travel experience - Roamah Travel",
        htmlContent: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff;">
            <div style="background-color: #ff6b35; padding: 20px; text-align: center;">
              <h1 style="color: white; margin: 0; font-size: 28px;">Roamah Travel</h1>
              <p style="color: white; margin: 5px 0 0 0; font-size: 16px;">Share your experience</p>
            </div>
            
            <div style="padding: 30px 20px;">
              <h2 style="color: #333; margin-bottom: 20px;">Hi {{customerName}},</h2>
              
              <p style="color: #666; line-height: 1.6; margin-bottom: 20px;">
                We hope you had an amazing {{tripType}} experience! Your feedback is incredibly valuable to us and helps other travelers discover great travel experts.
              </p>
              
              <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <h3 style="color: #ff6b35; margin-top: 0;">Your Travel Expert</h3>
                <p style="color: #666; margin: 0;"><strong>{{agentName}}</strong> helped plan your {{tripType}} adventure</p>
              </div>
              
              <p style="color: #666; line-height: 1.6; margin-bottom: 25px;">
                Would you mind taking 2 minutes to share your experience? Your review will help {{agentName}} and assist future travelers in making informed decisions.
              </p>
              
              <div style="text-align: center; margin: 30px 0;">
                <table style="margin: 0 auto;">
                  <tr>
                    <td style="background-color: #ff6b35; padding: 15px 30px; text-align: center; border-radius: 5px;">
                      <a href="https://{{domain}}/review/{{enquiryId}}" style="color: white; text-decoration: none; font-weight: bold; font-size: 16px;">Leave Your Review</a>
                    </td>
                  </tr>
                </table>
              </div>
              
              <p style="color: #666; line-height: 1.6; font-size: 14px; margin-top: 30px;">
                Thank you for choosing Roamah Travel!<br>
                The Roamah Team
              </p>
            </div>
            
            <div style="background-color: #f8f9fa; padding: 20px; text-align: center; border-top: 1px solid #e9ecef;">
              <p style="color: #999; font-size: 12px; margin: 0;">
                This email was sent by Roamah Travel. If you no longer wish to receive these emails, please contact us.
              </p>
            </div>
          </div>
        `,
        textContent: "Hi! We hope you had an amazing travel experience! Please take 2 minutes to share your review. Your feedback helps other travelers and assists future customers. Thank you for choosing Roamah Travel!",
        description: "Sent to customers 7 days after their enquiry to request a review",
        isActive: true
      },
      {
        id: "agent-enquiry-notification",
        type: "transactional",
        name: "New Enquiry Notification (Agent)",
        subject: "New travel enquiry received - Roamah Travel",
        htmlContent: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; background-color: #ffffff;">
            <div style="background-color: #ff6b35; padding: 20px; text-align: center;">
              <h1 style="color: white; margin: 0; font-size: 28px;">Roamah Travel</h1>
              <p style="color: white; margin: 5px 0 0 0; font-size: 16px;">New enquiry alert</p>
            </div>
            
            <div style="padding: 30px 20px;">
              <h2 style="color: #333; margin-bottom: 20px;">Hi {{agentName}},</h2>
              
              <p style="color: #666; line-height: 1.6; margin-bottom: 20px;">
                Great news! You have received a new travel enquiry through Roamah Travel.
              </p>
              
              <div style="background-color: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
                <h3 style="color: #ff6b35; margin-top: 0;">Enquiry Details:</h3>
                <ul style="color: #666; line-height: 1.6;">
                  <li><strong>Customer:</strong> {{customerName}}</li>
                  <li><strong>Email:</strong> {{customerEmail}}</li>
                  <li><strong>Trip Type:</strong> {{tripType}}</li>
                  <li><strong>Reference:</strong> ENQ-{{enquiryId}}</li>
                </ul>
              </div>
              
              <p style="color: #666; line-height: 1.6; margin-bottom: 25px;">
                Please respond to this enquiry within 24 hours to provide the best customer experience. You can view full details and manage your enquiries in your dashboard.
              </p>
              
              <div style="text-align: center; margin: 30px 0;">
                <table style="margin: 0 auto;">
                  <tr>
                    <td style="background-color: #ff6b35; padding: 15px 30px; text-align: center; border-radius: 5px;">
                      <a href="https://{{domain}}/dashboard" style="color: white; text-decoration: none; font-weight: bold; font-size: 16px;">View in Dashboard</a>
                    </td>
                  </tr>
                </table>
              </div>
              
              <p style="color: #666; line-height: 1.6; font-size: 14px; margin-top: 30px;">
                Best of luck with your new enquiry!<br>
                The Roamah Travel Team
              </p>
            </div>
            
            <div style="background-color: #f8f9fa; padding: 20px; text-align: center; border-top: 1px solid #e9ecef;">
              <p style="color: #999; font-size: 12px; margin: 0;">
                This email was sent by Roamah Travel. You can manage your notification preferences in your dashboard.
              </p>
            </div>
          </div>
        `,
        textContent: "Hi! Great news! You have received a new travel enquiry through Roamah Travel. Please respond within 24 hours for the best customer experience. View full details in your dashboard.",
        description: "Sent to agents when they receive a new enquiry",
        isActive: true
      }
    ];

    // Create each template
    for (const template of templates) {
      await storage.createEmailTemplate(template);
      console.log(`Created email template: ${template.name}`);
    }

    console.log(`Successfully initialized ${templates.length} email templates`);
  } catch (error) {
    console.error("Error initializing email templates:", error);
    throw error;
  }
}