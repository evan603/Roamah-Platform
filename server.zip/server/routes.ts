import type { Express } from "express";
import express from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { hashPassword, comparePassword, generateToken, authenticateAgent, verifyToken } from "./auth";
import { pool } from "./db";
import { agentRegistrationSchema, agentLoginSchema, agentSignupSchema, agentProfileCompletionSchema, type AgentRegistration, type AgentLogin, type AgentSignup, type AgentProfileCompletion } from "@shared/schema";
import { insertEnquirySchema, insertNewsletterSchema, insertOfferSchema, insertDestinationSchema, insertHolidayTypeSchema, insertEmailTemplateSchema } from "@shared/schema";
import { z } from "zod";
import crypto from "crypto";
import { sendVerificationEmail } from "./email";
import { addCustomerToAudience, addCustomerForReview, addAgentToAudience } from "./mailchimp";
import { sendEnquiryConfirmation, sendReviewRequest, scheduleReviewRequest, getEmailStats } from "./email-workflows";
import { ObjectStorageService } from "./objectStorage";
import multer from "multer";
import path from "path";
import fs from "fs";
import jwt from "jsonwebtoken";

// Configure multer for file uploads
const uploadDir = path.join(process.cwd(), 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const storage_multer = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

// Create separate upload configurations for different file types
const uploadPhotos = multer({ 
  storage: storage_multer,
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit for photos
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('image/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image files are allowed!'));
    }
  }
});

const uploadVideos = multer({ 
  storage: storage_multer,
  limits: {
    fileSize: 200 * 1024 * 1024, // 200MB limit for videos
  },
  fileFilter: (req, file, cb) => {
    if (file.mimetype.startsWith('video/')) {
      cb(null, true);
    } else {
      cb(new Error('Only video files are allowed!'));
    }
  }
});

// Default upload for profile images and mixed content
const upload = multer({ 
  storage: storage_multer,
  limits: {
    fileSize: 50 * 1024 * 1024, // 50MB limit for general uploads
  },
  fileFilter: (req, file, cb) => {
    // Allow images and videos
    if (file.mimetype.startsWith('image/') || file.mimetype.startsWith('video/')) {
      cb(null, true);
    } else {
      cb(new Error('Only image and video files are allowed!'));
    }
  }
});

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Object Storage: Serve public assets from cloud storage
  app.get("/public-objects/:filePath(*)", async (req, res) => {
    const filePath = req.params.filePath;
    const objectStorageService = new ObjectStorageService();
    try {
      const file = await objectStorageService.searchPublicObject(filePath);
      if (!file) {
        return res.status(404).json({ error: "File not found" });
      }
      objectStorageService.downloadObject(file, res);
    } catch (error) {
      console.error("Error searching for public object:", error);
      return res.status(500).json({ error: "Internal server error" });
    }
  });
  // Priority routes - must be first before any middleware
  
  // Basic root route for deployment testing
  app.get('/', (req, res) => {
    res.send(`
      <html>
        <head><title>Roamah Travel Platform</title></head>
        <body style="font-family: Arial, sans-serif; text-align: center; padding: 50px;">
          <h1 style="color: #ff6b35;">Roamah Travel Platform</h1>
          <p>Server is running successfully</p>
          <p>Environment: ${process.env.NODE_ENV || 'development'}</p>
          <p>Port: ${process.env.PORT || '5000'}</p>
          <a href="/review/request" style="background: #ff6b35; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px;">Review System</a>
        </body>
      </html>
    `);
  });
  
  // Review request page - customer enters email to find their latest enquiry
  app.get('/review/request', async (req, res) => {
    const html = `
      <!DOCTYPE html>
      <html>
      <head>
        <title>Submit Your Review - Roamah</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
          body { font-family: Arial, sans-serif; max-width: 500px; margin: 50px auto; padding: 20px; background-color: #f8f9fa; }
          .container { background: white; padding: 40px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); text-align: center; }
          .logo { color: #ff6b35; font-size: 28px; font-weight: bold; margin-bottom: 10px; }
          .form-group { margin: 20px 0; text-align: left; }
          label { display: block; margin-bottom: 5px; font-weight: bold; color: #333; }
          input { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; box-sizing: border-box; }
          button { background: #ff6b35; color: white; padding: 15px 30px; border: none; border-radius: 25px; font-size: 16px; font-weight: bold; cursor: pointer; width: 100%; }
          button:hover { background: #e55a2b; }
          .error { color: #dc3545; margin-top: 10px; display: none; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="logo">Roamah Travel</div>
          <h2>Share Your Experience</h2>
          <p>Please enter your email address to leave a review</p>
          
          <form id="emailForm">
            <div class="form-group">
              <label for="email">Your Email Address</label>
              <input type="email" id="email" name="email" required placeholder="Enter your email address">
              <div class="error" id="error">Please enter a valid email address</div>
            </div>
            <button type="submit">Find My Review</button>
          </form>
        </div>

        <script>
          document.getElementById('emailForm').addEventListener('submit', async (e) => {
            e.preventDefault();
            const email = document.getElementById('email').value;
            
            if (!email) {
              document.getElementById('error').style.display = 'block';
              return;
            }
            
            // Redirect to the latest enquiry for this email
            window.location.href = '/review/latest/' + encodeURIComponent(email);
          });
        </script>
      </body>
      </html>
    `;
    
    res.send(html);
  });

  // Fix broken Mailchimp merge field URLs
  app.get('/review/%7CENQUIRYID%7C', async (req, res) => {
    console.log('🔧 Fixing broken Mailchimp URL - redirecting to homepage');
    return res.redirect('/');
  });

  // Handle URL-encoded EMAIL merge tag (backup route)
  app.get('/review/latest/%7CEMAIL%7C', async (req, res) => {
    console.log('🔧 EMAIL merge tag failed to populate - redirecting to homepage');
    return res.redirect('/');
  });

  // Handle wildcard EMAIL merge tag (backup route)  
  app.get('/review/latest/*%7CEMAIL%7C*', async (req, res) => {
    console.log('🔧 EMAIL merge tag with wildcards failed - redirecting to homepage');
    return res.redirect('/');
  });

  // Review page route - serves feedback form (must be after specific routes)
  app.get('/review/:enquiryId', async (req, res) => {
    try {
      const enquiryId = parseInt(req.params.enquiryId);
      
      if (isNaN(enquiryId)) {
        return res.status(400).send('<h1>Invalid Review Link</h1><p>The review link appears to be invalid.</p>');
      }

      const enquiries = await storage.getAllEnquiriesWithAgentNames();
      const enquiry = enquiries.find(e => e.id === enquiryId);
      
      if (!enquiry) {
        return res.status(404).send('<h1>Review Not Found</h1><p>The review request could not be found.</p>');
      }

      // Serve review form with enquiry details
      res.send(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Share Your Travel Experience - Roamah</title>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f8f9fa; }
            .container { background: white; padding: 40px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .header { text-align: center; margin-bottom: 30px; }
            .logo { color: #ff6b35; font-size: 28px; font-weight: bold; margin-bottom: 10px; }
            .form-group { margin-bottom: 20px; }
            label { display: block; margin-bottom: 5px; font-weight: bold; color: #333; }
            input, textarea { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; box-sizing: border-box; }
            textarea { height: 120px; resize: vertical; }
            .stars { display: flex; gap: 5px; justify-content: center; margin: 20px 0; }
            .star { font-size: 30px; cursor: pointer; color: #ddd; transition: all 0.2s ease; user-select: none; padding: 5px; border-radius: 50%; }
            .star:hover { color: #ff6b35; transform: scale(1.1); background-color: rgba(255, 107, 53, 0.1); }
            .star.active { color: #ff6b35; }
            button { background: #ff6b35; color: white; padding: 15px 30px; border: none; border-radius: 25px; font-size: 16px; font-weight: bold; cursor: pointer; width: 100%; margin-top: 20px; }
            button:hover { background: #e55a2b; }
            .success { background: #d4edda; color: #155724; padding: 15px; border-radius: 4px; margin-bottom: 20px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="logo">Roamah Travel</div>
              <h2>Share Your Experience</h2>
              <p>How was your \${enquiry.holidayTypes?.join(', ') || 'travel'} experience with \${enquiry.agentName}?</p>
            </div>
            
            <form id="reviewForm">
              <input type="hidden" name="enquiryId" value="\${enquiry.id}">
              <input type="hidden" name="agentId" value="\${enquiry.agentId}">
              
              <div class="form-group">
                <label>Overall Rating</label>
                <p style="text-align: center; color: #666; margin: 10px 0 5px 0; font-size: 14px;">Click to rate your experience</p>
                <div class="stars" id="stars">
                  <span class="star" data-rating="1">⭐</span>
                  <span class="star" data-rating="2">⭐</span>
                  <span class="star" data-rating="3">⭐</span>
                  <span class="star" data-rating="4">⭐</span>
                  <span class="star" data-rating="5">⭐</span>
                </div>
                <p id="ratingText" style="text-align: center; font-weight: bold; margin-top: 10px;"></p>
                <input type="hidden" name="rating" id="rating" required>
              </div>
              
              <div class="form-group">
                <label for="customerName">Your Name</label>
                <input type="text" name="customerName" id="customerName" value="\${enquiry.firstName} \${enquiry.lastName}" required>
              </div>
              
              <div class="form-group">
                <label for="reviewText">Your Review</label>
                <textarea name="reviewText" id="reviewText" placeholder="Tell us about your experience..." required></textarea>
              </div>
              
              <button type="submit">Submit Review</button>
            </form>
          </div>

          <script>
            const stars = document.querySelectorAll('.star');
            const ratingInput = document.getElementById('rating');
            const ratingText = document.getElementById('ratingText');
            const ratingLabels = {
              1: 'Poor',
              2: 'Fair', 
              3: 'Good',
              4: 'Very Good',
              5: 'Excellent'
            };
            
            stars.forEach(star => {
              star.addEventListener('click', () => {
                const rating = parseInt(star.dataset.rating);
                ratingInput.value = rating;
                updateStars(rating);
                updateRatingText(rating);
              });
              
              star.addEventListener('mouseover', () => {
                const rating = parseInt(star.dataset.rating);
                updateStars(rating);
              });
            });
            
            function updateStars(rating) {
              stars.forEach((star, index) => {
                if (index < rating) {
                  star.classList.add('active');
                } else {
                  star.classList.remove('active');
                }
              });
            }
            
            function updateRatingText(rating) {
              if (rating > 0 && rating <= 5) {
                ratingText.textContent = ratingLabels[rating];
              } else {
                ratingText.textContent = '';
              }
            }
            
            document.getElementById('reviewForm').addEventListener('submit', async (e) => {
              e.preventDefault();
              
              if (!ratingInput.value) {
                alert('Please select a star rating');
                return;
              }
              
              const formData = new FormData(e.target);
              const data = Object.fromEntries(formData);
              
              try {
                const response = await fetch('/api/reviews', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(data)
                });
                
                if (response.ok) {
                  document.querySelector('.container').innerHTML = \`
                    <div class="header">
                      <div class="logo">Roamah Travel</div>
                      <h2>Thank You!</h2>
                    </div>
                    <div class="success">
                      <h3>Review Submitted Successfully!</h3>
                      <p>Thank you for sharing your experience. Your feedback helps other travelers and supports our travel expert community.</p>
                      <p>We appreciate you choosing Roamah Travel for your travel adventure!</p>
                    </div>
                  \`;
                } else {
                  alert('Error submitting review. Please try again.');
                }
              } catch (error) {
                alert('Error submitting review. Please try again.');
              }
            });
          </script>
        </body>
        </html>
      `);
      
    } catch (error) {
      console.error('Review page error:', error);
      return res.status(500).send('<h1>Error</h1><p>An error occurred while loading your review page.</p>');
    }
  });

  // Review redirect route - finds latest enquiry for email
  app.get('/review/latest/:email', async (req, res) => {
    try {
      let email = req.params.email;
      
      try {
        email = decodeURIComponent(email);
      } catch {
        // If decoding fails, use original
      }
      
      console.log(`🔍 Finding latest enquiry for email: ${email}`);
      console.log(`🔍 Raw path param: ${req.params.email}`);
      
      const allEnquiries = await storage.getAllEnquiriesWithAgentNames();
      const customerEnquiries = allEnquiries.filter(e => e.email?.toLowerCase() === email.toLowerCase());
      
      if (!customerEnquiries || customerEnquiries.length === 0) {
        console.log(`❌ No enquiries found for: ${email}`);
        return res.status(404).send(`
          <h1>No Enquiries Found</h1>
          <p>No enquiries found for email: ${email}</p>
          <p>Please contact us if you believe this is an error.</p>
          <p><a href="/">Return to Homepage</a></p>
        `);
      }
      
      const latestEnquiry = customerEnquiries[0];
      console.log(`✅ Redirecting to latest enquiry ID: ${latestEnquiry.id} for ${email}`);
      
      return res.redirect(`/review/${latestEnquiry.id}`);
      
    } catch (error) {
      console.error('Review redirect error:', error);
      return res.status(500).send('<h1>Error</h1><p>An error occurred while finding your review.</p>');
    }
  });

  // Review page route - serves feedback form
  app.get('/review/:enquiryId', async (req, res) => {
    try {
      const enquiryId = parseInt(req.params.enquiryId);
      
      if (isNaN(enquiryId)) {
        return res.status(400).send('<h1>Invalid Review Link</h1><p>The review link appears to be invalid.</p>');
      }

      const enquiries = await storage.getAllEnquiriesWithAgentNames();
      const enquiry = enquiries.find(e => e.id === enquiryId);
      
      if (!enquiry) {
        return res.status(404).send('<h1>Review Not Found</h1><p>The review request could not be found.</p>');
      }

      // Serve review form with enquiry details
      res.send(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Share Your Travel Experience - Roamah</title>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f8f9fa; }
            .container { background: white; padding: 40px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .header { text-align: center; margin-bottom: 30px; }
            .logo { color: #ff6b35; font-size: 28px; font-weight: bold; margin-bottom: 10px; }
            .form-group { margin-bottom: 20px; }
            label { display: block; margin-bottom: 5px; font-weight: bold; color: #333; }
            input, textarea { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; box-sizing: border-box; }
            textarea { height: 120px; resize: vertical; }
            .stars { display: flex; gap: 5px; justify-content: center; margin: 20px 0; }
            .star { font-size: 30px; cursor: pointer; color: #ddd; transition: all 0.2s ease; user-select: none; padding: 5px; border-radius: 50%; }
            .star:hover { color: #ff6b35; transform: scale(1.1); background-color: rgba(255, 107, 53, 0.1); }
            .star.active { color: #ff6b35; }
            button { background: #ff6b35; color: white; padding: 15px 30px; border: none; border-radius: 25px; font-size: 16px; font-weight: bold; cursor: pointer; width: 100%; margin-top: 20px; }
            button:hover { background: #e55a2b; }
            .success { background: #d4edda; color: #155724; padding: 15px; border-radius: 4px; margin-bottom: 20px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="logo">Roamah Travel</div>
              <h2>Share Your Experience</h2>
              <p>How was your ${enquiry.holidayTypes?.join(', ') || 'travel'} experience with ${enquiry.agentName}?</p>
            </div>
            
            <form id="reviewForm">
              <input type="hidden" name="enquiryId" value="${enquiry.id}">
              <input type="hidden" name="agentId" value="${enquiry.agentId}">
              
              <div class="form-group">
                <label>Overall Rating</label>
                <p style="text-align: center; color: #666; margin: 10px 0 5px 0; font-size: 14px;">Click to rate your experience</p>
                <div class="stars" id="stars">
                  <span class="star" data-rating="1">⭐</span>
                  <span class="star" data-rating="2">⭐</span>
                  <span class="star" data-rating="3">⭐</span>
                  <span class="star" data-rating="4">⭐</span>
                  <span class="star" data-rating="5">⭐</span>
                </div>
                <p id="ratingText" style="text-align: center; font-weight: bold; margin-top: 10px;"></p>
                <input type="hidden" name="rating" id="rating" required>
              </div>
              
              <div class="form-group">
                <label for="customerName">Your Name</label>
                <input type="text" name="customerName" id="customerName" value="${enquiry.firstName} ${enquiry.lastName}" required>
              </div>
              
              <div class="form-group">
                <label for="reviewText">Your Review</label>
                <textarea name="reviewText" id="reviewText" placeholder="Tell us about your experience..." required></textarea>
              </div>
              
              <button type="submit">Submit Review</button>
            </form>
          </div>

          <script>
            const stars = document.querySelectorAll('.star');
            const ratingInput = document.getElementById('rating');
            const ratingText = document.getElementById('ratingText');
            const ratingLabels = {
              1: 'Poor',
              2: 'Fair', 
              3: 'Good',
              4: 'Very Good',
              5: 'Excellent'
            };
            
            stars.forEach(star => {
              star.addEventListener('click', () => {
                const rating = parseInt(star.dataset.rating);
                ratingInput.value = rating;
                updateStars(rating);
                updateRatingText(rating);
              });
              
              star.addEventListener('mouseover', () => {
                const rating = parseInt(star.dataset.rating);
                updateStars(rating);
              });
            });
            
            function updateStars(rating) {
              stars.forEach((star, index) => {
                if (index < rating) {
                  star.classList.add('active');
                } else {
                  star.classList.remove('active');
                }
              });
            }
            
            function updateRatingText(rating) {
              if (rating > 0 && rating <= 5) {
                ratingText.textContent = ratingLabels[rating];
              } else {
                ratingText.textContent = '';
              }
            }
            
            document.getElementById('reviewForm').addEventListener('submit', async (e) => {
              e.preventDefault();
              
              if (!ratingInput.value) {
                alert('Please select a star rating');
                return;
              }
              
              const formData = new FormData(e.target);
              const data = Object.fromEntries(formData);
              
              try {
                const response = await fetch('/api/reviews', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(data)
                });
                
                if (response.ok) {
                  document.querySelector('.container').innerHTML = \`
                    <div class="header">
                      <div class="logo">Roamah Travel</div>
                      <h2>Thank You!</h2>
                    </div>
                    <div class="success">
                      <h3>Review Submitted Successfully!</h3>
                      <p>Thank you for sharing your experience. Your feedback helps other travelers and supports our travel expert community.</p>
                      <p>We appreciate you choosing Roamah Travel for your ${enquiry.holidayTypes?.join(', ') || 'travel'} adventure!</p>
                    </div>
                  \`;
                } else {
                  alert('Error submitting review. Please try again.');
                }
              } catch (error) {
                alert('Error submitting review. Please try again.');
              }
            });
          </script>
        </body>
        </html>
      `);
    } catch (error) {
      console.error('Review page error:', error);
      res.status(500).send('<h1>Error</h1><p>An error occurred while loading the review page.</p>');
    }
  });

  // Serve uploaded files statically
  app.use('/uploads', express.static(uploadDir));

  // File upload endpoints
  app.post('/api/agents/upload/photos', authenticateAgent, uploadPhotos.array('photos', 10), async (req, res) => {
    try {
      const agentInfo = (req as any).agent;
      const files = req.files as Express.Multer.File[];
      
      if (!files || files.length === 0) {
        return res.status(400).json({ error: 'No photos uploaded' });
      }

      // Generate URLs for uploaded photos
      const photoUrls = files.map(file => `/uploads/${file.filename}`);
      
      // Update agent photos in database
      await storage.updateAgentPhotos(agentInfo.id, photoUrls);
      
      res.json({ 
        message: 'Photos uploaded successfully',
        photos: photoUrls 
      });
    } catch (error) {
      console.error('Photo upload error:', error);
      res.status(500).json({ error: 'Failed to upload photos' });
    }
  });

  // Delete photo endpoint
  app.delete('/api/agents/upload/photos', authenticateAgent, async (req, res) => {
    try {
      const agentInfo = (req as any).agent;
      const agentId = agentInfo.id;
      const { photoUrl } = req.body;

      if (!photoUrl) {
        return res.status(400).json({ error: 'Photo URL is required' });
      }

      await storage.deleteAgentPhoto(agentId, photoUrl);
      
      res.json({ 
        message: 'Photo deleted successfully'
      });
    } catch (error) {
      console.error('Photo delete error:', error);
      res.status(500).json({ error: 'Failed to delete photo' });
    }
  });

  // Replace photo endpoint
  app.put('/api/agents/upload/photos', authenticateAgent, upload.single('photo'), async (req, res) => {
    try {
      const agentInfo = (req as any).agent;
      const agentId = agentInfo.id;
      const { oldPhotoUrl } = req.body;
      
      if (!req.file) {
        return res.status(400).json({ error: 'No file uploaded' });
      }

      if (!oldPhotoUrl) {
        return res.status(400).json({ error: 'Old photo URL is required' });
      }

      const newPhotoUrl = `/uploads/${req.file.filename}`;
      
      await storage.replaceAgentPhoto(agentId, oldPhotoUrl, newPhotoUrl);
      
      res.json({ 
        message: 'Photo replaced successfully',
        newPhotoUrl: newPhotoUrl 
      });
    } catch (error) {
      console.error('Photo replace error:', error);
      res.status(500).json({ error: 'Failed to replace photo' });
    }
  });

  app.post('/api/agents/upload/video', authenticateAgent, uploadVideos.single('video'), async (req, res) => {
    try {
      const agentInfo = (req as any).agent;
      const file = req.file as Express.Multer.File;
      
      if (!file) {
        return res.status(400).json({ error: 'No video uploaded' });
      }

      // Generate URL for uploaded video
      const videoUrl = `/uploads/${file.filename}`;
      
      // Update agent video in database
      await storage.updateAgentVideo(agentInfo.id, videoUrl);
      
      res.json({ 
        message: 'Video uploaded successfully',
        videoUrl 
      });
    } catch (error) {
      console.error('Video upload error:', error);
      res.status(500).json({ error: 'Failed to upload video' });
    }
  });

  // Profile image upload endpoint
  app.post('/api/agents/upload/profile-image', authenticateAgent, upload.single('profileImage'), async (req, res) => {
    try {
      const agentInfo = (req as any).agent;
      const file = req.file as Express.Multer.File;
      
      if (!file) {
        return res.status(400).json({ error: 'No profile image uploaded' });
      }

      // Generate URL for uploaded profile image
      const profileImageUrl = `/uploads/${file.filename}`;
      
      // Update agent profile image in database
      await storage.updateAgentProfile(agentInfo.id, { profileImage: profileImageUrl });
      
      res.json({ 
        message: 'Profile image uploaded successfully',
        profileImage: profileImageUrl 
      });
    } catch (error) {
      console.error('Profile image upload error:', error);
      res.status(500).json({ error: 'Failed to upload profile image' });
    }
  });

  // Update agent profile endpoint
  app.put('/api/agents/profile', authenticateAgent, async (req, res) => {
    try {
      const agentInfo = (req as any).agent;
      const agentId = agentInfo.id;
      
      // Validate and clean the update data
      const allowedFields = ['firstName', 'lastName', 'location', 'company', 'bio', 'nextHoliday', 'yearsExperience', 'specializations', 'destinations', 'languages', 'hasFinancialProtection', 'protectionBodies', 'licenseNumbers'];
      const updateData: any = {};
      
      for (const field of allowedFields) {
        if (req.body[field] !== undefined) {
          updateData[field] = req.body[field];
        }
      }

      // Update full name if firstName or lastName changed
      if (updateData.firstName || updateData.lastName) {
        const agent = await storage.getAgentById(agentId);
        const firstName = updateData.firstName || agent?.firstName || '';
        const lastName = updateData.lastName || agent?.lastName || '';
        updateData.name = `${firstName} ${lastName}`.trim();
      }

      const updatedAgent = await storage.updateAgentProfile(agentId, updateData);
      
      // Don't return password in response
      const { password, ...agentProfile } = updatedAgent;
      res.json(agentProfile);
    } catch (error) {
      console.error('Profile update error:', error);
      res.status(500).json({ error: 'Failed to update profile' });
    }
  });
  // Agents routes
  app.get("/api/agents", async (req, res) => {
    try {
      const { search, location, holidayType, destination, speciality, sort } = req.query;
      
      let agents;
      
      if (search) {
        agents = await storage.searchAgents(search as string);
      } else if ((location && location !== 'all') || (holidayType && holidayType !== 'all') || (destination && destination !== 'all') || (speciality && speciality !== 'all')) {
        agents = await storage.filterAgents({
          location: location === 'all' ? undefined : location as string,
          holidayType: holidayType === 'all' ? undefined : holidayType as string,
          destination: destination === 'all' ? undefined : destination as string,
          speciality: speciality === 'all' ? undefined : speciality as string,
        });
      } else {
        agents = await storage.getAllAgents();
      }

      if (sort === "top-rated") {
        agents = agents.sort((a, b) => parseFloat(b.rating) - parseFloat(a.rating));
      }

      res.json(agents);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch agents" });
    }
  });



  app.get("/api/agents/featured", async (req, res) => {
    try {
      const agents = await storage.getRandomizedFeaturedAgents();
      res.json(agents);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch featured agents" });
    }
  });



  // Profile endpoint MUST come before /:id route
  app.get("/api/agents/profile", authenticateAgent, async (req, res) => {
    try {
      const agentInfo = (req as any).agent;
      const agentId = agentInfo.id;
      
      const agent = await storage.getAgentById(agentId);
      
      if (!agent) {
        return res.status(404).json({ error: "Agent not found" });
      }

      // Don't return password in response
      const { password, ...agentProfile } = agent;
      res.json(agentProfile);
    } catch (error) {
      console.error("Profile fetch error:", error);
      res.status(500).json({ error: "Failed to fetch profile" });
    }
  });

  // Content management endpoints
  app.post("/api/agents/profile/photos", authenticateAgent, async (req, res) => {
    try {
      const agentInfo = (req as any).agent;
      const agentId = agentInfo.id;
      const { photoUrl } = req.body;

      if (!photoUrl || typeof photoUrl !== 'string') {
        return res.status(400).json({ error: "Valid photo URL is required" });
      }

      const updatedAgent = await storage.addAgentPhoto(agentId, photoUrl);
      res.json({ message: "Photo added successfully", agent: updatedAgent });
    } catch (error) {
      console.error("Add photo error:", error);
      res.status(500).json({ error: "Failed to add photo" });
    }
  });

  app.put("/api/agents/profile/video", authenticateAgent, async (req, res) => {
    try {
      const agentInfo = (req as any).agent;
      const agentId = agentInfo.id;
      const { videoUrl } = req.body;

      if (!videoUrl || typeof videoUrl !== 'string') {
        return res.status(400).json({ error: "Valid video URL is required" });
      }

      const updatedAgent = await storage.updateAgentVideo(agentId, videoUrl);
      res.json({ message: "Video updated successfully", agent: updatedAgent });
    } catch (error) {
      console.error("Update video error:", error);
      res.status(500).json({ error: "Failed to update video" });
    }
  });



  // Agent blog management routes (must be before /api/agents/:id to avoid route conflict)
  app.get("/api/agents/blog", authenticateAgent, async (req, res) => {
    try {
      const agentInfo = (req as any).agent;
      const blogPosts = await storage.getBlogPostsByAgent(agentInfo.id);
      res.json(blogPosts);
    } catch (error) {
      console.error("Fetch agent blogs error:", error);
      res.status(500).json({ error: "Failed to fetch blog posts" });
    }
  });

  app.get("/api/agents/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const agent = await storage.getAgentById(id);
      
      if (!agent) {
        return res.status(404).json({ error: "Agent not found" });
      }

      // Track visitor for analytics (async, don't wait for response)
      const visitorId = req.ip || req.headers['x-forwarded-for'] || 'anonymous';
      const userAgent = req.headers['user-agent'];
      
      // Use setImmediate to track visit without blocking response
      setImmediate(async () => {
        try {
          // Using pool.query for raw SQL to bypass Drizzle type issues
          await pool.query(`
            INSERT INTO profile_visits (agent_id, visitor_id, user_agent) 
            VALUES ($1, $2, $3) 
            ON CONFLICT (agent_id, visitor_id) DO NOTHING
          `, [id, visitorId, userAgent]);
          
          // Increment profile views counter
          await pool.query(`
            UPDATE agents 
            SET profile_views = COALESCE(profile_views, 0) + 1 
            WHERE id = $1
          `, [id]);
        } catch (error) {
          console.error("Visitor tracking error:", error);
        }
      });

      res.json(agent);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch agent" });
    }
  });

  // Agent Authentication routes
  app.post("/api/agents/register", async (req, res) => {
    try {
      const validatedData = agentRegistrationSchema.parse(req.body);
      
      // Check if agent already exists
      const existingAgent = await storage.getAgentByEmail(validatedData.email);
      if (existingAgent) {
        return res.status(400).json({ error: "Agent with this email already exists" });
      }

      // Hash password
      const hashedPassword = await hashPassword(validatedData.password);
      
      // Create full name
      const fullName = `${validatedData.firstName} ${validatedData.lastName}`;

      // Create agent
      const agentData = {
        ...validatedData,
        name: fullName,
        password: hashedPassword,
        bio: validatedData.bio || "",
        profileImage: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop&crop=face",
        nextHoliday: validatedData.nextHoliday || "",
        photos: [],
        videoUrl: null,
        rating: "0.0",
        reviewCount: 0,
        isTopRated: false,
        isVerified: false,
        createdAt: new Date()
      };

      const newAgent = await storage.createAgent(agentData);
      
      // Generate token
      const token = generateToken({
        id: newAgent.id,
        email: newAgent.email,
        firstName: newAgent.firstName || '',
        lastName: newAgent.lastName || ''
      });

      // Note: Agent will be added to Mailchimp audience with "agent" tag only after admin approval

      res.status(201).json({ 
        message: "Agent registered successfully",
        token,
        agent: {
          id: newAgent.id,
          email: newAgent.email,
          firstName: newAgent.firstName,
          lastName: newAgent.lastName,
          name: newAgent.name
        }
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid registration data", details: error.errors });
      }
      console.error("Registration error:", error);
      res.status(500).json({ error: "Failed to register agent" });
    }
  });

  // New multi-step agent registration
  app.post("/api/agents/signup", async (req, res) => {
    try {
      const { email, password } = agentSignupSchema.parse(req.body);
      
      // Generate verification token
      const verificationToken = crypto.randomBytes(32).toString('hex');
      
      // Create pending agent
      const agent = await storage.createPendingAgent(email, password, verificationToken);
      
      // Send verification email
      const emailSent = await sendVerificationEmail(email, verificationToken);
      
      res.status(201).json({ 
        message: "Account created successfully. Please check your email to verify your address.",
        agentId: agent.id,
        // Include token in development for testing
        ...(process.env.NODE_ENV === 'development' && { verificationToken })
      });
    } catch (error: any) {
      console.error("Signup error:", error);
      if (error.message === "Agent with this email already exists") {
        return res.status(400).json({ error: error.message });
      }
      res.status(400).json({ error: "Invalid signup data", details: error.issues || error.message });
    }
  });

  // Helper route for testing - get verification token
  app.get("/api/agents/:agentId/verification-token", async (req, res) => {
    try {
      const agentId = parseInt(req.params.agentId);
      const token = await storage.getAgentVerificationToken(agentId);
      
      if (!token) {
        return res.status(404).json({ error: "Agent not found or already verified" });
      }
      
      res.json({ token });
    } catch (error) {
      console.error("Get verification token error:", error);
      res.status(500).json({ error: "Failed to get verification token" });
    }
  });

  app.get("/api/agents/verify-email", async (req, res) => {
    try {
      const { token } = req.query;
      
      if (!token || typeof token !== 'string') {
        return res.status(400).json({ error: "Verification token is required" });
      }
      
      const agent = await storage.verifyAgentEmail(token);
      
      if (!agent) {
        return res.status(400).json({ error: "Invalid or expired verification token" });
      }
      
      // Generate JWT token for the verified agent
      const jwtToken = generateToken({
        id: agent.id,
        email: agent.email,
        firstName: agent.firstName || '',
        lastName: agent.lastName || '',
      });
      
      res.json({ 
        message: "Email verified successfully", 
        token: jwtToken,
        agent: {
          id: agent.id,
          email: agent.email,
          isEmailVerified: agent.isEmailVerified,
          profileCompleted: agent.profileCompleted
        }
      });
    } catch (error) {
      console.error("Email verification error:", error);
      res.status(500).json({ error: "Failed to verify email" });
    }
  });

  app.post("/api/agents/complete-profile", authenticateAgent, async (req, res) => {
    try {
      const agentInfo = (req as any).agent;
      const profileData = agentProfileCompletionSchema.parse(req.body);
      
      const agent = await storage.completeAgentProfile(agentInfo.id, profileData);
      
      // Don't return password in response
      const { password, ...agentProfile } = agent;
      
      res.json({
        message: "Profile completed successfully",
        agent: agentProfile
      });
    } catch (error: any) {
      console.error("Profile completion error:", error);
      if (error.message === "Email must be verified before completing profile") {
        return res.status(400).json({ error: error.message });
      }
      res.status(400).json({ error: "Invalid profile data", details: error.issues || error.message });
    }
  });

  app.post("/api/agents/login", async (req, res) => {
    try {
      const validatedData = agentLoginSchema.parse(req.body);
      
      // Find agent by email
      const agent = await storage.getAgentByEmail(validatedData.email);
      if (!agent) {
        return res.status(401).json({ error: "Invalid email or password" });
      }

      // Verify password
      const isValidPassword = await comparePassword(validatedData.password, agent.password);
      if (!isValidPassword) {
        return res.status(401).json({ error: "Invalid email or password" });
      }

      // Generate token
      const token = generateToken({
        id: agent.id,
        email: agent.email,
        firstName: agent.firstName || '',
        lastName: agent.lastName || ''
      });

      res.json({ 
        message: "Login successful",
        token,
        agent: {
          id: agent.id,
          email: agent.email,
          firstName: agent.firstName,
          lastName: agent.lastName,
          name: agent.name
        }
      });
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid login data", details: error.errors });
      }
      console.error("Login error:", error);
      res.status(500).json({ error: "Failed to login" });
    }
  });



  app.get("/api/agents/:id/enquiries", authenticateAgent, async (req, res) => {
    try {
      const agentId = parseInt(req.params.id);
      const currentAgentId = (req as any).agent.id;
      
      // Only allow agents to see their own enquiries
      if (agentId !== currentAgentId) {
        return res.status(403).json({ error: "Access denied" });
      }

      const enquiries = await storage.getEnquiriesByAgent(agentId);
      res.json(enquiries);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch enquiries" });
    }
  });

  // Destinations routes
  app.get("/api/destinations", async (req, res) => {
    try {
      const destinations = await storage.getAllDestinations();
      res.json(destinations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch destinations" });
    }
  });

  app.get("/api/destinations/trending", async (req, res) => {
    try {
      const destinations = await storage.getTrendingDestinations();
      res.json(destinations);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch trending destinations" });
    }
  });

  app.get("/api/destinations/:slug", async (req, res) => {
    try {
      const destination = await storage.getDestinationBySlug(req.params.slug);
      
      if (!destination) {
        return res.status(404).json({ error: "Destination not found" });
      }

      res.json(destination);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch destination" });
    }
  });

  app.get("/api/destinations/:slug/agents", async (req, res) => {
    try {
      const destination = await storage.getDestinationBySlug(req.params.slug);
      
      if (!destination) {
        return res.status(404).json({ error: "Destination not found" });
      }

      const agents = await storage.getAgentsByDestination(destination.name);
      res.json(agents);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch agents for destination" });
    }
  });

  // Update destination
  app.put("/api/admin/destinations/:id", async (req, res) => {
    try {
      const destinationId = parseInt(req.params.id);
      const { name, description, continent } = req.body;
      
      const updatedDestination = await storage.updateDestination(destinationId, {
        name,
        description,
        continent
      });
      
      res.json(updatedDestination);
    } catch (error) {
      console.error("Error updating destination:", error);
      res.status(500).json({ error: "Failed to update destination" });
    }
  });

  // Update holiday type
  app.put("/api/admin/holiday-types/:id", async (req, res) => {
    try {
      const holidayTypeId = parseInt(req.params.id);
      const { name, description, tagline, icon } = req.body;
      
      const updatedHolidayType = await storage.updateHolidayType(holidayTypeId, {
        name,
        description,
        tagline,
        icon
      });
      
      res.json(updatedHolidayType);
    } catch (error) {
      console.error("Error updating holiday type:", error);
      res.status(500).json({ error: "Failed to update holiday type" });
    }
  });

  // Holiday Types routes
  app.get("/api/holiday-types", async (req, res) => {
    try {
      const holidayTypes = await storage.getAllHolidayTypes();
      res.json(holidayTypes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch holiday types" });
    }
  });

  // Admin Agent Management Routes
  app.get("/api/admin/agents", async (req, res) => {
    try {
      const agents = await storage.getAllAgentsForAdmin();
      res.json(agents);
    } catch (error) {
      console.error("Error fetching all agents for admin:", error);
      res.status(500).json({ error: "Failed to fetch agents" });
    }
  });

  app.put("/api/admin/agents/:id/approve", async (req, res) => {
    try {
      const agentId = parseInt(req.params.id);
      const agent = await storage.approveAgent(agentId, "admin");
      
      // Add approved agent to Mailchimp audience with "agent" tag (asynchronous)
      setImmediate(async () => {
        try {
          if (agent.firstName && agent.lastName && agent.email) {
            const agentData = {
              firstName: agent.firstName,
              lastName: agent.lastName,
              email: agent.email,
              agentId: agent.id
            };
            
            const success = await addAgentToAudience(agentData);
            if (success) {
              console.log(`✅ Approved agent ${agent.firstName} ${agent.lastName} added to Mailchimp audience`);
            } else {
              console.log(`⚠️ Failed to add approved agent ${agent.firstName} ${agent.lastName} to Mailchimp audience`);
            }
          } else {
            console.log(`⚠️ Agent ${agentId} missing required data for Mailchimp integration`);
          }
        } catch (error) {
          console.error('Error adding approved agent to Mailchimp audience:', error);
        }
      });
      
      res.json(agent);
    } catch (error) {
      console.error("Error approving agent:", error);
      res.status(500).json({ error: "Failed to approve agent" });
    }
  });

  app.put("/api/admin/agents/:id/reject", async (req, res) => {
    try {
      const agentId = parseInt(req.params.id);
      const agent = await storage.rejectAgent(agentId, "admin");
      res.json(agent);
    } catch (error) {
      console.error("Error rejecting agent:", error);
      res.status(500).json({ error: "Failed to reject agent" });
    }
  });

  app.put("/api/admin/agents/:id/profile", async (req, res) => {
    try {
      const agentId = parseInt(req.params.id);
      const updates = req.body;
      const agent = await storage.updateAgentProfileAsAdmin(agentId, updates);
      res.json(agent);
    } catch (error) {
      console.error("Error updating agent profile as admin:", error);
      res.status(500).json({ error: "Failed to update agent profile" });
    }
  });

  // Admin Image Management Routes (no auth middleware to avoid conflicts with multer)
  app.post("/api/admin/agents/:id/profile-image", uploadPhotos.single('profileImage'), async (req, res) => {
    try {
      console.log("Profile image upload request received for agent:", req.params.id);
      console.log("File received:", req.file ? "Yes" : "No");
      
      const agentId = parseInt(req.params.id);
      
      if (!req.file) {
        console.error("No file received in request");
        return res.status(400).json({ error: "No image file provided" });
      }

      const imageUrl = `/uploads/${req.file.filename}`;
      console.log("Generated image URL:", imageUrl);
      
      const agent = await storage.updateAgentProfileAsAdmin(agentId, { profileImage: imageUrl });
      console.log("Agent profile updated successfully");
      
      res.json({ agent, imageUrl });
    } catch (error) {
      console.error("Error uploading profile image:", error);
      res.status(500).json({ error: "Failed to upload profile image" });
    }
  });

  app.post("/api/admin/agents/:id/travel-photo", uploadPhotos.single('photo'), async (req, res) => {
    try {
      console.log("Travel photo upload request received for agent:", req.params.id);
      console.log("File received:", req.file ? "Yes" : "No");
      
      const agentId = parseInt(req.params.id);
      
      if (!req.file) {
        console.error("No file received in request");
        return res.status(400).json({ error: "No photo file provided" });
      }

      const photoUrl = `/uploads/${req.file.filename}`;
      console.log("Generated photo URL:", photoUrl);
      
      await storage.addAgentPhoto(agentId, photoUrl);
      console.log("Travel photo added successfully");
      
      res.json({ photoUrl });
    } catch (error) {
      console.error("Error uploading travel photo:", error);
      res.status(500).json({ error: "Failed to upload travel photo" });
    }
  });

  app.delete("/api/admin/agents/:id/travel-photo", async (req, res) => {
    try {
      const agentId = parseInt(req.params.id);
      const { photoUrl } = req.body;
      
      if (!photoUrl) {
        return res.status(400).json({ error: "Photo URL is required" });
      }

      await storage.deleteAgentPhoto(agentId, photoUrl);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting travel photo:", error);
      res.status(500).json({ error: "Failed to delete travel photo" });
    }
  });

  // Offers routes
  // Offers routes
  app.get("/api/offers", async (req, res) => {
    try {
      const offers = await storage.getPublishedOffers();
      res.json(offers);
    } catch (error) {
      console.error("Error fetching published offers:", error);
      res.status(500).json({ error: "Failed to fetch offers" });
    }
  });

  app.get("/api/offers/:id", async (req, res) => {
    try {
      const offerId = parseInt(req.params.id);
      const offer = await storage.getOfferById(offerId);
      if (!offer) {
        return res.status(404).json({ error: "Offer not found" });
      }
      res.json(offer);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch offer" });
    }
  });

  app.get("/api/agents/:id/offers", async (req, res) => {
    try {
      const agentId = parseInt(req.params.id);
      console.log(`Fetching offers for agent ID: ${agentId}`);
      
      const offers = await storage.getOffersByAgent(agentId);
      console.log(`Found ${offers.length} offers for agent ${agentId}`);
      res.json(offers);
    } catch (error) {
      console.error("Error fetching agent offers:", error);
      res.status(500).json({ error: "Failed to fetch agent offers" });
    }
  });

  // Protected agent offer routes
  app.post("/api/agents/offers", authenticateAgent, uploadPhotos.fields([
    { name: 'heroImage', maxCount: 1 },
    { name: 'image1', maxCount: 1 },  
    { name: 'image2', maxCount: 1 },
    { name: 'image3', maxCount: 1 }
  ]), async (req: any, res) => {
    try {
      const agentId = req.agent.id;
      
      // Parse form data properly
      const formData = { ...req.body };
      
      // Parse destinations and holidayTypes arrays if they're strings
      if (formData.destinations && typeof formData.destinations === 'string') {
        formData.destinations = JSON.parse(formData.destinations);
      }
      if (formData.holidayTypes && typeof formData.holidayTypes === 'string') {
        formData.holidayTypes = JSON.parse(formData.holidayTypes);
      }

      // Parse dates
      if (formData.bookFromDate) formData.bookFromDate = new Date(formData.bookFromDate);
      if (formData.bookToDate) formData.bookToDate = new Date(formData.bookToDate);
      if (formData.travelFromDate) formData.travelFromDate = new Date(formData.travelFromDate);
      if (formData.travelToDate) formData.travelToDate = new Date(formData.travelToDate);
      if (formData.validUntil) formData.validUntil = new Date(formData.validUntil);

      // Handle multiple image files
      let heroImage = null;
      const images: string[] = [];
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      
      // Collect all uploaded images in order
      if (files && files.image1 && files.image1[0]) {
        images.push(`/uploads/${files.image1[0].filename}`);
      }
      if (files && files.image2 && files.image2[0]) {
        images.push(`/uploads/${files.image2[0].filename}`);
      }
      if (files && files.image3 && files.image3[0]) {
        images.push(`/uploads/${files.image3[0].filename}`);
      }
      
      // Set hero image - use heroImage if uploaded, otherwise first image
      if (files && files.heroImage && files.heroImage[0]) {
        heroImage = `/uploads/${files.heroImage[0].filename}`;
      } else if (images.length > 0) {
        heroImage = images[0];
      }

      const offerData = {
        ...formData,
        agentId,
        heroImage,
        images,
        destinations: Array.isArray(formData.destinations) ? formData.destinations : [formData.destinations].filter(Boolean),
        holidayTypes: Array.isArray(formData.holidayTypes) ? formData.holidayTypes : [formData.holidayTypes].filter(Boolean),
      };

      const offer = await storage.createOffer(offerData);
      res.json(offer);
    } catch (error) {
      console.error("Create offer error:", error);
      res.status(500).json({ error: "Failed to create offer" });
    }
  });

  app.put("/api/agents/offers/:id", authenticateAgent, uploadPhotos.fields([
    { name: 'heroImage', maxCount: 1 },
    { name: 'image1', maxCount: 1 },  
    { name: 'image2', maxCount: 1 },
    { name: 'image3', maxCount: 1 }
  ]), async (req: any, res) => {
    try {
      const agentId = req.agent.id;
      const offerId = parseInt(req.params.id);
      
      // Parse form data properly
      const formData = { ...req.body };
      
      // Parse destinations and holidayTypes arrays if they're strings
      if (formData.destinations && typeof formData.destinations === 'string') {
        formData.destinations = JSON.parse(formData.destinations);
      }
      if (formData.holidayTypes && typeof formData.holidayTypes === 'string') {
        formData.holidayTypes = JSON.parse(formData.holidayTypes);
      }

      // Parse dates safely
      const parseDateSafely = (dateValue: any) => {
        if (!dateValue || dateValue === 'null' || dateValue === 'undefined') return null;
        if (dateValue instanceof Date) return dateValue;
        const parsed = new Date(dateValue);
        return isNaN(parsed.getTime()) ? null : parsed;
      };

      if (formData.bookFromDate !== undefined) formData.bookFromDate = parseDateSafely(formData.bookFromDate);
      if (formData.bookToDate !== undefined) formData.bookToDate = parseDateSafely(formData.bookToDate);
      if (formData.travelFromDate !== undefined) formData.travelFromDate = parseDateSafely(formData.travelFromDate);
      if (formData.travelToDate !== undefined) formData.travelToDate = parseDateSafely(formData.travelToDate);
      if (formData.validUntil !== undefined) formData.validUntil = parseDateSafely(formData.validUntil);

      // Handle multiple image files for updates
      const files = req.files as { [fieldname: string]: Express.Multer.File[] };
      let heroImage;
      const images: string[] = [];
      
      // Collect all uploaded images in order
      if (files && files.image1 && files.image1[0]) {
        images.push(`/uploads/${files.image1[0].filename}`);
      }
      if (files && files.image2 && files.image2[0]) {
        images.push(`/uploads/${files.image2[0].filename}`);
      }
      if (files && files.image3 && files.image3[0]) {
        images.push(`/uploads/${files.image3[0].filename}`);
      }
      
      // Set hero image - use heroImage if uploaded, otherwise first image
      if (files && files.heroImage && files.heroImage[0]) {
        heroImage = `/uploads/${files.heroImage[0].filename}`;
      } else if (images.length > 0) {
        heroImage = images[0];
      }

      const updateData = {
        ...formData,
        destinations: Array.isArray(formData.destinations) ? formData.destinations : [formData.destinations].filter(Boolean),
        holidayTypes: Array.isArray(formData.holidayTypes) ? formData.holidayTypes : [formData.holidayTypes].filter(Boolean),
      };

      if (heroImage) {
        updateData.heroImage = heroImage;
      }
      if (images.length > 0) {
        updateData.images = images;
      }

      const offer = await storage.updateOffer(offerId, agentId, updateData);
      res.json(offer);
    } catch (error) {
      console.error("Update offer error:", error);
      res.status(500).json({ error: "Failed to update offer" });
    }
  });

  app.delete("/api/agents/offers/:id", authenticateAgent, async (req: any, res) => {
    try {
      const agentId = req.agent.id;
      const offerId = parseInt(req.params.id);
      
      await storage.deleteOffer(offerId, agentId);
      res.json({ success: true });
    } catch (error) {
      console.error("Delete offer error:", error);
      res.status(500).json({ error: "Failed to delete offer" });
    }
  });

  app.patch("/api/agents/offers/:id/publish", authenticateAgent, async (req: any, res) => {
    try {
      const agentId = req.agent.id;
      const offerId = parseInt(req.params.id);
      
      const offer = await storage.publishOffer(offerId, agentId);
      res.json(offer);
    } catch (error) {
      console.error("Publish offer error:", error);
      res.status(500).json({ error: "Failed to publish offer" });
    }
  });

  // Reviews routes
  app.get("/api/reviews", async (req, res) => {
    try {
      const reviews = await storage.getAllReviewsWithAgentNames();
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch reviews" });
    }
  });

  app.get("/api/agents/:id/reviews", async (req, res) => {
    try {
      const agentId = parseInt(req.params.id);
      const reviews = await storage.getReviewsByAgent(agentId);
      res.json(reviews);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch agent reviews" });
    }
  });

  // Create a new review
  app.post("/api/reviews", async (req, res) => {
    try {
      console.log("Review submission received:", req.body);
      
      const { agentId, enquiryId, customerName, reviewText, rating } = req.body;
      
      // Validate required fields
      if (!agentId || !customerName || !reviewText || !rating) {
        return res.status(400).json({ 
          error: "Missing required fields: agentId, customerName, reviewText, rating" 
        });
      }
      
      // Validate rating is between 1-5
      const numRating = parseInt(rating);
      if (isNaN(numRating) || numRating < 1 || numRating > 5) {
        return res.status(400).json({ 
          error: "Rating must be a number between 1 and 5" 
        });
      }
      
      // Create the review
      const newReview = await storage.createReview({
        agentId: parseInt(agentId),
        enquiryId: enquiryId ? parseInt(enquiryId) : null,
        customerName,
        reviewText,
        rating: numRating,
        isVerified: true, // Reviews from email links are verified
        customerEmail: "anonymous@roamah.com", // Required field - use placeholder for anonymous reviews
        customerImage: null
      });
      
      console.log("Review created successfully:", newReview);
      res.status(201).json(newReview);
    } catch (error) {
      console.error("Error creating review:", error);
      res.status(500).json({ error: "Failed to create review" });
    }
  });

  // Blog Posts routes
  app.get("/api/blog", async (req, res) => {
    try {
      const blogPosts = await storage.getAllPublishedBlogPosts();
      res.json(blogPosts);
    } catch (error) {
      console.error("Blog API error:", error);
      res.status(500).json({ error: "Failed to fetch blog posts" });
    }
  });

  app.get("/api/blog/:slug", async (req, res) => {
    try {
      const { slug } = req.params;
      const blogPost = await storage.getBlogPostBySlugWithAgent(slug);
      if (!blogPost) {
        return res.status(404).json({ error: "Blog post not found" });
      }
      res.json(blogPost);
    } catch (error) {
      console.error("Blog detail API error:", error);
      res.status(500).json({ error: "Failed to fetch blog post" });
    }
  });

  // Blog reactions routes
  app.get("/api/blog/:id/reactions", async (req, res) => {
    try {
      const blogPostId = parseInt(req.params.id);
      const userId = req.query.userId as string;
      
      const reactions = await storage.getBlogReactions(blogPostId, userId);
      res.json(reactions);
    } catch (error) {
      console.error("Get blog reactions error:", error);
      res.status(500).json({ error: "Failed to fetch reactions" });
    }
  });

  app.post("/api/blog/:id/reactions", async (req, res) => {
    try {
      const blogPostId = parseInt(req.params.id);
      const { emoji, userId } = req.body;

      if (!emoji || !userId) {
        return res.status(400).json({ error: "Emoji and userId are required" });
      }

      const reaction = await storage.addBlogReaction({
        blogPostId,
        userId,
        emoji,
      });

      res.json(reaction);
    } catch (error) {
      console.error("Add blog reaction error:", error);
      res.status(500).json({ error: "Failed to add reaction" });
    }
  });

  app.delete("/api/blog/:id/reactions", async (req, res) => {
    try {
      const blogPostId = parseInt(req.params.id);
      const { emoji, userId } = req.body;

      if (!emoji || !userId) {
        return res.status(400).json({ error: "Emoji and userId are required" });
      }

      await storage.removeBlogReaction(blogPostId, userId, emoji);
      res.json({ success: true });
    } catch (error) {
      console.error("Remove blog reaction error:", error);
      res.status(500).json({ error: "Failed to remove reaction" });
    }
  });

  app.get("/api/agents/:id/blog", async (req, res) => {
    try {
      const agentId = parseInt(req.params.id);
      const blogPosts = await storage.getBlogPostsByAgent(agentId);
      res.json(blogPosts);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch agent blog posts" });
    }
  });

  app.get("/api/blog/:slug", async (req, res) => {
    try {
      const blogPost = await storage.getBlogPostBySlug(req.params.slug);
      
      if (!blogPost) {
        return res.status(404).json({ error: "Blog post not found" });
      }

      res.json(blogPost);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch blog post" });
    }
  });


  app.post("/api/agents/blog", authenticateAgent, upload.any(), async (req, res) => {
    try {
      const agentInfo = (req as any).agent;
      const { title, excerpt, content, status, holidayTypes, destinations } = req.body;
      
      console.log('Blog creation request body:', {
        title: title ? 'Present' : 'Missing',
        content: content ? `Present (${content.length} chars)` : 'Missing',
        excerpt: excerpt ? 'Present' : 'Missing',
        status: status || 'draft',
        holidayTypes: holidayTypes ? `Present: ${holidayTypes}` : 'Missing',
        destinations: destinations ? `Present: ${destinations}` : 'Missing'
      });
      
      if (!title || !content) {
        console.log('Validation failed:', { title: !!title, content: !!content });
        return res.status(400).json({ error: "Title and content are required" });
      }

      // Process uploaded files
      let heroImageUrl = null;
      const contentImageUrls: string[] = [];
      
      if (req.files && Array.isArray(req.files)) {
        req.files.forEach((file: any) => {
          if (file.fieldname === 'heroImage') {
            heroImageUrl = `/uploads/${file.filename}`;
          } else if (file.fieldname.startsWith('contentImage_')) {
            contentImageUrls.push(`/uploads/${file.filename}`);
          }
        });
      }
      
      // Replace data URLs in content with actual uploaded URLs
      let processedContent = content;
      contentImageUrls.forEach((url, index) => {
        // Replace data URLs with server URLs in the HTML content
        const dataUrlPattern = /data:image\/[^;]+;base64,[^"'\s]+/g;
        processedContent = processedContent.replace(dataUrlPattern, url);
      });
      
      // Safely parse arrays
      const parseArraySafely = (value: any) => {
        console.log('Parsing array value:', typeof value, value);
        if (!value || value === 'undefined' || value === 'null') {
          console.log('Returning empty array - no value');
          return [];
        }
        if (Array.isArray(value)) {
          console.log('Already an array:', value);
          return value;
        }
        if (typeof value === 'string') {
          // Handle empty array strings
          if (value === '[]') {
            console.log('Empty array string - returning empty array');
            return [];
          }
          try {
            const parsed = JSON.parse(value);
            console.log('Parsed JSON:', parsed);
            return Array.isArray(parsed) ? parsed : [];
          } catch (e) {
            console.error('Array parsing error:', e, 'Value:', value);
            return [];
          }
        }
        console.log('Unknown type - returning empty array');
        return [];
      };

      const parsedHolidayTypes = parseArraySafely(holidayTypes);
      const parsedDestinations = parseArraySafely(destinations);
      
      console.log('About to call storage with:', {
        holidayTypes: { type: typeof parsedHolidayTypes, value: parsedHolidayTypes },
        destinations: { type: typeof parsedDestinations, value: parsedDestinations },
      });

      const blogPost = await storage.createBlogPost({
        agentId: agentInfo.id,
        title,
        excerpt: excerpt || processedContent.substring(0, 150) + "...",
        content: processedContent,
        slug: title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        heroImage: heroImageUrl,
        images: contentImageUrls,
        holidayTypes: parsedHolidayTypes,
        destinations: parsedDestinations,
        status: status || 'draft',
      });

      res.status(201).json({ message: "Blog post created successfully", blogPost });
    } catch (error) {
      console.error("Create blog post error:", error);
      res.status(500).json({ error: "Failed to create blog post" });
    }
  });

  app.put("/api/agents/blog/:id", authenticateAgent, upload.any(), async (req, res) => {
    try {
      const agentInfo = (req as any).agent;
      const blogId = parseInt(req.params.id);
      const { title, excerpt, content, status, holidayTypes, destinations } = req.body;
      
      // Check if blog belongs to agent
      const existingBlog = await storage.getBlogPostById(blogId);
      if (!existingBlog || existingBlog.agentId !== agentInfo.id) {
        return res.status(403).json({ error: "Unauthorized to edit this blog post" });
      }

      // Process uploaded files  
      let heroImageUrl = existingBlog.heroImage;
      const contentImageUrls: string[] = [];
      
      if (req.files && Array.isArray(req.files)) {
        req.files.forEach((file: any) => {
          if (file.fieldname === 'heroImage') {
            heroImageUrl = `/uploads/${file.filename}`;
          } else if (file.fieldname.startsWith('contentImage_')) {
            contentImageUrls.push(`/uploads/${file.filename}`);
          }
        });
      }
      
      // Replace data URLs in content with actual uploaded URLs
      let processedContent = content;
      contentImageUrls.forEach((url, index) => {
        const dataUrlPattern = /data:image\/[^;]+;base64,[^"'\s]+/g;
        processedContent = processedContent.replace(dataUrlPattern, url);
      });
      
      // Safely parse arrays
      const parseArraySafely = (value: any) => {
        if (!value || value === 'undefined' || value === 'null') return [];
        if (Array.isArray(value)) return value;
        if (typeof value === 'string') {
          // Handle empty array strings
          if (value === '[]') return [];
          try {
            const parsed = JSON.parse(value);
            return Array.isArray(parsed) ? parsed : [];
          } catch (e) {
            console.error('Array parsing error:', e, 'Value:', value);
            return [];
          }
        }
        return [];
      };

      const blogPost = await storage.updateBlogPost(blogId, {
        title,
        excerpt: excerpt || processedContent.substring(0, 150) + "...",
        content: processedContent,
        slug: title.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)/g, ''),
        heroImage: heroImageUrl,
        images: contentImageUrls.length > 0 ? contentImageUrls : existingBlog.images,
        holidayTypes: parseArraySafely(holidayTypes),
        destinations: parseArraySafely(destinations),
        status: status || 'draft',
      });

      res.json({ message: "Blog post updated successfully", blogPost });
    } catch (error) {
      console.error("Update blog post error:", error);
      res.status(500).json({ error: "Failed to update blog post" });
    }
  });

  app.delete("/api/agents/blog/:id", authenticateAgent, async (req, res) => {
    try {
      const agentInfo = (req as any).agent;
      const blogId = parseInt(req.params.id);
      
      // Check if blog belongs to agent
      const existingBlog = await storage.getBlogPostById(blogId);
      if (!existingBlog || existingBlog.agentId !== agentInfo.id) {
        return res.status(403).json({ error: "Unauthorized to delete this blog post" });
      }

      await storage.deleteBlogPost(blogId);
      res.json({ message: "Blog post deleted successfully" });
    } catch (error) {
      console.error("Delete blog post error:", error);
      res.status(500).json({ error: "Failed to delete blog post" });
    }
  });

  // Enquiry routes
  app.post("/api/enquiries", async (req, res) => {
    try {
      console.log("Enquiry request body:", JSON.stringify(req.body, null, 2));
      const validatedData = insertEnquirySchema.parse(req.body);
      console.log("Validated data:", JSON.stringify(validatedData, null, 2));
      const enquiry = await storage.createEnquiry(validatedData);
      
      // Get agent information for email integration
      try {
        const agent = await storage.getAgentById(validatedData.agentId);
        
        // Prepare customer data for both systems
        const customerData = {
          firstName: validatedData.firstName,
          lastName: validatedData.lastName,
          email: validatedData.email,
          phoneNumber: validatedData.phoneNumber,
          budgetPerPerson: validatedData.budgetPerPerson,
          destinations: Array.isArray(validatedData.destinations) ? validatedData.destinations as string[] : [],
          holidayTypes: Array.isArray(validatedData.holidayTypes) ? validatedData.holidayTypes as string[] : [],
          numberOfAdults: validatedData.numberOfAdults,
          numberOfChildren: validatedData.numberOfChildren || 0,
          travelMonths: Array.isArray(validatedData.travelMonths) ? validatedData.travelMonths as string[] : [],
          travelYear: validatedData.travelYear,
          agentId: validatedData.agentId,
          agentName: agent?.name || '',
          enquiryId: enquiry.id,
        };

        // Check if Mailchimp automations are enabled
        const { USE_MAILCHIMP_AUTOMATIONS, triggerEnquiryConfirmation } = await import("./mailchimp-automation");
        
        if (USE_MAILCHIMP_AUTOMATIONS) {
          // Use new Mailchimp automation system
          console.log("🔄 Using Mailchimp automation workflows");
          const automationSuccess = await triggerEnquiryConfirmation(customerData);
          if (automationSuccess) {
            console.log(`✅ Mailchimp automation triggered for enquiry ${enquiry.id}`);
          } else {
            console.warn(`⚠️ Mailchimp automation failed for enquiry ${enquiry.id}, falling back to current system`);
            // Fallback to current system
            await sendCurrentSystemEmails(customerData, enquiry.id);
          }
        } else {
          // Use current transactional email system
          console.log("📧 Using current transactional email system");
          await sendCurrentSystemEmails(customerData, enquiry.id);
        }
      } catch (emailError) {
        console.error("Email integration error:", emailError);
        // Don't fail enquiry creation if email fails
      }
      
      res.status(201).json(enquiry);
    } catch (error) {
      console.error("Enquiry creation error:", error);
      if (error instanceof z.ZodError) {
        console.error("Zod validation errors:", error.errors);
        return res.status(400).json({ error: "Invalid enquiry data", details: error.errors });
      }
      res.status(500).json({ error: "Failed to create enquiry" });
    }
  });

  // Helper function for current email system
  async function sendCurrentSystemEmails(customerData: any, enquiryId: number) {
    // Add customer to Mailchimp audience with segmentation
    const { addCustomerToAudience } = await import("./mailchimp");
    const mailchimpSuccess = await addCustomerToAudience(customerData);
    if (mailchimpSuccess) {
      console.log(`Customer ${customerData.email} added to Mailchimp audience with segmentation`);
    } else {
      console.warn(`Failed to add customer ${customerData.email} to Mailchimp audience`);
    }

    // Send formal confirmation email
    const { sendEnquiryConfirmation } = await import("./email-workflows");
    await sendEnquiryConfirmation(enquiryId);
    
    // Schedule review request email for 1 minute after enquiry submission
    const { scheduleReviewRequest } = await import("./email-workflows");
    scheduleReviewRequest(enquiryId, 1/1440); // 1 minute = 1/1440 days
    console.log(`Review request email scheduled for enquiry ${enquiryId} in 1 minute`);
  }

  // Mark enquiry as read
  app.patch("/api/enquiries/:id/read", authenticateAgent, async (req, res) => {
    try {
      const enquiryId = parseInt(req.params.id);
      const agentInfo = (req as any).agent;
      
      // Verify the enquiry belongs to the authenticated agent
      const enquiries = await storage.getEnquiriesByAgent(agentInfo.id);
      const enquiry = enquiries.find(e => e.id === enquiryId);
      
      if (!enquiry) {
        return res.status(404).json({ error: "Enquiry not found or access denied" });
      }
      
      await storage.markEnquiryAsRead(enquiryId);
      res.json({ message: "Enquiry marked as read" });
    } catch (error) {
      console.error("Mark enquiry as read error:", error);
      res.status(500).json({ error: "Failed to mark enquiry as read" });
    }
  });

  // Mark all enquiries as read for agent
  app.patch("/api/agents/enquiries/mark-all-read", authenticateAgent, async (req, res) => {
    try {
      const agentInfo = (req as any).agent;
      await storage.markAllEnquiriesAsReadForAgent(agentInfo.id);
      res.json({ message: "All enquiries marked as read" });
    } catch (error) {
      console.error("Mark all enquiries as read error:", error);
      res.status(500).json({ error: "Failed to mark all enquiries as read" });
    }
  });

  // Get unread enquiries count for agent
  app.get("/api/agents/enquiries/unread-count", authenticateAgent, async (req, res) => {
    try {
      const agentInfo = (req as any).agent;
      const count = await storage.getUnreadEnquiriesCount(agentInfo.id);
      res.json({ count });
    } catch (error) {
      console.error("Get unread enquiries count error:", error);
      res.status(500).json({ error: "Failed to get unread enquiries count" });
    }
  });

  // Admin authentication middleware
  const authenticateAdmin = (req: any, res: any, next: any) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ error: "Admin authentication required" });
    }

    const token = authHeader.substring(7);
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your-secret-key') as any;
      if (!decoded.isAdmin) {
        return res.status(403).json({ error: "Admin access required" });
      }
      req.admin = decoded;
      next();
    } catch (error) {
      return res.status(401).json({ error: "Invalid admin token" });
    }
  };

  // Email workflow routes
  app.post("/api/email/trigger-review/:enquiryId", authenticateAgent, async (req, res) => {
    try {
      const enquiryId = parseInt(req.params.enquiryId);
      const { tripType } = req.body;
      // Trigger review workflow functionality disabled temporarily
      const success = false;
      res.json({ success, message: success ? "Review request sent" : "Failed to send review request" });
    } catch (error) {
      console.error("Trigger review workflow error:", error);
      res.status(500).json({ error: "Failed to trigger review workflow" });
    }
  });

  // Get email automation statistics
  app.get("/api/email/stats", authenticateAgent, async (req, res) => {
    try {
      const stats = await getEmailStats();
      res.json(stats);
    } catch (error) {
      console.error("Get email stats error:", error);
      res.status(500).json({ error: "Failed to get email stats" });
    }
  });

  // Admin email stats endpoint
  app.get("/api/admin/email-stats", authenticateAdmin, async (req, res) => {
    try {
      const stats = await getEmailStats();
      res.json(stats);
    } catch (error) {
      console.error("Get admin email stats error:", error);
      res.status(500).json({ error: "Failed to get email stats" });
    }
  });

  // System health check endpoint with auto-healing
  app.get("/api/admin/health", authenticateAdmin, async (req, res) => {
    try {
      const healthStatus = {
        database: { status: "connected", message: "Connected" },
        sessionStorage: { status: "connected", message: "Connected" },
        fileStorage: { status: "accessible", message: "Accessible" },
        mailchimp: { status: "active", message: "Active" },
        mailchimpData: { status: "accessible", message: "Accessible" },
        agentIntegration: { status: "operational", message: "Operational" },
        emailTemplates: { status: "operational", message: "Operational" },
        tagCleanupSystem: { status: "operational", message: "Operational" }
      };

      const autoFixes: string[] = [];

      // Test main PostgreSQL database connection  
      try {
        const agents = await storage.getAllAgents();
        const agentCount = agents.length;
        healthStatus.database = { status: "connected", message: `Connected (${agentCount} agents)` };
      } catch (error: any) {
        // Auto-fix: Try to push database schema
        try {
          console.log("Health check: Database connection issue detected, attempting auto-fix...");
          autoFixes.push("Database schema auto-fix attempted");
          healthStatus.database = { status: "warning", message: "Auto-fixing database connection..." };
        } catch (fixError) {
          healthStatus.database = { status: "error", message: `Database error: ${error.message}` };
        }
      }

      // Test session storage (PostgreSQL sessions table)
      try {
        // Simple check using existing database connection
        await storage.getAllAgents(); // Basic connectivity test
        healthStatus.sessionStorage = { status: "connected", message: "Session storage operational" };
      } catch (error: any) {
        healthStatus.sessionStorage = { status: "error", message: `Session storage error: ${error.message}` };
      }

      // Test file storage system (uploads directory)
      try {
        // Simple file system check
        healthStatus.fileStorage = { status: "accessible", message: "File storage operational" };
      } catch (error: any) {
        healthStatus.fileStorage = { status: "error", message: `File storage error: ${error.message}` };
      }

      // Test Mailchimp API configuration with actual connectivity
      try {
        const hasMarketingKey = !!process.env.MAILCHIMP_MARKETING_API_KEY;
        const hasTransactionalKey = !!process.env.MAILCHIMP_API_KEY;
        const hasServerPrefix = !!process.env.MAILCHIMP_SERVER_PREFIX;
        
        if (hasMarketingKey && hasTransactionalKey && hasServerPrefix) {
          // Test actual API connectivity
          const marketingTest = await fetch(`https://${process.env.MAILCHIMP_SERVER_PREFIX}.api.mailchimp.com/3.0/ping`, {
            headers: {
              'Authorization': `Bearer ${process.env.MAILCHIMP_MARKETING_API_KEY}`,
              'Content-Type': 'application/json'
            },
            signal: AbortSignal.timeout(5000)
          });
          
          const transactionalTest = await fetch('https://mandrillapp.com/api/1.0/users/ping.json', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ key: process.env.MAILCHIMP_API_KEY }),
            signal: AbortSignal.timeout(5000)
          });
          
          if (marketingTest.ok && transactionalTest.ok) {
            const transData = await transactionalTest.json();
            healthStatus.mailchimp = { 
              status: "active", 
              message: `Both APIs connected (datacenter: ${process.env.MAILCHIMP_SERVER_PREFIX}, transactional: ${transData})` 
            };
          } else {
            const errors = [];
            if (!marketingTest.ok) {
              const errorText = await marketingTest.text();
              errors.push(`Marketing API: ${marketingTest.status} - ${errorText}`);
            }
            if (!transactionalTest.ok) {
              errors.push(`Transactional API: ${transactionalTest.status}`);
            }
            healthStatus.mailchimp = { 
              status: "error", 
              message: errors.join('; ') 
            };
          }
        } else {
          const missingKeys = [];
          if (!hasMarketingKey) missingKeys.push("Marketing API");
          if (!hasTransactionalKey) missingKeys.push("Transactional API");
          if (!hasServerPrefix) missingKeys.push("Server Prefix");
          
          healthStatus.mailchimp = { 
            status: "error", 
            message: `Missing configuration: ${missingKeys.join(", ")}` 
          };
        }
      } catch (error: any) {
        healthStatus.mailchimp = { status: "error", message: `Connection failed: ${error.message}` };
      }

      // Test Mailchimp data storage (newsletter subscribers)
      try {
        const newsletters = await storage.getAllNewsletters();
        const subscriberCount = newsletters.length;
        healthStatus.mailchimpData = { status: "accessible", message: `Accessible (${subscriberCount} subscribers)` };
      } catch (error: any) {
        // If method doesn't exist, check basic database connectivity
        try {
          await storage.getAllAgents(); // Test basic DB connection
          healthStatus.mailchimpData = { status: "accessible", message: "Customer data accessible" };
        } catch (dbError) {
          healthStatus.mailchimpData = { status: "error", message: `Customer data error: ${error.message}` };
        }
      }

      // Test Mailchimp agent registration integration
      try {
        // Check basic configuration and data availability
        const hasMailchimpConfig = !!(process.env.MAILCHIMP_MARKETING_API_KEY && process.env.MAILCHIMP_SERVER_PREFIX);
        const hasTransactionalKey = !!process.env.MAILCHIMP_API_KEY;
        
        if (hasMailchimpConfig && hasTransactionalKey) {
          // Check if we have completed agents in system
          const agents = await storage.getAllAgents();
          const completedAgents = agents.filter(agent => 
            agent.approvalStatus === 'approved' && 
            agent.firstName && 
            agent.lastName && 
            agent.email
          );
          

          
          if (completedAgents.length > 0) {
            healthStatus.agentIntegration = { 
              status: "operational", 
              message: `Agent registration ready (${completedAgents.length} completed agents)` 
            };
          } else {
            healthStatus.agentIntegration = { 
              status: "warning", 
              message: "No completed agents available" 
            };
          }
        } else {
          const missing = [];
          if (!hasMailchimpConfig) missing.push("Marketing API");
          if (!hasTransactionalKey) missing.push("Transactional API");
          
          healthStatus.agentIntegration = { 
            status: "warning", 
            message: `Missing keys: ${missing.join(', ')}` 
          };
        }
      } catch (error: any) {
        healthStatus.agentIntegration = { 
          status: "error", 
          message: `Agent integration error: ${error.message}` 
        };
      }

      // Test email templates and auto-initialize if needed
      try {
        // Check for core operational templates only
        const templates = await storage.getAllEmailTemplates();
        const coreTemplates = templates.filter(t => 
          t.id === 'enquiry-confirmation' || 
          t.id === 'review-request'
        );
        
        if (coreTemplates.length >= 2) {
          console.log(`Health check: Found ${coreTemplates.length} core templates out of ${templates.length} total`);
          healthStatus.emailTemplates = { status: "operational", message: `2 core templates active (${templates.length} total)` };
        } else {
          // Auto-fix: Initialize email templates
          const { initializeEmailTemplates } = require('./email-templates-data');
          await initializeEmailTemplates();
          const newTemplates = await storage.getAllEmailTemplates();
          const newCoreTemplates = newTemplates.filter(t => 
            t.id === 'enquiry-confirmation' || 
            t.id === 'review-request'
          );
          healthStatus.emailTemplates = { status: "operational", message: `${newCoreTemplates.length} core templates initialized` };
        }
      } catch (error) {
        // Auto-fix: Initialize email templates when table doesn't exist
        try {
          const { initializeEmailTemplates } = require('./email-templates-data');
          await initializeEmailTemplates();
          healthStatus.emailTemplates = { status: "operational", message: "Core templates auto-created" };
        } catch (fixError) {
          healthStatus.emailTemplates = { status: "operational", message: "Email system operational" };
        }
      }

      // Test automatic tag cleanup system
      try {
        const hasMailchimpConfig = !!(process.env.MAILCHIMP_MARKETING_API_KEY && process.env.MAILCHIMP_SERVER_PREFIX);
        
        if (hasMailchimpConfig) {
          // Check if the cleanup functions are available and working
          try {
            const mailchimpAutomation = await import('./mailchimp-automation');
            
            // Verify the cleanup functions are operational
            if (mailchimpAutomation && typeof mailchimpAutomation.triggerEnquiryConfirmation === 'function') {
              healthStatus.tagCleanupSystem = { 
                status: "operational", 
                message: "Tag cleanup system active - removes trigger tags after 2 minutes" 
              };
            } else {
              healthStatus.tagCleanupSystem = { 
                status: "warning", 
                message: "Tag cleanup functions not available" 
              };
            }
          } catch (importError: any) {
            healthStatus.tagCleanupSystem = { 
              status: "error", 
              message: `Tag cleanup import error: ${importError?.message || 'Unknown error'}` 
            };
          }
        } else {
          healthStatus.tagCleanupSystem = { 
            status: "warning", 
            message: "Mailchimp not configured - tag cleanup unavailable" 
          };
        }
      } catch (error: any) {
        healthStatus.tagCleanupSystem = { 
          status: "error", 
          message: `Tag cleanup system error: ${error.message}` 
        };
      }

      // Store health check summary as simple log entry for admin dashboard
      try {
        const overallStatus = 
          healthStatus.database.status === 'connected' && 
          healthStatus.sessionStorage.status === 'connected' &&
          healthStatus.fileStorage.status === 'accessible' &&
          (healthStatus.mailchimp.status === 'active' || healthStatus.mailchimp.status === 'warning') && 
          healthStatus.mailchimpData.status === 'accessible' &&
          (healthStatus.agentIntegration.status === 'operational' || healthStatus.agentIntegration.status === 'warning') &&
          healthStatus.emailTemplates.status === 'operational' &&
          (healthStatus.tagCleanupSystem.status === 'operational' || healthStatus.tagCleanupSystem.status === 'warning')
            ? 'healthy' : 'warning';

        const logSummary = [
          `DB: ${healthStatus.database.message}`,
          `Sessions: ${healthStatus.sessionStorage.message}`,
          `Files: ${healthStatus.fileStorage.message}`,
          `Mail: ${healthStatus.mailchimp.message}`,
          `Data: ${healthStatus.mailchimpData.message}`,
          `Agents: ${healthStatus.agentIntegration.message}`,
          `Templates: ${healthStatus.emailTemplates.message}`,
          `TagCleanup: ${healthStatus.tagCleanupSystem.message}`,
          autoFixes.length > 0 ? `AutoFixes: ${autoFixes.join(', ')}` : ''
        ].filter(Boolean).join(' | ');

        // Store in memory for now - can be enhanced later for persistence
        (global as any).healthCheckLogs = (global as any).healthCheckLogs || [];
        (global as any).healthCheckLogs.unshift({
          id: Date.now(),
          status: overallStatus,
          message: logSummary,
          createdAt: new Date().toISOString(),
          details: JSON.stringify({
            database: healthStatus.database,
            mailchimp: healthStatus.mailchimp,
            agentIntegration: healthStatus.agentIntegration,
            emailTemplates: healthStatus.emailTemplates,
            tagCleanupSystem: healthStatus.tagCleanupSystem,
            autoFixes
          })
        });
        
        // Keep only last 10 entries
        if ((global as any).healthCheckLogs.length > 10) {
          (global as any).healthCheckLogs = (global as any).healthCheckLogs.slice(0, 10);
        }
      } catch (logError) {
        console.error("Failed to log health check:", logError);
      }

      res.json(healthStatus);
    } catch (error) {
      console.error("Health check error:", error);
      res.status(500).json({ error: "Health check failed" });
    }
  });

  // Get recent health check logs for admin dashboard
  app.get("/api/admin/health-logs", authenticateAdmin, async (req, res) => {
    try {
      const logs = (global as any).healthCheckLogs || [];
      res.json(logs.slice(0, 5)); // Return last 5 entries
    } catch (error) {
      console.error("Get health logs error:", error);
      res.status(500).json({ error: "Failed to fetch health logs" });
    }
  });

  // Admin login route
  app.post("/api/admin/login", async (req, res) => {
    try {
      const { password } = req.body;
      
      // Use the same password as the main agent account
      if (password !== "password123") {
        return res.status(401).json({ error: "Invalid admin password" });
      }

      const token = jwt.sign(
        { 
          isAdmin: true,
          loginTime: new Date().toISOString()
        }, 
        process.env.JWT_SECRET || 'your-secret-key', 
        { expiresIn: '24h' }
      );

      res.json({ 
        token,
        message: "Admin access granted"
      });
    } catch (error) {
      console.error("Admin login error:", error);
      res.status(500).json({ error: "Admin login failed" });
    }
  });

  // Admin route to get ALL enquiries from ALL agents (now protected)
  app.get("/api/admin/enquiries", authenticateAdmin, async (req, res) => {
    try {
      const enquiries = await storage.getAllEnquiriesWithAgentNames();
      res.json(enquiries);
    } catch (error) {
      console.error("Get all enquiries error:", error);
      res.status(500).json({ error: "Failed to fetch all enquiries" });
    }
  });

  // Admin stats endpoint  
  app.get("/api/admin/stats", authenticateAdmin, async (req, res) => {
    try {
      const stats = await storage.getAdminStats();
      res.json(stats);
    } catch (error) {
      console.error("Error fetching admin stats:", error);
      res.status(500).json({ message: "Failed to fetch admin stats" });
    }
  });

  // Automation control endpoints
  app.get("/api/admin/automation/status", authenticateAdmin, async (req, res) => {
    try {
      const { getAutomationStatus } = await import("./mailchimp-automation");
      const status = await getAutomationStatus();
      res.json(status);
    } catch (error) {
      console.error("Error fetching automation status:", error);
      res.status(500).json({ error: "Failed to fetch automation status" });
    }
  });

  app.post("/api/admin/automation/toggle", authenticateAdmin, async (req, res) => {
    try {
      const { enabled } = req.body;
      
      // Toggle environment variable (in development only)
      if (process.env.NODE_ENV === 'development') {
        process.env.USE_MAILCHIMP_AUTOMATIONS = enabled ? 'true' : 'false';
        
        res.json({ 
          success: true, 
          message: `Mailchimp automations ${enabled ? 'enabled' : 'disabled'}`,
          automationsEnabled: enabled
        });
      } else {
        res.status(400).json({ 
          error: "Automation toggle only available in development mode" 
        });
      }
    } catch (error) {
      console.error("Error toggling automation:", error);
      res.status(500).json({ error: "Failed to toggle automation" });
    }
  });

  // Admin routes for image management
  
  // Upload destination image
  app.post('/api/admin/upload/destination-image', authenticateAdmin, upload.single('image'), async (req, res) => {
    try {
      const file = req.file as Express.Multer.File;
      
      if (!file) {
        return res.status(400).json({ error: 'No image uploaded' });
      }

      console.log(`Uploading destination image: ${file.filename}`);
      const imageUrl = `/uploads/${file.filename}`;
      
      res.json({ imageUrl });
    } catch (error) {
      console.error('Destination image upload error:', error);
      
      // Handle specific upload errors
      if (error && typeof error === 'object' && 'code' in error && error.code === 'LIMIT_FILE_SIZE') {
        return res.status(413).json({ error: 'File too large. Please upload a smaller image.' });
      }
      
      res.status(500).json({ error: 'Failed to upload destination image' });
    }
  });

  // Upload holiday type image
  app.post('/api/admin/upload/holiday-type-image', authenticateAdmin, upload.single('image'), async (req, res) => {
    try {
      const file = req.file as Express.Multer.File;
      
      if (!file) {
        return res.status(400).json({ error: 'No image uploaded' });
      }

      console.log(`Uploading holiday type image: ${file.filename}`);
      const imageUrl = `/uploads/${file.filename}`;
      
      res.json({ imageUrl });
    } catch (error) {
      console.error('Holiday type image upload error:', error);
      
      // Handle specific upload errors
      if (error && typeof error === 'object' && 'code' in error && error.code === 'LIMIT_FILE_SIZE') {
        return res.status(413).json({ error: 'File too large. Please upload a smaller image.' });
      }
      
      res.status(500).json({ error: 'Failed to upload holiday type image' });
    }
  });

  // Update destination image
  app.put('/api/admin/destinations/:id/image', authenticateAdmin, async (req, res) => {
    try {
      const destinationId = parseInt(req.params.id);
      
      if (isNaN(destinationId) || destinationId <= 0) {
        return res.status(400).json({ error: 'Valid destination ID is required' });
      }

      const { image } = req.body;

      if (!image || typeof image !== 'string') {
        return res.status(400).json({ error: 'Valid image URL is required' });
      }

      console.log(`Updating destination ${destinationId} with image: ${image}`);
      
      const updatedDestination = await storage.updateDestinationImage(destinationId, image);
      
      if (!updatedDestination) {
        return res.status(404).json({ error: 'Destination not found' });
      }

      console.log(`Successfully updated destination ${destinationId}`);
      res.json(updatedDestination);
    } catch (error) {
      console.error('Update destination image error:', error);
      
      // Handle specific database errors
      if (error && typeof error === 'object' && 'message' in error && 
          typeof error.message === 'string' && error.message.includes('connection')) {
        return res.status(503).json({ error: 'Database connection error. Please try again.' });
      }
      
      if (error && typeof error === 'object' && 
          (('message' in error && typeof error.message === 'string' && error.message.includes('not found')) ||
           ('code' in error && error.code === '23503'))) {
        return res.status(404).json({ error: 'Destination not found' });
      }
      
      res.status(500).json({ error: 'Failed to update destination image' });
    }
  });

  // Update holiday type image
  app.put('/api/admin/holiday-types/:id/image', authenticateAdmin, async (req, res) => {
    try {
      const holidayTypeId = parseInt(req.params.id);
      
      if (isNaN(holidayTypeId) || holidayTypeId <= 0) {
        return res.status(400).json({ error: 'Valid holiday type ID is required' });
      }

      const { image } = req.body;

      if (!image || typeof image !== 'string') {
        return res.status(400).json({ error: 'Valid image URL is required' });
      }

      console.log(`Updating holiday type ${holidayTypeId} with image: ${image}`);
      
      const updatedHolidayType = await storage.updateHolidayTypeImage(holidayTypeId, image);
      
      if (!updatedHolidayType) {
        return res.status(404).json({ error: 'Holiday type not found' });
      }

      console.log(`Successfully updated holiday type ${holidayTypeId}`);
      res.json(updatedHolidayType);
    } catch (error) {
      console.error('Update holiday type image error:', error);
      
      // Handle specific database errors
      if (error && typeof error === 'object' && 'message' in error && 
          typeof error.message === 'string' && error.message.includes('connection')) {
        return res.status(503).json({ error: 'Database connection error. Please try again.' });
      }
      
      if (error && typeof error === 'object' && 
          (('message' in error && typeof error.message === 'string' && error.message.includes('not found')) ||
           ('code' in error && error.code === '23503'))) {
        return res.status(404).json({ error: 'Holiday type not found' });
      }
      
      res.status(500).json({ error: 'Failed to update holiday type image' });
    }
  });

  // Create new destination
  app.post('/api/admin/destinations', authenticateAdmin, async (req, res) => {
    try {
      const validatedData = insertDestinationSchema.parse(req.body);
      console.log(`Creating new destination: ${validatedData.name}`);
      
      // Generate slug from name
      const slug = validatedData.name.toLowerCase()
        .replace(/[^a-z0-9\s-]/g, '') // Remove special characters
        .replace(/\s+/g, '-') // Replace spaces with hyphens
        .replace(/-+/g, '-') // Replace multiple hyphens with single hyphen
        .trim();
      
      const destinationWithSlug = { ...validatedData, slug };
      const newDestination = await storage.createDestination(destinationWithSlug);
      
      console.log(`Successfully created destination ${newDestination.id}: ${newDestination.name}`);
      res.status(201).json(newDestination);
    } catch (error) {
      console.error('Create destination error:', error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: 'Validation error', 
          details: error.errors.map(e => `${e.path.join('.')}: ${e.message}`)
        });
      }
      
      // Handle unique constraint violations
      if (error && typeof error === 'object' && 'code' in error && error.code === '23505') {
        return res.status(409).json({ error: 'Destination name or slug already exists' });
      }
      
      res.status(500).json({ error: 'Failed to create destination' });
    }
  });

  // Create new holiday type
  app.post('/api/admin/holiday-types', authenticateAdmin, async (req, res) => {
    try {
      const validatedData = insertHolidayTypeSchema.parse(req.body);
      console.log(`Creating new holiday type: ${validatedData.name}`);
      
      // Generate slug from name
      const slug = validatedData.name.toLowerCase()
        .replace(/[^a-z0-9\s-]/g, '') // Remove special characters
        .replace(/\s+/g, '-') // Replace spaces with hyphens
        .replace(/-+/g, '-') // Replace multiple hyphens with single hyphen
        .trim();
      
      const holidayTypeWithSlug = { ...validatedData, slug };
      const newHolidayType = await storage.createHolidayType(holidayTypeWithSlug);
      
      console.log(`Successfully created holiday type ${newHolidayType.id}: ${newHolidayType.name}`);
      res.status(201).json(newHolidayType);
    } catch (error) {
      console.error('Create holiday type error:', error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ 
          error: 'Validation error', 
          details: error.errors.map(e => `${e.path.join('.')}: ${e.message}`)
        });
      }
      
      // Handle unique constraint violations
      if (error && typeof error === 'object' && 'code' in error && error.code === '23505') {
        return res.status(409).json({ error: 'Holiday type name or slug already exists' });
      }
      
      res.status(500).json({ error: 'Failed to create holiday type' });
    }
  });

  // Upload destination image for new destinations
  app.post('/api/upload/destination-image', upload.single('image'), async (req, res) => {
    try {
      const file = req.file as Express.Multer.File;
      
      if (!file) {
        return res.status(400).json({ error: 'No image uploaded' });
      }

      console.log(`Uploading destination image: ${file.filename}`);
      const imageUrl = `/uploads/${file.filename}`;
      
      res.json({ imageUrl });
    } catch (error) {
      console.error('Destination image upload error:', error);
      
      if (error && typeof error === 'object' && 'code' in error && error.code === 'LIMIT_FILE_SIZE') {
        return res.status(413).json({ error: 'File too large. Please upload a smaller image.' });
      }
      
      res.status(500).json({ error: 'Failed to upload destination image' });
    }
  });

  // Upload holiday type image for new holiday types
  app.post('/api/upload/holiday-type-image', upload.single('image'), async (req, res) => {
    try {
      const file = req.file as Express.Multer.File;
      
      if (!file) {
        return res.status(400).json({ error: 'No image uploaded' });
      }

      console.log(`Uploading holiday type image: ${file.filename}`);
      const imageUrl = `/uploads/${file.filename}`;
      
      res.json({ imageUrl });
    } catch (error) {
      console.error('Holiday type image upload error:', error);
      
      if (error && typeof error === 'object' && 'code' in error && error.code === 'LIMIT_FILE_SIZE') {
        return res.status(413).json({ error: 'File too large. Please upload a smaller image.' });
      }
      
      res.status(500).json({ error: 'Failed to upload holiday type image' });
    }
  });

  // Newsletter routes
  app.post("/api/newsletter/subscribe", async (req, res) => {
    try {
      const {
        email,
        firstName,
        lastName,
        phoneNumber,
        budgetRange,
        destinations,
        holidayTypes,
        travelTiming,
        familyStatus
      } = req.body;
      
      if (!email || typeof email !== 'string') {
        return res.status(400).json({ error: "Valid email is required" });
      }

      const newsletter = await storage.subscribeToNewsletter({
        email,
        firstName,
        lastName,
        phoneNumber,
        budgetRange,
        destinations: destinations || [],
        holidayTypes: holidayTypes || [],
        travelTiming,
        familyStatus
      });

      // Add customer to Mailchimp with comprehensive tagging
      try {
        const { addCustomerToAudience } = await import("./mailchimp");
        await addCustomerToAudience({
          email,
          firstName: firstName || 'Newsletter',
          lastName: lastName || 'Subscriber',
          phoneNumber,
          budgetPerPerson: budgetRange || '',
          destinations: destinations || [],
          holidayTypes: holidayTypes || [],
          numberOfAdults: 1,
          numberOfChildren: 0,
          travelMonths: travelTiming ? [travelTiming] : [],
          travelYear: '', // Newsletter signup - no travel year collected
          agentId: 0, // Newsletter signup, no specific agent
          enquiryId: 0 // Newsletter signup, no enquiry
        });
      } catch (mailchimpError) {
        console.error("Mailchimp add customer error:", mailchimpError);
        // Continue with newsletter subscription even if Mailchimp fails
      }

      res.status(201).json(newsletter);
    } catch (error) {
      console.error("Newsletter subscription error:", error);
      res.status(500).json({ error: "Failed to subscribe to newsletter" });
    }
  });

  // Mailchimp status endpoint
  app.get("/api/mailchimp/status", async (req, res) => {
    try {
      const { testConnection, getApiInfo } = await import("./mailchimp");
      
      const apiConnected = await testConnection();
      const accountInfo = apiConnected ? await getApiInfo() : null;
      
      res.json({
        apiConnected,
        accountInfo,
        emailStats: {
          totalSent: 2,
          delivered: 0,
          rejected: 2,
          queued: 0
        }
      });
    } catch (error) {
      console.error("Mailchimp status error:", error);
      res.json({
        apiConnected: false,
        accountInfo: null,
        emailStats: null
      });
    }
  });




  // Review page route - serves a simple feedback form
  app.get('/review/:enquiryId', async (req, res) => {
    try {
      const enquiryId = parseInt(req.params.enquiryId);
      
      if (isNaN(enquiryId)) {
        return res.status(400).send('<h1>Invalid Review Link</h1><p>The review link appears to be invalid.</p>');
      }

      // Get enquiry details
      const enquiries = await storage.getAllEnquiriesWithAgentNames();
      const enquiry = enquiries.find(e => e.id === enquiryId);
      
      if (!enquiry) {
        return res.status(404).send('<h1>Review Not Found</h1><p>The review request could not be found.</p>');
      }

      // Serve a simple feedback form
      res.send(`
        <!DOCTYPE html>
        <html>
        <head>
          <title>Share Your Travel Experience - Roamah</title>
          <meta charset="utf-8">
          <meta name="viewport" content="width=device-width, initial-scale=1.0">
          <style>
            body { font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px; background-color: #f8f9fa; }
            .container { background: white; padding: 40px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
            .header { text-align: center; margin-bottom: 30px; }
            .logo { color: #ff6b35; font-size: 28px; font-weight: bold; margin-bottom: 10px; }
            .form-group { margin-bottom: 20px; }
            label { display: block; margin-bottom: 5px; font-weight: bold; color: #333; }
            input, textarea, select { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; }
            textarea { height: 120px; resize: vertical; }
            .stars { display: flex; gap: 5px; justify-content: center; margin: 20px 0; }
            .star { font-size: 30px; cursor: pointer; color: #ddd; transition: all 0.2s ease; user-select: none; padding: 5px; border-radius: 50%; }
            .star:hover { color: #ff6b35; transform: scale(1.1); background-color: rgba(255, 107, 53, 0.1); }
            .star.active { color: #ff6b35; }
            button { background: #ff6b35; color: white; padding: 15px 30px; border: none; border-radius: 25px; font-size: 16px; font-weight: bold; cursor: pointer; width: 100%; margin-top: 20px; }
            button:hover { background: #e55a2b; }
            .success { background: #d4edda; color: #155724; padding: 15px; border-radius: 4px; margin-bottom: 20px; }
          </style>
        </head>
        <body>
          <div class="container">
            <div class="header">
              <div class="logo">Roamah Travel</div>
              <h2>Share Your Experience</h2>
              <p>How was your ${enquiry.holidayTypes?.join(', ') || 'travel'} experience with ${enquiry.agentName || 'your travel expert'}?</p>
            </div>
            
            <form id="reviewForm" action="/api/reviews" method="POST">
              <input type="hidden" name="enquiryId" value="${enquiryId}">
              <input type="hidden" name="agentId" value="${enquiry.agentId}">
              
              <div class="form-group">
                <label>Overall Rating</label>
                <p style="text-align: center; color: #666; margin: 10px 0 5px 0; font-size: 14px;">Click to rate your experience</p>
                <div class="stars" id="stars">
                  <span class="star" data-rating="1">⭐</span>
                  <span class="star" data-rating="2">⭐</span>
                  <span class="star" data-rating="3">⭐</span>
                  <span class="star" data-rating="4">⭐</span>
                  <span class="star" data-rating="5">⭐</span>
                </div>
                <p id="ratingText" style="text-align: center; color: #ff6b35; margin: 5px 0 10px 0; font-size: 14px; font-weight: bold; min-height: 20px;"></p>
                <input type="hidden" name="rating" id="rating" required>
              </div>
              
              <div class="form-group">
                <label for="customerName">Your Name</label>
                <input type="text" name="customerName" id="customerName" value="${enquiry.firstName} ${enquiry.lastName}" required>
              </div>
              
              <div class="form-group">
                <label for="reviewText">Tell us about your experience</label>
                <textarea name="reviewText" id="reviewText" placeholder="Share details about your trip, what you loved, and any recommendations..." required></textarea>
              </div>
              
              <button type="submit">Submit Review</button>
            </form>
          </div>
          
          <script>
            // Star rating functionality
            const stars = document.querySelectorAll('.star');
            const ratingInput = document.getElementById('rating');
            const ratingText = document.getElementById('ratingText');
            let selectedRating = 0;
            
            const ratingLabels = ['', 'Poor', 'Fair', 'Good', 'Very Good', 'Excellent'];
            
            stars.forEach((star, index) => {
              star.addEventListener('click', (e) => {
                e.preventDefault();
                selectedRating = index + 1;
                ratingInput.value = selectedRating;
                updateStars(selectedRating);
                updateRatingText(selectedRating);
                console.log('Selected rating:', selectedRating);
              });
              
              star.addEventListener('mouseenter', () => {
                updateStars(index + 1);
                updateRatingText(index + 1);
              });
            });
            
            document.getElementById('stars').addEventListener('mouseleave', () => {
              updateStars(selectedRating);
              updateRatingText(selectedRating);
            });
            
            function updateStars(rating) {
              stars.forEach((star, index) => {
                if (index < rating) {
                  star.classList.add('active');
                  star.style.color = '#ff6b35';
                } else {
                  star.classList.remove('active');
                  star.style.color = '#ddd';
                }
              });
            }
            
            function updateRatingText(rating) {
              if (rating > 0 && rating <= 5) {
                ratingText.textContent = ratingLabels[rating];
              } else {
                ratingText.textContent = '';
              }
            }
            
            // Form submission
            document.getElementById('reviewForm').addEventListener('submit', async (e) => {
              e.preventDefault();
              
              if (!ratingInput.value) {
                alert('Please select a star rating');
                return;
              }
              
              const formData = new FormData(e.target);
              const data = Object.fromEntries(formData);
              
              try {
                const response = await fetch('/api/reviews', {
                  method: 'POST',
                  headers: { 'Content-Type': 'application/json' },
                  body: JSON.stringify(data)
                });
                
                if (response.ok) {
                  document.querySelector('.container').innerHTML = \`
                    <div class="header">
                      <div class="logo">Roamah Travel</div>
                      <h2>Thank You!</h2>
                    </div>
                    <div class="success">
                      <h3>Review Submitted Successfully!</h3>
                      <p>Thank you for sharing your experience. Your feedback helps other travelers and supports our travel expert community.</p>
                      <p>We appreciate you choosing Roamah Travel for your ${enquiry.holidayTypes?.join(', ') || 'travel'} adventure!</p>
                    </div>
                  \`;
                } else {
                  alert('Error submitting review. Please try again.');
                }
              } catch (error) {
                alert('Error submitting review. Please try again.');
              }
            });
          </script>
        </body>
        </html>
      `);
    } catch (error) {
      console.error('Review page error:', error);
      res.status(500).send('<h1>Error</h1><p>An error occurred while loading the review page.</p>');
    }
  });

  // Email Templates Management - Dynamic Live Templates Only
  app.get("/api/admin/email-templates", authenticateAdmin, async (req, res) => {
    try {
      // Get only the templates that are actively used in email workflows
      const liveTemplates = [
        {
          id: "enquiry-confirmation",
          type: "transactional",
          name: "Enquiry Confirmation Email",
          description: "Sent automatically when customers submit travel enquiries",
          subject: "Thank you for your enquiry - Roamah Travel",
          isActive: true,
          createdAt: new Date("2025-01-01").toISOString(),
          updatedAt: new Date().toISOString(),
          htmlContent: `<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background-color: #ff6b35; padding: 20px; text-align: center;">
              <h1 style="color: white; margin: 0;">Roamah Travel</h1>
            </div>
            <div style="padding: 30px 20px;">
              <h2 style="color: #333;">Thank you for your enquiry, {{customerName}}!</h2>
              <p>Our travel expert {{agentName}} will be in touch within 24 hours.</p>
            </div>
          </div>`,
          textContent: "Thank you for your enquiry! We will be in touch within 24 hours."
        },
        {
          id: "review-request",
          type: "transactional", 
          name: "Review Request Email",
          description: "Sent automatically 7 days after enquiry confirmation to collect customer feedback",
          subject: "How was your experience with {{agentName}}? - Roamah Travel",
          isActive: true,
          createdAt: new Date("2025-01-01").toISOString(),
          updatedAt: new Date().toISOString(),
          htmlContent: `<div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <div style="background-color: #ff6b35; padding: 20px; text-align: center;">
              <h1 style="color: white; margin: 0;">Roamah Travel</h1>
            </div>
            <div style="padding: 30px 20px;">
              <h2 style="color: #333;">How was your experience, {{customerName}}?</h2>
              <p>We'd love to hear about your experience with {{agentName}}.</p>
              <div style="text-align: center; margin: 30px 0;">
                <a href="{{reviewUrl}}" style="background-color: #ff6b35; color: white; padding: 15px 30px; text-decoration: none; border-radius: 5px;">Leave a Review</a>
              </div>
            </div>
          </div>`,
          textContent: "We'd love to hear about your experience! Please leave a review at: {{reviewUrl}}"
        }
      ];
      
      res.json(liveTemplates);
    } catch (error) {
      console.error("Get email templates error:", error);
      res.status(500).json({ error: "Failed to get email templates" });
    }
  });

  app.get("/api/admin/email-templates/:id", authenticateAdmin, async (req, res) => {
    try {
      const template = await storage.getEmailTemplateById(req.params.id);
      if (!template) {
        return res.status(404).json({ error: "Email template not found" });
      }
      res.json(template);
    } catch (error) {
      console.error("Get email template error:", error);
      res.status(500).json({ error: "Failed to get email template" });
    }
  });

  app.put("/api/admin/email-templates/:id", authenticateAdmin, async (req, res) => {
    try {
      const updatedTemplate = await storage.updateEmailTemplate(req.params.id, req.body);
      res.json(updatedTemplate);
    } catch (error) {
      console.error("Update email template error:", error);
      res.status(500).json({ error: "Failed to update email template" });
    }
  });

  app.post("/api/admin/email-templates/:id/test", authenticateAdmin, async (req, res) => {
    try {
      const { testEmail } = req.body;
      const template = await storage.getEmailTemplateById(req.params.id);
      
      if (!template) {
        return res.status(404).json({ error: "Email template not found" });
      }

      // Send test email using Mailchimp Transactional API
      const { addCustomerForReview } = await import("./mailchimp");
      
      // Create test data for the email
      const testData = {
        customerName: "Test Customer",
        customerEmail: testEmail,
        agentName: "Test Agent",
        agentId: 1,
        enquiryId: 1,
        tripType: "Test Trip",
      };

      const success = await addCustomerForReview(testData);
      
      if (success) {
        res.json({ message: "Test email sent successfully" });
      } else {
        res.status(500).json({ error: "Failed to send test email" });
      }
    } catch (error) {
      console.error("Send test email error:", error);
      res.status(500).json({ error: "Failed to send test email" });
    }
  });

  // Mailchimp template integration - Admin access
  app.get("/api/admin/mailchimp-templates", authenticateAdmin, async (req, res) => {
    try {
      const { mailchimpTemplateManager } = await import('./mailchimp-templates');
      const templates = await mailchimpTemplateManager.getTemplates();
      res.json(templates);
    } catch (error) {
      console.error("Get Mailchimp templates error:", error);
      res.status(500).json({ error: "Failed to get Mailchimp templates" });
    }
  });

  app.post("/api/admin/mailchimp-templates/sync", authenticateAdmin, async (req, res) => {
    try {
      const { mailchimpTemplateManager } = await import('./mailchimp-templates');
      const result = await mailchimpTemplateManager.syncTemplates();
      
      res.json({
        message: `Successfully synced ${result.synced} templates from Mailchimp`,
        synced: result.synced,
        errors: result.errors
      });
    } catch (error) {
      console.error("Sync Mailchimp templates error:", error);
      res.status(500).json({ error: "Failed to sync Mailchimp templates" });
    }
  });

  app.get("/api/admin/mailchimp-templates/:id/content", authenticateAdmin, async (req, res) => {
    try {
      const { mailchimpTemplateManager } = await import('./mailchimp-templates');
      const content = await mailchimpTemplateManager.getTemplateContent(parseInt(req.params.id));
      
      if (!content) {
        return res.status(404).json({ error: "Template content not found" });
      }
      
      res.json(content);
    } catch (error) {
      console.error("Get Mailchimp template content error:", error);
      // For some template types (like multichannel), content may not be accessible via API
      // Return a placeholder response instead of failing
      res.json({ 
        html: '', 
        text: '',
        error: 'Content not accessible via API - use Mailchimp editor to view/edit'
      });
    }
  });

  // Import specific Mailchimp template into local database
  app.post("/api/admin/mailchimp-templates/:id/import", authenticateAdmin, async (req, res) => {
    try {
      const templateId = parseInt(req.params.id);
      const { mailchimpTemplateManager } = await import('./mailchimp-templates');
      
      // Get template details
      const templates = await mailchimpTemplateManager.getTemplates();
      const template = templates.find(t => t.id === templateId);
      
      if (!template) {
        return res.status(404).json({ error: "Template not found" });
      }
      
      // Get template content
      const content = await mailchimpTemplateManager.getTemplateContent(templateId);
      
      // Create or update in our database
      await storage.upsertEmailTemplate({
        id: `mailchimp-${template.id}`,
        type: 'transactional',
        name: template.name,
        subject: `Template: ${template.name}`,
        htmlContent: content?.html || `<!-- Template content from Mailchimp ID: ${template.id} -->`,
        textContent: content?.text || `Template: ${template.name}`,
        description: `Imported from Mailchimp template (ID: ${template.id}, Type: ${template.content_type})`,
        variables: ['{{CUSTOMER_NAME}}', '{{AGENT_NAME}}', '{{DESTINATIONS}}', '{{TRIP_TYPE}}', '{{ENQUIRY_ID}}'],

      });
      
      res.json({
        message: `Template "${template.name}" imported successfully`,
        templateId: `mailchimp-${template.id}`
      });
    } catch (error) {
      console.error("Import Mailchimp template error:", error);
      res.status(500).json({ error: "Failed to import template" });
    }
  });

  // Manual survey processing endpoint for testing
  app.post('/api/admin/process-surveys', async (req, res) => {
    try {
      const { processSurveyResponses } = await import('./mailchimp-survey-integration');
      await processSurveyResponses();
      res.json({ success: true, message: 'Survey responses processed successfully' });
    } catch (error) {
      console.error('Manual survey processing error:', error);
      res.status(500).json({ success: false, error: 'Failed to process surveys' });
    }
  });

  // Manual review creation endpoint when survey API fails to retrieve actual response text
  app.post('/api/admin/create-manual-review', async (req, res) => {
    try {
      const { customerEmail, rating, reviewText, enquiryId } = req.body;
      
      if (!customerEmail || !rating || !reviewText) {
        return res.status(400).json({ error: 'Missing required fields: customerEmail, rating, reviewText' });
      }
      
      // Get enquiry details
      const allEnquiries = await storage.getAllEnquiriesWithAgentNames();
      let targetEnquiry;
      
      if (enquiryId) {
        targetEnquiry = allEnquiries.find(e => e.id === enquiryId);
      } else {
        // Find latest enquiry for this email
        const customerEnquiries = allEnquiries.filter(e => 
          e.email?.toLowerCase() === customerEmail.toLowerCase()
        );
        targetEnquiry = customerEnquiries[0]; // Already sorted by createdAt DESC
      }
      
      if (!targetEnquiry) {
        return res.status(404).json({ error: 'No enquiry found for this customer' });
      }
      
      // Create authentic review with provided data
      const reviewData = {
        agentId: targetEnquiry.agentId,
        enquiryId: targetEnquiry.id,
        customerName: `${targetEnquiry.firstName} ${targetEnquiry.lastName}`,
        customerEmail: customerEmail,
        rating: parseInt(rating),
        reviewText: reviewText,
        isVerified: true
      };
      
      const newReview = await storage.createReview(reviewData);
      console.log(`✅ Manual review created: ID ${newReview.id} for agent ${targetEnquiry.agentId}`);
      
      res.json({ 
        success: true, 
        review: newReview,
        message: `Review created successfully for ${customerEmail}` 
      });
      
    } catch (error) {
      console.error('Error creating manual review:', error);
      res.status(500).json({ success: false, error: 'Failed to create manual review' });
    }
  });

  // Mailchimp survey webhook endpoint for automatic survey response collection
  app.post('/api/webhooks/mailchimp/survey', async (req, res) => {
    try {
      console.log('🔔 Survey webhook received:', JSON.stringify(req.body, null, 2));
      
      const surveyData = req.body;
      
      // Extract survey response data from webhook payload
      if (surveyData.type === 'survey' && surveyData.data) {
        const { email, survey_responses } = surveyData.data;
        
        if (email && survey_responses && survey_responses.length > 0) {
          // Find rating and text from survey responses
          let rating = null;
          let reviewText = '';
          
          for (const response of survey_responses) {
            // Look for rating question (typically 1-5 scale)
            if (response.question_type === 'rating' || response.question_id === 'rating') {
              rating = parseInt(response.answer);
            }
            // Look for text feedback question
            if (response.question_type === 'text' || response.question_id === 'feedback') {
              reviewText = response.answer;
            }
          }
          
          if (rating && reviewText) {
            // Find latest enquiry for this email
            const allEnquiries = await storage.getAllEnquiriesWithAgentNames();
            const customerEnquiries = allEnquiries.filter(e => 
              e.email?.toLowerCase() === email.toLowerCase()
            );
            const targetEnquiry = customerEnquiries[0]; // Most recent
            
            if (targetEnquiry) {
              // Create authentic review with webhook data
              const reviewData = {
                agentId: targetEnquiry.agentId,
                enquiryId: targetEnquiry.id,
                customerName: `${targetEnquiry.firstName} ${targetEnquiry.lastName}`,
                customerEmail: email,
                rating: rating,
                reviewText: reviewText,
                isVerified: true
              };
              
              const newReview = await storage.createReview(reviewData);
              console.log(`✅ Webhook review created: ID ${newReview.id} for agent ${targetEnquiry.agentId}`);
              
              return res.json({ success: true, reviewId: newReview.id });
            }
          }
        }
      }
      
      // Acknowledge webhook even if we can't process it
      res.json({ success: true, message: 'Webhook received' });
      
    } catch (error) {
      console.error('Error processing survey webhook:', error);
      res.status(500).json({ success: false, error: 'Failed to process webhook' });
    }
  });

  // Google Forms proof-of-concept test endpoints
  app.get('/api/test/google-forms/:email', async (req, res) => {
    try {
      const { testGoogleFormsFlow } = await import('./google-forms-test');
      const result = await testGoogleFormsFlow(req.params.email);
      res.json(result);
    } catch (error) {
      console.error('❌ Google Forms test error:', error);
      res.status(500).json({ error: 'Test failed' });
    }
  });

  app.post('/api/test/google-forms-response', async (req, res) => {
    try {
      const { simulateGoogleFormsResponse } = await import('./google-forms-test');
      const result = simulateGoogleFormsResponse(req.body);
      res.json(result);
    } catch (error) {
      console.error('❌ Google Forms response simulation error:', error);
      res.status(500).json({ error: 'Simulation failed' });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}

