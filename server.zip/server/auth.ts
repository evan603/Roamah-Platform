import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import type { Request, Response, NextFunction } from 'express';

const JWT_SECRET = process.env.JWT_SECRET || 'your-secret-key-change-in-production';

export interface AuthenticatedAgent {
  id: number;
  email: string;
  firstName: string;
  lastName: string;
}

export async function hashPassword(password: string): Promise<string> {
  const saltRounds = 12;
  return bcrypt.hash(password, saltRounds);
}

export async function comparePassword(password: string, hashedPassword: string): Promise<boolean> {
  return bcrypt.compare(password, hashedPassword);
}

export function generateToken(agent: AuthenticatedAgent): string {
  return jwt.sign(
    { 
      id: agent.id, 
      email: agent.email,
      firstName: agent.firstName,
      lastName: agent.lastName
    },
    JWT_SECRET,
    { expiresIn: '7d' }
  );
}

export function verifyToken(token: string): AuthenticatedAgent | null {
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as AuthenticatedAgent;
    return decoded;
  } catch {
    return null;
  }
}

export function authenticateAgent(req: Request, res: Response, next: NextFunction) {
  const authHeader = req.headers.authorization;
  const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

  console.log("Auth header:", authHeader);
  console.log("Token:", token);

  if (!token) {
    console.log("No token provided");
    return res.status(401).json({ message: 'Access token required' });
  }

  const agent = verifyToken(token);
  console.log("Verified agent:", agent);
  
  if (!agent) {
    console.log("Invalid token verification");
    return res.status(401).json({ message: 'Invalid or expired token' });
  }

  // Add agent info to request object
  (req as any).agent = agent;
  next();
}