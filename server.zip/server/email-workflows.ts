import { storage } from './storage';
import { addCustomerForReview } from './mailchimp';

// Send formal confirmation email with structured template
export async function sendEnquiryConfirmation(enquiryId: number) {
  try {
    const enquiries = await storage.getAllEnquiriesWithAgentNames();
    const enquiry = enquiries.find(e => e.id === enquiryId);
    if (!enquiry) {
      console.error('Enquiry not found:', enquiryId);
      return false;
    }

    const agent = await storage.getAgentById(enquiry.agentId);
    if (!agent) {
      console.error('Agent not found:', enquiry.agentId);
      return false;
    }

    const confirmationHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Travel Enquiry Confirmation</title>
      </head>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">Roamah Travel</h1>
          <p style="color: white; margin: 10px 0 0 0; font-size: 16px;">Your Travel Enquiry Confirmation</p>
        </div>
        
        <div style="background: white; padding: 30px; border: 1px solid #ddd; border-top: none; border-radius: 0 0 10px 10px;">
          <h2 style="color: #ff6b35; margin-top: 0;">Hello ${enquiry.firstName}!</h2>
          
          <p>Thank you for your travel enquiry. We've received your request and ${agent.name} will be in touch with you shortly to discuss your travel plans.</p>
          
          <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #ff6b35; margin-top: 0;">Your Enquiry Details:</h3>
            <p><strong>Travel Expert:</strong> ${agent.name}</p>
            <p><strong>Destinations:</strong> ${enquiry.destinations.join(', ')}</p>
            <p><strong>Holiday Types:</strong> ${enquiry.holidayTypes.join(', ')}</p>
            <p><strong>Travel Party:</strong> ${enquiry.numberOfAdults} adults${enquiry.numberOfChildren > 0 ? `, ${enquiry.numberOfChildren} children` : ''}</p>
            <p><strong>Budget:</strong> ${enquiry.budgetPerPerson}</p>
            <p><strong>Travel Timing:</strong> ${enquiry.travelMonths?.join(', ')} ${enquiry.travelYear}</p>
            <p><strong>Callback Preference:</strong> ${enquiry.preferredCallbackTime}</p>
          </div>
          
          <div style="background: #e8f5e8; padding: 15px; border-radius: 8px; margin: 20px 0;">
            <p style="margin: 0;"><strong>What happens next?</strong></p>
            <p style="margin: 5px 0 0 0;">${agent.name} will contact you within 24 hours to discuss your requirements and start planning your perfect trip.</p>
          </div>
          
          <p>If you have any urgent questions, please don't hesitate to contact us.</p>
          
          <p style="margin-top: 30px;">Best regards,<br>The Roamah Travel Team</p>
        </div>
        
        <div style="text-align: center; padding: 20px; color: #666; font-size: 12px;">
          <p>© 2025 Roamah Travel. All rights reserved.</p>
        </div>
      </body>
      </html>
    `;

    // Send email directly via Mailchimp Transactional API with deliverability optimization
    const response = await fetch('https://mandrillapp.com/api/1.0/messages/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        key: process.env.MAILCHIMP_API_KEY,
        message: {
          subject: 'Your Travel Enquiry Confirmation - Roamah',
          from_email: "hello@roamah.com",
          from_name: "Roamah Travel", 
          to: [{
            email: enquiry.email,
            name: `${enquiry.firstName} ${enquiry.lastName}`,
            type: "to"
          }],
          html: confirmationHtml,
          text: `Hello ${enquiry.firstName}!

Thank you for your travel enquiry. We've received your request and ${agent.name} will be in touch with you shortly to discuss your travel plans.

Your Enquiry Details:
- Travel Expert: ${agent.name}
- Destinations: ${enquiry.destinations.join(', ')}
- Holiday Types: ${enquiry.holidayTypes.join(', ')}
- Travel Party: ${enquiry.numberOfAdults} adults${enquiry.numberOfChildren > 0 ? `, ${enquiry.numberOfChildren} children` : ''}
- Budget: ${enquiry.budgetPerPerson}
- Travel Timing: ${enquiry.travelMonths?.join(', ')} ${enquiry.travelYear}
- Callback Preference: ${enquiry.preferredCallbackTime}

What happens next?
${agent.name} will contact you within 24 hours to discuss your requirements and start planning your perfect trip.

If you have any urgent questions, please don't hesitate to contact us.

Best regards,
The Roamah Travel Team

© 2025 Roamah Travel. All rights reserved.`,
          important: false,
          track_opens: true,
          track_clicks: true,
          auto_text: false,
          auto_html: false,
          inline_css: true,
          preserve_recipients: false,
          view_content_link: false,
          tracking_domain: null,
          signing_domain: null,
          return_path_domain: null,
          merge: true,
          merge_language: "mailchimp",
          tags: ["enquiry-confirmation", "transactional"],
          subaccount: null,
          google_analytics_domains: [],
          google_analytics_campaign: "enquiry-confirmation",
          metadata: {
            enquiry_id: enquiryId.toString(),
            agent_id: enquiry.agentId.toString(),
            email_type: "confirmation"
          },
          recipient_metadata: [{
            rcpt: enquiry.email,
            values: {
              customer_name: `${enquiry.firstName} ${enquiry.lastName}`,
              agent_name: agent.name
            }
          }],
          headers: {
            "Reply-To": "hello@roamah.com",
            "X-MC-Important": "true",
            "X-MC-AutoText": "false",
            "List-Unsubscribe": `<mailto:unsubscribe@roamah.com?subject=unsubscribe>`,
            "X-Priority": "3",
            "X-MSMail-Priority": "Normal"
          }
        }
      })
    });

    const result = await response.json();
    console.log(`📧 Formal confirmation email sent to ${enquiry.email}`, result);
    return true;
  } catch (error) {
    console.error('Error sending enquiry confirmation:', error);
    return false;
  }
}

export async function sendReviewRequest(enquiryId: number) {
  try {
    const enquiries = await storage.getAllEnquiriesWithAgentNames();
    const enquiry = enquiries.find(e => e.id === enquiryId);
    if (!enquiry) {
      console.error('Enquiry not found for review request:', enquiryId);
      return false;
    }

    const agent = await storage.getAgentById(enquiry.agentId);
    if (!agent) {
      console.error('Agent not found for review request:', enquiry.agentId);
      return false;
    }

    const reviewHtml = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Share Your Travel Experience</title>
      </head>
      <body style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px;">
        <div style="background: linear-gradient(135deg, #ff6b35 0%, #f7931e 100%); padding: 30px; text-align: center; border-radius: 10px 10px 0 0;">
          <h1 style="color: white; margin: 0; font-size: 28px;">Roamah Travel</h1>
          <p style="color: white; margin: 10px 0 0 0; font-size: 16px;">How was your travel experience?</p>
        </div>
        
        <div style="background: white; padding: 30px; border: 1px solid #ddd; border-top: none; border-radius: 0 0 10px 10px;">
          <h2 style="color: #ff6b35; margin-top: 0;">Hello ${enquiry.firstName}!</h2>
          
          <p>We hope you had an amazing ${enquiry.holidayTypes?.join(', ').toLowerCase() || 'travel'} experience in ${enquiry.destinations?.join(', ') || 'your destination'} with ${agent.name}!</p>
          
          <p>Your feedback helps other travelers discover great travel experts and helps us improve our service. Would you mind taking a moment to share your experience?</p>
          
          <div style="text-align: center; margin: 30px 0;">
            <a href="https://roamah.replit.app/review/latest/*|URL:EMAIL|*" 
               style="background: #ff6b35; color: white; padding: 15px 30px; text-decoration: none; border-radius: 25px; font-size: 16px; font-weight: bold; display: inline-block;">
              Share Your Experience
            </a>
          </div>
          
          <div style="background: #f8f9fa; padding: 20px; border-radius: 8px; margin: 20px 0;">
            <h3 style="color: #ff6b35; margin-top: 0;">Your Trip Details:</h3>
            <p><strong>Travel Expert:</strong> ${agent.name}</p>
            <p><strong>Destinations:</strong> ${enquiry.destinations?.join(', ') || 'Your chosen destinations'}</p>
            <p><strong>Trip Type:</strong> ${enquiry.holidayTypes?.join(', ') || 'Travel Experience'}</p>
          </div>
          
          <p>Thank you for choosing Roamah Travel for your travel needs!</p>
          
          <p style="margin-top: 30px;">Best regards,<br>The Roamah Travel Team</p>
        </div>
        
        <div style="text-align: center; padding: 20px; color: #666; font-size: 12px;">
          <p>© 2025 Roamah Travel. All rights reserved.</p>
        </div>
      </body>
      </html>
    `;

    // Use the standard review request system
    const result = await addCustomerForReview({
      customerName: `${enquiry.firstName} ${enquiry.lastName}`,
      customerEmail: enquiry.email,
      agentName: agent.name || 'Travel Expert',
      agentId: enquiry.agentId,
      enquiryId: enquiryId,
      tripType: enquiry.holidayTypes?.join(', ') || 'Travel Experience',
      customTemplate: {
        subject: 'Share your travel experience with Roamah',
        html: reviewHtml,
        text: `Hello ${enquiry.firstName}!

We hope you had an amazing ${enquiry.holidayTypes?.join(', ').toLowerCase() || 'travel'} experience in ${enquiry.destinations?.join(', ') || 'your destination'} with ${agent.name}!

Your feedback helps other travelers discover great travel experts and helps us improve our service. Would you mind taking a moment to share your experience?

Please visit: https://roamah.replit.app/review/latest/*|EMAIL|*

Your Trip Details:
- Travel Expert: ${agent.name}
- Destinations: ${enquiry.destinations?.join(', ') || 'Your chosen destinations'}
- Trip Type: ${enquiry.holidayTypes?.join(', ') || 'Travel Experience'}

Thank you for choosing Roamah Travel for your travel needs!

Best regards,
The Roamah Travel Team

© 2025 Roamah Travel. All rights reserved.`
      }
    });

    console.log('Review request email sent:', result);
    return result;
  } catch (error) {
    console.error('Error sending review request:', error);
    return false;
  }
}

// Schedule review request with flexible timing
export async function scheduleReviewRequest(enquiryId: number, daysDelay: number = 1/1440): Promise<void> {
  try {
    // Convert days to milliseconds (supports fractional days for testing)
    const delayMs = daysDelay * 24 * 60 * 60 * 1000;
    
    setTimeout(async () => {
      console.log(`Triggering scheduled review request for enquiry ${enquiryId}`);
      const success = await sendReviewRequest(enquiryId);
      if (success) {
        console.log(`✅ Review request email sent successfully for enquiry ${enquiryId}`);
      } else {
        console.log(`❌ Failed to send review request email for enquiry ${enquiryId}`);
      }
    }, delayMs);
    
    const timeUnit = daysDelay >= 1 ? `${daysDelay} day(s)` : `${Math.round(daysDelay * 24 * 60)} minute(s)`;
    console.log(`Review request scheduled for enquiry ${enquiryId} in ${timeUnit}`);
  } catch (error) {
    console.error("Error scheduling review request:", error);
  }
}

// Get email automation statistics
export async function getEmailStats() {
  try {
    const allEnquiries = await storage.getAllEnquiriesWithAgentNames();
    const allReviews = await storage.getAllReviews();
    
    // Every enquiry gets a confirmation email automatically
    const confirmationEmailsSent = allEnquiries.length;
    
    // Count review emails sent (approximate based on reviews + some percentage of enquiries without reviews)
    // In practice, we would track this in the database, but for now we'll estimate
    const reviewEmailsSent = allReviews.length + Math.floor(allEnquiries.length * 0.3); // Estimate 30% additional review emails sent
    
    // Reviews received = total reviews in database
    const reviewsReceived = allReviews.length;
    
    // Total automated emails = confirmation emails + review emails
    const totalAutomatedEmails = confirmationEmailsSent + reviewEmailsSent;
    
    // Calculate conversion rate (reviews received / review emails sent)
    const conversionRate = reviewEmailsSent > 0 ? ((reviewsReceived / reviewEmailsSent) * 100).toFixed(1) : '0.0';
    
    return {
      totalEnquiries: allEnquiries.length,
      reviewEmailsSent,
      reviewsReceived,
      confirmationEmailsSent,
      totalAutomatedEmails,
      conversionRate,
    };
  } catch (error) {
    console.error("Error getting email stats:", error);
    return {
      totalEnquiries: 0,
      reviewEmailsSent: 0,
      reviewsReceived: 0,
      confirmationEmailsSent: 0,
      totalAutomatedEmails: 0,
      conversionRate: '0.0',
    };
  }
}