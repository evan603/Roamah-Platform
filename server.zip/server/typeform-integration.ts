import { storage } from './storage';

interface TypeformResponse {
  event_id: string;
  event_type: string;
  form_response: {
    form_id: string;
    token: string;
    landed_at: string;
    submitted_at: string;
    hidden: {
      enquiry_id?: string;
      email?: string;
    };
    definition: {
      id: string;
      title: string;
      fields: Array<{
        id: string;
        title: string;
        type: string;
        ref: string;
      }>;
    };
    answers: Array<{
      type: string;
      number?: number;
      text?: string;
      field: {
        id: string;
        type: string;
        ref: string;
      };
    }>;
  };
}

export async function processTypeformSurveyResponse(webhookData: TypeformResponse) {
  console.log('🔍 Processing Typeform survey response...');
  console.log('📋 Webhook data:', JSON.stringify(webhookData, null, 2));

  try {
    const { form_response } = webhookData;
    
    // Extract hidden fields (enquiry_id and email)
    const enquiryId = form_response.hidden?.enquiry_id;
    const customerEmail = form_response.hidden?.email;
    
    if (!enquiryId) {
      throw new Error('No enquiry_id found in survey response');
    }

    console.log(`📧 Processing survey for enquiry ID: ${enquiryId}, email: ${customerEmail}`);

    // Find the enquiry to get agent attribution
    const enquiry = await storage.getEnquiry(parseInt(enquiryId));
    if (!enquiry) {
      throw new Error(`Enquiry ${enquiryId} not found`);
    }

    console.log(`👤 Found enquiry for agent: ${enquiry.agentId}`);

    // Extract survey responses
    let rating: number | undefined;
    let reviewText: string | undefined;

    for (const answer of form_response.answers) {
      // Look for rating question (number type, typically 1-5)
      if (answer.type === 'number' && answer.number) {
        rating = answer.number;
        console.log(`⭐ Rating found: ${rating} stars`);
      }
      
      // Look for text feedback (text type)
      if (answer.type === 'text' && answer.text) {
        reviewText = answer.text;
        console.log(`💬 Feedback found: ${answer.text.substring(0, 100)}...`);
      }
    }

    if (!rating || !reviewText) {
      throw new Error('Missing rating or review text in survey response');
    }

    // Validate rating is between 1-5
    if (rating < 1 || rating > 5) {
      throw new Error(`Invalid rating: ${rating}. Must be between 1-5`);
    }

    // Create the review with authentic survey data
    const review = await storage.createReview({
      agentId: enquiry.agentId,
      enquiryId: parseInt(enquiryId),
      customerName: enquiry.firstName + ' ' + enquiry.lastName,
      customerEmail: enquiry.email,
      rating: rating,
      reviewText: reviewText,
      isVerified: true // Typeform responses are verified
    });

    console.log(`✅ Created authentic review with ID: ${review.id}`);

    // Add survey-completed tag to Mailchimp for customer segmentation
    try {
      const mailchimp = require('./mailchimp');
      await mailchimp.addTagToContact(enquiry.email, 'survey-completed');
      console.log(`🏷️ Added 'survey-completed' tag to ${enquiry.email}`);
    } catch (tagError) {
      console.log(`⚠️ Failed to add Mailchimp tag: ${tagError}`);
      // Don't fail the whole process if tagging fails
    }

    return {
      success: true,
      reviewId: review.id,
      rating: rating,
      message: 'Survey response processed successfully'
    };

  } catch (error) {
    console.error('❌ Error processing Typeform survey:', error);
    throw error;
  }
}

export function validateTypeformWebhook(signature: string, payload: string): boolean {
  // Typeform webhook signature validation
  // This would use your Typeform webhook secret for security
  // Implementation depends on Typeform's signature format
  console.log('🔐 Validating Typeform webhook signature...');
  return true; // Simplified for demo - implement proper validation
}