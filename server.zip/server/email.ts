// SendGrid removed - Roamah uses Mailchimp for all email services
let mailService: any = null;

console.log("Email service: Using Mailchimp for all email automation and transactional emails");

interface EmailParams {
  to: string;
  from: string;
  subject: string;
  text?: string;
  html?: string;
}

export async function sendEmail(params: EmailParams): Promise<boolean> {
  // Check if SendGrid is properly configured
  if (!mailService) {
    console.log('Email simulation mode - would send email to:', params.to);
    console.log('Subject:', params.subject);
    return true; // Simulate successful email sending for development
  }

  try {
    await mailService.send({
      to: params.to,
      from: params.from,
      subject: params.subject,
      text: params.text,
      html: params.html,
    });
    console.log(`✅ Email sent successfully to ${params.to}`);
    return true;
  } catch (error) {
    console.error('SendGrid email error:', error);
    console.log('⚠️ Falling back to email simulation mode');
    console.log('Email simulation - would send to:', params.to);
    console.log('Subject:', params.subject);
    return true; // Fall back to simulation for demonstration
  }
}

export async function sendVerificationEmail(email: string, token: string): Promise<boolean> {
  // Roamah uses Mailchimp for all email automation - verification handled via Mailchimp workflows
  console.log('Email verification handled via Mailchimp automation workflows');
  console.log(`Verification would be processed for: ${email}`);
  console.log(`Verification token: ${token}`);
  
  // In production, this would trigger a Mailchimp automation workflow
  // For now, simulate successful verification
  return true;
}

export function getVerificationTokenFromUrl(): string | null {
  if (typeof window === 'undefined') return null;
  const urlParams = new URLSearchParams(window.location.search);
  return urlParams.get('token');
}